#!/usr/bin/env python3
"""Deterministic scorer for identity-validated-single-request-v1 run."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path
from typing import Any

HARNESS_DIR = Path(__file__).resolve().parents[1]
STUDY_ROOT = HARNESS_DIR.parent
SCORING_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(HARNESS_DIR))

from single_request_protocol import (  # noqa: E402
    _parse_exactly_one_json,
    request_identity,
    validate_wrapper_response,
)

TOPICS = ["technology", "persona", "sports", "education"]
SAMPLE_PREFIXES = {
    "A bilingual technical": "technology",
    "A bilingual personal-introduction": "persona",
    "A bilingual sports": "sports",
    "A bilingual ordinary-language": "education",
}
DURATIONS_SECONDS = {
    "technology": 1020.335,
    "persona": 1139.751,
    "sports": 672.835,
    "education": 601.165,
}
EXPECTED_POSITIVES_PER_SAMPLE = {
    "technology": 3,
    "persona": 0,
    "sports": 10,
    "education": 0,
}
APPROVED_ARTIFACT_DIR = HARNESS_DIR / "run-artifacts-20260715-193000"
REQUESTS_48_PATH = STUDY_ROOT / "retrieval-0.3-sidecar-v3-external/ranking-requests-retrieval-0.3-sidecar-v3.jsonl"
REQUESTS_148_PATH = STUDY_ROOT / "tools/ranking-requests.jsonl"
EXPECTATION_PATH = HARNESS_DIR / "frozen-retrieval-0.3-expectation.json"
PRE_RUN_MANIFEST_PATH = HARNESS_DIR / "pre-run-manifest.json"
HASH_INVENTORY_PATH = HARNESS_DIR / "hash-inventory-run-20260715.json"
GROUND_TRUTH_PATH = STUDY_ROOT / "ground-truth-labels.json"
METRICS_PATH = STUDY_ROOT / "metrics.json"

FROZEN_REQUEST_JSONL_SHA = "836ecc3fdfc808640d0ed06c29f95fa62f044a00a1a1d80684de89f3c969ee27"
FROZEN_EXPECTATION_SHA = "a71b9a01ae802fed62c1bcf59dd052af8614df2e843735cc416d4f5364b8b65c"
FROZEN_HASH_INVENTORY_SHA = "66daf314d22fc389583ccfcc19e7ff8c034fbc190ac39b3116104f25c3eb5c99"
EXPECTED_AGGREGATE = {"selected": 13, "selected_true": 12, "selected_false": 1}

CALIBRATION_REPORTS = [
    STUDY_ROOT / "runs" / topic / "external-retrieval-0.3-sidecar-v3/experimental-report.json"
    for topic in TOPICS
]
ORIGINAL_REPORTS = [
    STUDY_ROOT / "runs" / topic / "rules-only" / "experimental-report.json" for topic in TOPICS
]
IMMUTABLE_FILES = [
    REQUESTS_48_PATH,
    REQUESTS_148_PATH,
    EXPECTATION_PATH,
    PRE_RUN_MANIFEST_PATH,
    HASH_INVENTORY_PATH,
    GROUND_TRUTH_PATH,
    METRICS_PATH,
    HARNESS_DIR / "post-run-record-20260715.json",
    *ORIGINAL_REPORTS,
    *CALIBRATION_REPORTS,
]
IMMUTABLE_TREES = [APPROVED_ARTIFACT_DIR]

JSONL_CANDIDATE_FIELDS = [
    "candidate_id",
    "canonical_term",
    "distance",
    "producer",
    "ratio_denominator",
    "ratio_numerator",
    "source_representation",
    "target_representation",
]


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_tree(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for child in sorted(path.rglob("*")):
        if child.is_file():
            out[str(child)] = sha256_path(child)
    return out


def hash_inventory() -> dict[str, Any]:
    inventory: dict[str, Any] = {"files": {}, "trees": {}}
    for path in IMMUTABLE_FILES:
        inventory["files"][str(path)] = sha256_path(path)
    for path in IMMUTABLE_TREES:
        inventory["trees"][str(path)] = sha256_tree(path)
    return inventory


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def normalize_producer(value: str) -> str:
    return "".join(ch for ch in value.casefold() if ch.isalnum())


def sample_of(request: dict[str, Any]) -> str:
    for prefix, sample in SAMPLE_PREFIXES.items():
        if request["session_description"].startswith(prefix):
            return sample
    raise ValueError(f"unknown session_description: {request['session_description'][:80]!r}")


def jsonl_candidate_view(candidate: dict[str, Any]) -> dict[str, Any]:
    return {
        "candidate_id": candidate["candidate_id"],
        "canonical_term": candidate["canonical_term"],
        "distance": candidate["distance"],
        "producer": normalize_producer(candidate["producer"]),
        "ratio_denominator": candidate["ratio_denominator"],
        "ratio_numerator": candidate["ratio_numerator"],
        "source_representation": candidate.get("source_representation"),
        "target_representation": candidate.get("target_representation"),
    }


def report_candidate_view(report_entry: dict[str, Any]) -> dict[str, Any]:
    return {
        "candidate_id": report_entry["candidate_id"],
        "canonical_term": report_entry["canonical_term"],
        "distance": report_entry["distance"],
        "producer": normalize_producer(report_entry["producer"]),
        "ratio_denominator": report_entry["ratio_denominator"],
        "ratio_numerator": report_entry["ratio_numerator"],
        "source_representation": report_entry.get("source_representation"),
        "target_representation": report_entry.get("target_representation"),
    }


def anchor_key(
    sample: str,
    anchor: dict[str, int],
    source_surface: str,
    canonical_term: str,
    producer: str,
) -> tuple[Any, ...]:
    return (
        sample,
        anchor["segment_position"],
        anchor["start_byte"],
        anchor["end_byte"],
        source_surface,
        canonical_term,
        normalize_producer(producer),
    )


def grouped_original_windows(report: dict[str, Any]) -> list[list[dict[str, Any]]]:
    windows: list[list[dict[str, Any]]] = []
    index_by_key: dict[tuple[Any, ...], int] = {}
    for candidate in report["reports"]:
        anchor = candidate["source_anchor"]
        window_key = (
            anchor["segment_position"],
            anchor["start_byte"],
            anchor["end_byte"],
            candidate["source_surface"],
        )
        if window_key not in index_by_key:
            index_by_key[window_key] = len(windows)
            windows.append([])
        windows[index_by_key[window_key]].append(candidate)
    return windows


def verify_original_reports_against_jsonl(requests_148: list[dict[str, Any]]) -> None:
    cursor = 0
    for topic, report_path in zip(TOPICS, ORIGINAL_REPORTS):
        report = load_json(report_path)
        windows = grouped_original_windows(report)
        topic_requests: list[dict[str, Any]] = []
        while cursor < len(requests_148) and sample_of(requests_148[cursor]) == topic:
            topic_requests.append(requests_148[cursor])
            cursor += 1
        if len(windows) != len(topic_requests):
            raise RuntimeError(
                f"original window count mismatch for {topic}: "
                f"{len(windows)} report windows vs {len(topic_requests)} request lines"
            )
        for window_index, (window_candidates, request) in enumerate(zip(windows, topic_requests)):
            if request["source_surface"] != window_candidates[0]["source_surface"]:
                raise RuntimeError(
                    f"source_surface mismatch for {topic} window {window_index}: "
                    f"{request['source_surface']!r} != {window_candidates[0]['source_surface']!r}"
                )
            if len(window_candidates) != len(request["candidates"]):
                raise RuntimeError(
                    f"candidate count mismatch for {topic} window {window_index}: "
                    f"{len(window_candidates)} report candidates vs {len(request['candidates'])} request candidates"
                )
            for report_candidate, request_candidate in zip(window_candidates, request["candidates"]):
                if report_candidate_view(report_candidate) != jsonl_candidate_view(request_candidate):
                    raise RuntimeError(
                        f"candidate field mismatch for {topic} window {window_index} "
                        f"request index {cursor - len(topic_requests) + window_index}: "
                        f"{report_candidate_view(report_candidate)} != {jsonl_candidate_view(request_candidate)}"
                    )


def verify_frozen_requests_and_expectation(
    requests_48: list[dict[str, Any]],
    request_bytes: bytes,
) -> list[str]:
    request_sha = hashlib.sha256(request_bytes).hexdigest()
    expectation = load_json(EXPECTATION_PATH)
    manifest = load_json(PRE_RUN_MANIFEST_PATH)

    if request_sha != expectation["request_sha256"]:
        raise RuntimeError("request JSONL SHA-256 does not match frozen expectation")
    if request_sha != FROZEN_REQUEST_JSONL_SHA:
        raise RuntimeError("request JSONL SHA-256 does not match approved frozen value")
    if sha256_path(EXPECTATION_PATH) != FROZEN_EXPECTATION_SHA:
        raise RuntimeError("expectation file SHA-256 does not match approved frozen value")
    if manifest["frozen_inputs"]["expectation_sha256"] != FROZEN_EXPECTATION_SHA:
        raise RuntimeError("expectation SHA-256 does not match pre-run manifest")
    if manifest["frozen_inputs"]["request_jsonl_sha256"] != FROZEN_REQUEST_JSONL_SHA:
        raise RuntimeError("request JSONL SHA-256 does not match pre-run manifest")

    recomputed = [request_identity(request) for request in requests_48]
    expected = expectation["expected_request_identities"]
    if recomputed != expected:
        raise RuntimeError("recomputed request identities do not match frozen expectation order")
    if len(recomputed) != expectation["expected_request_count"]:
        raise RuntimeError("request count does not match frozen expectation")
    return recomputed


def load_frozen_hash_inventory() -> dict[str, Any]:
    inventory_sha = sha256_path(HASH_INVENTORY_PATH)
    if inventory_sha != FROZEN_HASH_INVENTORY_SHA:
        raise RuntimeError(
            f"hash inventory SHA-256 mismatch: expected {FROZEN_HASH_INVENTORY_SHA}, got {inventory_sha}"
        )
    return load_json(HASH_INVENTORY_PATH)


def verify_run_summary(summary: dict[str, Any], expected_identities: list[str]) -> None:
    if summary.get("request_file_sha256") != FROZEN_REQUEST_JSONL_SHA:
        raise RuntimeError("run-summary request_file_sha256 does not match frozen request SHA")
    if summary.get("accepted_count") != 48:
        raise RuntimeError(f"run-summary accepted_count must be 48; got {summary.get('accepted_count')}")
    if summary.get("failure_count") != 0:
        raise RuntimeError(f"run-summary failure_count must be 0; got {summary.get('failure_count')}")
    outcomes = summary.get("outcomes", [])
    if len(outcomes) != 48:
        raise RuntimeError(f"run-summary must contain exactly 48 outcomes; got {len(outcomes)}")
    outcome_identities = [outcome["request_identity"] for outcome in outcomes]
    if outcome_identities != expected_identities:
        raise RuntimeError("run-summary outcome identities do not match frozen expected order")


def load_validated_responses(
    requests_48: list[dict[str, Any]],
    expected_identities: list[str],
    hash_inventory_doc: dict[str, Any],
) -> dict[str, dict[str, Any]]:
    summary = load_json(APPROVED_ARTIFACT_DIR / "run-summary.json")
    verify_run_summary(summary, expected_identities)

    by_identity = {request_identity(request): request for request in requests_48}
    if set(by_identity) != set(expected_identities):
        raise RuntimeError("request identity set does not match frozen expectation")

    raw_inventory = hash_inventory_doc["raw_responses"]
    metadata_inventory = hash_inventory_doc["metadata"]
    responses: dict[str, dict[str, Any]] = {}

    for outcome in summary["outcomes"]:
        if outcome["outcome"] != "accepted":
            raise RuntimeError(f"unexpected failed outcome in complete run: {outcome}")
        identity = outcome["request_identity"]
        raw_path = APPROVED_ARTIFACT_DIR / "raw-responses" / f"{identity}.stdout"
        metadata_path = APPROVED_ARTIFACT_DIR / "metadata" / f"{identity}.json"
        descriptive_raw = Path(outcome["raw_response_path"])
        if descriptive_raw.name != f"{identity}.stdout":
            raise RuntimeError(
                f"summary raw_response_path basename mismatch for {identity}: {descriptive_raw.name}"
            )

        if not raw_path.exists():
            raise RuntimeError(f"missing approved raw response file for {identity}")
        if not metadata_path.exists():
            raise RuntimeError(f"missing approved metadata file for {identity}")

        raw = raw_path.read_bytes()
        raw_sha = hashlib.sha256(raw).hexdigest()
        metadata = load_json(metadata_path)
        metadata_sha = sha256_path(metadata_path)

        if metadata.get("outcome") != "accepted":
            raise RuntimeError(f"metadata outcome must be accepted for {identity}")
        if metadata.get("failure") is not None:
            raise RuntimeError(f"metadata failure must be null for {identity}")
        if metadata.get("request_identity") != identity:
            raise RuntimeError(f"metadata request_identity mismatch for {identity}")
        if metadata.get("request_sha256") != identity:
            raise RuntimeError(f"metadata request_sha256 mismatch for {identity}")
        if metadata.get("raw_response_sha256") != raw_sha:
            raise RuntimeError(f"metadata raw_response_sha256 mismatch for {identity}")

        raw_key = f"{identity}.stdout"
        metadata_key = f"{identity}.json"
        if raw_inventory.get(raw_key) != raw_sha:
            raise RuntimeError(f"raw response SHA not present in frozen hash inventory for {identity}")
        if metadata_inventory.get(metadata_key) != metadata_sha:
            raise RuntimeError(f"metadata SHA not present in frozen hash inventory for {identity}")

        request = by_identity[identity]
        wrapper = _parse_exactly_one_json(raw)
        inner = validate_wrapper_response(request, wrapper)
        responses[identity] = {
            "request": request,
            "wrapper": wrapper,
            "inner": inner,
            "raw_sha256": raw_sha,
            "metadata_sha256": metadata_sha,
        }

    if len(responses) != 48:
        raise RuntimeError(f"expected 48 validated responses; got {len(responses)}")
    return responses


def build_label_map(requests_48: list[dict[str, Any]], requests_148: list[dict[str, Any]]) -> list[dict[str, Any]]:
    truth = load_json(GROUND_TRUTH_PATH)
    true_indices = set(truth["true_experimental_request_indices"])

    verify_original_reports_against_jsonl(requests_148)

    original_by_key: dict[tuple[Any, ...], list[tuple[int, dict[str, Any]]]] = {}
    request_cursor = 0
    for topic, report_path in zip(TOPICS, ORIGINAL_REPORTS):
        report = load_json(report_path)
        for window_candidates in grouped_original_windows(report):
            for candidate in window_candidates:
                key = anchor_key(
                    topic,
                    candidate["source_anchor"],
                    candidate["source_surface"],
                    candidate["canonical_term"],
                    candidate["producer"],
                )
                original_by_key.setdefault(key, []).append((request_cursor, candidate))
            request_cursor += 1

    requests_by_sample: dict[str, list[tuple[int, dict[str, Any]]]] = {topic: [] for topic in TOPICS}
    for position, request in enumerate(requests_48):
        requests_by_sample[sample_of(request)].append((position, request))

    label_map: list[dict[str, Any]] = []
    for topic, report_path in zip(TOPICS, CALIBRATION_REPORTS):
        calibration_reports = load_json(report_path)["reports"]
        flattened: list[tuple[int, dict[str, Any], dict[str, Any]]] = []
        for position, request in requests_by_sample[topic]:
            for candidate in request["candidates"]:
                flattened.append((position, request, candidate))
        if len(calibration_reports) != len(flattened):
            raise RuntimeError(
                f"calibration candidate count mismatch for {topic}: "
                f"{len(calibration_reports)} reports vs {len(flattened)} request candidates"
            )
        for calibration, (position, request, candidate) in zip(calibration_reports, flattened):
            if report_candidate_view(calibration) != jsonl_candidate_view(candidate):
                raise RuntimeError(
                    f"ordered calibration/request candidate mismatch in {topic} at request {position}: "
                    f"{report_candidate_view(calibration)} != {jsonl_candidate_view(candidate)}"
                )
            key = anchor_key(
                topic,
                calibration["source_anchor"],
                calibration["source_surface"],
                calibration["canonical_term"],
                calibration["producer"],
            )
            original_hits = original_by_key.get(key, [])
            if len(original_hits) != 1:
                raise RuntimeError(
                    f"expected exactly one original adjudication match for key {key}; got {len(original_hits)}"
                )
            original_index, original_candidate = original_hits[0]
            truth_label = "true" if original_index in true_indices else "false"
            identity = request_identity(request)
            label_map.append(
                {
                    "sample": topic,
                    "request_identity": identity,
                    "request_position": position,
                    "candidate_id": candidate["candidate_id"],
                    "source_surface": request["source_surface"],
                    "canonical_term": candidate["canonical_term"],
                    "producer": candidate["producer"],
                    "source_representation": candidate.get("source_representation"),
                    "target_representation": candidate.get("target_representation"),
                    "source_anchor": calibration["source_anchor"],
                    "original_request_index": original_index,
                    "adjudication_provenance": {
                        "ground_truth_file": str(GROUND_TRUTH_PATH),
                        "original_report_file": str(ORIGINAL_REPORTS[TOPICS.index(topic)]),
                        "calibration_report_file": str(report_path),
                        "join_method": "ordered_calibration_to_request_candidates_then_source_anchor_to_original_148",
                    },
                    "join_evidence": {
                        "anchor_key": list(key),
                        "original_candidate_id": original_candidate["candidate_id"],
                        "in_true_experimental_request_indices": original_index in true_indices,
                        "calibration_candidate_id": calibration["candidate_id"],
                    },
                    "truth_label": truth_label,
                }
            )

    if len(label_map) != 49:
        raise RuntimeError(f"label map must contain exactly 49 candidates; got {len(label_map)}")
    positives = [entry for entry in label_map if entry["truth_label"] == "true"]
    if len(positives) != 13:
        raise RuntimeError(f"label map must contain exactly 13 true candidates; got {len(positives)}")
    per_sample = Counter(entry["sample"] for entry in positives)
    for sample, expected in EXPECTED_POSITIVES_PER_SAMPLE.items():
        if per_sample[sample] != expected:
            raise RuntimeError(
                f"positive count mismatch for {sample}: expected {expected}, got {per_sample[sample]}"
            )
    truth_to_candidates: dict[int, list[str]] = {}
    for entry in positives:
        truth_to_candidates.setdefault(entry["original_request_index"], []).append(
            f"{entry['request_position']}:{entry['candidate_id']}"
        )
    for index, mapped in truth_to_candidates.items():
        if len(mapped) != 1:
            raise RuntimeError(
                f"truth index {index} mapped to multiple retrieval-0.3 candidates: {mapped}"
            )
    return label_map


def score(label_map: list[dict[str, Any]], responses: dict[str, dict[str, Any]]) -> dict[str, Any]:
    truth = load_json(GROUND_TRUTH_PATH)
    by_identity_candidate = {
        (entry["request_identity"], entry["candidate_id"]): entry for entry in label_map
    }
    by_identity: dict[str, list[dict[str, Any]]] = {}
    for entry in label_map:
        by_identity.setdefault(entry["request_identity"], []).append(entry)

    selected_rows: list[dict[str, Any]] = []
    selected_false_rows: list[dict[str, Any]] = []
    true_not_selected_rows: list[dict[str, Any]] = []
    assessment_counts: Counter[str] = Counter()
    reason_counts: Counter[str] = Counter()

    for identity, payload in responses.items():
        inner = payload["inner"]
        assessment_counts[inner["assessment"]] += 1
        for reason in inner["reason_codes"]:
            reason_counts[reason] += 1
        selected_id = inner["selected_candidate_id"]
        if selected_id is None:
            continue
        label_entry = by_identity_candidate[(identity, selected_id)]
        row = {
            "sample": label_entry["sample"],
            "request_position": label_entry["request_position"],
            "request_identity": identity,
            "candidate_id": selected_id,
            "source_surface": label_entry["source_surface"],
            "canonical_term": label_entry["canonical_term"],
            "producer": label_entry["producer"],
            "truth_label": label_entry["truth_label"],
            "assessment": inner["assessment"],
            "reason_codes": inner["reason_codes"],
            "display_explanation": inner["display_explanation"],
            "original_request_index": label_entry["original_request_index"],
        }
        selected_rows.append(row)
        if label_entry["truth_label"] == "false":
            selected_false_rows.append(row)

    for entry in label_map:
        if entry["truth_label"] != "true":
            continue
        identity = entry["request_identity"]
        inner = responses[identity]["inner"]
        if inner["selected_candidate_id"] != entry["candidate_id"]:
            true_not_selected_rows.append(
                {
                    "sample": entry["sample"],
                    "request_position": entry["request_position"],
                    "request_identity": identity,
                    "candidate_id": entry["candidate_id"],
                    "source_surface": entry["source_surface"],
                    "canonical_term": entry["canonical_term"],
                    "producer": entry["producer"],
                    "original_request_index": entry["original_request_index"],
                    "model_selected_candidate_id": inner["selected_candidate_id"],
                    "assessment": inner["assessment"],
                    "display_explanation": inner["display_explanation"],
                }
            )

    per_sample: dict[str, dict[str, Any]] = {}
    for sample in TOPICS:
        entries = [entry for entry in label_map if entry["sample"] == sample]
        windows = len({entry["request_identity"] for entry in entries})
        true_candidates = [entry for entry in entries if entry["truth_label"] == "true"]
        selected = [row for row in selected_rows if row["sample"] == sample]
        selected_true = [row for row in selected if row["truth_label"] == "true"]
        selected_false = [row for row in selected if row["truth_label"] == "false"]
        minutes = DURATIONS_SECONDS[sample] / 60.0
        per_sample[sample] = {
            "windows": windows,
            "candidates": len(entries),
            "retrieved_true_candidates": len(true_candidates),
            "selected": len(selected),
            "selected_true": len(selected_true),
            "selected_false": len(selected_false),
            "selected_precision": len(selected_true) / len(selected) if selected else None,
            "retention_of_retrieved_true": len(selected_true) / len(true_candidates) if true_candidates else None,
            "candidates_per_minute": len(entries) / minutes,
            "selected_per_minute": len(selected) / minutes,
        }

    total_candidates = len(label_map)
    total_windows = len(responses)
    retrieved_true = sum(1 for entry in label_map if entry["truth_label"] == "true")
    selected_total = len(selected_rows)
    selected_true_total = sum(1 for row in selected_rows if row["truth_label"] == "true")
    selected_false_total = len(selected_false_rows)
    actual_non_exact = sum(truth["actual_relevant_non_exact_corrections"].values())
    exact_relevant_total = sum(truth["exact_path_relevant"].values())
    duration_minutes = sum(DURATIONS_SECONDS.values()) / 60.0

    pinyin_entries = [
        entry
        for entry in label_map
        if normalize_producer(entry["producer"]) == normalize_producer("HanPinyinAuxiliary")
    ]
    if len(pinyin_entries) != 1:
        raise RuntimeError(f"expected exactly one pinyin candidate; got {len(pinyin_entries)}")
    pinyin_entry = pinyin_entries[0]
    pinyin_response = responses[pinyin_entry["request_identity"]]["inner"]

    multi_candidate_requests = [
        identity for identity, entries in by_identity.items() if len(entries) > 1
    ]
    if len(multi_candidate_requests) != 1:
        raise RuntimeError(
            f"expected exactly one multi-candidate window; got {len(multi_candidate_requests)}"
        )
    multi_identity = multi_candidate_requests[0]
    multi_response = responses[multi_identity]["inner"]
    multi_entries = by_identity[multi_identity]

    aggregate = {
        "windows": total_windows,
        "candidates": total_candidates,
        "retrieved_true_candidates": retrieved_true,
        "selected": selected_total,
        "selected_true": selected_true_total,
        "selected_false": selected_false_total,
        "selected_precision": selected_true_total / selected_total if selected_total else None,
        "retention_of_retrieved_true": selected_true_total / retrieved_true if retrieved_true else None,
        "non_exact_recall": selected_true_total / actual_non_exact if actual_non_exact else None,
        "combined_exact_plus_selected_recall": (exact_relevant_total + selected_true_total)
        / (exact_relevant_total + actual_non_exact),
        "candidates_per_minute": total_candidates / duration_minutes,
        "selected_per_minute": selected_total / duration_minutes,
        "assessment_counts": dict(assessment_counts),
        "reason_code_counts": dict(reason_counts),
        "multiple_candidate_windows": 1,
    }

    original_metrics = load_json(METRICS_PATH)["aggregate"]
    descriptive_comparison = {
        "label": "descriptive_protocol_confounded",
        "original_positional_batch": {
            "protocol": "positional_batch_148_requests",
            "selected": original_metrics["external_selected"],
            "selected_true": original_metrics["external_selected_true"],
            "selected_false": original_metrics["external_selected_false"],
            "selected_precision": original_metrics["external_selection_precision"],
            "retention_of_retrieved_true": original_metrics["external_recall_of_retrieved_true"],
            "non_exact_recall": original_metrics["external_recall_of_all_non_exact_corrections"],
            "combined_exact_plus_selected_recall": original_metrics["combined_exact_plus_external_recall"],
        },
        "current_identity_validated_run": {
            "protocol": "identity-validated-single-request-v1",
            "model": "gpt-5.6-sol",
            "reasoning_effort": "low",
            "retrieval_corpus": "retrieval-0.3-sidecar-v3",
            "windows": total_windows,
            "candidates": total_candidates,
            "selected": selected_total,
            "selected_true": selected_true_total,
            "selected_false": selected_false_total,
            "selected_precision": aggregate["selected_precision"],
            "retention_of_retrieved_true": aggregate["retention_of_retrieved_true"],
            "non_exact_recall": aggregate["non_exact_recall"],
            "combined_exact_plus_selected_recall": aggregate["combined_exact_plus_selected_recall"],
        },
        "note": "Differences confound protocol, corpus size, and execution shape; not an isolated model-quality estimate.",
    }

    return {
        "protocol": "identity-validated-single-request-v1",
        "status": "provisional_pending_chatgpt_review",
        "aggregate": aggregate,
        "per_sample": per_sample,
        "selected_candidates": selected_rows,
        "selected_false_positives": selected_false_rows,
        "retrieved_true_not_selected": true_not_selected_rows,
        "remaining_pinyin_candidate": {
            "sample": pinyin_entry["sample"],
            "request_position": pinyin_entry["request_position"],
            "candidate_id": pinyin_entry["candidate_id"],
            "source_surface": pinyin_entry["source_surface"],
            "canonical_term": pinyin_entry["canonical_term"],
            "truth_label": pinyin_entry["truth_label"],
            "selected": pinyin_response["selected_candidate_id"] == pinyin_entry["candidate_id"],
            "assessment": pinyin_response["assessment"],
            "display_explanation": pinyin_response["display_explanation"],
        },
        "multi_candidate_window": {
            "sample": multi_entries[0]["sample"],
            "request_position": multi_entries[0]["request_position"],
            "request_identity": multi_identity,
            "candidates": [
                {
                    "candidate_id": entry["candidate_id"],
                    "canonical_term": entry["canonical_term"],
                    "truth_label": entry["truth_label"],
                }
                for entry in multi_entries
            ],
            "selected_candidate_id": multi_response["selected_candidate_id"],
            "assessment": multi_response["assessment"],
            "reason_codes": multi_response["reason_codes"],
            "display_explanation": multi_response["display_explanation"],
        },
        "descriptive_comparison": descriptive_comparison,
        "frozen_reference_counts": {
            "actual_relevant_non_exact_corrections": truth["actual_relevant_non_exact_corrections"],
            "exact_path_relevant": truth["exact_path_relevant"],
            "true_experimental_request_indices": truth["true_experimental_request_indices"],
        },
        "frozen_hash_inventory_sha256": FROZEN_HASH_INVENTORY_SHA,
    }


def write_tsv(path: Path, rows: list[dict[str, Any]], columns: list[str]) -> None:
    lines = ["\t".join(columns)]
    for row in rows:
        lines.append(
            "\t".join(
                str(row.get(column, "")).replace("\t", " ").replace("\n", " ")
                for column in columns
            )
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_report(results: dict[str, Any]) -> str:
    agg = results["aggregate"]
    lines = [
        "# Provisional Scoring Report — identity-validated-single-request-v1",
        "",
        "Status: provisional pending ChatGPT review of scorer, label mapping, and results.",
        "",
        "## Aggregate",
        f"- windows: {agg['windows']}",
        f"- candidates: {agg['candidates']}",
        f"- retrieved true candidates: {agg['retrieved_true_candidates']}",
        f"- selected: {agg['selected']}",
        f"- selected true: {agg['selected_true']}",
        f"- selected false: {agg['selected_false']}",
        f"- selected precision: {agg['selected_precision']}",
        f"- retention of retrieved true: {agg['retention_of_retrieved_true']}",
        f"- non-exact recall (25 frozen corrections): {agg['non_exact_recall']}",
        f"- combined exact + selected recall: {agg['combined_exact_plus_selected_recall']}",
        f"- candidates per minute: {agg['candidates_per_minute']}",
        f"- selected per minute: {agg['selected_per_minute']}",
        "",
        "## Per sample",
    ]
    for sample, metrics in results["per_sample"].items():
        lines.append(
            f"- {sample}: windows={metrics['windows']} candidates={metrics['candidates']} "
            f"retrieved_true={metrics['retrieved_true_candidates']} selected={metrics['selected']} "
            f"selected_true={metrics['selected_true']} selected_false={metrics['selected_false']} "
            f"precision={metrics['selected_precision']} retention={metrics['retention_of_retrieved_true']}"
        )
    lines.extend(
        [
            "",
            "## Special outcomes",
            f"- remaining pinyin candidate selected: {results['remaining_pinyin_candidate']['selected']}",
            f"- multi-candidate window assessment: {results['multi_candidate_window']['assessment']}",
            f"- multi-candidate window selected: {results['multi_candidate_window']['selected_candidate_id']}",
            "",
            "## Descriptive comparison",
            results["descriptive_comparison"]["note"],
        ]
    )
    return "\n".join(lines) + "\n"


def assert_expected_aggregate(results: dict[str, Any]) -> None:
    aggregate = results["aggregate"]
    for key, expected in EXPECTED_AGGREGATE.items():
        actual = aggregate[key]
        if actual != expected:
            raise RuntimeError(
                f"hardened scorer aggregate mismatch for {key}: expected {expected}, got {actual}"
            )


def main() -> None:
    log_lines: list[str] = []
    hashes_before = hash_inventory()
    (SCORING_DIR / "immutable-input-hashes-before.json").write_text(
        json.dumps(hashes_before, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    request_bytes = REQUESTS_48_PATH.read_bytes()
    requests_48 = [
        json.loads(line)
        for line in request_bytes.decode("utf-8").splitlines()
        if line.strip()
    ]
    requests_148 = [
        json.loads(line)
        for line in REQUESTS_148_PATH.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    expected_identities = verify_frozen_requests_and_expectation(requests_48, request_bytes)
    hash_inventory_doc = load_frozen_hash_inventory()

    label_map = build_label_map(requests_48, requests_148)
    (SCORING_DIR / "frozen-scoring-label-map.json").write_text(
        json.dumps(label_map, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    responses = load_validated_responses(requests_48, expected_identities, hash_inventory_doc)
    results = score(label_map, responses)
    assert_expected_aggregate(results)
    results["label_map_sha256"] = sha256_path(SCORING_DIR / "frozen-scoring-label-map.json")
    results["label_map_candidate_count"] = len(label_map)
    results["label_map_positive_count"] = sum(1 for entry in label_map if entry["truth_label"] == "true")

    (SCORING_DIR / "scoring-results-retrieval-0.3-identity-v1.json").write_text(
        json.dumps(results, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (SCORING_DIR / "scoring-report-retrieval-0.3-identity-v1.md").write_text(
        write_report(results),
        encoding="utf-8",
    )

    selected_columns = [
        "sample",
        "request_position",
        "request_identity",
        "candidate_id",
        "source_surface",
        "canonical_term",
        "producer",
        "truth_label",
        "assessment",
        "reason_codes",
        "display_explanation",
        "original_request_index",
    ]
    write_tsv(SCORING_DIR / "selected-candidate-audit.tsv", results["selected_candidates"], selected_columns)
    write_tsv(
        SCORING_DIR / "selected-false-positive-audit.tsv",
        results["selected_false_positives"],
        selected_columns,
    )
    write_tsv(
        SCORING_DIR / "true-not-selected.tsv",
        results["retrieved_true_not_selected"],
        [
            "sample",
            "request_position",
            "request_identity",
            "candidate_id",
            "source_surface",
            "canonical_term",
            "producer",
            "original_request_index",
            "model_selected_candidate_id",
            "assessment",
            "display_explanation",
        ],
    )

    hashes_after = hash_inventory()
    unchanged = hashes_before == hashes_after
    hash_record = {
        "unchanged": unchanged,
        "frozen_hash_inventory_sha256": FROZEN_HASH_INVENTORY_SHA,
        "before": hashes_before,
        "after": hashes_after,
    }
    (SCORING_DIR / "immutable-input-hash-comparison.json").write_text(
        json.dumps(hash_record, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (SCORING_DIR / "immutable-input-hash-table.json").write_text(
        json.dumps(hashes_before, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    if not unchanged:
        raise RuntimeError("immutable inputs changed during scoring")

    repo = Path("/Users/Ezra4/Coding/Repo/vox-proof")
    status = subprocess.run(["git", "-C", str(repo), "status", "--short"], capture_output=True, text=True)
    head = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"], capture_output=True, text=True)
    diff = subprocess.run(["git", "-C", str(repo), "diff", "--stat"], capture_output=True, text=True)
    repository_status = {
        "head": head.stdout.strip(),
        "diff_stat": diff.stdout.strip() or "(empty)",
        "status_short": [line for line in status.stdout.splitlines() if line.strip()],
        "files_modified": bool(diff.stdout.strip()),
        "commit_created": False,
        "push_performed": False,
    }
    (SCORING_DIR / "repository-status.json").write_text(
        json.dumps(repository_status, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    log_lines.extend(
        [
            "command: python3 score_identity_validated_run.py",
            f"label_map_candidates: {len(label_map)}",
            f"label_map_positives: {results['label_map_positive_count']}",
            f"selected: {results['aggregate']['selected']}",
            f"selected_true: {results['aggregate']['selected_true']}",
            f"selected_false: {results['aggregate']['selected_false']}",
            f"immutable_inputs_unchanged: {unchanged}",
            f"frozen_hash_inventory_sha256: {FROZEN_HASH_INVENTORY_SHA}",
            f"repository_head: {repository_status['head']}",
        ]
    )
    (SCORING_DIR / "scoring-run-log.txt").write_text("\n".join(log_lines) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {
                "status": "ok",
                "selected": results["aggregate"]["selected"],
                "selected_true": results["aggregate"]["selected_true"],
                "selected_false": results["aggregate"]["selected_false"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
