#!/usr/bin/env python3
"""Deterministic scorer for identity-validated-single-request-v1 run."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any

HARNESS_DIR = Path(__file__).resolve().parents[1]
STUDY_ROOT = HARNESS_DIR.parent
SCORING_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(HARNESS_DIR))

from single_request_protocol import (  # noqa: E402
    _parse_exactly_one_json,
    request_identity,
    validate_wrapper_response,
)

TOPICS = ["technology", "persona", "sports", "education"]
SAMPLE_PREFIXES = {
    "A bilingual technical": "technology",
    "A bilingual personal-introduction": "persona",
    "A bilingual sports": "sports",
    "A bilingual ordinary-language": "education",
}
DURATIONS_SECONDS = {
    "technology": 1020.335,
    "persona": 1139.751,
    "sports": 672.835,
    "education": 601.165,
}
EXPECTED_POSITIVES_PER_SAMPLE = {
    "technology": 3,
    "persona": 0,
    "sports": 10,
    "education": 0,
}
IMMUTABLE_PATHS = [
    STUDY_ROOT / "identity-validated-single-request-v1/run-artifacts-20260715-193000",
    STUDY_ROOT / "retrieval-0.3-sidecar-v3-external/ranking-requests-retrieval-0.3-sidecar-v3.jsonl",
    STUDY_ROOT / "identity-validated-single-request-v1/frozen-retrieval-0.3-expectation.json",
    STUDY_ROOT / "ground-truth-labels.json",
    STUDY_ROOT / "tools/ranking-requests.jsonl",
    STUDY_ROOT / "identity-validated-single-request-v1/pre-run-manifest.json",
    STUDY_ROOT / "identity-validated-single-request-v1/post-run-record-20260715.json",
]
CALIBRATION_REPORTS = [
    STUDY_ROOT / "runs" / topic / "external-retrieval-0.3-sidecar-v3/experimental-report.json"
    for topic in TOPICS
]
ORIGINAL_REPORTS = [
    STUDY_ROOT / "runs" / topic / "rules-only" / "experimental-report.json" for topic in TOPICS
]


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_tree(path: Path) -> dict[str, str]:
    if path.is_file():
        return {str(path): sha256_path(path)}
    out: dict[str, str] = {}
    for child in sorted(path.rglob("*")):
        if child.is_file():
            out[str(child)] = sha256_path(child)
    return out


def hash_inventory() -> dict[str, Any]:
    inventory: dict[str, Any] = {"files": {}, "trees": {}}
    for path in IMMUTABLE_PATHS + CALIBRATION_REPORTS:
        if path.is_dir():
            inventory["trees"][str(path)] = sha256_tree(path)
        else:
            inventory["files"][str(path)] = sha256_path(path)
    return inventory


def normalize_producer(value: str) -> str:
    return "".join(ch for ch in value.casefold() if ch.isalnum())


def sample_of(request: dict[str, Any]) -> str:
    for prefix, sample in SAMPLE_PREFIXES.items():
        if request["session_description"].startswith(prefix):
            return sample
    raise ValueError(f"unknown session_description: {request['session_description'][:80]!r}")


def anchor_key(
    sample: str,
    anchor: dict[str, int],
    source_surface: str,
    canonical_term: str,
    producer: str,
) -> tuple[Any, ...]:
    return (
        sample,
        anchor["segment_position"],
        anchor["start_byte"],
        anchor["end_byte"],
        source_surface,
        canonical_term,
        normalize_producer(producer),
    )


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def candidate_signature(candidate: dict[str, Any], source_surface: str) -> tuple[Any, ...]:
    return (
        source_surface,
        candidate["canonical_term"],
        normalize_producer(candidate["producer"]),
        candidate.get("source_representation"),
        candidate.get("target_representation"),
    )


def build_label_map() -> list[dict[str, Any]]:
    truth = load_json(STUDY_ROOT / "ground-truth-labels.json")
    true_indices = set(truth["true_experimental_request_indices"])

    original_by_key: dict[tuple[Any, ...], list[tuple[int, dict[str, Any]]]] = {}
    request_cursor = 0
    for topic, report_path in zip(TOPICS, ORIGINAL_REPORTS):
        report = load_json(report_path)
        grouped: dict[tuple[Any, ...], list[dict[str, Any]]] = {}
        for candidate in report["reports"]:
            anchor = candidate["source_anchor"]
            window_key = (
                anchor["segment_position"],
                anchor["start_byte"],
                anchor["end_byte"],
                candidate["source_surface"],
            )
            grouped.setdefault(window_key, []).append(candidate)
        for candidates in grouped.values():
            for candidate in candidates:
                key = anchor_key(
                    topic,
                    candidate["source_anchor"],
                    candidate["source_surface"],
                    candidate["canonical_term"],
                    candidate["producer"],
                )
                original_by_key.setdefault(key, []).append((request_cursor, candidate))
            request_cursor += 1

    requests = [
        json.loads(line)
        for line in (
            STUDY_ROOT / "retrieval-0.3-sidecar-v3-external/ranking-requests-retrieval-0.3-sidecar-v3.jsonl"
        ).read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    requests_by_sample: dict[str, list[tuple[int, dict[str, Any]]]] = {topic: [] for topic in TOPICS}
    for position, request in enumerate(requests):
        requests_by_sample[sample_of(request)].append((position, request))

    label_map: list[dict[str, Any]] = []
    for topic, report_path in zip(TOPICS, CALIBRATION_REPORTS):
        calibration_reports = load_json(report_path)["reports"]
        sample_requests = requests_by_sample[topic]
        flattened: list[tuple[int, dict[str, Any], dict[str, Any]]] = []
        for position, request in sample_requests:
            for candidate in request["candidates"]:
                flattened.append((position, request, candidate))
        if len(calibration_reports) != len(flattened):
            raise RuntimeError(
                f"calibration candidate count mismatch for {topic}: "
                f"{len(calibration_reports)} reports vs {len(flattened)} request candidates"
            )
        for calibration, (position, request, candidate) in zip(calibration_reports, flattened):
            expected = candidate_signature(
                {
                    "canonical_term": calibration["canonical_term"],
                    "producer": calibration["producer"],
                    "source_representation": calibration.get("source_representation"),
                    "target_representation": calibration.get("target_representation"),
                },
                calibration["source_surface"],
            )
            actual = candidate_signature(candidate, request["source_surface"])
            if expected != actual:
                raise RuntimeError(
                    f"ordered calibration/request mismatch in {topic} at request {position}: "
                    f"{expected} != {actual}"
                )
            key = anchor_key(
                topic,
                calibration["source_anchor"],
                calibration["source_surface"],
                calibration["canonical_term"],
                calibration["producer"],
            )
            original_hits = original_by_key.get(key, [])
            if len(original_hits) != 1:
                raise RuntimeError(
                    f"expected exactly one original adjudication match for key {key}; got {len(original_hits)}"
                )
            original_index, original_candidate = original_hits[0]
            truth_label = "true" if original_index in true_indices else "false"
            identity = request_identity(request)
            label_map.append(
                {
                    "sample": topic,
                    "request_identity": identity,
                    "request_position": position,
                    "candidate_id": candidate["candidate_id"],
                    "source_surface": request["source_surface"],
                    "canonical_term": candidate["canonical_term"],
                    "producer": candidate["producer"],
                    "source_representation": candidate.get("source_representation"),
                    "target_representation": candidate.get("target_representation"),
                    "source_anchor": calibration["source_anchor"],
                    "original_request_index": original_index,
                    "adjudication_provenance": {
                        "ground_truth_file": str(STUDY_ROOT / "ground-truth-labels.json"),
                        "original_report_file": str(ORIGINAL_REPORTS[TOPICS.index(topic)]),
                        "calibration_report_file": str(report_path),
                        "join_method": "ordered_calibration_to_request_candidates_then_source_anchor_to_original_148",
                    },
                    "join_evidence": {
                        "anchor_key": list(key),
                        "original_candidate_id": original_candidate["candidate_id"],
                        "in_true_experimental_request_indices": original_index in true_indices,
                        "calibration_candidate_id": calibration["candidate_id"],
                    },
                    "truth_label": truth_label,
                }
            )

    if len(label_map) != 49:
        raise RuntimeError(f"label map must contain exactly 49 candidates; got {len(label_map)}")
    positives = [entry for entry in label_map if entry["truth_label"] == "true"]
    if len(positives) != 13:
        raise RuntimeError(f"label map must contain exactly 13 true candidates; got {len(positives)}")
    per_sample = Counter(entry["sample"] for entry in positives)
    for sample, expected in EXPECTED_POSITIVES_PER_SAMPLE.items():
        if per_sample[sample] != expected:
            raise RuntimeError(
                f"positive count mismatch for {sample}: expected {expected}, got {per_sample[sample]}"
            )
    truth_to_candidates: dict[int, list[str]] = {}
    for entry in positives:
        truth_to_candidates.setdefault(entry["original_request_index"], []).append(
            f"{entry['request_position']}:{entry['candidate_id']}"
        )
    for index, mapped in truth_to_candidates.items():
        if len(mapped) != 1:
            raise RuntimeError(
                f"truth index {index} mapped to multiple retrieval-0.3 candidates: {mapped}"
            )
    return label_map


def load_validated_responses(requests: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    artifact_dir = STUDY_ROOT / "identity-validated-single-request-v1/run-artifacts-20260715-193000"
    summary = load_json(artifact_dir / "run-summary.json")
    if summary["accepted_count"] != 48 or summary["failure_count"] != 0:
        raise RuntimeError("run summary is not a complete accepted corpus")
    by_identity = {request_identity(request): request for request in requests}
    if set(by_identity) != set(summary["expected_request_identities"] if "expected_request_identities" in summary else by_identity):
        expectation = load_json(HARNESS_DIR / "frozen-retrieval-0.3-expectation.json")
        if set(by_identity) != set(expectation["expected_request_identities"]):
            raise RuntimeError("request identities do not match frozen expectation")

    responses: dict[str, dict[str, Any]] = {}
    seen: set[str] = set()
    for outcome in summary["outcomes"]:
        if outcome["outcome"] != "accepted":
            raise RuntimeError(f"unexpected failed outcome in complete run: {outcome}")
        identity = outcome["request_identity"]
        if identity in seen:
            raise RuntimeError(f"duplicate response identity: {identity}")
        seen.add(identity)
        request = by_identity[identity]
        raw = Path(outcome["raw_response_path"]).read_bytes()
        wrapper = _parse_exactly_one_json(raw)
        inner = validate_wrapper_response(request, wrapper)
        responses[identity] = {
            "request": request,
            "wrapper": wrapper,
            "inner": inner,
            "raw_sha256": hashlib.sha256(raw).hexdigest(),
        }
    if len(responses) != 48:
        raise RuntimeError(f"expected 48 validated responses; got {len(responses)}")
    return responses


def score(label_map: list[dict[str, Any]], responses: dict[str, dict[str, Any]]) -> dict[str, Any]:
    truth = load_json(STUDY_ROOT / "ground-truth-labels.json")
    by_identity_candidate = {
        (entry["request_identity"], entry["candidate_id"]): entry for entry in label_map
    }
    by_identity = {}
    for entry in label_map:
        by_identity.setdefault(entry["request_identity"], []).append(entry)

    selected_rows: list[dict[str, Any]] = []
    selected_false_rows: list[dict[str, Any]] = []
    true_not_selected_rows: list[dict[str, Any]] = []
    assessment_counts: Counter[str] = Counter()
    reason_counts: Counter[str] = Counter()

    for identity, payload in responses.items():
        inner = payload["inner"]
        assessment_counts[inner["assessment"]] += 1
        for reason in inner["reason_codes"]:
            reason_counts[reason] += 1
        selected_id = inner["selected_candidate_id"]
        if selected_id is None:
            continue
        label_entry = by_identity_candidate[(identity, selected_id)]
        row = {
            "sample": label_entry["sample"],
            "request_position": label_entry["request_position"],
            "request_identity": identity,
            "candidate_id": selected_id,
            "source_surface": label_entry["source_surface"],
            "canonical_term": label_entry["canonical_term"],
            "producer": label_entry["producer"],
            "truth_label": label_entry["truth_label"],
            "assessment": inner["assessment"],
            "reason_codes": inner["reason_codes"],
            "display_explanation": inner["display_explanation"],
            "original_request_index": label_entry["original_request_index"],
        }
        selected_rows.append(row)
        if label_entry["truth_label"] == "false":
            selected_false_rows.append(row)

    for entry in label_map:
        if entry["truth_label"] != "true":
            continue
        identity = entry["request_identity"]
        inner = responses[identity]["inner"]
        if inner["selected_candidate_id"] != entry["candidate_id"]:
            true_not_selected_rows.append(
                {
                    "sample": entry["sample"],
                    "request_position": entry["request_position"],
                    "request_identity": identity,
                    "candidate_id": entry["candidate_id"],
                    "source_surface": entry["source_surface"],
                    "canonical_term": entry["canonical_term"],
                    "producer": entry["producer"],
                    "original_request_index": entry["original_request_index"],
                    "model_selected_candidate_id": inner["selected_candidate_id"],
                    "assessment": inner["assessment"],
                    "display_explanation": inner["display_explanation"],
                }
            )

    per_sample: dict[str, dict[str, Any]] = {}
    for sample in TOPICS:
        entries = [entry for entry in label_map if entry["sample"] == sample]
        windows = len({entry["request_identity"] for entry in entries})
        true_candidates = [entry for entry in entries if entry["truth_label"] == "true"]
        selected = [row for row in selected_rows if row["sample"] == sample]
        selected_true = [row for row in selected if row["truth_label"] == "true"]
        selected_false = [row for row in selected if row["truth_label"] == "false"]
        minutes = DURATIONS_SECONDS[sample] / 60.0
        per_sample[sample] = {
            "windows": windows,
            "candidates": len(entries),
            "retrieved_true_candidates": len(true_candidates),
            "selected": len(selected),
            "selected_true": len(selected_true),
            "selected_false": len(selected_false),
            "selected_precision": len(selected_true) / len(selected) if selected else None,
            "retention_of_retrieved_true": len(selected_true) / len(true_candidates) if true_candidates else None,
            "candidates_per_minute": len(entries) / minutes,
            "selected_per_minute": len(selected) / minutes,
        }

    total_candidates = len(label_map)
    total_windows = len(responses)
    retrieved_true = sum(1 for entry in label_map if entry["truth_label"] == "true")
    selected_total = len(selected_rows)
    selected_true_total = sum(1 for row in selected_rows if row["truth_label"] == "true")
    selected_false_total = len(selected_false_rows)
    actual_non_exact = sum(truth["actual_relevant_non_exact_corrections"].values())
    exact_relevant_total = sum(truth["exact_path_relevant"].values())
    duration_minutes = sum(DURATIONS_SECONDS.values()) / 60.0

    pinyin_entries = [
        entry for entry in label_map if normalize_producer(entry["producer"]) == normalize_producer("HanPinyinAuxiliary")
    ]
    if len(pinyin_entries) != 1:
        raise RuntimeError(f"expected exactly one pinyin candidate; got {len(pinyin_entries)}")
    pinyin_entry = pinyin_entries[0]
    pinyin_response = responses[pinyin_entry["request_identity"]]["inner"]

    multi_candidate_requests = [
        identity
        for identity, entries in by_identity.items()
        if len(entries) > 1
    ]
    if len(multi_candidate_requests) != 1:
        raise RuntimeError(
            f"expected exactly one multi-candidate window; got {len(multi_candidate_requests)}"
        )
    multi_identity = multi_candidate_requests[0]
    multi_response = responses[multi_identity]["inner"]
    multi_entries = by_identity[multi_identity]

    aggregate = {
        "windows": total_windows,
        "candidates": total_candidates,
        "retrieved_true_candidates": retrieved_true,
        "selected": selected_total,
        "selected_true": selected_true_total,
        "selected_false": selected_false_total,
        "selected_precision": selected_true_total / selected_total if selected_total else None,
        "retention_of_retrieved_true": selected_true_total / retrieved_true if retrieved_true else None,
        "non_exact_recall": selected_true_total / actual_non_exact if actual_non_exact else None,
        "combined_exact_plus_selected_recall": (exact_relevant_total + selected_true_total)
        / (exact_relevant_total + actual_non_exact),
        "candidates_per_minute": total_candidates / duration_minutes,
        "selected_per_minute": selected_total / duration_minutes,
        "assessment_counts": dict(assessment_counts),
        "reason_code_counts": dict(reason_counts),
        "multiple_candidate_windows": 1,
    }

    original_metrics = load_json(STUDY_ROOT / "metrics.json")["aggregate"]
    descriptive_comparison = {
        "label": "descriptive_protocol_confounded",
        "original_positional_batch": {
            "protocol": "positional_batch_148_requests",
            "selected": original_metrics["external_selected"],
            "selected_true": original_metrics["external_selected_true"],
            "selected_false": original_metrics["external_selected_false"],
            "selected_precision": original_metrics["external_selection_precision"],
            "retention_of_retrieved_true": original_metrics["external_recall_of_retrieved_true"],
            "non_exact_recall": original_metrics["external_recall_of_all_non_exact_corrections"],
            "combined_exact_plus_selected_recall": original_metrics["combined_exact_plus_external_recall"],
        },
        "current_identity_validated_run": {
            "protocol": "identity-validated-single-request-v1",
            "model": "gpt-5.6-sol",
            "reasoning_effort": "low",
            "retrieval_corpus": "retrieval-0.3-sidecar-v3",
            "windows": total_windows,
            "candidates": total_candidates,
            "selected": selected_total,
            "selected_true": selected_true_total,
            "selected_false": selected_false_total,
            "selected_precision": aggregate["selected_precision"],
            "retention_of_retrieved_true": aggregate["retention_of_retrieved_true"],
            "non_exact_recall": aggregate["non_exact_recall"],
            "combined_exact_plus_selected_recall": aggregate["combined_exact_plus_selected_recall"],
        },
        "note": "Differences confound protocol, corpus size, and execution shape; not an isolated model-quality estimate.",
    }

    return {
        "protocol": "identity-validated-single-request-v1",
        "status": "provisional_pending_chatgpt_review",
        "aggregate": aggregate,
        "per_sample": per_sample,
        "selected_candidates": selected_rows,
        "selected_false_positives": selected_false_rows,
        "retrieved_true_not_selected": true_not_selected_rows,
        "remaining_pinyin_candidate": {
            "sample": pinyin_entry["sample"],
            "request_position": pinyin_entry["request_position"],
            "candidate_id": pinyin_entry["candidate_id"],
            "source_surface": pinyin_entry["source_surface"],
            "canonical_term": pinyin_entry["canonical_term"],
            "truth_label": pinyin_entry["truth_label"],
            "selected": pinyin_response["selected_candidate_id"] == pinyin_entry["candidate_id"],
            "assessment": pinyin_response["assessment"],
            "display_explanation": pinyin_response["display_explanation"],
        },
        "multi_candidate_window": {
            "sample": multi_entries[0]["sample"],
            "request_position": multi_entries[0]["request_position"],
            "request_identity": multi_identity,
            "candidates": [
                {
                    "candidate_id": entry["candidate_id"],
                    "canonical_term": entry["canonical_term"],
                    "truth_label": entry["truth_label"],
                }
                for entry in multi_entries
            ],
            "selected_candidate_id": multi_response["selected_candidate_id"],
            "assessment": multi_response["assessment"],
            "reason_codes": multi_response["reason_codes"],
            "display_explanation": multi_response["display_explanation"],
        },
        "descriptive_comparison": descriptive_comparison,
        "frozen_reference_counts": {
            "actual_relevant_non_exact_corrections": truth["actual_relevant_non_exact_corrections"],
            "exact_path_relevant": truth["exact_path_relevant"],
            "true_experimental_request_indices": truth["true_experimental_request_indices"],
        },
    }


def write_tsv(path: Path, rows: list[dict[str, Any]], columns: list[str]) -> None:
    lines = ["\t".join(columns)]
    for row in rows:
        lines.append(
            "\t".join(
                str(row.get(column, "")).replace("\t", " ").replace("\n", " ")
                for column in columns
            )
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_report(results: dict[str, Any]) -> str:
    agg = results["aggregate"]
    lines = [
        "# Provisional Scoring Report — identity-validated-single-request-v1",
        "",
        "Status: provisional pending ChatGPT review of scorer, label mapping, and results.",
        "",
        "## Aggregate",
        f"- windows: {agg['windows']}",
        f"- candidates: {agg['candidates']}",
        f"- retrieved true candidates: {agg['retrieved_true_candidates']}",
        f"- selected: {agg['selected']}",
        f"- selected true: {agg['selected_true']}",
        f"- selected false: {agg['selected_false']}",
        f"- selected precision: {agg['selected_precision']}",
        f"- retention of retrieved true: {agg['retention_of_retrieved_true']}",
        f"- non-exact recall (25 frozen corrections): {agg['non_exact_recall']}",
        f"- combined exact + selected recall: {agg['combined_exact_plus_selected_recall']}",
        f"- candidates per minute: {agg['candidates_per_minute']}",
        f"- selected per minute: {agg['selected_per_minute']}",
        "",
        "## Per sample",
    ]
    for sample, metrics in results["per_sample"].items():
        lines.append(
            f"- {sample}: windows={metrics['windows']} candidates={metrics['candidates']} "
            f"retrieved_true={metrics['retrieved_true_candidates']} selected={metrics['selected']} "
            f"selected_true={metrics['selected_true']} selected_false={metrics['selected_false']} "
            f"precision={metrics['selected_precision']} retention={metrics['retention_of_retrieved_true']}"
        )
    lines.extend(
        [
            "",
            "## Special outcomes",
            f"- remaining pinyin candidate selected: {results['remaining_pinyin_candidate']['selected']}",
            f"- multi-candidate window assessment: {results['multi_candidate_window']['assessment']}",
            f"- multi-candidate window selected: {results['multi_candidate_window']['selected_candidate_id']}",
            "",
            "## Descriptive comparison",
            results["descriptive_comparison"]["note"],
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    log_lines: list[str] = []
    hashes_before = hash_inventory()
    (SCORING_DIR / "immutable-input-hashes-before.json").write_text(
        json.dumps(hashes_before, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    label_map = build_label_map()
    (SCORING_DIR / "frozen-scoring-label-map.json").write_text(
        json.dumps(label_map, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    requests = [
        json.loads(line)
        for line in (
            STUDY_ROOT / "retrieval-0.3-sidecar-v3-external/ranking-requests-retrieval-0.3-sidecar-v3.jsonl"
        ).read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    responses = load_validated_responses(requests)
    results = score(label_map, responses)
    results["label_map_sha256"] = sha256_path(SCORING_DIR / "frozen-scoring-label-map.json")
    results["label_map_candidate_count"] = len(label_map)
    results["label_map_positive_count"] = sum(1 for entry in label_map if entry["truth_label"] == "true")

    (SCORING_DIR / "scoring-results-retrieval-0.3-identity-v1.json").write_text(
        json.dumps(results, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (SCORING_DIR / "scoring-report-retrieval-0.3-identity-v1.md").write_text(
        write_report(results),
        encoding="utf-8",
    )

    selected_columns = [
        "sample",
        "request_position",
        "request_identity",
        "candidate_id",
        "source_surface",
        "canonical_term",
        "producer",
        "truth_label",
        "assessment",
        "reason_codes",
        "display_explanation",
        "original_request_index",
    ]
    write_tsv(
        SCORING_DIR / "selected-candidate-audit.tsv",
        results["selected_candidates"],
        selected_columns,
    )
    write_tsv(
        SCORING_DIR / "selected-false-positive-audit.tsv",
        results["selected_false_positives"],
        selected_columns,
    )
    write_tsv(
        SCORING_DIR / "true-not-selected.tsv",
        results["retrieved_true_not_selected"],
        [
            "sample",
            "request_position",
            "request_identity",
            "candidate_id",
            "source_surface",
            "canonical_term",
            "producer",
            "original_request_index",
            "model_selected_candidate_id",
            "assessment",
            "display_explanation",
        ],
    )

    hashes_after = hash_inventory()
    unchanged = hashes_before == hashes_after
    hash_record = {
        "unchanged": unchanged,
        "before": hashes_before,
        "after": hashes_after,
    }
    (SCORING_DIR / "immutable-input-hash-comparison.json").write_text(
        json.dumps(hash_record, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    if not unchanged:
        raise RuntimeError("immutable inputs changed during scoring")

    repo = Path("/Users/Ezra4/Coding/Repo/vox-proof")
    status = subprocess.run(["git", "-C", str(repo), "status", "--short"], capture_output=True, text=True)
    head = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"], capture_output=True, text=True)
    diff = subprocess.run(["git", "-C", str(repo), "diff", "--stat"], capture_output=True, text=True)
    repository_status = {
        "head": head.stdout.strip(),
        "diff_stat": diff.stdout.strip() or "(empty)",
        "status_short": [line for line in status.stdout.splitlines() if line.strip()],
        "files_modified": bool(diff.stdout.strip()),
        "commit_created": False,
        "push_performed": False,
    }
    (SCORING_DIR / "repository-status.json").write_text(
        json.dumps(repository_status, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    log_lines.extend(
        [
            "command: python3 score_identity_validated_run.py",
            f"label_map_candidates: {len(label_map)}",
            f"label_map_positives: {results['label_map_positive_count']}",
            f"selected: {results['aggregate']['selected']}",
            f"selected_true: {results['aggregate']['selected_true']}",
            f"selected_false: {results['aggregate']['selected_false']}",
            f"immutable_inputs_unchanged: {unchanged}",
            f"repository_head: {repository_status['head']}",
        ]
    )
    (SCORING_DIR / "scoring-run-log.txt").write_text("\n".join(log_lines) + "\n", encoding="utf-8")
    print(json.dumps({"status": "ok", "selected_true": results["aggregate"]["selected_true"]}, indent=2))


if __name__ == "__main__":
    main()
