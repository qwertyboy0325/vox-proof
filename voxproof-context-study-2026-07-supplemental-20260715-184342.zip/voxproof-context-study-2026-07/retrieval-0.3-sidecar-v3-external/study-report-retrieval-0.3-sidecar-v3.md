# VoxProof retrieval 0.3 / sidecar v3 external-ranking rerun

Date: 2026-07-15  
Repository HEAD: `5286c1627e54852fc08f4766240ce7545269e982`  
Status: **external model-quality comparison invalid because the only completed batch response lost request alignment**

## Result

Deterministic retrieval passed every pre-ranking gate:

- 49 candidates in 48 windows.
- Producers: 36 Latin normalized, 12 Latin token-boundary, 1 Han pinyin.
- All 13 frozen true candidates remained.
- Candidate multiset matched the accepted calibrated retrieval result.
- Retrieval version, sidecar revision, and both active profiles matched the requested values.

The external batch did not yield a valid ranking result. Attempt 1 timed out at 120 seconds. Attempt 2 completed in 65.351 seconds, but from request index 18 its response content shifted forward by one request. Ten selected IDs were therefore not members of their requests. The strict replay adapter suppressed those invalid selections. Attempt 3 timed out at 120 seconds. No prompt, model, reasoning, sandbox, frozen input, or repository file was changed between attempts.

## Completed-batch diagnostic only

These numbers describe safe replay of the invalid completed batch. They are not a model-quality result:

| Metric | Original external result | Current safe-replay diagnostic |
|---|---:|---:|
| Retrieval windows | 148 | 48 |
| Candidates | 149 | 49 |
| Selected | 30 | 4 |
| Selected true | 12 | 3 |
| Selected false | 18 | 1 |
| Selected precision | 40.0% | 75.0% |
| Retained retrieved true | 12/13 | 3/13 |
| Non-exact recall | 48.0% | 12.0% |
| Exact + selected recall | 70.45% | 50.0% |
| Persona selected false | 12 | 1 |
| Education selected | 0 | 0 |
| Candidates/minute | 2.60 | 0.856 |
| Selected/minute | 0.524 | 0.070 |

The current column must not be interpreted as calibrated model performance. The safe adapter removed invalid cross-window selections after the model output lost alignment.

## Per-sample safe-replay diagnostic

| Sample | Candidates/windows | Retrieved true | Selected | TP | FP |
|---|---:|---:|---:|---:|---:|
| technology | 15/14 | 3 | 3 | 3 | 0 |
| persona | 5/5 | 0 | 1 | 0 | 1 |
| sports | 18/18 | 10 | 0 | 0 | 0 |
| education negative control | 11/11 | 0 | 0 | 0 | 0 |

Replay dispositions were 48 `succeeded`, 0 `fell_back_after_failure`, and 0 `not_run`. This reflects that the replay adapter returned schema-valid safe suppressions; it does not erase the upstream batch-alignment failure.

## Selected false positive

- `persona`, anchor segment 26 bytes 22..51: `information system management` -> `information systems management`; producer `latin_token_boundary`; assessment `strong`; explanation: “Information systems management is the standard major name and a one-character correction.”
- Taxonomy: frozen-ground-truth-negative domain-term morphology/context-overlap selection.

## Retrieved true candidates not selected after safe replay

- `so far` -> `soccer`
- `ten days` -> `tennis`
- `Bagminton` -> `badminton` (six occurrences)
- `brackminton` -> `badminton`
- `Tracy Magrady` -> `Tracy McGrady`

All ten are in the sports sample. Most were affected directly or semantically by the shifted batch response. The remaining pinyin candidate `所以嗯` -> `Duolingo` was not selected, but its response was also in the shifted region and is not a valid contextual judgment.

## Ordering

There was one multi-candidate window (`phone` -> `iPhone` or `Python`). Neither candidate is a frozen true candidate. Therefore no correctness-based model-ordering comparison was possible; the response-alignment failure independently invalidates ranking interpretation.

## Safety

- Frozen manifest file hashes: all matched.
- Reviewed SRT cue indices, timing, and text: unchanged for all four samples.
- Literal raw-to-reviewed bytes differ only because the existing serializer emits one final newline while the raw files contain two; this was accepted as semantic identity for this rerun.
- Decision logs contain no experimental selections.
- Manual-correction markers: 0 in every sample.
- Sidecar selections remained experiment-only.
- Final replay selected IDs were bounded candidate IDs.
- Raw model response contained 10 unbounded cross-window selected IDs; all were suppressed.
- No arbitrary replacement text was accepted or materialized.
- Replay calls used the original 5-second adapter timeout; batch attempts used the frozen strict output schema with the authorized 48-item cardinality and a 120-second direct-process timeout.
- Repository worktree remained clean; no commit or push occurred.

## Runtime anomalies

1. Attempt 1: timeout after 120 seconds; no response artifact; Codex logged two model-catalog refresh timeouts.
2. Attempt 2: completed in 65.351 seconds; response content shifted from request index 18; 10 invalid selected IDs.
3. Attempt 3: timeout after 120 seconds; no replacement response artifact.

The attempt-2 response is preserved for inspection. It must not be repaired by shifting rows after the fact because that would alter model output and undermine the frozen comparison.
