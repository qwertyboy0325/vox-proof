# FLEURS Calibration Evaluate Probe — Final Handoff

## Study Root

`/private/tmp/voxproof-fleurs-calibration-evaluate-e21be2e-20260717T064024Z`

## Classification and Limitations

**Classification:** Exploratory mechanism-level calibration correspondence probe only.

**Not claimed:**
- product validation
- ground truth or correctness adjudication
- precision/recall
- detector effectiveness
- v0.1 release claim
- audio listening or human correctness adjudication

**Scope:** Two deterministic `vox-proof evaluate` runs at repository HEAD `e21be2e8fb337f30c1fcff6be26eba499fbfab23` against the frozen FLEURS positive-control package, using a study-local canonical-only session-terms projection.

## Repository Preconditions (verified)

| Check | Result |
|-------|--------|
| HEAD | `e21be2e8fb337f30c1fcff6be26eba499fbfab23` |
| `main...origin/main` | `0 0` |
| Staged/modified tracked files | none |
| Research artifacts | 48 untracked before and after; paths/sizes/SHA-256 unchanged |
| Existing FLEURS/AMI study tree written | no |
| Repo-root ZIP/seal created | no |

## Authoritative Frozen Package Bindings

| Artifact | SHA-256 | Bytes |
|----------|---------|------:|
| `voxproof-fleurs-en-positive-control-24363d9-20260717-final.zip` | `d23bf1b0fc84b7276b98668de660639d500221e44ca30c22fdfd2c57250ee46b` | 9517058 |
| `package-seal-fleurs-en-positive-control-24363d9-20260717-final.json` | `05a84e53e859120727118117d9b8b979779d2f95d45b96b4146186b2c16f4164` | 3616 |

**ZIP listing:** 64 entries; path safety check passed (no absolute or `..` paths).

**Archive comment / entry manifest:**
- storage: ZIP archive comment
- manifest SHA-256: `c0395f00ea6f9ef58ca08c45fd48f573f3d2428818dc89a1438ad2754aa0108a` (matches seal)
- external relative path: `finalization/entry-manifest.json`

**Extracted to:** `source-package/` (read-only for probe inputs)

### Corrected transcript bindings (verified)

| Input | File SHA-256 | Transcript revision |
|-------|--------------|---------------------|
| `raw.srt` | `bb2bdc55b8b988b6d59ea7df2cbe7f276b733cef8da8de5380f12c8dce2b9f2e` | `rev:sha256-v1:f4fd816eee5e5e859d78ed143126b6737064d36c245d0dba18f74a577968ad14` |
| `reference-final.srt` | `f02546025e7404467ae53aec9b7a0a203ab886d382eb0785f7c62c762276c39a` | `rev:sha256-v1:2b9532648beaafe44ebc72c641e9aac3206258a4badf3454d523a9209b752641` |

**Frozen historical session terms:** `source-package/phase-a/frozen-session-terms.txt`
- SHA-256: `47302c50f7dd7a0e07f1a7f6d320094f7020f6ac3d41a4e92019894e7ab4e7e2`
- bytes: 152

**15-cue study binding:** package `finalization/handoff-summary.json` and `finalization/final-report.json` both record parsed cue count 15 and the corrected revision IDs above.

## Canonical-Only Terms Projection (Phase B)

**Study-local output:** `canonical-only-session-terms.txt`

**Deterministic rule:** For each frozen line `CANONICAL | alias:CANONICAL`, emit one line `CANONICAL`; preserve source order; remove only the self-referential alias suffix; invent no aliases, error forms, targets, or ordering changes.

| Before (frozen) | After (projected) |
|-----------------|-------------------|
| `Google Translate \| alias:Google Translate` | `Google Translate` |
| `Microsoft \| alias:Microsoft` | `Microsoft` |
| `MySpace \| alias:MySpace` | `MySpace` |
| `Yahoo \| alias:Yahoo` | `Yahoo` |
| `ASUS \| alias:ASUS` | `ASUS` |
| `Apple \| alias:Apple` | `Apple` |

| Hash | Value |
|------|-------|
| source terms SHA-256 | `47302c50f7dd7a0e07f1a7f6d320094f7020f6ac3d41a4e92019894e7ab4e7e2` |
| projected terms SHA-256 | `d64fec82ee19df990cb8e5f6736d3b6543638487f7019d972a8e9b9187dedc86` |
| projected session-terms identity | `session-terms:sha256-v1:1b9750bdcdd756a82618caaa40f0767563f8d7558b5dee648865c9a9174a57c5` |

Historical frozen provenance in `source-package/` was not rewritten.

## Build / Binary Binding (Phase C)

| Field | Value |
|-------|-------|
| command | `cargo build --locked --bin vox-proof` |
| repository HEAD | `e21be2e8fb337f30c1fcff6be26eba499fbfab23` |
| `CARGO_TARGET_DIR` | `/private/tmp/voxproof-fleurs-calibration-evaluate-e21be2e-20260717T064024Z/build/cargo-target` |
| binary path | `build/cargo-target/debug/vox-proof` |
| binary SHA-256 | `6e06589909bfe11858152ea6dfd433d1b79de11cdec86d7b0976e4aa048b1fc7` |
| binary bytes | 5118264 |

## Evaluate Runs (Phase D)

Inputs (identical for both runs):
- raw: `source-package/raw.srt`
- final: `source-package/reference-final.srt`
- terms: `canonical-only-session-terms.txt`
- stdin: not used

### Run 1

```
/private/tmp/voxproof-fleurs-calibration-evaluate-e21be2e-20260717T064024Z/build/cargo-target/debug/vox-proof evaluate \
  .../source-package/raw.srt \
  .../source-package/reference-final.srt \
  .../canonical-only-session-terms.txt \
  .../run1/evaluation-report.json
```

| Field | Value |
|-------|-------|
| exit code | 0 |
| stdout | `wrote calibration evaluation report: .../run1/evaluation-report.json\n` |
| stderr | empty |

### Run 2

Same command with destination `run2/evaluation-report.json`.

| Field | Value |
|-------|-------|
| exit code | 0 |
| stdout | `wrote calibration evaluation report: .../run2/evaluation-report.json\n` |
| stderr | empty |

**Determinism:** run1 and run2 reports are byte-identical.

| Report SHA-256 | Bytes |
|----------------|------:|
| `5c2d2d5b45447415e0e8b10e9b16e764f0dc68e69f889fa887591a14c2c55e15` | 46743 |

## Complete Report Summary Counts

From `run1/evaluation-report.json`:

| Count | Value |
|-------|------:|
| cue_count | 15 |
| unchanged_cue_count | 3 |
| changed_cue_count | 12 |
| local_edit_count | 41 |
| insertion_edit_count | 15 |
| deletion_edit_count | 10 |
| replacement_edit_count | 16 |
| review_case_count | 1 |
| candidate_on_unchanged_cue_count | 0 |
| candidate_changed_cue_no_overlap_count | 0 |
| candidate_edit_overlap_relation_count | 1 |
| candidate_with_edit_overlap_count | 1 |
| edit_with_candidate_overlap_count | 1 |
| exact_anchor_exact_alternative_relation_count | 0 |
| edit_without_candidate_overlap_count | 40 |
| multi_candidate_edit_count | 0 |
| multi_edit_candidate_count | 0 |
| ambiguous_overlap_component_count | 0 |
| mechanically_unclassified_edit_count | 40 |

Schema: `voxproof-calibration-correspondence-v0`  
Compatibility policy: `identical-cue-count-index-and-timing-v0`

## Detailed Candidate / Edit / Correspondence Facts

### Sole emitted review case (`local:0`)

| Field | Value |
|-------|-------|
| detector | `ascii-latin-phonetic-similarity @ 0.1.0` |
| detection kind | `phonetic_similarity` |
| cue | segment_position 1, cue_index 2 |
| matched surface | `ASIS` |
| candidate raw anchor (cue-local bytes) | 86..90 (length 4) |
| evidence observed_surface | `ASIS` |
| evidence target/canonical_owner | `ASUS` |
| edit_distance | 1 |
| ratio | 3/4 |
| ratio_permille | 750 |
| matched_key | `ASS` |
| alternative replacement_text | `ASUS` |
| edit_relation.state | `single_edit_overlap` |
| edit_relation.geometry | `candidate_contains_edit` |
| linked edit | `cue:1:edit:0` |

**Raw cue text (segment 1):** contains `... after ASIS was awarded in the 2007 Taiwan Sustainable Award ...`

**Reference-final cue text (segment 1):** contains `... after ASUS was awarded in the 2007 Taiwan Sustainable Award ...` (deterministic text localization only; no audio adjudication)

### Linked local edit (`cue:1:edit:0`)

| Field | Value |
|-------|-------|
| kind | replacement |
| raw bytes | 88..89 |
| raw text | `I` |
| final bytes | 88..89 |
| final text | `U` |
| source_anchor | present; resolves to `I` |
| overlapping_case_ids | `[local:0]` |

**Geometry observed:** candidate span 86..90 contains edit span 88..89 → `CandidateContainsEdit`, not `Exact`.

### Sole correspondence record

| Field | Value |
|-------|-------|
| correspondence_id | `case:0/cue:1:edit:0` |
| anchor_relation | `candidate_contains_edit` |
| alternative_index 0 replacement_text | `ASUS` |
| final_region_relation | `different` |
| exact_anchor_exact_alternative_indices | `[]` |

## Independent Verification (Phase E)

**Checker:** `verification/verify_evaluation_report.py` (study-local Python; outside repo)

**Results:** `verification/verification-results.json`
- check_count: 95
- all_pass: true

Verified at minimum:
1. JSON schema and compatibility policy
2. raw/final/session-term identity bindings
3. cue count 15 and skeleton facts from report records
4. all 41 local edits reconstruct final cue text (reverse raw-byte application)
5. all non-empty raw anchors resolve exactly
6. all 15 insertions have no SourceAnchor and no correspondence edge
7. single review case and phonetic evidence inventory consistent with report
8. correspondence relations and recomputed summary counts match detailed records
9. ASIS/ASUS phonetic facts and CandidateContainsEdit geometry match committed output
10. no synthesized effectiveness metrics
11. run1/run2 byte identity confirmed

## Anomalies

None blocking. Notes only:

- Projected canonical-only terms identity differs from frozen self-alias terms identity by design; probe intentionally uses native canonical-only representation at HEAD `e21be2e`.
- Binary SHA differs from packaged historical binary (`a8aa686a...` at repo `24363d9`) because this probe rebuilt at `e21be2e`; evaluate behavior is bound to the freshly built binary recorded above.
- Reference-final.srt is used as comparison-final input; no human adjudication of transcript correctness was performed.

## Repository and Artifact Preservation (Phase F)

| Check | Result |
|-------|--------|
| HEAD unchanged | `e21be2e8fb337f30c1fcff6be26eba499fbfab23` |
| main...origin/main | `0 0` |
| tracked modifications | none |
| 48 research artifacts unchanged | yes (`artifact-inventory-before.txt` == `artifact-inventory-after.txt`) |
| extracted source-package inputs unchanged | yes |
| existing FLEURS/AMI study tree written | no |

## Stop Point

Exploratory probe complete. Handoff written. No repository commit, push, package, or seal created.

**Next step:** ChatGPT review of this handoff and report hash `5c2d2d5b45447415e0e8b10e9b16e764f0dc68e69f889fa887591a14c2c55e15`.
