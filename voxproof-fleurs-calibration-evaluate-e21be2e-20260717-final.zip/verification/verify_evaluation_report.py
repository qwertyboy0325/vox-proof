#!/usr/bin/env python3
"""Independent study-local checker for voxproof calibration correspondence reports."""
import hashlib
import json
import struct
from pathlib import Path

DOMAIN = b"voxproof-session-terms-identity-v1"


def hash_len(h, n):
    h.update(struct.pack("<Q", n))


def hash_string(h, s):
    b = s.encode("utf-8")
    hash_len(h, len(b))
    h.update(b)


def session_terms_identity(entries):
    h = hashlib.sha256()
    h.update(DOMAIN)
    hash_len(h, len(entries))
    for canonical, aliases, errors in entries:
        hash_string(h, canonical)
        hash_len(h, len(aliases))
        for alias in aliases:
            hash_string(h, alias)
        hash_len(h, len(errors))
        for error in errors:
            hash_string(h, error)
    return "session-terms:sha256-v1:" + h.hexdigest()


def ranges_overlap(a0, a1, b0, b1):
    return a0 < b1 and b0 < a1


def geometry(cs, ce, es, ee):
    if cs == es and ce == ee:
        return "exact"
    if cs <= es and ce >= ee:
        return "candidate_contains_edit"
    if es <= cs and ee >= ce:
        return "edit_contains_candidate"
    if ranges_overlap(cs, ce, es, ee):
        return "partial_overlap"
    return "none"


def recompute_summary(report):
    rel = report["correspondences"]
    edits = report["local_edits"]
    cases = report["review_cases"]
    return {
        "candidate_edit_overlap_relation_count": len(rel),
        "exact_anchor_exact_alternative_relation_count": sum(
            len(c["exact_anchor_exact_alternative_indices"]) for c in rel
        ),
        "review_case_count": len(cases),
        "local_edit_count": len(edits),
        "insertion_edit_count": sum(1 for e in edits if e["kind"] == "insertion"),
        "deletion_edit_count": sum(1 for e in edits if e["kind"] == "deletion"),
        "replacement_edit_count": sum(1 for e in edits if e["kind"] == "replacement"),
    }


def verify(report_path, terms_path):
    report = json.loads(Path(report_path).read_text())
    terms_lines = [
        line for line in Path(terms_path).read_text().splitlines() if line.strip()
    ]
    entries = [(line, [], []) for line in terms_lines]
    checks = []

    def ok(name, cond, detail=""):
        checks.append({"name": name, "pass": bool(cond), "detail": detail})
        if not cond:
            raise AssertionError(f"{name}: {detail}")

    ok("schema", report["schema_revision"] == "voxproof-calibration-correspondence-v0")
    ok(
        "policy",
        report["compatibility_policy_id"]
        == "identical-cue-count-index-and-timing-v0",
    )
    ok("cue_count", report["summary"]["cue_count"] == 15)
    ok(
        "raw_rev",
        report["inputs"]["raw"]["revision_id"]
        == "rev:sha256-v1:f4fd816eee5e5e859d78ed143126b6737064d36c245d0dba18f74a577968ad14",
    )
    ok(
        "final_rev",
        report["inputs"]["comparison_final"]["revision_id"]
        == "rev:sha256-v1:2b9532648beaafe44ebc72c641e9aac3206258a4badf3454d523a9209b752641",
    )
    expected_id = session_terms_identity(entries)
    ok("session_terms_identity", report["inputs"]["session_terms"]["identity"] == expected_id, expected_id)
    ok(
        "analysis_session_terms",
        report["analysis_snapshot"]["session_terms_identity"] == expected_id,
    )
    ok("skeleton_count", len(report["cues"]) == 15)

    edits_by_cue = {}
    for edit in report["local_edits"]:
        segment_position = edit["segment_position"]
        edits_by_cue.setdefault(segment_position, []).append(edit)
        raw_text = report["cues"][segment_position]["raw_text"]
        if edit["kind"] == "insertion":
            ok(f"{edit['edit_id']}_insertion_no_anchor", edit["raw"]["source_anchor"] is None)
            ok(f"{edit['edit_id']}_insertion_no_cases", edit["overlapping_case_ids"] == [])
        else:
            anchor = edit["raw"]["source_anchor"]
            ok(
                f"{edit['edit_id']}_anchor_resolves",
                raw_text[anchor["start_byte"] : anchor["end_byte"]] == edit["raw"]["text"],
            )

    for segment_position, cue_edits in edits_by_cue.items():
        raw_text = report["cues"][segment_position]["raw_text"]
        final_text = report["cues"][segment_position]["final_text"]
        rebuilt = raw_text
        for edit in sorted(
            cue_edits, key=lambda e: (-e["raw"]["start_byte"], -e["ordinal_in_cue"])
        ):
            raw_side = edit["raw"]
            final_side = edit["final"]
            rebuilt = (
                rebuilt[: raw_side["start_byte"]]
                + final_side["text"]
                + rebuilt[raw_side["end_byte"] :]
            )
        ok(f"cue_{segment_position}_reconstruct", rebuilt == final_text)

    summary = report["summary"]
    relations = report["correspondences"]
    recomputed = recompute_summary(report)
    for key, value in recomputed.items():
        ok(f"summary_{key}", summary[key] == value, f"report={summary[key]} recomputed={value}")

    insertions = [edit for edit in report["local_edits"] if edit["kind"] == "insertion"]
    ok("insertions_no_anchor", all(edit["raw"]["source_anchor"] is None for edit in insertions))
    ok(
        "insertion_corr_empty",
        all(
            not any(corr["edit_id"] == edit["edit_id"] for corr in relations)
            for edit in insertions
        ),
    )

    cases = {case["case_id"]: case for case in report["review_cases"]}
    edits = {edit["edit_id"]: edit for edit in report["local_edits"]}
    for corr in relations:
        case = cases[corr["case_id"]]
        edit = edits[corr["edit_id"]]
        segment_position = case["candidate_key_components"]["source_anchor"]["segment_position"]
        raw_text = report["cues"][segment_position]["raw_text"]
        anchor = case["candidate_key_components"]["source_anchor"]
        ok(
            f"{corr['correspondence_id']}_matched",
            raw_text[anchor["start_byte"] : anchor["end_byte"]] == case["matched_text"],
        )
        raw_side = edit["raw"]
        geom = geometry(
            anchor["start_byte"],
            anchor["end_byte"],
            raw_side["start_byte"],
            raw_side["end_byte"],
        )
        ok(f"{corr['correspondence_id']}_geometry", corr["anchor_relation"] == geom, geom)
        ok(
            f"{corr['correspondence_id']}_relation_match",
            corr["anchor_relation"] == case["edit_relation"]["geometry"],
        )

    case = report["review_cases"][0]
    segment_position = case["candidate_key_components"]["source_anchor"]["segment_position"]
    raw_text = report["cues"][segment_position]["raw_text"]
    anchor = case["candidate_key_components"]["source_anchor"]
    ok(
        "asis_candidate_range",
        (anchor["start_byte"], anchor["end_byte"])
        == (raw_text.find("ASIS"), raw_text.find("ASIS") + 4),
    )
    edit = edits[case["edit_relation"]["edit_ids"][0]]
    ok("asis_edit_scalar", edit["raw"]["text"] == "I" and edit["final"]["text"] == "U")
    ok(
        "asis_edit_within_candidate",
        anchor["start_byte"]
        < edit["raw"]["start_byte"]
        < edit["raw"]["end_byte"]
        < anchor["end_byte"],
    )
    ok("asis_relation", case["edit_relation"]["geometry"] == "candidate_contains_edit")
    ok("asis_not_exact", all(corr["anchor_relation"] != "exact" for corr in relations))
    evidence = case["evidence"]["payload"]
    ok(
        "asis_phonetic",
        evidence["observed_surface"] == "ASIS"
        and evidence["canonical_owner"] == "ASUS"
        and evidence["edit_distance"] == 1
        and evidence["ratio_numerator"] == 3
        and evidence["ratio_denominator"] == 4
        and evidence["ratio_permille"] == 750
        and evidence["matched_key"] == "ASS",
    )
    ok("reference_final_contains_asus", "ASUS" in report["cues"][segment_position]["final_text"])
    return checks


if __name__ == "__main__":
    study = Path("/private/tmp/voxproof-fleurs-calibration-evaluate-e21be2e-20260717T064024Z")
    checks = verify(
        str(study / "run1/evaluation-report.json"),
        str(study / "canonical-only-session-terms.txt"),
    )
    out = {
        "check_count": len(checks),
        "all_pass": all(check["pass"] for check in checks),
        "checks": checks,
    }
    Path(study / "verification/verification-results.json").write_text(
        json.dumps(out, indent=2) + "\n"
    )
    print(json.dumps({"check_count": out["check_count"], "all_pass": out["all_pass"]}, indent=2))
