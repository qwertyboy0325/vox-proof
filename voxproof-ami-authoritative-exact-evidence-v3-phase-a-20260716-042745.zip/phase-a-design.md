# VoxProof Authoritative Exact-Evidence V3 Phase A Correction

## Executable envelope correction
This correction packages the complete Phase B implementation under
`phase-b/scripts/`, byte-locked in `phase-b/script-lock.json`. The lock is
generated only during Phase A packaging; Phase B preflight reads and verifies it
without mutation.

`VOXPROOF_V3_STUDY_ROOT` selects one approved/extracted study root, defaulting to
this correction tree. Every binary, state, transform, review, scoring, report,
and package path derives from that root. The isolated product binary is
`phase-b/cargo-target-isolated/debug/vox-proof`.

`phase_b_runner.py` is the sole Phase B command surface: `preflight`,
`build-binary`, `hypothesis`, `probe-candidates`, `reference`,
`validate-review-inputs`, `authoritative-review`, `score`,
`independent-verify`, and `package`.

The hypothesis stage durably crosses the target-content gate before opening ASR
XML. It strictly parses words/segments, resolves href ranges, validates tags,
IDs and timestamps, and writes SRT/cue/token ledgers. Reference access requires
and records the sealed candidate-inventory hash before opening manual XML.
Failure after gate crossing is terminal and preserves persistent artifacts.

Human ground truth, candidate labels, and decisions are jointly validated
against inventory/reference hashes and one designated reviewer attestation.
No decision is derived automatically from the reference.

Raw and reviewed streams are scored independently. The primary scorer writes
both operation paths and count decompositions; the independent verifier does
not import primary alignment code and reconstructs both paths directly.

Reviewed scoring uses frozen policy
`cue-local-edit-global-midpoint-merge-v1`: each reviewed cue is aligned to its
original normalized cue tokens; mapped edits retain original token sort keys,
insertions receive deterministic before/after anchor keys, and all resulting
tokens are merged by original midpoint, speaker, element ID, token subindex,
and insertion tie key. Identity review must exactly reproduce the frozen raw
global stream, including overlapping speakers. Independent verification
duplicates this projection.

Unsafe acceptance uses frozen definition
`selected-false-or-unsupported-or-incorrect-materialization-v1`; the value is
derived from classification, replacement support, boundary support, and
materialization correctness, never accepted as an unconstrained reviewer flag.

Phase A and Phase B package modes are explicit. The Phase B runner builds the
deterministically named Phase B ZIP/seal and verifies closure after sealing.

## Target
- meeting_id: `ES2004b`
- window: `[300.000, 900.000)`
- terms frozen: see `session-terms/session-terms.txt`

## Frozen Phase B planning estimates
These are conservative local planning ranges, not measured performance claims:
- preflight plus isolated locked build: 1–10 minutes;
- hypothesis and reference transforms combined: 1–10 minutes;
- automated candidate probe and authoritative reproduction/materialization: 1–5 minutes;
- designated human review: 10–30 minutes setup plus approximately 0.5–2 minutes per candidate; actual time depends on candidate count and judgment difficulty;
- scoring plus independent verification: 1–5 minutes;
- package construction and verification: 1–5 minutes.

Expected local machine time excluding human judgment is 4–35 minutes. Current
required download is `0` bytes because both exact-hash archives are already
present locally. If absent, the only planned download is `94,650,143` bytes:
`71,762,278` bytes for `ami_public_auto_1.5.1.zip` plus `22,887,865`
bytes for `ami_public_manual_1.6.2.zip`. No other download is planned.
External model/API cost is `$0`; no external model or API is authorized.

## Zero-candidate interpretation
A sealed zero-candidate inventory is a valid executable path. It is not evidence
that the detector is effective and is not evidence that the manual reference
contains no opportunities. Candidate precision is JSON `null` because its
denominator is zero. After human ground truth, candidate recall is `null` when
opportunity count is zero; otherwise recall is `0` and every opportunity is a
detector miss. False-positive burden is `0`.

The human decision list is empty, the reviewed SRT is byte-identical to the
input SRT, and unsafe edit count is zero. The raw and reviewed scoring streams
are identical, raw and reviewed WER are equal, and raw-to-reviewed WER delta is
`0`. The runner does not retry, invoke fallback, or reselect a meeting.

## Expected Phase B output allowlist
Only the following study outputs are expected. “No schema” means the byte
format/fields are frozen by the executable envelope but the artifact does not
carry a `schema_revision` field.

- `phase-b/binary-attestation.json` — `voxproof-ami-binary-attestation-v1`
- `phase-b/stage-state.json` — `voxproof-ami-stage-state-v2`
- `phase-b/build-primary/input.srt` — SRT, no schema
- `phase-b/build-primary/parsed/hypothesis_tokens.jsonl` — frozen hypothesis token-record JSONL, no schema
- `phase-b/build-primary/parsed/asr_cues.json` — frozen cue-ledger JSON, no schema
- `phase-b/build-primary/layer_manifest.json` — `voxproof-ami-hypothesis-layer-manifest-v1`
- `phase-b/probe/candidate-inventory.json` — `voxproof-ami-candidate-inventory-v1`
- `phase-b/probe/probe-cli-capture.json` — frozen CLI-capture object, no schema
- `phase-b/build-primary/parsed/reference_tokens.jsonl` — frozen reference token-record JSONL, no schema
- `phase-b/build-primary/scoring_tokens.json` — `voxproof-ami-scoring-tokens-v1`
- `phase-b/build-primary/reference-layer-manifest.json` — `voxproof-ami-reference-layer-manifest-v1`
- `phase-b/review/ground-truth.json` — `voxproof-ami-ground-truth-v2`
- `phase-b/review/candidate-labels.json` — `voxproof-ami-candidate-labels-v2`
- `phase-b/review/decision-inputs.json` — `voxproof-ami-decision-inputs-v2`
- `phase-b/review/review-input-validation.json` — `voxproof-ami-review-input-validation-v1`
- `phase-b/review/reviewed-output.srt` — SRT, no schema
- `phase-b/review/decision-log.txt` — text, no schema
- `phase-b/review/session-summary.txt` — text, no schema
- `phase-b/review/authoritative-review-binding.json` — `voxproof-ami-authoritative-review-binding-v1`
- `phase-b/review/cli-capture.json` — frozen CLI-capture object, no schema
- `phase-b/raw-alignment-operations.tsv` — frozen alignment-operation TSV, no schema
- `phase-b/reviewed-alignment-operations.tsv` — frozen alignment-operation TSV, no schema
- `phase-b/alignment-audit.json` — `voxproof-ami-alignment-audit-v1`
- `phase-b/metrics.json` — `voxproof-ami-study-metrics-v1`
- `phase-b/reports/independent-verifier-output.json` — frozen independent-verifier report, no schema
- `phase-b/reports/package-verification-output.json` — frozen package-verifier report, no schema
- `manifest.json` — `voxproof-ami-phase-a-package-manifest-v1`, with `mode=phase-b`
- `phase-b/package/voxproof-ami-authoritative-exact-evidence-v3-phase-b-final.zip` — ZIP container
- `phase-b/package/package-seal-v3-phase-b-final.json` — `voxproof-ami-phase-a-detached-seal-v1`
- `phase-b/failures/<UTC-stamp>-<stage>/failure-record.json` — `voxproof-ami-failure-record-v1`, only on stage failure
- `phase-b/failures/authoritative-review-<UTC-stamp>/failure-record.json` and forensic companions — `voxproof-ami-failure-record-v1`, only on authoritative-review failure

The isolated build directory
`phase-b/cargo-target-isolated/` is transient build material, not a study
result and not a package entry.

## Acceptance and fail-closed gates
Preflight requires the frozen repository HEAD, clean tracked state, Cargo lock,
source archive bytes/hashes, session terms, configuration, and exact script
lock. Every stage requires its predecessor exactly once. Before reading or
using data, downstream stages re-hash all applicable earlier artifacts and
compare them with immutable `stage_details`.

The candidate inventory is durably hashed before manual-reference access.
Human inputs require one reviewer identity, exact inventory/reference joins,
one-to-one opportunity mappings, frozen unsafe-label consistency, and complete
decision coverage. Authoritative execution must reproduce the inventory and
materialize outputs matching the binding. Scoring requires all human,
reference, inventory, and authoritative hashes unchanged. Independent
verification duplicates reviewed-stream projection, verifies operation
invariants/edit distance, recomputes every study metric, and rechecks all
joins. Packaging requires a passing independent report, exact manifest/seal
closure, safe unique paths, byte lengths and SHA-256 hashes.

Any mismatch after the target-content gate writes a persistent failure record,
sets terminal failure state, and forbids retry, fallback, stage rerun, or target
reselection. No later artifact may be accepted after such a failure.

## Chronology
See `phase-b-commands.md` for the authoritative runnable sequence.

## Preserved artifacts
- first V3 ZIP/seal unchanged: `voxproof-ami-authoritative-exact-evidence-v3-phase-a-20260716-031102.zip`
- c1 and exploratory v2 hashes recorded in `source-lock.json`

## Access boundary
ES2004b ASR/manual words/segments content remained unopened. Synthetic
auto/manual ZIPs with matching XML/member shape exercised the exact runner
chronology end to end for zero and nonzero paths.
