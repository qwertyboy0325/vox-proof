#!/usr/bin/env python3
"""Build and verify VoxProof authoritative exact-evidence V5 Phase A package."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
SCRIPTS = ROOT / "phase-b/scripts"
REPO = Path("/Users/Ezra4/Coding/Repo/vox-proof")
BASELINE_ZIP = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/v4-exact-evidence-phase-a/"
    "package/voxproof-ami-authoritative-exact-evidence-v4-phase-a-20260716-082828.zip"
)
BASELINE_SEAL_SHA256 = (
    "e6299ddc5122d4da23a75ebc3045bfd7e92ea10780cb886f375a829dd009ad49"
)
BASELINE_ZIP_SHA256 = (
    "8a3d1141a820859863c170b87cd2adce96d822ab4c49990bffa2a450296ccd7e"
)
V4_TERMINAL_ROOT = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/v4-exact-evidence-phase-a"
)
V4_PRESERVED_HASHES = {
    "stage_state": "0683a46f73fcd690dbf6c105ddb23b141b8653cb246af7e576a15d827ba4f82a",
    "failure_record": "9bddf194f8de67d832af6ab4e0eb8d728761aabae027912e17c8b1508d07a19b",
    "structural_report": "a05057f82f264296b38742af9dbfe80c8b8596f7dec143a9e2ba83c9c9aa87f8",
    "failure_handoff_zip": "07c360764b4a6a34390c6abc5eec36d8efa25942342f95469b2e3474d11a4b1e",
    "failure_handoff_seal": "232e7bf15eb6a5ab9b3227cc1a4b9c4958d9626adef1131fe81bca98473039f5",
}
sys.path.insert(0, str(SCRIPTS))

from common import sha256_file, write_json  # noqa: E402
from package_builder import build_package  # noqa: E402
from package_verifier import verify_package  # noqa: E402
from study_config import SCRIPT_NAMES  # noqa: E402

REQUIRED_HEAD = "5286c1627e54852fc08f4766240ce7545269e982"


def run(command: list[str], *, cwd: Path = ROOT) -> dict[str, Any]:
    process = subprocess.run(
        command, cwd=cwd, text=True, capture_output=True, check=False
    )
    return {
        "command": command,
        "exit_code": process.returncode,
        "stdout": process.stdout,
        "stderr": process.stderr,
    }


def require(result: dict[str, Any], name: str) -> None:
    if result["exit_code"] != 0:
        raise RuntimeError(
            f"{name} failed\n{result['stdout']}\n{result['stderr']}"
        )


def verify_v4_terminal_tree_unchanged() -> None:
    checks = {
        "stage_state": V4_TERMINAL_ROOT / "phase-b/stage-state.json",
        "failure_record": V4_TERMINAL_ROOT
        / "phase-b/failures/20260716-083648-911431-structural-preflight/failure-record.json",
        "structural_report": V4_TERMINAL_ROOT / "phase-b/structural-preflight-report.json",
    }
    for key, path in checks.items():
        if sha256_file(path) != V4_PRESERVED_HASHES[key]:
            raise RuntimeError(f"V4 preserved hash mismatch for {key}: {path}")
    handoff_zip = REPO / "voxproof-v4-phase-b-pre-review-handoff-20260716-083648.zip"
    handoff_seal = REPO / "package-seal-v4-phase-b-pre-review-handoff-20260716-083648.json"
    if sha256_file(handoff_zip) != V4_PRESERVED_HASHES["failure_handoff_zip"]:
        raise RuntimeError("V4 failure handoff ZIP hash mismatch")
    if sha256_file(handoff_seal) != V4_PRESERVED_HASHES["failure_handoff_seal"]:
        raise RuntimeError("V4 failure handoff seal hash mismatch")


def generate_script_lock() -> dict[str, Any]:
    rows = []
    for name in SCRIPT_NAMES:
        path = SCRIPTS / name
        rows.append(
            {
                "path": f"phase-b/scripts/{name}",
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
        )
    payload = {
        "schema_revision": "voxproof-ami-script-lock-v2",
        "generation_scope": "phase-a-build-only",
        "scripts": rows,
    }
    write_json(ROOT / "phase-b/script-lock.json", payload)
    return payload


def reset_phase_b_state() -> None:
    write_json(
        ROOT / "phase-b/stage-state.json",
        {
            "schema_revision": "voxproof-ami-stage-state-v2",
            "completed": [],
            "access_gate_crossed": False,
            "terminal_failed": False,
            "failure_record": None,
            "stage_details": {},
        },
    )
    attestation = ROOT / "phase-b/binary-attestation.json"
    if attestation.exists():
        attestation.unlink()


def generate_incremental_diff_from_baseline() -> dict[str, Any]:
    if sha256_file(BASELINE_ZIP) != BASELINE_ZIP_SHA256:
        raise RuntimeError("082828 baseline ZIP hash mismatch; refusing to build")
    baseline_seal = BASELINE_ZIP.parent / "package-seal-v4-phase-a-20260716-082828.json"
    if sha256_file(baseline_seal) != BASELINE_SEAL_SHA256:
        raise RuntimeError("082828 baseline seal hash mismatch; refusing to build")
    reports = ROOT / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    patch_path = reports / "incremental-diff-from-082828.patch"
    with tempfile.TemporaryDirectory(prefix="voxproof-082828-baseline-") as tmp:
        baseline_root = Path(tmp) / "baseline"
        current_root = Path(tmp) / "current"
        with zipfile.ZipFile(BASELINE_ZIP) as archive:
            archive.extractall(baseline_root)
        for path in ROOT.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(ROOT)
            if rel.parts[0] in {"package", "outputs", "cargo-target-isolated"}:
                continue
            if path.suffix in {".zip", ".pyc"}:
                continue
            if "test-out" in rel.parts or "rehearsal" in rel.parts:
                continue
            target = current_root / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
        result = subprocess.run(
            ["diff", "-ruN", str(baseline_root), str(current_root)],
            text=True,
            capture_output=True,
            check=False,
        )
        patch_path.write_text(result.stdout, encoding="utf-8")
    payload = {
        "schema_revision": "voxproof-ami-v5-phase-a-incremental-diff-v1",
        "baseline_zip": BASELINE_ZIP.name,
        "baseline_zip_sha256": BASELINE_ZIP_SHA256,
        "baseline_seal_sha256": BASELINE_SEAL_SHA256,
        "patch_path": str(patch_path.relative_to(ROOT)),
        "patch_sha256": sha256_file(patch_path),
        "patch_bytes": patch_path.stat().st_size,
        "diff_exit_code": result.returncode,
    }
    write_json(reports / "incremental-diff-from-082828.json", payload)
    return payload


def main() -> int:
    verify_v4_terminal_tree_unchanged()
    output_dir = ROOT / "outputs"
    output_dir.mkdir(exist_ok=True)
    script_lock = generate_script_lock()
    reset_phase_b_state()

    cycles: list[dict[str, Any]] = []
    compile_result = run(
        [
            sys.executable,
            "-m",
            "compileall",
            "-q",
            str(SCRIPTS),
            str(ROOT / "tests"),
        ]
    )
    require(compile_result, "Python compile")
    cycles.append({"cycle": 1, "name": "python-compile", **compile_result})

    tests = run(
        [
            sys.executable,
            "-m",
            "unittest",
            "discover",
            "-s",
            str(ROOT / "tests"),
            "-v",
        ]
    )
    require(tests, "Python tests")
    test_match = re.search(r"Ran (\d+) tests?", tests["stderr"])
    if not test_match:
        raise RuntimeError("could not determine Python test count")
    python_test_count = int(test_match.group(1))
    cycles.append({"cycle": 2, "name": "python-tests", **tests})
    (output_dir / "python-test-output.txt").write_text(
        tests["stdout"] + tests["stderr"], encoding="utf-8"
    )

    rehearsal = run(
        [sys.executable, str(ROOT / "tests/run_full_pipeline_rehearsal.py")]
    )
    require(rehearsal, "full fixture rehearsal")
    cycles.append({"cycle": 3, "name": "exact-fixture-runner-rehearsal", **rehearsal})

    cargo_commands = [
        ["cargo", "fmt", "--all", "--", "--check"],
        [
            "cargo",
            "clippy",
            "--all-targets",
            "--all-features",
            "--",
            "-D",
            "warnings",
        ],
        ["cargo", "test", "--locked", "--all-targets"],
    ]
    for command in cargo_commands:
        result = run(command, cwd=REPO)
        require(result, " ".join(command))
        cycles.append(
            {
                "cycle": len(cycles) + 1,
                "name": " ".join(command),
                **result,
            }
        )

    command_check = run(
        [sys.executable, str(SCRIPTS / "phase_b_runner.py"), "self-check-commands"]
    )
    require(command_check, "command self-check")
    parsed_check = json.loads(command_check["stdout"])
    if parsed_check["result"]["status"] != "pass":
        raise RuntimeError(f"command self-check failed: {parsed_check}")
    cycles.append(
        {
            "cycle": len(cycles) + 1,
            "name": "command-reference-self-check",
            **command_check,
        }
    )

    head = subprocess.check_output(
        ["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True
    ).strip()
    tracked_diff = subprocess.run(
        ["git", "-C", str(REPO), "diff", "--quiet"], check=False
    ).returncode
    staged_diff = subprocess.run(
        ["git", "-C", str(REPO), "diff", "--cached", "--quiet"], check=False
    ).returncode
    diff_check = run(["git", "diff", "--check"], cwd=REPO)
    if head != REQUIRED_HEAD or tracked_diff or staged_diff or diff_check["exit_code"]:
        raise RuntimeError("repository HEAD/clean tracked state/diff-check gate failed")
    write_json(
        ROOT / "repository-status-evidence.json",
        {
            "required_head": REQUIRED_HEAD,
            "actual_head": head,
            "head_matches": True,
            "tracked_diff": False,
            "staged_diff": False,
            "diff_check_pass": True,
        },
    )

    stale_manifest = ROOT / "manifest.json"
    if stale_manifest.exists():
        stale_manifest.unlink()

    reset_phase_b_state()
    incremental_diff = generate_incremental_diff_from_baseline()
    debug = {
        "schema_revision": "voxproof-ami-internal-debug-v2",
        "internal_cycle_count": len(cycles),
        "cycles": cycles,
        "semantic_correction_cycle": {
            "cycle_id": "v5-phase-a-shared-child-href-v2",
            "preserved_v4_phase_a_zip": BASELINE_ZIP.name,
            "preserved_v4_phase_a_seal": "package-seal-v4-phase-a-20260716-082828.json",
            "preserved_v4_phase_a_zip_sha256": BASELINE_ZIP_SHA256,
            "preserved_v4_phase_a_seal_sha256": BASELINE_SEAL_SHA256,
            "incremental_diff_patch": incremental_diff["patch_path"],
            "incremental_diff_sha256": incremental_diff["patch_sha256"],
            "resolved_target_meeting_id": "ES2004d",
            "es2004c_structural_regression_input_only": True,
            "es2004d_lexical_content_opened": False,
            "v4_terminal_tree_preserved": True,
        },
        "validation_failures": [],
        "final_status": "pass",
    }
    write_json(ROOT / "internal-debugging-record.json", debug)

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    summary = build_package(
        root=ROOT,
        output_dir=ROOT / "package",
        mode="phase-a",
        name_suffix=stamp,
    )
    verification = verify_package(
        ROOT,
        Path(summary["zip_path"]),
        Path(summary["seal_path"]),
        "phase-a",
    )
    if verification["status"] != "pass":
        raise RuntimeError("; ".join(verification["errors"]))
    write_json(output_dir / "package-verification-output.json", verification)
    write_json(ROOT / "package/package-summary.json", summary)

    final = {
        **summary,
        "verification_status": "pass",
        "python_tests": python_test_count,
        "internal_cycles": len(cycles),
        "script_lock": script_lock,
        "incremental_diff": incremental_diff,
        "resolved_target_meeting_id": "ES2004d",
        "es2004c_structural_regression_input_only": True,
        "es2004d_lexical_content_opened": False,
        "v4_terminal_tree_preserved": True,
        "repository_head": head,
    }
    write_json(output_dir / "build-summary.json", final)
    print(json.dumps(final, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
