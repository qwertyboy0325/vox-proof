#!/usr/bin/env python3
"""Complete V5 Phase B after owner acceptance of zero glossary opportunities."""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import sys
import unicodedata
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any

STUDY = Path(__file__).resolve().parent
SCRIPTS = STUDY / "phase-b/scripts"
BUILD = STUDY / "phase-b/build-primary"
PARSED = BUILD / "parsed"
PROBE = STUDY / "phase-b/probe"
REVIEW = STUDY / "phase-b/review"
REPORTS = STUDY / "phase-b/reports"
PACKAGE_DIR = STUDY / "phase-b/package"
OWNER_REVIEW = STUDY / "owner-review-20260716"
RUNNER = SCRIPTS / "phase_b_runner.py"
REPO = Path("/Users/Ezra4/Coding/Repo/vox-proof")
FLAWED_PACKET_ZIP_SHA = (
    "70cc1a5f5fc16699a5483f18c3661f5d8b558c644f733e5313d28d53bc78d320"
)
FLAWED_PACKET_SEAL_SHA = (
    "bc986e224ca29df931d17c7b769526277dc74dad3a0e5d631394ba676d0359a5"
)

WINDOW_START = Decimal("300.000")
WINDOW_END = Decimal("900.000")
SPEAKERS = ("A", "B", "C", "D")
CANONICAL_TERMS = [
    "Project Manager",
    "Industrial Designer",
    "User Interface Designer",
    "Marketing Expert",
]
ALIASES = ["PM", "ID", "UI", "UID", "ME"]
COMPONENT_WORDS = [
    "project",
    "manager",
    "industrial",
    "designer",
    "user",
    "interface",
    "marketing",
    "expert",
]
RELEVANT_WHOLE_TOKENS = [
    "i'd",
    "me",
    "interface",
    "user",
    "marketing",
    "designer",
]

sys.path.insert(0, str(SCRIPTS))
from ami_common import scoring_tokens  # noqa: E402
from common import sha256_file, utc_now, write_json  # noqa: E402
from study_config import MEETING_ID, SESSION_TERMS_LINES  # noqa: E402

ENV = {
    **{k: v for k, v in __import__("os").environ.items() if not k.startswith("VOXPROOF_V3_")},
    "VOXPROOF_V3_STUDY_ROOT": str(STUDY),
}
STAGES = [
    "validate-review-inputs",
    "authoritative-review",
    "audit-materialization",
    "score",
    "independent-verify",
    "package",
]
REVIEWER = {
    "reviewer_id": "voxproof-product-owner",
    "display_name": "VoxProof product owner",
    "attested_at_utc": utc_now(),
    "attestation": (
        "I attest that I completed an exhaustive frozen-glossary scan over the "
        "ES2004d [300.000, 900.000) window using immutable ASR cues, same-speaker "
        "manual reference tokens, canonical session terms, aliases, and normalized "
        "component words. ChatGPT assisted the deterministic scan; final acceptance "
        "of zero opportunities belongs to me as product owner. I did not personally "
        "listen to audio and make no general transcript-correctness claim."
    ),
}
ATTESTATION_TEXT = (
    "Full-window frozen-glossary opportunity review completed for ES2004d "
    "[300.000, 900.000). Exhaustive same-speaker scan found zero supported "
    "frozen-glossary opportunities. Nine relevant whole-token hits were reviewed "
    "and rejected. Product owner accepts opportunities=[]. No audio listening "
    "claim and no general transcript-correctness claim."
)


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def ms_to_seconds(ms: int) -> Decimal:
    return Decimal(ms) / Decimal(1000)


def intervals_overlap(a0: Decimal, a1: Decimal, b0: Decimal, b1: Decimal) -> bool:
    return not (a1 <= b0 or b1 <= a0)


def load_records(path: Path) -> list[dict[str, Any]]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line
    ]


def same_speaker_overlap_rendering(
    cue: dict[str, Any], reference_records: list[dict[str, Any]]
) -> tuple[str, list[str], list[str]]:
    cue_start = ms_to_seconds(cue["start_ms"])
    cue_end = ms_to_seconds(cue["end_ms"])
    speaker = cue["speaker"]
    overlap = [
        record
        for record in reference_records
        if record.get("tag") == "w"
        and record["speaker"] == speaker
        and intervals_overlap(
            cue_start,
            cue_end,
            Decimal(record["start"]),
            Decimal(record["end"]),
        )
    ]
    overlap.sort(
        key=lambda record: (
            (Decimal(record["start"]) + Decimal(record["end"])) / 2,
            record["element_id"],
        )
    )
    rendering = " ".join(record["text"] for record in overlap).strip()
    token_ids = [record["element_id"] for record in overlap]
    return rendering, token_ids, [speaker] if overlap else []


def find_canonical_sequences(tokens: list[str]) -> list[dict[str, Any]]:
    hits = []
    joined = " ".join(tokens)
    for term in CANONICAL_TERMS:
        term_tokens = scoring_tokens(term)
        if not term_tokens:
            continue
        needle = " ".join(term_tokens)
        start = 0
        while True:
            index = joined.find(needle, start)
            if index < 0:
                break
            hits.append(
                {
                    "canonical_term": term,
                    "normalized_sequence": needle,
                    "start_token_offset": index,
                }
            )
            start = index + 1
    return hits


def analyze_flawed_worksheet() -> dict[str, Any]:
    worksheet_path = STUDY / "review-preparation-20260716/cue-side-by-side-worksheet.json"
    worksheet = json.loads(worksheet_path.read_text(encoding="utf-8"))
    reference_records = load_records(PARSED / "reference_tokens.jsonl")
    merged_rows = []
    for row in worksheet["rows"]:
        cue = {
            "speaker": row["speaker"],
            "start_ms": int(Decimal(row["cue_start_seconds"]) * 1000),
            "end_ms": int(Decimal(row["cue_end_seconds"]) * 1000),
        }
        _, _, same_speakers = same_speaker_overlap_rendering(cue, reference_records)
        if len(row["manual_speakers"]) > 1:
            merged_rows.append(row["cue_index"])
    merged_count = len(merged_rows)
    if merged_count != 133:
        raise RuntimeError(
            f"expected 133 merged-speaker worksheet rows, found {merged_count}"
        )
    return {
        "schema_revision": "voxproof-ami-v5-flawed-worksheet-exclusion-v1",
        "sealed_packet_zip_sha256": FLAWED_PACKET_ZIP_SHA,
        "sealed_packet_seal_sha256": FLAWED_PACKET_SEAL_SHA,
        "excluded_from_final_evidence": True,
        "flaw": "cue-level rendering merged speakers via temporal overlap without same-speaker restriction",
        "merged_speaker_row_count": merged_count,
        "total_cue_count": len(worksheet["rows"]),
        "merged_speaker_row_fraction": f"{merged_count}/{len(worksheet['rows'])}",
        "merged_speaker_cue_indices": merged_rows,
        "note": "Sealed human-review packet preserved byte-identical; not modified or deleted.",
    }


def build_owner_review_record() -> dict[str, Any]:
    cues = json.loads((PARSED / "asr_cues.json").read_text(encoding="utf-8"))["cues"]
    if len(cues) != 258:
        raise RuntimeError(f"expected 258 ASR cues, found {len(cues)}")
    reference_records = load_records(PARSED / "reference_tokens.jsonl")
    hypothesis_records = load_records(PARSED / "hypothesis_tokens.jsonl")
    in_window_reference_w = [
        record for record in reference_records if record.get("tag") == "w" and record["in_window"]
    ]
    if len(in_window_reference_w) != 2027:
        raise RuntimeError(
            f"expected 2027 in-window lexical reference tokens, found {len(in_window_reference_w)}"
        )
    cue_rows = []
    relevant_hits = []
    canonical_hits = []
    design_difference = None

    for index, cue in enumerate(cues, start=1):
        rendering, token_ids, speakers = same_speaker_overlap_rendering(cue, reference_records)
        asr_tokens = scoring_tokens(cue["text"])
        ref_tokens = scoring_tokens(rendering)
        cue_canonical = find_canonical_sequences(asr_tokens) + find_canonical_sequences(ref_tokens)
        for hit in cue_canonical:
            canonical_hits.append({"cue_index": index, **hit, "layer": "cue"})
        cue_rows.append(
            {
                "cue_index": index,
                "speaker": cue["speaker"],
                "cue_timing": f"{ms_to_seconds(cue['start_ms']):.3f}-{ms_to_seconds(cue['end_ms']):.3f}",
                "asr_text": cue["text"],
                "same_speaker_reference_rendering": rendering,
                "same_speaker_reference_token_ids": token_ids,
                "canonical_sequence_hits": cue_canonical,
            }
        )

    def inspect_token(record: dict[str, Any], layer: str) -> None:
        raw = record["text"]
        normalized = scoring_tokens(raw)
        whole = normalized[0] if len(normalized) == 1 else None
        token = None
        if whole in RELEVANT_WHOLE_TOKENS:
            token = whole
        elif raw.lower() in ("i'd", "i’d") or raw == "I'd":
            token = "i'd"
        if token is None:
            return
        relevant_hits.append(
            {
                "hit_id": f"hit-{len(relevant_hits)+1:03d}",
                "normalized_token": token,
                "raw_token": raw,
                "layer": layer,
                "speaker": record["speaker"],
                "element_id": record["element_id"],
                "start": record["start"],
                "end": record["end"],
                "classification": "not_supported_frozen_glossary_opportunity",
                "reason": "relevant whole-token hit without supported frozen-glossary opportunity",
            }
        )

    for record in in_window_reference_w:
        inspect_token(record, "reference")

    # Relevant whole-token hits are counted from in-window lexical reference tokens only.
    # Hypothesis-layer tokens are not duplicated into the nine owner-accepted hits.

    # Deduplicate identical element/layer hits while preserving first id
    deduped = []
    seen = set()
    for hit in relevant_hits:
        key = (hit["layer"], hit["element_id"], hit["normalized_token"], hit["raw_token"])
        if key in seen:
            continue
        seen.add(key)
        hit["hit_id"] = f"hit-{len(deduped)+1:03d}"
        deduped.append(hit)
    relevant_hits = deduped

    counts = Counter(hit["normalized_token"] for hit in relevant_hits)
    expected = Counter(
        {
            "i'd": 3,
            "me": 1,
            "interface": 1,
            "user": 1,
            "marketing": 2,
            "designer": 1,
        }
    )
    if counts != expected:
        raise RuntimeError(f"relevant whole-token hit counts mismatch: {dict(counts)} != {dict(expected)}")

    for record in hypothesis_records:
        if record.get("tag") == "w" and record.get("in_window") and scoring_tokens(record["text"]) == ["design"]:
            design_difference = {
                "hypothesis_element_id": record["element_id"],
                "hypothesis_token": record["text"],
                "speaker": record["speaker"],
                "start": record["start"],
                "end": record["end"],
                "note": "ASR token 'design' is a real lexical difference from nearby reference 'designer'; outside frozen exact-glossary opportunity definition",
            }
            break

    return {
        "schema_revision": "voxproof-ami-v5-owner-review-record-v1",
        "meeting_id": MEETING_ID,
        "window": {"start_inclusive": "300.000", "end_exclusive": "900.000"},
        "reviewer": REVIEWER,
        "method": "same-speaker exhaustive deterministic scan from immutable raw artifacts",
        "bindings": {
            "asr_cue_count": len(cues),
            "in_window_lexical_reference_token_count": len(in_window_reference_w),
            "complete_canonical_term_occurrence_count": len(canonical_hits),
            "relevant_whole_token_hit_counts": dict(counts),
        },
        "accepted_opportunities": [],
        "relevant_whole_token_hits": relevant_hits,
        "asr_difference_outside_glossary_definition": design_difference,
        "cue_rows": cue_rows,
        "classification": "prospective real-corpus negative-control evidence only",
        "claims_not_made": [
            "no audio listening by product owner",
            "no general transcript correctness claim",
            "no general VoxProof effectiveness claim",
        ],
    }


def write_human_inputs() -> dict[str, str]:
    REVIEW.mkdir(parents=True, exist_ok=True)
    layer_manifest = json.loads((BUILD / "layer_manifest.json").read_text(encoding="utf-8"))
    reference_manifest = json.loads(
        (BUILD / "reference-layer-manifest.json").read_text(encoding="utf-8")
    )
    inventory = json.loads((PROBE / "candidate-inventory.json").read_text(encoding="utf-8"))
    reference_records = load_records(PARSED / "reference_tokens.jsonl")
    cues = json.loads((PARSED / "asr_cues.json").read_text(encoding="utf-8"))["cues"]
    reference_token_count = sum(1 for record in reference_records if record.get("tag") == "w")

    ground_truth = {
        "schema_revision": "voxproof-ami-ground-truth-v3",
        "reviewer": REVIEWER,
        "meeting_id": MEETING_ID,
        "window": {"start_inclusive": "300.000", "end_exclusive": "900.000"},
        "input_srt_sha256": layer_manifest["files"]["input.srt"],
        "terms_sha256": sha256_file(STUDY / "session-terms/session-terms.txt"),
        "reference_layer_sha256": sha256_file(BUILD / "reference-layer-manifest.json"),
        "normalization_policy_id": "unicode-nfc-casefold-remove-punctuation-v1",
        "overlap_policy_id": "localized-time-and-cue-overlap-one-to-one-v1",
        "acceptable_variant_policy_id": "acceptable-variants-are-not-opportunities-v1",
        "full_window_glossary_opportunity_review_attestation": {
            "completed": True,
            "reviewer_attestation": ATTESTATION_TEXT,
        },
        "reviewed_cue_count": len(cues),
        "reference_token_count": reference_token_count,
        "opportunities": [],
    }
    candidate_labels = {
        "schema_revision": "voxproof-ami-candidate-labels-v3",
        "reviewer": REVIEWER,
        "reference_layer_sha256": sha256_file(BUILD / "reference-layer-manifest.json"),
        "inventory_sha256": sha256_file(PROBE / "candidate-inventory.json"),
        "labels": [],
    }
    decision_inputs = {
        "schema_revision": "voxproof-ami-decision-inputs-v2",
        "reviewer": REVIEWER,
        "inventory_sha256": sha256_file(PROBE / "candidate-inventory.json"),
        "transcript_revision": inventory["transcript_revision"],
        "candidate_fingerprints": [],
        "decisions": [],
    }
    write_json(REVIEW / "ground-truth.json", ground_truth)
    write_json(REVIEW / "candidate-labels.json", candidate_labels)
    write_json(REVIEW / "decision-inputs.json", decision_inputs)
    return {
        "ground_truth_sha256": sha256_file(REVIEW / "ground-truth.json"),
        "candidate_labels_sha256": sha256_file(REVIEW / "candidate-labels.json"),
        "decision_inputs_sha256": sha256_file(REVIEW / "decision-inputs.json"),
    }


def run_stage(stage: str, chronology: list[dict[str, Any]]) -> None:
    started = utc_now()
    t0 = datetime.now(timezone.utc)
    proc = subprocess.run(
        [sys.executable, str(RUNNER), stage],
        cwd=STUDY,
        env=ENV,
        text=True,
        capture_output=True,
    )
    ended = utc_now()
    wall = (datetime.now(timezone.utc) - t0).total_seconds()
    (OWNER_REVIEW / "console" / f"{stage}.stdout").write_text(proc.stdout, encoding="utf-8")
    (OWNER_REVIEW / "console" / f"{stage}.stderr").write_text(proc.stderr, encoding="utf-8")
    chronology.append(
        {
            "stage": stage,
            "started_at_utc": started,
            "ended_at_utc": ended,
            "exit_code": proc.returncode,
            "wall_seconds": round(wall, 3),
        }
    )
    if proc.returncode != 0:
        raise RuntimeError(f"stage {stage} failed: {proc.stdout}\n{proc.stderr}")


def build_final_report(
    *,
    chronology: list[dict[str, Any]],
    exclusion: dict[str, Any],
    owner_review: dict[str, Any],
    human_hashes: dict[str, str],
) -> dict[str, Any]:
    metrics = json.loads((STUDY / "phase-b/metrics.json").read_text(encoding="utf-8"))
    alignment = json.loads((STUDY / "phase-b/alignment-audit.json").read_text(encoding="utf-8"))
    materialization = json.loads((REVIEW / "materialization-audit.json").read_text(encoding="utf-8"))
    independent = json.loads((REPORTS / "independent-verifier-output.json").read_text(encoding="utf-8"))
    state = json.loads((STUDY / "phase-b/stage-state.json").read_text(encoding="utf-8"))
    input_srt_sha = sha256_file(BUILD / "input.srt")
    reviewed_srt_sha = sha256_file(REVIEW / "reviewed-output.srt")
    return {
        "schema_revision": "voxproof-ami-v5-phase-b-final-report-v1",
        "classification": "prospective real-corpus negative-control evidence only",
        "target": {
            "meeting_id": MEETING_ID,
            "window": {"start_inclusive": "300.000", "end_exclusive": "900.000"},
        },
        "semantic_outcome": {
            "candidates": metrics["candidate_precision"]["denominator"],
            "opportunities": 0,
            "accepted_edits": metrics["accepted_candidate_count"],
            "reviewed_srt_sha256": reviewed_srt_sha,
            "input_srt_sha256": input_srt_sha,
            "reviewed_srt_byte_identical_to_input": input_srt_sha == reviewed_srt_sha,
            "candidate_precision_ratio": metrics["candidate_precision"]["ratio"],
            "candidate_recall_ratio": metrics["candidate_recall"]["ratio"],
            "correction_recall_ratio": metrics["correction_recall"]["ratio"],
            "unsafe_edit_rate_ratio": metrics["unsafe_edit_rate"]["ratio"],
            "raw_wer": metrics["raw_wer"],
            "reviewed_wer": metrics["reviewed_wer"],
            "raw_to_reviewed_wer_delta": metrics["raw_to_reviewed_wer_delta"],
        },
        "claims_not_made": owner_review["claims_not_made"],
        "flawed_worksheet_exclusion": exclusion,
        "owner_review_record_sha256": sha256_file(OWNER_REVIEW / "owner-review-record.json"),
        "human_inputs": human_hashes,
        "stage_chronology": chronology,
        "stage_state_sha256": sha256_file(STUDY / "phase-b/stage-state.json"),
        "terminal_failed": state.get("terminal_failed", False),
        "materialization_audit_sha256": sha256_file(REVIEW / "materialization-audit.json"),
        "alignment_audit_sha256": sha256_file(STUDY / "phase-b/alignment-audit.json"),
        "metrics_sha256": sha256_file(STUDY / "phase-b/metrics.json"),
        "independent_verifier_status": independent.get("status"),
        "no_model_api_calls": True,
        "no_repository_source_edit": True,
        "no_commit": True,
        "no_push": True,
    }


def main() -> int:
    OWNER_REVIEW.mkdir(parents=True, exist_ok=True)
    (OWNER_REVIEW / "console").mkdir(exist_ok=True)

    exclusion = analyze_flawed_worksheet()
    owner_review = build_owner_review_record()
    write_json(OWNER_REVIEW / "flawed-worksheet-exclusion.json", exclusion)
    write_json(OWNER_REVIEW / "owner-review-record.json", owner_review)
    human_hashes = write_human_inputs()

    chronology = []
    for stage in STAGES:
        run_stage(stage, chronology)
    write_json(OWNER_REVIEW / "stage-chronology.json", chronology)

    final_report = build_final_report(
        chronology=chronology,
        exclusion=exclusion,
        owner_review=owner_review,
        human_hashes=human_hashes,
    )
    write_json(OWNER_REVIEW / "final-report.json", final_report)

    anomaly_src = STUDY / "review-preparation-20260716/execution-anomaly-record.json"
    shutil.copy2(anomaly_src, OWNER_REVIEW / "execution-anomaly-record.json")

    head = subprocess.check_output(["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True).strip()
    repo_status = {
        "head": head,
        "tracked_diff": subprocess.run(["git", "-C", str(REPO), "diff", "--quiet"]).returncode != 0,
        "staged_diff": subprocess.run(["git", "-C", str(REPO), "diff", "--cached", "--quiet"]).returncode != 0,
    }
    write_json(OWNER_REVIEW / "repository-status-evidence.json", repo_status)

    package_summary = json.loads((PACKAGE_DIR / "package-summary.json").read_text(encoding="utf-8"))
    handoff = {
        "schema_revision": "voxproof-ami-v5-phase-b-completion-handoff-v1",
        "outcome": "completed_through_package",
        "final_report_sha256": sha256_file(OWNER_REVIEW / "final-report.json"),
        "stage_state_sha256": sha256_file(STUDY / "phase-b/stage-state.json"),
        "package": package_summary,
        "repository_status": repo_status,
    }
    write_json(OWNER_REVIEW / "completion-handoff.json", handoff)
    print(json.dumps(handoff, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
