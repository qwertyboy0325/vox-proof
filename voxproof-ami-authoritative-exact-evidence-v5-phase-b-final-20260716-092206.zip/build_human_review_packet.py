#!/usr/bin/env python3
"""Build deterministic V5 human-review preparation packet from frozen pre-review tree."""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import sys
import unicodedata
import zipfile
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any

STUDY = Path(__file__).resolve().parent
SCRIPTS = STUDY / "phase-b/scripts"
BUILD = STUDY / "phase-b/build-primary"
PARSED = BUILD / "parsed"
PROBE = STUDY / "phase-b/probe"
PREP = STUDY / "review-preparation-20260716"
DRAFT = PREP / "draft-inputs"
SOURCES = PREP / "sources"
PACKAGE_DIR = PREP / "package"

sys.path.insert(0, str(SCRIPTS))

from alignment_scorer import align_tokens  # noqa: E402
from ami_common import normalize_token, scoring_tokens  # noqa: E402
from study_config import (  # noqa: E402
    MEETING_ID,
    SESSION_TERMS_LINES,
    SPEAKERS,
    WINDOW_END,
    WINDOW_START,
)

SEARCH_PATTERNS = [
    "PM",
    "ID",
    "UI",
    "UID",
    "ME",
    "Project Manager",
    "Industrial Designer",
    "User Interface Designer",
    "Marketing Expert",
]
COMPONENT_WORDS = [
    "project",
    "manager",
    "industrial",
    "designer",
    "user",
    "interface",
    "marketing",
    "expert",
]
BLANK_REVIEWER = {
    "reviewer_id": "",
    "display_name": "",
    "attested_at_utc": "",
    "attestation": "",
}
BLANK_GLOSSARY_FIELDS = {
    "reviewed": "",
    "is_glossary_opportunity": "",
    "canonical_term": "",
    "source_rendering": "",
    "acceptable_variant": "",
    "support_rationale": "",
}
IMMUTABLE_SOURCES = [
    (BUILD / "input.srt", "sources/input.srt"),
    (PARSED / "asr_cues.json", "sources/asr_cues.json"),
    (PARSED / "hypothesis_tokens.jsonl", "sources/hypothesis_tokens.jsonl"),
    (PARSED / "reference_tokens.jsonl", "sources/reference_tokens.jsonl"),
    (BUILD / "scoring_tokens.json", "sources/scoring_tokens.json"),
    (PROBE / "candidate-inventory.json", "sources/candidate-inventory.json"),
    (BUILD / "layer_manifest.json", "sources/layer_manifest.json"),
    (BUILD / "reference-layer-manifest.json", "sources/reference-layer-manifest.json"),
    (STUDY / "phase-b/structural-preflight-report.json", "sources/structural-preflight-report.json"),
    (STUDY / "phase-b/stage-state.json", "sources/stage-state.json"),
]


def sha_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def ms_to_seconds(ms: int) -> Decimal:
    return Decimal(ms) / Decimal(1000)


def intervals_overlap(
    left_start: Decimal, left_end: Decimal, right_start: Decimal, right_end: Decimal
) -> bool:
    return not (left_end <= right_start or right_end <= left_start)


def format_timing(start_ms: int, end_ms: int) -> str:
    return f"{ms_to_seconds(start_ms):.3f}-{ms_to_seconds(end_ms):.3f}"


def token_diff_summary(reference: list[str], hypothesis: list[str]) -> dict[str, Any]:
    if not reference and not hypothesis:
        return {
            "operations": [],
            "operations_compact": "",
            "edit_distance": 0,
            "matches": 0,
            "substitutions": 0,
            "deletions": 0,
            "insertions": 0,
        }
    result = align_tokens(reference, hypothesis)
    compact_ops: list[str] = []
    for op in result.operations:
        if op.operation == "match":
            compact_ops.append(f"M:{op.reference_token}")
        elif op.operation == "substitution":
            compact_ops.append(f"S:{op.hypothesis_token}->{op.reference_token}")
        elif op.operation == "deletion":
            compact_ops.append(f"D:{op.reference_token}")
        elif op.operation == "insertion":
            compact_ops.append(f"I:{op.hypothesis_token}")
    return {
        "operations": [op.to_dict() for op in result.operations],
        "operations_compact": "|".join(compact_ops),
        "edit_distance": result.edit_distance,
        "matches": result.matches,
        "substitutions": result.substitutions,
        "deletions": result.deletions,
        "insertions": result.insertions,
    }


def casefold_text(text: str) -> str:
    return unicodedata.normalize("NFC", text).casefold()


def find_hits(text: str) -> dict[str, list[dict[str, Any]]]:
    hits: dict[str, list[dict[str, Any]]] = {
        "exact": [],
        "casefold": [],
        "normalized": [],
    }
    if not text:
        return hits
    folded = casefold_text(text)
    normalized_tokens = scoring_tokens(text)
    normalized_blob = " ".join(normalized_tokens)
    for pattern in SEARCH_PATTERNS:
        for match in re.finditer(re.escape(pattern), text):
            hits["exact"].append(
                {
                    "pattern": pattern,
                    "matched_text": match.group(0),
                    "start_char": match.start(),
                    "end_char": match.end(),
                }
            )
        pattern_folded = casefold_text(pattern)
        start = 0
        while True:
            index = folded.find(pattern_folded, start)
            if index < 0:
                break
            hits["casefold"].append(
                {
                    "pattern": pattern,
                    "matched_text": text[index : index + len(pattern)],
                    "start_char": index,
                    "end_char": index + len(pattern),
                }
            )
            start = index + 1
        pattern_norm_tokens = scoring_tokens(pattern)
        if not pattern_norm_tokens:
            continue
        pattern_norm = " ".join(pattern_norm_tokens)
        start = 0
        while True:
            index = normalized_blob.find(pattern_norm, start)
            if index < 0:
                break
            hits["normalized"].append(
                {
                    "pattern": pattern,
                    "matched_text": pattern_norm,
                    "start_token_offset": index,
                    "end_token_offset": index + len(pattern_norm),
                }
            )
            start = index + 1
    for word in COMPONENT_WORDS:
        for token_index, token in enumerate(normalized_tokens):
            if token == word:
                hits["normalized"].append(
                    {
                        "pattern": word,
                        "matched_text": token,
                        "token_index": token_index,
                        "component_word": True,
                    }
                )
    return hits


def load_reference_records() -> list[dict[str, Any]]:
    return [
        json.loads(line)
        for line in (PARSED / "reference_tokens.jsonl").read_text(encoding="utf-8").splitlines()
        if line
    ]


def load_hypothesis_by_id() -> dict[str, dict[str, Any]]:
    return {
        json.loads(line)["element_id"]: json.loads(line)
        for line in (PARSED / "hypothesis_tokens.jsonl")
        .read_text(encoding="utf-8")
        .splitlines()
        if line
    }


def overlapping_reference_tokens(
    cue_start: Decimal, cue_end: Decimal, reference_records: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    overlapping = []
    for record in reference_records:
        if record.get("tag") != "w":
            continue
        start = Decimal(record["start"])
        end = Decimal(record["end"])
        if intervals_overlap(cue_start, cue_end, start, end):
            overlapping.append(record)
    overlapping.sort(
        key=lambda record: (
            (Decimal(record["start"]) + Decimal(record["end"])) / 2,
            SPEAKERS.index(record["speaker"]),
            record["element_id"],
        )
    )
    return overlapping


def build_worksheet(
    cues: list[dict[str, Any]], reference_records: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    rows = []
    for index, cue in enumerate(cues, start=1):
        cue_start = ms_to_seconds(cue["start_ms"])
        cue_end = ms_to_seconds(cue["end_ms"])
        overlap = overlapping_reference_tokens(cue_start, cue_end, reference_records)
        reference_rendering = " ".join(record["text"] for record in overlap).strip()
        reference_token_ids = [record["element_id"] for record in overlap]
        reference_speakers = sorted({record["speaker"] for record in overlap})
        asr_text = cue["text"]
        hypothesis_tokens = scoring_tokens(asr_text)
        reference_tokens = scoring_tokens(reference_rendering)
        diff = token_diff_summary(reference_tokens, hypothesis_tokens)
        rows.append(
            {
                "cue_index": index,
                "cue_timing": format_timing(cue["start_ms"], cue["end_ms"]),
                "cue_start_seconds": str(cue_start),
                "cue_end_seconds": str(cue_end),
                "speaker": cue["speaker"],
                "segment_id": cue["segment_id"],
                "asr_text": asr_text,
                "overlapping_manual_reference_rendering": reference_rendering,
                "manual_speakers": reference_speakers,
                "manual_token_ids": reference_token_ids,
                "deterministic_token_diff": diff,
                "term_hits": {
                    "asr_text": find_hits(asr_text),
                    "reference_rendering": find_hits(reference_rendering),
                },
            }
        )
    return rows


def build_glossary_table(
    cues: list[dict[str, Any]],
    reference_records: list[dict[str, Any]],
    worksheet: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    occurrence_id = 0

    def append_row(
        *,
        source_layer: str,
        cue_index: int | None,
        speaker: str,
        token_id: str | None,
        text: str,
        start: str,
        end: str,
        matched_pattern: str,
        match_kind: str,
        matched_text: str,
        asr_context: str,
        reference_context: str,
    ) -> None:
        nonlocal occurrence_id
        occurrence_id += 1
        rows.append(
            {
                "occurrence_id": f"gloss-{occurrence_id:04d}",
                "source_layer": source_layer,
                "cue_index": cue_index,
                "speaker": speaker,
                "token_id": token_id,
                "start": start,
                "end": end,
                "matched_pattern": matched_pattern,
                "match_kind": match_kind,
                "matched_text": matched_text,
                "asr_context": asr_context,
                "reference_context": reference_context,
                **BLANK_GLOSSARY_FIELDS,
            }
        )

    for row in worksheet:
        cue_index = row["cue_index"]
        asr_text = row["asr_text"]
        reference_text = row["overlapping_manual_reference_rendering"]
        for kind, bucket in row["term_hits"]["asr_text"].items():
            for hit in bucket:
                append_row(
                    source_layer="asr_cue",
                    cue_index=cue_index,
                    speaker=row["speaker"],
                    token_id=None,
                    text=asr_text,
                    start=row["cue_start_seconds"],
                    end=row["cue_end_seconds"],
                    matched_pattern=hit["pattern"],
                    match_kind=kind,
                    matched_text=hit.get("matched_text", ""),
                    asr_context=asr_text,
                    reference_context=reference_text,
                )
        for kind, bucket in row["term_hits"]["reference_rendering"].items():
            for hit in bucket:
                append_row(
                    source_layer="manual_reference_overlap",
                    cue_index=cue_index,
                    speaker=",".join(row["manual_speakers"]),
                    token_id=None,
                    text=reference_text,
                    start=row["cue_start_seconds"],
                    end=row["cue_end_seconds"],
                    matched_pattern=hit["pattern"],
                    match_kind=kind,
                    matched_text=hit.get("matched_text", ""),
                    asr_context=asr_text,
                    reference_context=reference_text,
                )

    for record in reference_records:
        if record.get("tag") != "w":
            continue
        text = record.get("text", "")
        hits = find_hits(text)
        if not any(hits.values()):
            continue
        cue_index = None
        midpoint = (Decimal(record["start"]) + Decimal(record["end"])) / 2
        for cue in cues:
            if intervals_overlap(
                ms_to_seconds(cue["start_ms"]),
                ms_to_seconds(cue["end_ms"]),
                Decimal(record["start"]),
                Decimal(record["end"]),
            ):
                cue_index = cues.index(cue) + 1
                break
        asr_context = ""
        reference_context = text
        if cue_index is not None:
            asr_context = worksheet[cue_index - 1]["asr_text"]
            reference_context = worksheet[cue_index - 1][
                "overlapping_manual_reference_rendering"
            ]
        for kind, bucket in hits.items():
            for hit in bucket:
                append_row(
                    source_layer="manual_reference_token",
                    cue_index=cue_index,
                    speaker=record["speaker"],
                    token_id=record["element_id"],
                    text=text,
                    start=record["start"],
                    end=record["end"],
                    matched_pattern=hit["pattern"],
                    match_kind=kind,
                    matched_text=hit.get("matched_text", ""),
                    asr_context=asr_context,
                    reference_context=reference_context,
                )
    rows.sort(
        key=lambda row: (
            row["cue_index"] if row["cue_index"] is not None else 10**9,
            row["source_layer"],
            row["token_id"] or "",
            row["matched_pattern"],
            row["match_kind"],
        )
    )
    return rows


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def build_draft_inputs(
    *,
    input_srt_sha256: str,
    terms_sha256: str,
    reference_layer_sha256: str,
    inventory_sha256: str,
    transcript_revision: str,
    reviewed_cue_count: int,
    reference_token_count: int,
) -> None:
    ground_truth = {
        "schema_revision": "voxproof-ami-ground-truth-v3",
        "reviewer": dict(BLANK_REVIEWER),
        "meeting_id": MEETING_ID,
        "window": {
            "start_inclusive": str(WINDOW_START),
            "end_exclusive": str(WINDOW_END),
        },
        "input_srt_sha256": input_srt_sha256,
        "terms_sha256": terms_sha256,
        "reference_layer_sha256": reference_layer_sha256,
        "normalization_policy_id": "unicode-nfc-casefold-remove-punctuation-v1",
        "overlap_policy_id": "localized-time-and-cue-overlap-one-to-one-v1",
        "acceptable_variant_policy_id": "acceptable-variants-are-not-opportunities-v1",
        "full_window_glossary_opportunity_review_attestation": {
            "completed": False,
            "reviewer_attestation": "",
        },
        "reviewed_cue_count": reviewed_cue_count,
        "reference_token_count": reference_token_count,
        "opportunities": [],
    }
    candidate_labels = {
        "schema_revision": "voxproof-ami-candidate-labels-v3",
        "reviewer": dict(BLANK_REVIEWER),
        "reference_layer_sha256": reference_layer_sha256,
        "inventory_sha256": inventory_sha256,
        "labels": [],
    }
    decision_inputs = {
        "schema_revision": "voxproof-ami-decision-inputs-v2",
        "reviewer": dict(BLANK_REVIEWER),
        "inventory_sha256": inventory_sha256,
        "transcript_revision": transcript_revision,
        "candidate_fingerprints": [],
        "decisions": [],
    }
    write_json(DRAFT / "ground-truth.json", ground_truth)
    write_json(DRAFT / "candidate-labels.json", candidate_labels)
    write_json(DRAFT / "decision-inputs.json", decision_inputs)


def build_execution_anomaly_record() -> dict[str, Any]:
    v3_state = Path(
        "/private/tmp/voxproof-ami-authoritative-study-2026-07/"
        "v3-exact-evidence-phase-a-correction/phase-b/stage-state.json"
    )
    v5_pristine_hash = "65f8348cfdefb72a0ba64f56280408e8c3258d7fc484772a4ac41cf7a14a24b8"
    return {
        "schema_revision": "voxproof-ami-v5-review-prep-execution-anomaly-v1",
        "inherited_v3_root_command_attempt": {
            "observed": True,
            "command": [
                "python3",
                str(STUDY / "phase-b/scripts/phase_b_runner.py"),
                "preflight",
            ],
            "inherited_environment": {
                "VOXPROOF_V3_STUDY_ROOT": (
                    "/private/tmp/voxproof-ami-authoritative-study-2026-07/"
                    "v3-exact-evidence-phase-a-correction"
                )
            },
            "effective_study_root": (
                "/private/tmp/voxproof-ami-authoritative-study-2026-07/"
                "v3-exact-evidence-phase-a-correction"
            ),
            "started_at_utc": "2026-07-16T08:59:39Z",
            "ended_at_utc": "2026-07-16T08:59:39Z",
            "exit_code": 1,
            "stderr_captured": False,
            "stdout_error": (
                "terminal failed state: "
                "/private/tmp/voxproof-ami-authoritative-study-2026-07/"
                "v3-exact-evidence-phase-a-correction/phase-b/failures/"
                "20260716-073922-999959-reference/failure-record.json"
            ),
            "stages_attempted": ["preflight"],
            "did_not_execute_against_v5_tree": True,
            "root_cause": (
                "Inherited shell VOXPROOF_V3_STUDY_ROOT pointed at terminal V3 tree; "
                "runner gate() read V3 stage-state and refused preflight."
            ),
        },
        "v3_terminal_state_hashes_at_review_prep_time": {
            "stage_state_sha256": sha_file(v3_state) if v3_state.exists() else None,
            "failure_record_sha256": sha_file(
                Path(
                    "/private/tmp/voxproof-ami-authoritative-study-2026-07/"
                    "v3-exact-evidence-phase-a-correction/phase-b/failures/"
                    "20260716-073922-999959-reference/failure-record.json"
                )
            ),
        },
        "v5_pristine_stage_state_before_successful_run": {
            "sha256": v5_pristine_hash,
            "completed": [],
            "access_gate_crossed": False,
            "terminal_failed": False,
            "failure_record": None,
        },
        "successful_rerun_requirement": {
            "explicit_VOXPROOF_V3_STUDY_ROOT": str(STUDY),
            "completed_through_reference_at_utc": "2026-07-16T09:00:21Z",
        },
        "v5_tree_unmodified_by_failed_attempt": True,
    }


def copy_immutable_sources() -> list[dict[str, Any]]:
    rows = []
    for src, rel in IMMUTABLE_SOURCES:
        if not src.is_file():
            raise RuntimeError(f"missing immutable source: {src}")
        dst = PREP / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        if sha_file(src) != sha_file(dst):
            raise RuntimeError(f"source copy hash mismatch: {src}")
        rows.append(
            {
                "source_path": str(src),
                "packet_path": rel,
                "sha256": sha_file(dst),
                "bytes": dst.stat().st_size,
            }
        )
    return rows


def build_package(files: list[Path]) -> dict[str, Any]:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    zip_name = f"voxproof-v5-human-review-packet-{stamp}.zip"
    seal_name = f"package-seal-v5-human-review-packet-{stamp}.json"
    zip_path = PACKAGE_DIR / zip_name
    entries: list[dict[str, Any]] = []
    manifest = {
        "schema_revision": "voxproof-ami-v5-human-review-packet-manifest-v1",
        "generated_at_utc": utc_now(),
        "entry_count": len(files),
        "files": [
            {
                "path": str(path.relative_to(PREP)).replace("\\", "/"),
                "sha256": sha_file(path),
                "bytes": path.stat().st_size,
            }
            for path in files
        ],
    }
    manifest_bytes = json.dumps(manifest, indent=2, sort_keys=True).encode("utf-8") + b"\n"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in files:
            arc = str(path.relative_to(PREP)).replace("\\", "/")
            data = path.read_bytes()
            zf.writestr(arc, data)
            entries.append({"path": arc, "sha256": sha_bytes(data), "bytes": len(data)})
        zf.writestr("manifest.json", manifest_bytes)
        entries.append(
            {
                "path": "manifest.json",
                "sha256": sha_bytes(manifest_bytes),
                "bytes": len(manifest_bytes),
            }
        )
    seal = {
        "schema_revision": "voxproof-ami-v5-human-review-packet-detached-seal-v1",
        "zip_filename": zip_name,
        "zip_sha256": sha_file(zip_path),
        "zip_entry_count": len(entries),
        "embedded_manifest_sha256": sha_bytes(manifest_bytes),
        "entries": entries,
        "sealed_at_utc": utc_now(),
        "no_model_api_calls": True,
        "no_pipeline_stage_executed": True,
    }
    seal_path = PACKAGE_DIR / seal_name
    write_json(seal_path, seal)
    return {
        "zip_filename": zip_name,
        "zip_path": str(zip_path),
        "zip_sha256": seal["zip_sha256"],
        "seal_filename": seal_name,
        "seal_path": str(seal_path),
        "seal_sha256": sha_file(seal_path),
        "entry_count": len(entries),
    }


def main() -> int:
    if PREP.exists():
        shutil.rmtree(PREP)
    PREP.mkdir(parents=True)
    DRAFT.mkdir(parents=True)
    SOURCES.mkdir(parents=True)
    PACKAGE_DIR.mkdir(parents=True)

    cues_payload = json.loads((PARSED / "asr_cues.json").read_text(encoding="utf-8"))
    cues = cues_payload["cues"]
    if len(cues) != 258:
        raise RuntimeError(f"expected 258 cues, found {len(cues)}")

    reference_records = load_reference_records()
    reference_token_count = sum(1 for record in reference_records if record.get("tag") == "w")
    inventory = json.loads((PROBE / "candidate-inventory.json").read_text(encoding="utf-8"))
    layer_manifest = json.loads((BUILD / "layer_manifest.json").read_text(encoding="utf-8"))
    reference_manifest = json.loads(
        (BUILD / "reference-layer-manifest.json").read_text(encoding="utf-8")
    )
    terms_sha256 = sha_file(STUDY / "session-terms/session-terms.txt")

    worksheet = build_worksheet(cues, reference_records)
    glossary = build_glossary_table(cues, reference_records, worksheet)
    source_rows = copy_immutable_sources()
    build_draft_inputs(
        input_srt_sha256=layer_manifest["files"]["input.srt"],
        terms_sha256=terms_sha256,
        reference_layer_sha256=sha_file(BUILD / "reference-layer-manifest.json"),
        inventory_sha256=sha_file(PROBE / "candidate-inventory.json"),
        transcript_revision=inventory["transcript_revision"],
        reviewed_cue_count=len(cues),
        reference_token_count=reference_token_count,
    )
    anomaly = build_execution_anomaly_record()

    write_json(PREP / "cue-side-by-side-worksheet.json", {
        "schema_revision": "voxproof-ami-v5-cue-side-by-side-worksheet-v1",
        "meeting_id": MEETING_ID,
        "window": {
            "start_inclusive": str(WINDOW_START),
            "end_exclusive": str(WINDOW_END),
        },
        "cue_count": len(worksheet),
        "overlap_policy_id": "localized-time-and-cue-overlap-one-to-one-v1",
        "normalization_policy_id": "unicode-nfc-casefold-remove-punctuation-v1",
        "search_patterns": SEARCH_PATTERNS,
        "component_words": COMPONENT_WORDS,
        "rows": worksheet,
    })
    write_json(PREP / "glossary-review-table.json", {
        "schema_revision": "voxproof-ami-v5-glossary-review-table-v1",
        "meeting_id": MEETING_ID,
        "session_terms_lines": SESSION_TERMS_LINES,
        "occurrence_count": len(glossary),
        "rows": glossary,
        "human_fields_left_blank_by_design": list(BLANK_GLOSSARY_FIELDS),
    })
    write_json(PREP / "execution-anomaly-record.json", anomaly)
    write_json(
        PREP / "immutable-source-index.json",
        {
            "schema_revision": "voxproof-ami-v5-human-review-immutable-source-index-v1",
            "sources": source_rows,
        },
    )

    package_files = sorted(
        path
        for path in PREP.rglob("*")
        if path.is_file() and "package" not in path.relative_to(PREP).parts
    )
    package_summary = build_package(package_files)
    summary = {
        "schema_revision": "voxproof-ami-v5-human-review-packet-summary-v1",
        "generated_at_utc": utc_now(),
        "study_root": str(STUDY),
        "meeting_id": MEETING_ID,
        "cue_count": len(worksheet),
        "glossary_occurrence_count": len(glossary),
        "candidate_count": inventory["candidate_count"],
        "reference_token_count": reference_token_count,
        "no_model_api_calls": True,
        "no_pipeline_stage_executed": True,
        "no_frozen_artifact_modification": True,
        "package": package_summary,
    }
    write_json(PREP / "packet-summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
