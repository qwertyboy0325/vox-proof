# Phase B exact commands (V5 frozen executable envelope; do not execute in Phase A)

```sh
export VOXPROOF_V3_STUDY_ROOT="/private/tmp/voxproof-ami-authoritative-study-2026-07/v5-exact-evidence-phase-a"
cd "$VOXPROOF_V3_STUDY_ROOT"

python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" preflight
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" build-binary
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" structural-preflight
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" hypothesis
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" probe-candidates
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" reference
```

## Frozen target
meeting_id=ES2004d
window=[300.000, 900.000)
