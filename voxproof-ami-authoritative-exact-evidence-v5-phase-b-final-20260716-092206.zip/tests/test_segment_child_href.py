#!/usr/bin/env python3
"""Tests for shared AMI segment child-href grammar and expansion."""

from __future__ import annotations

import sys
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "phase-b/scripts"
sys.path.insert(0, str(SCRIPTS))

from ami_common import (  # noqa: E402
    expand_segment_child_element_ids,
    expected_words_basename_for_segment_member,
    parse_segment_child_href,
    validate_segment_child_expansions,
)

NITE = "http://nite.sourceforge.net/"


class SegmentChildHrefTests(unittest.TestCase):
    def setUp(self) -> None:
        self.member = "ASR/ASR_AS_CTM_v1.0_feb07/TS0001a.A.segments.xml"
        self.expected = "TS0001a.A.words.xml"
        self.words_order = ["A-w1", "A-w2", "A-w3", "A-w4"]

    def test_single_point_href_accepted(self) -> None:
        first, last = parse_segment_child_href(
            "TS0001a.A.words.xml#A-w2",
            expected_words_basename=self.expected,
            member=self.member,
        )
        self.assertEqual((first, last), ("A-w2", "A-w2"))
        self.assertEqual(
            expand_segment_child_element_ids(
                "TS0001a.A.words.xml#A-w2",
                expected_words_basename=self.expected,
                words_order=self.words_order,
                member=self.member,
            ),
            ["A-w2"],
        )

    def test_inclusive_range_href_accepted(self) -> None:
        self.assertEqual(
            expand_segment_child_element_ids(
                "TS0001a.A.words.xml#id(A-w1)..id(A-w3)",
                expected_words_basename=self.expected,
                words_order=self.words_order,
                member=self.member,
            ),
            ["A-w1", "A-w2", "A-w3"],
        )

    def test_mixed_valid_children_preserve_order(self) -> None:
        expansions = [
            expand_segment_child_element_ids(
                "TS0001a.A.words.xml#A-w1",
                expected_words_basename=self.expected,
                words_order=self.words_order,
                member=self.member,
            ),
            expand_segment_child_element_ids(
                "TS0001a.A.words.xml#id(A-w2)..id(A-w4)",
                expected_words_basename=self.expected,
                words_order=self.words_order,
                member=self.member,
            ),
        ]
        validate_segment_child_expansions(
            expansions, member=self.member, words_order=self.words_order
        )
        self.assertEqual(
            [element for expansion in expansions for element in expansion],
            ["A-w1", "A-w2", "A-w3", "A-w4"],
        )

    def test_wrong_words_filename_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "wrong words filename"):
            parse_segment_child_href(
                "TS0001a.B.words.xml#A-w1",
                expected_words_basename=self.expected,
                member=self.member,
            )

    def test_missing_endpoint_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "endpoint missing"):
            expand_segment_child_element_ids(
                "TS0001a.A.words.xml#missing",
                expected_words_basename=self.expected,
                words_order=self.words_order,
                member=self.member,
            )

    def test_malformed_fragment_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "malformed child href"):
            parse_segment_child_href(
                "TS0001a.A.words.xml#",
                expected_words_basename=self.expected,
                member=self.member,
            )

    def test_reverse_range_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "reverse href range"):
            expand_segment_child_element_ids(
                "TS0001a.A.words.xml#id(A-w3)..id(A-w1)",
                expected_words_basename=self.expected,
                words_order=self.words_order,
                member=self.member,
            )

    def test_duplicate_point_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "duplicate expanded token"):
            validate_segment_child_expansions(
                [["A-w1"], ["A-w1"]],
                member=self.member,
                words_order=self.words_order,
            )

    def test_overlapping_ranges_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "duplicate expanded token"):
            validate_segment_child_expansions(
                [["A-w1", "A-w2"], ["A-w2", "A-w3"]],
                member=self.member,
                words_order=self.words_order,
            )

    def test_backward_child_sequence_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "backward child sequence"):
            validate_segment_child_expansions(
                [["A-w3", "A-w4"], ["A-w1", "A-w2"]],
                member=self.member,
                words_order=self.words_order,
            )

    def test_expected_words_basename_from_segment_member(self) -> None:
        self.assertEqual(
            expected_words_basename_for_segment_member(self.member),
            "TS0001a.A.words.xml",
        )

    def test_runtime_segment_resolution_uses_shared_expansion(self) -> None:
        from ami_transform import resolve_segment_tokens
        from ami_common import Token
        from decimal import Decimal

        words = [
            Token("A", "m", element_id, "w", Decimal("1"), Decimal("2"), "x")
            for element_id in self.words_order
        ]
        segment = ET.fromstring(
            f'<segment xmlns:nite="{NITE}">'
            f'<child href="TS0001a.A.words.xml#A-w1"/>'
            f'<child href="TS0001a.A.words.xml#id(A-w2)..id(A-w3)"/>'
            f"</segment>"
        )
        tokens = resolve_segment_tokens(words, segment, "A", self.member)
        self.assertEqual([token.element_id for token in tokens], ["A-w1", "A-w2", "A-w3"])


if __name__ == "__main__":
    raise SystemExit(unittest.main(verbosity=2))
