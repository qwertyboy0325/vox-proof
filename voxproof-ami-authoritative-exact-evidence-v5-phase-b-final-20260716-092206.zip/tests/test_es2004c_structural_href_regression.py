#!/usr/bin/env python3
"""Lexical-free ES2004c disclosed structural href regression."""

from __future__ import annotations

import sys
import unittest
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "phase-b/scripts"
sys.path.insert(0, str(SCRIPTS))

from ami_common import (  # noqa: E402
    ALLOWED_ASR_TAGS,
    NITE_NS,
    expand_segment_child_element_ids,
    expected_words_basename_for_segment_member,
    local_name,
    parse_timestamp_attributes,
    validate_segment_child_expansions,
    verify_no_forbidden_lexical_fields,
)
from study_config import AUTO_PREFIX  # noqa: E402

AUTO_ZIP = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/phase-b/downloads/"
    "ami_public_auto_1.5.1.zip"
)
MEETING = "ES2004c"
EXPECTED_COUNTS = {"A": 1596, "B": 2289, "C": 2987, "D": 1918}
FORBIDDEN = {"text", "lexical_text", "matched_text", "cue_text", "lexical_text_exposed"}


def words_order_without_lexical(archive: zipfile.ZipFile, member: str) -> list[str]:
    root = ET.fromstring(archive.read(member))
    order: list[str] = []
    for element in root:
        tag = local_name(element.tag)
        if tag not in ALLOWED_ASR_TAGS:
            raise AssertionError(f"unexpected tag {tag!r} in {member}")
        element_id = element.attrib.get(f"{NITE_NS}id")
        if not element_id:
            raise AssertionError(f"missing nite:id in {member}")
        if "starttime" not in element.attrib or "endtime" not in element.attrib:
            raise AssertionError(f"missing timestamps for {element_id} in {member}")
        parse_timestamp_attributes(element.attrib["starttime"], element.attrib["endtime"])
        order.append(element_id)
    return order


class ES2004cStructuralHrefRegressionTests(unittest.TestCase):
    def test_disclosed_es2004c_child_hrefs_parse_without_lexical_emission(self) -> None:
        per_speaker: dict[str, int] = {}
        report_rows: list[dict[str, str]] = []
        with zipfile.ZipFile(AUTO_ZIP) as archive:
            for speaker, expected in EXPECTED_COUNTS.items():
                words_member = f"{AUTO_PREFIX}{MEETING}.{speaker}.words.xml"
                segments_member = f"{AUTO_PREFIX}{MEETING}.{speaker}.segments.xml"
                words_order = words_order_without_lexical(archive, words_member)
                expected_words = expected_words_basename_for_segment_member(segments_member)
                root = ET.fromstring(archive.read(segments_member))
                href_count = 0
                for segment in root:
                    if local_name(segment.tag) != "segment":
                        continue
                    expansions = []
                    for child in segment:
                        self.assertEqual(local_name(child.tag), "child")
                        href = child.attrib.get("href", "")
                        self.assertNotIn("text", child.attrib)
                        row = {
                            "member": segments_member,
                            "href": href,
                            "speaker": speaker,
                        }
                        verify_no_forbidden_lexical_fields(row)
                        report_rows.append(row)
                        expansions.append(
                            expand_segment_child_element_ids(
                                href,
                                expected_words_basename=expected_words,
                                words_order=words_order,
                                member=segments_member,
                            )
                        )
                        href_count += 1
                    validate_segment_child_expansions(
                        expansions,
                        member=segments_member,
                        words_order=words_order,
                    )
                per_speaker[speaker] = href_count
                self.assertEqual(href_count, expected)
        self.assertEqual(sum(per_speaker.values()), 8790)
        self.assertTrue(FORBIDDEN.isdisjoint(set().union(*[row.keys() for row in report_rows])))


if __name__ == "__main__":
    raise SystemExit(unittest.main(verbosity=2))
