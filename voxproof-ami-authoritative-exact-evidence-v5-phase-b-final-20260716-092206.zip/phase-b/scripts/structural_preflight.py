#!/usr/bin/env python3
"""Structural preflight: archive/member verification without lexical exposure."""

from __future__ import annotations

import json
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from ami_common import (  # noqa: E402
    ALLOWED_ASR_TAGS,
    ALLOWED_MANUAL_TAGS,
    NITE_NS,
    TIMESTAMP_POLICY_ID,
    anomaly_partition_sha256,
    classify_timestamp_interval,
    expand_segment_child_element_ids,
    expected_words_basename_for_segment_member,
    local_name,
    parse_timestamp_attributes,
    validate_segment_child_expansions,
    verify_no_forbidden_lexical_fields,
)
from ami_transform import required_auto_members, required_manual_members  # noqa: E402
from common import read_json, sha256_file, utc_now, write_json  # noqa: E402
from study_config import (  # noqa: E402
    AUTO_ZIP,
    BUILD_ROOT,
    MANUAL_ZIP,
    MEETING_ID,
    SOURCE_LOCK_PATH,
    WINDOW_END,
    WINDOW_START,
)


def verify_archives_against_source_lock() -> dict[str, str]:
    source = read_json(SOURCE_LOCK_PATH)
    archive_by_name = {row["name"]: row for row in source["archives"]}
    verified: dict[str, str] = {}
    for path, name in (
        (AUTO_ZIP, "ami_public_auto_1.5.1.zip"),
        (MANUAL_ZIP, "ami_public_manual_1.6.2.zip"),
    ):
        row = archive_by_name[name]
        actual_sha = sha256_file(path)
        if path.stat().st_size != row["bytes"] or actual_sha != row["sha256"]:
            raise RuntimeError(f"archive hash/bytes mismatch at structural access: {name}")
        verified[name] = actual_sha
    return {
        "verified_auto_archive_sha256": verified["ami_public_auto_1.5.1.zip"],
        "verified_manual_archive_sha256": verified["ami_public_manual_1.6.2.zip"],
    }


def _words_member_for_segment(segment_member: str) -> str:
    if not segment_member.endswith(".segments.xml"):
        raise ValueError(f"unexpected segment member path: {segment_member}")
    return segment_member.replace(".segments.xml", ".words.xml")


def _scan_words_member(
    archive: zipfile.ZipFile,
    member: str,
    *,
    allowed_tags: set[str],
    tolerated: list[dict[str, Any]],
    errors: list[str],
) -> tuple[int, list[str]]:
    root = ET.fromstring(archive.read(member))
    seen: set[str] = set()
    scanned = 0
    order: list[str] = []
    for element in root:
        tag = local_name(element.tag)
        if tag not in allowed_tags:
            errors.append(f"unknown tag {tag!r} in {member}")
            continue
        element_id = element.attrib.get(f"{NITE_NS}id")
        if not element_id:
            errors.append(f"missing nite:id on {tag} in {member}")
            continue
        if element_id in seen:
            errors.append(f"duplicate nite:id {element_id} in {member}")
            continue
        seen.add(element_id)
        order.append(element_id)
        if "starttime" not in element.attrib or "endtime" not in element.attrib:
            errors.append(f"missing timestamps for {element_id} in {member}")
            continue
        try:
            start, end, start_ok, end_ok = parse_timestamp_attributes(
                element.attrib["starttime"], element.attrib["endtime"]
            )
        except ValueError as error:
            errors.append(f"{element_id} in {member}: {error}")
            continue
        if not start_ok or not end_ok:
            errors.append(f"non-finite/negative timestamp for {element_id} in {member}")
            continue
        classification = classify_timestamp_interval(start, end)
        scanned += 1
        if classification == "valid":
            continue
        if classification in {
            "excluded_before_window",
            "excluded_after_window",
        }:
            tolerated.append(
                {
                    "member": member,
                    "element_id": element_id,
                    "tag": tag,
                    "raw_starttime": element.attrib["starttime"],
                    "raw_endtime": element.attrib["endtime"],
                    "exclusion_reason": (
                        "both_endpoints_strictly_before_window_start"
                        if classification == "excluded_before_window"
                        else "both_endpoints_at_or_after_window_end"
                    ),
                }
            )
            continue
        errors.append(
            f"fail-closed possibly window-relevant reversed interval for {element_id} in {member}"
        )
    return scanned, order


def _scan_segments_member(
    archive: zipfile.ZipFile,
    member: str,
    *,
    words_order: list[str],
    errors: list[str],
) -> int:
    root = ET.fromstring(archive.read(member))
    scanned = 0
    seen_segment_ids: set[str] = set()
    for segment in root:
        if local_name(segment.tag) != "segment":
            errors.append(f"unexpected root child {local_name(segment.tag)!r} in {member}")
            continue
        segment_id = segment.attrib.get(f"{NITE_NS}id")
        if not segment_id:
            errors.append(f"segment missing nite:id in {member}")
            continue
        if segment_id in seen_segment_ids:
            errors.append(f"duplicate segment nite:id {segment_id} in {member}")
            continue
        seen_segment_ids.add(segment_id)
        children = list(segment)
        if not children:
            errors.append(f"segment without child href in {member}")
            continue
        expected_words = expected_words_basename_for_segment_member(member)
        expansions: list[list[str]] = []
        child_ok = True
        for child in children:
            if local_name(child.tag) != "child":
                errors.append(
                    f"unexpected segment child {local_name(child.tag)!r} in {member}"
                )
                child_ok = False
                continue
            href = child.attrib.get("href", "")
            try:
                expansions.append(
                    expand_segment_child_element_ids(
                        href,
                        expected_words_basename=expected_words,
                        words_order=words_order,
                        member=member,
                    )
                )
            except ValueError as error:
                errors.append(str(error))
                child_ok = False
        if child_ok:
            try:
                validate_segment_child_expansions(
                    expansions, member=member, words_order=words_order
                )
                scanned += len(expansions)
            except ValueError as error:
                errors.append(str(error))
    return scanned


def run_structural_preflight() -> dict[str, Any]:
    verified_archives = verify_archives_against_source_lock()
    auto_tolerated: list[dict[str, Any]] = []
    manual_tolerated: list[dict[str, Any]] = []
    errors: list[str] = []
    member_results: list[dict[str, Any]] = []
    timestamped_elements = 0
    segment_hrefs = 0
    words_order_by_member: dict[str, list[str]] = {}

    with zipfile.ZipFile(AUTO_ZIP) as auto_archive, zipfile.ZipFile(MANUAL_ZIP) as manual_archive:
        auto_names = auto_archive.namelist()
        manual_names = manual_archive.namelist()
        if len(auto_names) != len(set(auto_names)):
            errors.append("duplicate auto archive member path")
        if len(manual_names) != len(set(manual_names)):
            errors.append("duplicate manual archive member path")
        auto_name_set = set(auto_names)
        manual_name_set = set(manual_names)

        for member in required_auto_members():
            if member not in auto_name_set:
                errors.append(f"missing auto member: {member}")
                continue
            if member.endswith(".words.xml"):
                count, order = _scan_words_member(
                    auto_archive,
                    member,
                    allowed_tags=ALLOWED_ASR_TAGS,
                    tolerated=auto_tolerated,
                    errors=errors,
                )
                words_order_by_member[member] = order
                timestamped_elements += count
                member_results.append(
                    {"member": member, "archive": AUTO_ZIP.name, "timestamped_elements": count}
                )
            else:
                words_member = _words_member_for_segment(member)
                words_order = words_order_by_member.get(words_member)
                if words_order is None:
                    errors.append(f"missing words order for segment scan: {words_member}")
                    continue
                count = _scan_segments_member(
                    auto_archive,
                    member,
                    words_order=words_order,
                    errors=errors,
                )
                segment_hrefs += count
                member_results.append(
                    {"member": member, "archive": AUTO_ZIP.name, "segment_child_hrefs": count}
                )

        for member in required_manual_members():
            if member not in manual_name_set:
                errors.append(f"missing manual member: {member}")
                continue
            count, _ = _scan_words_member(
                manual_archive,
                member,
                allowed_tags=ALLOWED_MANUAL_TAGS,
                tolerated=manual_tolerated,
                errors=errors,
            )
            timestamped_elements += count
            member_results.append(
                {"member": member, "archive": MANUAL_ZIP.name, "timestamped_elements": count}
            )

    report = {
        "schema_revision": "voxproof-ami-structural-preflight-report-v2",
        "timestamp_policy_id": TIMESTAMP_POLICY_ID,
        "meeting_id": MEETING_ID,
        "window": {
            "start_inclusive": str(WINDOW_START),
            "end_exclusive": str(WINDOW_END),
        },
        "target_member_bytes_opened": True,
        "lexical_text_fields_inspected": False,
        "lexical_text_emitted": False,
        "verified_auto_archive_sha256": verified_archives["verified_auto_archive_sha256"],
        "verified_manual_archive_sha256": verified_archives["verified_manual_archive_sha256"],
        "required_members_verified": not any("missing" in err for err in errors),
        "timestamped_element_count": timestamped_elements,
        "segment_child_href_count": segment_hrefs,
        "member_results": member_results,
        "auto_tolerated_outside_window_anomalies": auto_tolerated,
        "manual_tolerated_outside_window_anomalies": manual_tolerated,
        "tolerated_outside_window_anomalies": auto_tolerated + manual_tolerated,
        "tolerated_anomaly_count": len(auto_tolerated) + len(manual_tolerated),
        "structural_error_count": len(errors),
        "structural_errors": errors,
        "fail_closed": bool(errors),
        "completed_at_utc": utc_now(),
    }
    verify_no_forbidden_lexical_fields(report)
    out = BUILD_ROOT.parent / "structural-preflight-report.json"
    write_json(out, report)
    if errors:
        raise RuntimeError("; ".join(errors))
    return {
        "structural_preflight_report_sha256": sha256_file(out),
        "report_path": str(out),
        "verified_auto_archive_sha256": verified_archives["verified_auto_archive_sha256"],
        "verified_manual_archive_sha256": verified_archives["verified_manual_archive_sha256"],
        "target_member_bytes_opened": True,
        "lexical_text_fields_inspected": False,
        "lexical_text_emitted": False,
        "timestamp_policy_id": TIMESTAMP_POLICY_ID,
        "meeting_id": MEETING_ID,
        "window": report["window"],
        "auto_anomaly_partition_sha256": anomaly_partition_sha256(auto_tolerated),
        "manual_anomaly_partition_sha256": anomaly_partition_sha256(manual_tolerated),
        "tolerated_anomaly_count": len(auto_tolerated) + len(manual_tolerated),
        "timestamped_element_count": timestamped_elements,
    }


def main() -> int:
    try:
        result = run_structural_preflight()
    except Exception as error:
        print(json.dumps({"status": "fail", "error": str(error)}, indent=2))
        return 1
    print(json.dumps({"status": "pass", "result": result}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
