#!/usr/bin/env python3
"""Fail-closed Phase A package verifier with manifest/seal closure checks."""

from __future__ import annotations

import json
import sys
import zipfile
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from common import is_unsafe_zip_path, sha256_bytes, sha256_file  # noqa: E402


def verify_package(
    root: Path, zip_path: Path, seal_path: Path, expected_mode: str | None = None
) -> dict[str, Any]:
    errors: list[str] = []
    if not zip_path.exists():
        return {"status": "fail", "errors": ["missing zip"]}
    if not seal_path.exists():
        return {"status": "fail", "errors": ["missing detached seal"]}

    seal = json.loads(seal_path.read_text(encoding="utf-8"))
    zip_sha = sha256_file(zip_path)
    if seal.get("zip_sha256") != zip_sha:
        errors.append("detached seal zip_sha256 mismatch")

    with zipfile.ZipFile(zip_path) as zf:
        names = sorted(zf.namelist())
        seen: set[str] = set()
        zip_entries: list[dict[str, Any]] = []
        for name in names:
            if is_unsafe_zip_path(name):
                errors.append(f"unsafe zip path: {name}")
            if name in seen:
                errors.append(f"duplicate zip path: {name}")
            seen.add(name)
            data = zf.read(name)
            zip_entries.append({"path": name, "sha256": sha256_bytes(data), "bytes": len(data)})

    seal_entries = {entry["path"]: entry for entry in seal.get("entries", [])}
    zip_entry_map = {entry["path"]: entry for entry in zip_entries}
    if set(seal_entries) != set(zip_entry_map):
        errors.append("seal entry set does not match zip entry set")
    for path, meta in seal_entries.items():
        actual = zip_entry_map.get(path)
        if not actual:
            continue
        if actual["sha256"] != meta["sha256"]:
            errors.append(f"seal hash mismatch: {path}")
        if actual["bytes"] != meta["bytes"]:
            errors.append(f"seal byte length mismatch: {path}")

    if "manifest.json" not in names:
        errors.append("missing embedded manifest.json")
    else:
        with zipfile.ZipFile(zip_path) as zf:
            embedded_manifest = json.loads(zf.read("manifest.json"))
        if expected_mode and embedded_manifest.get("mode") != expected_mode:
            errors.append("package manifest mode mismatch")
        manifest_files = {item["path"]: item for item in embedded_manifest.get("files", [])}
        ordinary = [name for name in names if name != "manifest.json"]
        if embedded_manifest.get("entry_count") != len(ordinary):
            errors.append("manifest entry_count mismatch with ordinary zip entries")
        if set(manifest_files) != set(ordinary):
            missing = sorted(set(manifest_files) - set(ordinary))
            extra = sorted(set(ordinary) - set(manifest_files))
            if missing:
                errors.append(f"manifest lists missing zip entries: {missing[:3]}")
            if extra:
                errors.append(f"zip entries missing from manifest: {extra[:3]}")
        for path, meta in manifest_files.items():
            actual = zip_entry_map[path]
            if actual["sha256"] != meta["sha256"]:
                errors.append(f"manifest hash mismatch: {path}")
            if actual["bytes"] != meta["bytes"]:
                errors.append(f"manifest byte length mismatch: {path}")
        manifest_sha = sha256_bytes(json.dumps(embedded_manifest, indent=2, sort_keys=True).encode("utf-8") + b"\n")
        on_disk_manifest = root / "manifest.json"
        if on_disk_manifest.exists():
            if manifest_sha != sha256_file(on_disk_manifest):
                errors.append("embedded manifest hash mismatch with on-disk manifest.json")

    if seal.get("zip_entry_count") != len(names):
        errors.append("seal zip_entry_count mismatch")
    if seal.get("embedded_manifest_sha256") != zip_entry_map.get("manifest.json", {}).get("sha256"):
        errors.append("seal embedded_manifest_sha256 mismatch")

    required = ["phase-b/script-lock.json", "session-terms/session-terms.txt"]
    if expected_mode == "phase-a":
        required += [
            "phase-a-design.md",
            "pre-run-freeze.json",
            "phase-b-commands.md",
            "access-boundary-statement.json",
            "target-selection-evidence.json",
        ]
    elif expected_mode == "phase-b":
        required += [
            "phase-b/metrics.json",
            "phase-b/review/authoritative-review-binding.json",
            "phase-b/reports/independent-verifier-output.json",
            "phase-b/structural-preflight-report.json",
        ]
    for req in required:
        if req not in names:
            errors.append(f"missing required entry: {req}")

    if expected_mode == "phase-b":
        source_lock_path = root / "source-lock.json"
        structural_report_path = "phase-b/structural-preflight-report.json"
        hypothesis_manifest_path = "phase-b/build-primary/layer_manifest.json"
        reference_manifest_path = "phase-b/build-primary/reference-layer-manifest.json"
        if source_lock_path.is_file():
            source_lock = json.loads(source_lock_path.read_text(encoding="utf-8"))
            archives = {row["name"]: row for row in source_lock.get("archives", [])}
            auto_row = archives.get("ami_public_auto_1.5.1.zip", {})
            manual_row = archives.get("ami_public_manual_1.6.2.zip", {})
            with zipfile.ZipFile(zip_path) as zf:
                structural_report = None
                if structural_report_path in names:
                    structural_report = json.loads(zf.read(structural_report_path))
                if hypothesis_manifest_path in names:
                    hypothesis_manifest = json.loads(zf.read(hypothesis_manifest_path))
                    for field in ("archive_sha256_at_read", "archive_bytes_at_read"):
                        if field not in hypothesis_manifest:
                            errors.append(f"phase-b package missing hypothesis manifest {field}")
                    if hypothesis_manifest.get("archive_sha256_at_read") != auto_row.get("sha256"):
                        errors.append("phase-b hypothesis archive_sha256_at_read mismatch")
                    if hypothesis_manifest.get("archive_bytes_at_read") != auto_row.get("bytes"):
                        errors.append("phase-b hypothesis archive_bytes_at_read mismatch")
                    if structural_report and hypothesis_manifest.get(
                        "archive_sha256_at_read"
                    ) != structural_report.get("verified_auto_archive_sha256"):
                        errors.append(
                            "phase-b hypothesis archive_sha256_at_read mismatch with structural-preflight"
                        )
                else:
                    errors.append("phase-b package missing hypothesis layer manifest")
                if reference_manifest_path in names:
                    reference_manifest = json.loads(zf.read(reference_manifest_path))
                    for field in ("archive_sha256_at_read", "archive_bytes_at_read"):
                        if field not in reference_manifest:
                            errors.append(f"phase-b package missing reference manifest {field}")
                    if reference_manifest.get("archive_sha256_at_read") != manual_row.get("sha256"):
                        errors.append("phase-b reference archive_sha256_at_read mismatch")
                    if reference_manifest.get("archive_bytes_at_read") != manual_row.get("bytes"):
                        errors.append("phase-b reference archive_bytes_at_read mismatch")
                    if structural_report and reference_manifest.get(
                        "archive_sha256_at_read"
                    ) != structural_report.get("verified_manual_archive_sha256"):
                        errors.append(
                            "phase-b reference archive_sha256_at_read mismatch with structural-preflight"
                        )
                else:
                    errors.append("phase-b package missing reference layer manifest")
        else:
            errors.append("phase-b package verification missing source-lock.json on disk")

    return {
        "status": "pass" if not errors else "fail",
        "errors": errors,
        "zip_sha256": zip_sha,
        "entry_count": len(names),
        "embedded_manifest_sha256": zip_entry_map.get("manifest.json", {}).get("sha256"),
        "entries": zip_entries,
    }


def main() -> int:
    if len(sys.argv) < 3:
        print(
            "usage: package_verifier.py <study_root> <zip_path> <seal_path> [phase-a|phase-b]",
            file=sys.stderr,
        )
        return 2
    root = Path(sys.argv[1]).resolve()
    zip_path = Path(sys.argv[2]).resolve()
    seal_path = Path(sys.argv[3]).resolve() if len(sys.argv) > 3 else root / "package" / sorted((root / "package").glob("package-seal-*.json"))[-1]
    mode = sys.argv[4] if len(sys.argv) > 4 else None
    out = verify_package(root, zip_path, seal_path, mode)
    output = root / ("outputs" if mode == "phase-a" else "phase-b/reports") / "package-verification-output.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": out["status"], "zip_sha256": out.get("zip_sha256"), "entry_count": out.get("entry_count")}, indent=2))
    return 0 if out["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
