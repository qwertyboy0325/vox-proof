#!/usr/bin/env python3
"""Resolve V5 metadata-only target and freeze study configuration."""

from __future__ import annotations

import json
import re
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROTOCOL_ID = "voxproof-ami-authoritative-exact-evidence-v5"
RULE_ID = "lexicographic-after-ES2004a-complete-members-duration-ge-900-v1"
EXCLUDED = {
    "ES2004a": "prior AMI scenario meeting excluded by frozen lexicographic selection rule",
    "ES2004b": "preserved V3 terminal reference-stage failure; excluded from later protocols",
    "ES2004c": "preserved V4 terminal structural-preflight child-href failure; regression input only",
}
V4_PRESERVED = {
    "study_root": "/private/tmp/voxproof-ami-authoritative-study-2026-07/v4-exact-evidence-phase-a",
    "stage_state_sha256": "0683a46f73fcd690dbf6c105ddb23b141b8653cb246af7e576a15d827ba4f82a",
    "failure_record_sha256": "9bddf194f8de67d832af6ab4e0eb8d728761aabae027912e17c8b1508d07a19b",
    "structural_report_sha256": "a05057f82f264296b38742af9dbfe80c8b8596f7dec143a9e2ba83c9c9aa87f8",
    "failure_handoff_zip_sha256": "07c360764b4a6a34390c6abc5eec36d8efa25942342f95469b2e3474d11a4b1e",
    "failure_handoff_seal_sha256": "232e7bf15eb6a5ab9b3227cc1a4b9c4958d9626adef1131fe81bca98473039f5",
}


def resolve_target() -> dict[str, object]:
    inv = json.loads((ROOT / "references/archive-member-inventories.json").read_text())
    auto_paths = {m["path"] for m in inv["ami_public_auto_1.5.1.zip"]}
    manual_paths = {m["path"] for m in inv["ami_public_manual_1.6.2.zip"]}
    signals = (ROOT / "attribution/pages/corpus_signals.shtml.html").read_text(
        encoding="utf-8", errors="replace"
    )
    durations = {
        mid: int(sec)
        for mid, sec in re.findall(
            r"<tr>\s*<td>([A-Z]{2}\d{4}[a-z])</td>.*?<td class=\"xl24\" align=\"right\">(\d+)</td>",
            signals,
            re.S,
        )
    }
    auto_prefix = "ASR/ASR_AS_CTM_v1.0_feb07/"
    pat = re.compile(rf"^{re.escape(auto_prefix)}([A-Z]{{2}}\d{{4}}[a-z])\.([A-D])\.words\.xml$")
    meetings = set()
    for path in auto_paths:
        match = pat.match(path)
        if match:
            meetings.add(match.group(1))
    ordered = sorted(
        mid for mid in meetings if mid > "ES2004a" and mid not in EXCLUDED
    )
    rows = []
    resolved = None
    for mid in ordered:
        req = [f"{auto_prefix}{mid}.{sp}.words.xml" for sp in "ABCD"] + [
            f"{auto_prefix}{mid}.{sp}.segments.xml" for sp in "ABCD"
        ] + [f"words/{mid}.{sp}.words.xml" for sp in "ABCD"]
        present = {
            member: (
                member in auto_paths if member.startswith("ASR/") else member in manual_paths
            )
            for member in req
        }
        complete = all(present.values())
        duration = durations.get(mid)
        eligible = complete and duration is not None and duration >= 900
        row = {
            "meeting_id": mid,
            "complete_required_members": complete,
            "duration_seconds": duration,
            "eligible": eligible,
            "missing_members": [k for k, v in present.items() if not v],
            "required_members": req,
        }
        rows.append(row)
        if eligible and resolved is None:
            resolved = row
    if resolved is None:
        raise SystemExit(f"target resolution failed: {resolved}")
    return {
        "resolved": resolved,
        "rows": rows,
        "eligible_count": sum(1 for row in rows if row["eligible"]),
    }


def write_href_spec() -> None:
    (ROOT / "segment-child-href-grammar-spec.json").write_text(
        json.dumps(
            {
                "schema_revision": "voxproof-ami-segment-child-href-grammar-v2",
                "grammar_id": "ami-segment-child-href-v2",
                "supported_forms": [
                    {
                        "form_id": "single-point",
                        "pattern": "<words-filename>#<element-id>",
                        "example": "ES2004c.A.words.xml#ES2004c.A.sil2289",
                    },
                    {
                        "form_id": "inclusive-range",
                        "pattern": "<words-filename>#id(<first-id>)..id(<last-id>)",
                        "example": "TS0001a.A.words.xml#id(A-w1)..id(A-w2)",
                    },
                ],
                "requirements": [
                    "referenced filename must exactly equal expected speaker words basename",
                    "fragment must match exactly one supported grammar",
                    "every referenced endpoint must exist in frozen words order",
                    "range must be forward",
                    "single point expands to exactly one token",
                    "range expands inclusively",
                    "child order preserved",
                    "duplicate overlapping or backward expanded references within one segment fail closed",
                    "structural and runtime expansion share one implementation",
                ],
                "forbidden_fields": ["text", "lexical_text", "matched_text", "cue_text"],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


def write_metadata(target: dict[str, object]) -> str:
    resolved = target["resolved"]
    meeting_id = resolved["meeting_id"]
    rule = {
        "schema_revision": "voxproof-ami-target-selection-rule-v1",
        "protocol_id": PROTOCOL_ID,
        "rule_id": RULE_ID,
        "excluded_meeting_ids": sorted(EXCLUDED),
        "minimum_duration_seconds": 900,
        "window": {"start_inclusive": "300.000", "end_exclusive": "900.000"},
        "fail_closed": True,
        "reselection_on_structural_failure": False,
    }
    evidence = {
        "schema_revision": "voxproof-ami-target-selection-evidence-v2",
        "protocol_id": PROTOCOL_ID,
        "resolved_meeting_id": meeting_id,
        "resolved_duration_seconds": resolved["duration_seconds"],
        "resolved_required_members": resolved["required_members"],
        "eligible_count": target["eligible_count"],
        "candidate_scan_first_10": target["rows"][:10],
        "metadata_only_resolution": True,
        "excluded_meeting_disclosures": [
            {"meeting_id": mid, "reason": reason} for mid, reason in sorted(EXCLUDED.items())
        ],
        f"{meeting_id.lower()}_lexical_content_opened": False,
    }
    (ROOT / "target-selection-rule.json").write_text(json.dumps(rule, indent=2) + "\n")
    (ROOT / "target-selection-evidence.json").write_text(
        json.dumps(evidence, indent=2) + "\n", encoding="utf-8"
    )
    source = json.loads((ROOT / "source-lock.json").read_text(encoding="utf-8"))
    source["protocol_id"] = PROTOCOL_ID
    source["meeting_id"] = meeting_id
    source["prior_artifacts_preserved"] = {
        **source.get("prior_artifacts_preserved", {}),
        "v4_phase_a_zip": "voxproof-ami-authoritative-exact-evidence-v4-phase-a-20260716-082828.zip",
        "v4_phase_a_seal": "package-seal-v4-phase-a-20260716-082828.json",
        "v4_terminal_study_root": V4_PRESERVED["study_root"],
        "v4_failure_handoff_zip_sha256": V4_PRESERVED["failure_handoff_zip_sha256"],
    }
    (ROOT / "source-lock.json").write_text(json.dumps(source, indent=2) + "\n", encoding="utf-8")
    (ROOT / "pre-run-freeze.json").write_text(
        json.dumps(
            {
                "schema_revision": "voxproof-ami-pre-run-freeze-v1",
                "protocol_id": PROTOCOL_ID,
                "meeting_id": meeting_id,
                "window": {"start_inclusive": "300.000", "end_exclusive": "900.000"},
                "selection_rule_id": RULE_ID,
                "excluded_meeting_ids": sorted(EXCLUDED),
                "timestamp_policy_id": "window-local-timestamp-integrity-v1",
                "segment_child_href_grammar_id": "ami-segment-child-href-v2",
                "structural_preflight_required": True,
                f"{meeting_id.lower()}_lexical_content_opened": False,
                "phase_a_structural_preflight_on_production_target": False,
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return meeting_id


def patch_study_config(meeting_id: str) -> None:
    path = ROOT / "phase-b/scripts/study_config.py"
    text = path.read_text(encoding="utf-8")
    text = text.replace(
        '    "/private/tmp/voxproof-ami-authoritative-study-2026-07/"\n    "v4-exact-evidence-phase-a"',
        '    "/private/tmp/voxproof-ami-authoritative-study-2026-07/"\n    "v5-exact-evidence-phase-a"',
    )
    text = text.replace('FROZEN_MEETING_ID = "ES2004c"', f'FROZEN_MEETING_ID = "{meeting_id}"')
    text = text.replace(
        'PROTOCOL_ID = "voxproof-ami-authoritative-exact-evidence-v4"',
        f'PROTOCOL_ID = "{PROTOCOL_ID}"',
    )
    path.write_text(text, encoding="utf-8")


def write_access_boundary(meeting_id: str) -> None:
    payload = {
        "schema_revision": "voxproof-ami-access-boundary-v4",
        "protocol_id": PROTOCOL_ID,
        "frozen_target": {
            "meeting_id": meeting_id,
            "window": {"start_inclusive": "300.000", "end_exclusive": "900.000"},
            "excluded_meeting_ids": sorted(EXCLUDED),
        },
        "excluded_meeting_disclosures": [
            {"meeting_id": mid, "reason": reason} for mid, reason in sorted(EXCLUDED.items())
        ],
        "preserved_v4_terminal_tree": V4_PRESERVED,
        "confirmed_prohibited_operations_not_performed": [
            f"No {meeting_id} target member was opened, extracted, decompressed, read, or parsed during V5 Phase A.",
            "No production V5 structural-preflight stage has run.",
            "No V5 Phase B stage was executed.",
            "No candidate generation, human review, scoring, retry, fallback, or reselection was run for the V5 target.",
        ],
        "confirmed_unopened_target_content": [
            f"ASR/ASR_AS_CTM_v1.0_feb07/{meeting_id}.*.words.xml",
            f"ASR/ASR_AS_CTM_v1.0_feb07/{meeting_id}.*.segments.xml",
            f"words/{meeting_id}.*.words.xml",
        ],
        "es2004c_structural_regression_input_only": True,
        f"{meeting_id.lower()}_lexical_content_opened": False,
        "fixture_rehearsals_only": True,
        "no_model_api_calls": True,
        "no_repository_modification": True,
        "no_target_scoring": True,
        "phase_a_structural_preflight_on_production_target": False,
        "metadata_only_target_selection": True,
    }
    (ROOT / "access-boundary-statement.json").write_text(
        json.dumps(payload, indent=2) + "\n", encoding="utf-8"
    )


def write_phase_b_commands(meeting_id: str) -> None:
    (ROOT / "phase-b-commands.md").write_text(
        textwrap.dedent(
            f"""\
            # Phase B exact commands (V5 frozen executable envelope; do not execute in Phase A)

            ```sh
            export VOXPROOF_V3_STUDY_ROOT="{ROOT}"
            cd "$VOXPROOF_V3_STUDY_ROOT"

            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" preflight
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" build-binary
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" structural-preflight
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" hypothesis
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" probe-candidates
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" reference
            ```

            ## Frozen target
            meeting_id={meeting_id}
            window=[300.000, 900.000)
            """
        ),
        encoding="utf-8",
    )


def main() -> int:
    write_href_spec()
    target = resolve_target()
    meeting_id = write_metadata(target)
    patch_study_config(meeting_id)
    write_access_boundary(meeting_id)
    write_phase_b_commands(meeting_id)
    print(
        json.dumps(
            {
                "status": "implemented",
                "protocol_id": PROTOCOL_ID,
                "resolved_meeting_id": meeting_id,
                "eligible_count": target["eligible_count"],
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
