#!/usr/bin/env python3
"""One-shot V4 Phase A implementation inside the fresh study tree."""

from __future__ import annotations

import json
import re
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCRIPTS = ROOT / "phase-b/scripts"
TESTS = ROOT / "tests"

STRUCTURAL_PREFLIGHT = textwrap.dedent('''\
#!/usr/bin/env python3
"""Structural preflight: archive/member verification without lexical exposure."""

from __future__ import annotations

import json
import sys
import zipfile
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from ami_common import (  # noqa: E402
    ALLOWED_ASR_TAGS,
    ALLOWED_MANUAL_TAGS,
    HREF_RE,
    NITE_NS,
    TIMESTAMP_POLICY_ID,
    classify_timestamp_interval,
    local_name,
    parse_timestamp_attributes,
)
from ami_transform import required_auto_members, required_manual_members  # noqa: E402
from common import sha256_file, utc_now, write_json  # noqa: E402
from study_config import (  # noqa: E402
    AUTO_ZIP,
    BUILD_ROOT,
    MANUAL_ZIP,
    MEETING_ID,
    PHASE_B_DIR,
    WINDOW_END,
    WINDOW_START,
)

FORBIDDEN_REPORT_KEYS = {"text", "lexical_text", "matched_text", "cue_text"}


def _scan_words_member(
    archive: zipfile.ZipFile,
    member: str,
    *,
    allowed_tags: set[str],
    tolerated: list[dict[str, Any]],
    errors: list[str],
) -> int:
    root = __import__("xml.etree.ElementTree", fromlist=["ElementTree"]).ElementTree.fromstring(
        archive.read(member)
    )
    seen: set[str] = set()
    scanned = 0
    for element in root:
        tag = local_name(element.tag)
        if tag not in allowed_tags:
            errors.append(f"unknown tag {tag!r} in {member}")
            continue
        element_id = element.attrib.get(f"{NITE_NS}id")
        if not element_id:
            errors.append(f"missing nite:id on {tag} in {member}")
            continue
        if element_id in seen:
            errors.append(f"duplicate nite:id {element_id} in {member}")
            continue
        seen.add(element_id)
        if "starttime" not in element.attrib or "endtime" not in element.attrib:
            errors.append(f"missing timestamps for {element_id} in {member}")
            continue
        try:
            start, end, start_ok, end_ok = parse_timestamp_attributes(
                element.attrib["starttime"], element.attrib["endtime"]
            )
        except ValueError as error:
            errors.append(f"{element_id} in {member}: {error}")
            continue
        if not start_ok or not end_ok:
            errors.append(f"non-finite/negative timestamp for {element_id} in {member}")
            continue
        classification = classify_timestamp_interval(start, end)
        scanned += 1
        if classification == "valid":
            continue
        if classification in {
            "excluded_before_window",
            "excluded_after_window",
        }:
            tolerated.append(
                {
                    "member": member,
                    "element_id": element_id,
                    "tag": tag,
                    "raw_starttime": element.attrib["starttime"],
                    "raw_endtime": element.attrib["endtime"],
                    "exclusion_reason": (
                        "both_endpoints_strictly_before_window_start"
                        if classification == "excluded_before_window"
                        else "both_endpoints_at_or_after_window_end"
                    ),
                }
            )
            continue
        errors.append(
            f"fail-closed possibly window-relevant reversed interval for {element_id} in {member}"
        )
    return scanned


def _scan_segments_member(archive: zipfile.ZipFile, member: str, *, errors: list[str]) -> int:
    root = __import__("xml.etree.ElementTree", fromlist=["ElementTree"]).ElementTree.fromstring(
        archive.read(member)
    )
    scanned = 0
    for segment in root:
        if local_name(segment.tag) != "segment":
            errors.append(f"unexpected root child {local_name(segment.tag)!r} in {member}")
            continue
        for child in segment:
            if local_name(child.tag) != "child":
                errors.append(
                    f"unexpected segment child {local_name(child.tag)!r} in {member}"
                )
                continue
            href = child.attrib.get("href", "")
            if not HREF_RE.match(href):
                errors.append(f"malformed child href in {member}: {href!r}")
                continue
            scanned += 1
    return scanned


def run_structural_preflight() -> dict[str, Any]:
    tolerated: list[dict[str, Any]] = []
    errors: list[str] = []
    member_results: list[dict[str, Any]] = []
    timestamped_elements = 0
    segment_hrefs = 0
    with zipfile.ZipFile(AUTO_ZIP) as auto_archive, zipfile.ZipFile(MANUAL_ZIP) as manual_archive:
        auto_names = set(auto_archive.namelist())
        manual_names = set(manual_archive.namelist())
        for member in required_auto_members():
            if member not in auto_names:
                errors.append(f"missing auto member: {member}")
                continue
            if member.endswith(".words.xml"):
                count = _scan_words_member(
                    auto_archive,
                    member,
                    allowed_tags=ALLOWED_ASR_TAGS,
                    tolerated=tolerated,
                    errors=errors,
                )
                timestamped_elements += count
                member_results.append({"member": member, "archive": AUTO_ZIP.name, "timestamped_elements": count})
            else:
                count = _scan_segments_member(auto_archive, member, errors=errors)
                segment_hrefs += count
                member_results.append({"member": member, "archive": AUTO_ZIP.name, "segment_child_hrefs": count})
        for member in required_manual_members():
            if member not in manual_names:
                errors.append(f"missing manual member: {member}")
                continue
            count = _scan_words_member(
                manual_archive,
                member,
                allowed_tags=ALLOWED_MANUAL_TAGS,
                tolerated=tolerated,
                errors=errors,
            )
            timestamped_elements += count
            member_results.append({"member": member, "archive": MANUAL_ZIP.name, "timestamped_elements": count})
    report = {
        "schema_revision": "voxproof-ami-structural-preflight-report-v1",
        "timestamp_policy_id": TIMESTAMP_POLICY_ID,
        "meeting_id": MEETING_ID,
        "window": {
            "start_inclusive": str(WINDOW_START),
            "end_exclusive": str(WINDOW_END),
        },
        "lexical_text_exposed": False,
        "required_members_verified": not any("missing" in err for err in errors),
        "timestamped_element_count": timestamped_elements,
        "segment_child_href_count": segment_hrefs,
        "member_results": member_results,
        "tolerated_outside_window_anomalies": tolerated,
        "tolerated_anomaly_count": len(tolerated),
        "structural_error_count": len(errors),
        "structural_errors": errors,
        "fail_closed": bool(errors),
        "completed_at_utc": utc_now(),
    }
    for key in FORBIDDEN_REPORT_KEYS:
        if key in report:
            raise RuntimeError(f"forbidden lexical field in structural report: {key}")
    out = BUILD_ROOT.parent / "structural-preflight-report.json"
    write_json(out, report)
    if errors:
        raise RuntimeError("; ".join(errors))
    return {
        "structural_preflight_report_sha256": sha256_file(out),
        "report_path": str(out),
        "tolerated_anomaly_count": len(tolerated),
        "timestamped_element_count": timestamped_elements,
        "lexical_text_exposed": False,
    }


def main() -> int:
    try:
        result = run_structural_preflight()
    except Exception as error:
        print(json.dumps({"status": "fail", "error": str(error)}, indent=2))
        return 1
    print(json.dumps({"status": "pass", "result": result}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
''')

TEST_TIMESTAMP_POLICY = textwrap.dedent('''\
#!/usr/bin/env python3
"""Frozen window-local timestamp policy and structural-preflight tests."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "phase-b/scripts"
REPO = Path("/Users/Ezra4/Coding/Repo/vox-proof")
sys.path.insert(0, str(SCRIPTS))

from ami_common import (  # noqa: E402
    TIMESTAMP_POLICY_ID,
    classify_timestamp_interval,
    parse_timestamp_attributes,
    parse_tokens,
)
from common import sha256_file, write_json  # noqa: E402
from structural_preflight import run_structural_preflight  # noqa: E402

NITE = "http://nite.sourceforge.net/"
V3_STUDY = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-a-correction"
)
V3_FORENSIC = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/v3-phase-b-forensic-diagnosis-20260716"
)
FORENSIC_ZIP = V3_FORENSIC / "package/voxproof-phase-b-forensic-diagnosis-20260716.zip"
FORENSIC_SEAL = V3_FORENSIC / "package/package-seal-phase-b-forensic-diagnosis-20260716.json"
V3_STAGE_STATE = V3_STUDY / "phase-b/stage-state.json"
V3_FAILURE = (
    V3_STUDY
    / "phase-b/failures/20260716-073922-999959-reference/failure-record.json"
)

PRESERVED_HASHES = {
    "v3_stage_state": "b19b022df63a3737acfee1019e1ffe3d803bb1b656af6898fbf254f27ea054a2",
    "v3_failure_record": "8078f9e1bcd5eceb396276d734c6aaf0f3400ddf75358e339ac9977f159d641f",
    "forensic_zip": "543185326470b1ffde569be67282e2b2da27a3086a55080ae792c1e1c80fdf42",
    "forensic_seal": "6eb6ae180362b729f48e489ce800a6040ab2b5b8130c23e93c9dd2c6ccd448a2",
}


def element_xml(tag: str, element_id: str, start: str, end: str, text: str = "x") -> str:
    if tag == "w":
        return f'<w nite:id="{element_id}" starttime="{start}" endtime="{end}">{text}</w>'
    return f'<{tag} nite:id="{element_id}" starttime="{start}" endtime="{end}"/>'


def words_root(*elements: str) -> bytes:
    body = "".join(elements)
    return f'<words xmlns:nite="{NITE}">{body}</words>'.encode()


class TimestampPolicyTests(unittest.TestCase):
    def test_es2004b_words1260_regression_recorded_and_excluded(self) -> None:
        xml = words_root(
            element_xml("disfmarker", "ES2004b.A.words1260", "2329.81", "2329.68")
        )
        root = __import__("xml.etree.ElementTree", fromlist=["ElementTree"]).ElementTree.fromstring(xml)
        excluded: list[dict[str, object]] = []
        tokens = parse_tokens(
            root,
            speaker="A",
            member="words/ES2004b.A.words.xml",
            allowed_tags={"w", "disfmarker", "gap", "vocalsound"},
            excluded_collector=excluded,
        )
        self.assertEqual(tokens, [])
        self.assertEqual(len(excluded), 1)
        row = excluded[0]
        self.assertEqual(row["element_id"], "ES2004b.A.words1260")
        self.assertEqual(row["tag"], "disfmarker")
        self.assertEqual(row["raw_starttime"], "2329.81")
        self.assertEqual(row["raw_endtime"], "2329.68")
        self.assertEqual(
            row["exclusion_reason"], "both_endpoints_at_or_after_window_end"
        )
        self.assertNotIn("text", row)

    def test_reversed_lexical_after_window_excluded(self) -> None:
        excluded: list[dict[str, object]] = []
        root = __import__("xml.etree.ElementTree", fromlist=["ElementTree"]).ElementTree.fromstring(
            words_root(element_xml("w", "t1", "950.00", "940.00", "alpha"))
        )
        tokens = parse_tokens(
            root,
            speaker="A",
            member="m",
            allowed_tags={"w"},
            excluded_collector=excluded,
        )
        self.assertEqual(tokens, [])
        self.assertEqual(excluded[0]["exclusion_reason"], "both_endpoints_at_or_after_window_end")

    def test_reversed_lexical_before_window_excluded(self) -> None:
        excluded: list[dict[str, object]] = []
        root = __import__("xml.etree.ElementTree", fromlist=["ElementTree"]).ElementTree.fromstring(
            words_root(element_xml("w", "t1", "120.00", "110.00", "beta"))
        )
        tokens = parse_tokens(
            root,
            speaker="A",
            member="m",
            allowed_tags={"w"},
            excluded_collector=excluded,
        )
        self.assertEqual(tokens, [])
        self.assertEqual(
            excluded[0]["exclusion_reason"], "both_endpoints_strictly_before_window_start"
        )

    def test_reversed_inside_window_fails(self) -> None:
        root = __import__("xml.etree.ElementTree", fromlist=["ElementTree"]).ElementTree.fromstring(
            words_root(element_xml("w", "t1", "500.00", "400.00", "gamma"))
        )
        with self.assertRaisesRegex(ValueError, "possibly window-relevant"):
            parse_tokens(root, speaker="A", member="m", allowed_tags={"w"})

    def test_reversed_straddling_boundary_fails(self) -> None:
        root = __import__("xml.etree.ElementTree", fromlist=["ElementTree"]).ElementTree.fromstring(
            words_root(element_xml("w", "t1", "850.00", "250.00", "delta"))
        )
        with self.assertRaisesRegex(ValueError, "possibly window-relevant"):
            parse_tokens(root, speaker="A", member="m", allowed_tags={"w"})

    def test_negative_timestamp_fails(self) -> None:
        with self.assertRaises(ValueError):
            parse_timestamp_attributes("-1.0", "2.0")

    def test_nan_infinite_timestamp_fails(self) -> None:
        with self.assertRaises(ValueError):
            parse_timestamp_attributes("NaN", "1.0")
        with self.assertRaises(ValueError):
            parse_timestamp_attributes("1.0", "Infinity")

    def test_tolerated_malformed_never_in_reference_ledgers(self) -> None:
        excluded: list[dict[str, object]] = []
        root = __import__("xml.etree.ElementTree", fromlist=["ElementTree"]).ElementTree.fromstring(
            words_root(
                element_xml("w", "ok", "400.00", "401.00", "keep"),
                element_xml("disfmarker", "bad", "2329.81", "2329.68"),
            )
        )
        tokens = parse_tokens(
            root,
            speaker="A",
            member="m",
            allowed_tags={"w", "disfmarker"},
            excluded_collector=excluded,
        )
        self.assertEqual([token.element_id for token in tokens], ["ok"])
        self.assertEqual(len(excluded), 1)

    def test_structural_preflight_report_has_no_lexical_fields(self) -> None:
        from test_correction_rehearsals import FixtureStudy

        with tempfile.TemporaryDirectory() as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=False)
            fixture.setup()
            fixture.run("preflight")
            fixture.run("build-binary")
            fixture.run("structural-preflight")
            report_path = fixture.root / "phase-b/structural-preflight-report.json"
            payload = json.loads(report_path.read_text(encoding="utf-8"))
            self.assertFalse(payload["lexical_text_exposed"])
            serialized = json.dumps(payload)
            self.assertNotIn("lexical_text", serialized)
            for anomaly in payload.get("tolerated_outside_window_anomalies", []):
                self.assertNotIn("text", anomaly)

    def test_structural_preflight_mutation_blocks_hypothesis(self) -> None:
        from test_correction_rehearsals import FixtureStudy

        with tempfile.TemporaryDirectory() as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=False)
            fixture.setup()
            for stage in ("preflight", "build-binary", "structural-preflight"):
                fixture.run(stage)
            report = fixture.root / "phase-b/structural-preflight-report.json"
            report.write_text(report.read_text() + " ", encoding="utf-8")
            result = fixture.run("hypothesis", succeeds=False)
            self.assertNotEqual(result.returncode, 0)

    def test_target_override_after_structural_failure_rejected(self) -> None:
        from test_correction_rehearsals import FixtureStudy

        with tempfile.TemporaryDirectory() as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=False)
            fixture.setup()
            for stage in ("preflight", "build-binary"):
                fixture.run(stage)
            manual = fixture.manual
            with zipfile.ZipFile(manual, "a") as archive:
                archive.writestr(
                    f"words/{fixture.meeting}.A.words.xml",
                    words_root(element_xml("w", "bad", "500.00", "400.00", "fail")),
                )
            result = fixture.run("structural-preflight", succeeds=False)
            self.assertNotEqual(result.returncode, 0)
            env = {**fixture.env, "VOXPROOF_V3_MEETING_ID": "TS0002a"}
            env.pop("VOXPROOF_V3_FIXTURE_MODE", None)
            check = subprocess.run(
                [sys.executable, "-c", "import study_config"],
                cwd=fixture.root / "phase-b/scripts",
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertNotEqual(check.returncode, 0)

    def test_v3_failed_tree_and_forensic_hashes_unchanged(self) -> None:
        self.assertTrue(V3_STAGE_STATE.exists())
        self.assertTrue(V3_FAILURE.exists())
        self.assertTrue(FORENSIC_ZIP.exists())
        self.assertTrue(FORENSIC_SEAL.exists())
        self.assertEqual(sha256_file(V3_STAGE_STATE), PRESERVED_HASHES["v3_stage_state"])
        self.assertEqual(sha256_file(V3_FAILURE), PRESERVED_HASHES["v3_failure_record"])
        self.assertEqual(sha256_file(FORENSIC_ZIP), PRESERVED_HASHES["forensic_zip"])
        self.assertEqual(sha256_file(FORENSIC_SEAL), PRESERVED_HASHES["forensic_seal"])


if __name__ == "__main__":
    raise SystemExit(unittest.main())
''')

def patch_ami_common() -> None:
    path = SCRIPTS / "ami_common.py"
    text = path.read_text(encoding="utf-8")
    insert_after = "MANUAL_EVENT_TAGS = ALLOWED_MANUAL_TAGS - {\"w\"}\n"
    policy_block = textwrap.dedent('''\
    TIMESTAMP_POLICY_ID = "window-local-timestamp-integrity-v1"


    def parse_timestamp_attributes(raw_start: str, raw_end: str) -> tuple[Decimal, Decimal, bool, bool]:
        start = strict_decimal(raw_start, "starttime")
        end = strict_decimal(raw_end, "endtime")
        return start, end, True, True


    def classify_timestamp_interval(start: Decimal, end: Decimal) -> str:
        if end >= start:
            return "valid"
        if end < WINDOW_START and start < WINDOW_START:
            return "excluded_before_window"
        if start >= WINDOW_END and end >= WINDOW_END:
            return "excluded_after_window"
        return "fail_closed_possibly_window_relevant"


    def exclusion_reason_for(classification: str) -> str:
        return {
            "excluded_before_window": "both_endpoints_strictly_before_window_start",
            "excluded_after_window": "both_endpoints_at_or_after_window_end",
        }[classification]


    ''')
    if "TIMESTAMP_POLICY_ID" not in text:
        text = text.replace(insert_after, insert_after + policy_block)

    old_parse = textwrap.dedent('''\
    def parse_tokens(
        root: ET.Element, *, speaker: str, member: str, allowed_tags: set[str]
    ) -> list[Token]:
        records: list[Token] = []
        seen: set[str] = set()
        for element in root:
            tag = local_name(element.tag)
            if tag not in allowed_tags:
                raise ValueError(f"unknown tag {tag!r} in {member}")
            element_id = element.attrib.get(f"{NITE_NS}id")
            if not element_id:
                raise ValueError(f"missing nite:id on {tag} in {member}")
            if element_id in seen:
                raise ValueError(f"duplicate nite:id {element_id} in {member}")
            seen.add(element_id)
            if "starttime" not in element.attrib or "endtime" not in element.attrib:
                raise ValueError(f"missing timestamps for {element_id} in {member}")
            start = strict_decimal(element.attrib["starttime"], "starttime")
            end = strict_decimal(element.attrib["endtime"], "endtime")
            if end < start:
                raise ValueError(f"end before start for {element_id} in {member}")
            text = "".join(element.itertext()).strip() if tag == "w" else ""
            if tag == "w" and not text:
                raise ValueError(f"empty lexical token {element_id} in {member}")
            records.append(Token(speaker, member, element_id, tag, start, end, text))
        return records
    ''')

    new_parse = textwrap.dedent('''\
    def parse_tokens(
        root: ET.Element,
        *,
        speaker: str,
        member: str,
        allowed_tags: set[str],
        excluded_collector: list[dict[str, str]] | None = None,
    ) -> list[Token]:
        records: list[Token] = []
        seen: set[str] = set()
        for element in root:
            tag = local_name(element.tag)
            if tag not in allowed_tags:
                raise ValueError(f"unknown tag {tag!r} in {member}")
            element_id = element.attrib.get(f"{NITE_NS}id")
            if not element_id:
                raise ValueError(f"missing nite:id on {tag} in {member}")
            if element_id in seen:
                raise ValueError(f"duplicate nite:id {element_id} in {member}")
            seen.add(element_id)
            if "starttime" not in element.attrib or "endtime" not in element.attrib:
                raise ValueError(f"missing timestamps for {element_id} in {member}")
            start, end, _, _ = parse_timestamp_attributes(
                element.attrib["starttime"], element.attrib["endtime"]
            )
            classification = classify_timestamp_interval(start, end)
            if classification != "valid":
                if classification in {
                    "excluded_before_window",
                    "excluded_after_window",
                }:
                    if excluded_collector is not None:
                        excluded_collector.append(
                            {
                                "member": member,
                                "element_id": element_id,
                                "tag": tag,
                                "raw_starttime": element.attrib["starttime"],
                                "raw_endtime": element.attrib["endtime"],
                                "exclusion_reason": exclusion_reason_for(classification),
                            }
                        )
                    continue
                raise ValueError(
                    f"possibly window-relevant reversed interval for {element_id} in {member}"
                )
            text = "".join(element.itertext()).strip() if tag == "w" else ""
            if tag == "w" and not text:
                raise ValueError(f"empty lexical token {element_id} in {member}")
            records.append(Token(speaker, member, element_id, tag, start, end, text))
        return records
    ''')
    if "excluded_collector" not in text:
        text = text.replace(old_parse, new_parse)
    path.write_text(text, encoding="utf-8")


def patch_study_config() -> None:
    path = SCRIPTS / "study_config.py"
    text = path.read_text(encoding="utf-8")
    replacements = {
        'v3-exact-evidence-phase-a-correction': 'v4-exact-evidence-phase-a',
        'FROZEN_MEETING_ID = "ES2004b"': 'FROZEN_MEETING_ID = "ES2004c"',
        'voxproof-ami-authoritative-exact-evidence-v3': 'voxproof-ami-authoritative-exact-evidence-v4',
        '"phase_b_runner.py",\n)': '"phase_b_runner.py",\n    "structural_preflight.py",\n)',
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    if "STRUCTURAL_PREFLIGHT_REPORT_PATH" not in text:
        text = text.replace(
            "STAGE_STATE_PATH = PHASE_B_DIR / \"stage-state.json\"\n",
            "STAGE_STATE_PATH = PHASE_B_DIR / \"stage-state.json\"\n"
            "STRUCTURAL_PREFLIGHT_REPORT_PATH = PHASE_B_DIR / \"structural-preflight-report.json\"\n",
        )
    path.write_text(text, encoding="utf-8")


def patch_phase_b_runner() -> None:
    path = SCRIPTS / "phase_b_runner.py"
    text = path.read_text(encoding="utf-8")
    text = text.replace(
        '"""Frozen fail-closed V3 Phase B runner; all target stages execute here."""',
        '"""Frozen fail-closed V4 Phase B runner; all target stages execute here."""',
    )
    text = text.replace(
        "from ami_transform import build_hypothesis_layers, build_reference_layers  # noqa: E402\n",
        "from ami_transform import build_hypothesis_layers, build_reference_layers  # noqa: E402\n"
        "from structural_preflight import run_structural_preflight  # noqa: E402\n",
    )
    text = text.replace(
        "    STAGE_STATE_PATH,\n    STUDY_ROOT,\n",
        "    STAGE_STATE_PATH,\n    STRUCTURAL_PREFLIGHT_REPORT_PATH,\n    STUDY_ROOT,\n",
    )
    text = text.replace(
        '    "build-binary": "preflight",\n    "hypothesis": "build-binary",\n',
        '    "build-binary": "preflight",\n    "structural-preflight": "build-binary",\n    "hypothesis": "structural-preflight",\n',
    )
    if "def verify_structural_preflight_bindings" not in text:
        text = text.replace(
            "def verify_hypothesis_bindings() -> None:\n",
            "def verify_structural_preflight_bindings() -> str:\n"
            "    detail = stage_detail(\"structural-preflight\")\n"
            "    return require_hash(\n"
            "        STRUCTURAL_PREFLIGHT_REPORT_PATH,\n"
            "        detail[\"structural_preflight_report_sha256\"],\n"
            "        \"structural preflight report\",\n"
            "    )\n\n\n"
            "def verify_hypothesis_bindings() -> None:\n"
            "    verify_structural_preflight_bindings()\n",
        )
    if "def structural_preflight_action" not in text:
        text = text.replace(
            "def hypothesis_action() -> dict[str, Any]:\n",
            "def structural_preflight_action() -> dict[str, Any]:\n"
            "    return run_structural_preflight()\n\n\n"
            "def hypothesis_action() -> dict[str, Any]:\n"
            "    verify_structural_preflight_bindings()\n",
        )
    text = text.replace(
        '    "build-binary": build_binary_action,\n    "hypothesis": hypothesis_action,\n',
        '    "build-binary": build_binary_action,\n    "structural-preflight": structural_preflight_action,\n    "hypothesis": hypothesis_action,\n',
    )
    text = text.replace(
        '    parser = argparse.ArgumentParser(description="V3 Phase B exact stage runner")\n',
        '    parser = argparse.ArgumentParser(description="V4 Phase B exact stage runner")\n',
    )
    path.write_text(text, encoding="utf-8")


def patch_package_builder() -> None:
    path = SCRIPTS / "package_builder.py"
    text = path.read_text(encoding="utf-8")
    text = text.replace(
        "f\"voxproof-ami-authoritative-exact-evidence-v3-{mode}-{name_suffix}.zip\"",
        "f\"voxproof-ami-authoritative-exact-evidence-v4-{mode}-{name_suffix}.zip\"",
    )
    text = text.replace(
        'seal_name = f"package-seal-v3-{mode}-{name_suffix}.json"',
        'seal_name = f"package-seal-v4-{mode}-{name_suffix}.json"',
    )
    path.write_text(text, encoding="utf-8")


def patch_correction_rehearsals() -> None:
    path = TESTS / "test_correction_rehearsals.py"
    text = path.read_text(encoding="utf-8")
    text = text.replace(
        "            \"build-binary\",\n            \"hypothesis\",\n",
        "            \"build-binary\",\n            \"structural-preflight\",\n            \"hypothesis\",\n",
    )
    text = text.replace(
        "voxproof-ami-authoritative-exact-evidence-v3-phase-b-final.zip",
        "voxproof-ami-authoritative-exact-evidence-v4-phase-b-final.zip",
    )
    text = text.replace(
        'for stage in ("preflight", "build-binary", "hypothesis", "probe-candidates"):',
        'for stage in ("preflight", "build-binary", "structural-preflight", "hypothesis", "probe-candidates"):',
    )
    text = text.replace(
        'for stage in ("preflight", "build-binary", "hypothesis"):',
        'for stage in ("preflight", "build-binary", "structural-preflight", "hypothesis"):',
    )
    path.write_text(text, encoding="utf-8")


def patch_run_full_pipeline() -> None:
    path = TESTS / "run_full_pipeline_rehearsal.py"
    text = path.read_text(encoding="utf-8")
    if '"structural-preflight"' not in text:
        text = text.replace(
            '            "build-binary",\n            "hypothesis",\n',
            '            "build-binary",\n            "structural-preflight",\n            "hypothesis",\n',
        )
    path.write_text(text, encoding="utf-8")


def write_specs() -> None:
    (ROOT / "timestamp-policy-spec.json").write_text(
        json.dumps(
            {
                "schema_revision": "voxproof-ami-timestamp-policy-spec-v1",
                "policy_id": "window-local-timestamp-integrity-v1",
                "protocol_id": "voxproof-ami-authoritative-exact-evidence-v4",
                "window": {"start_inclusive": "300.000", "end_exclusive": "900.000"},
                "rules": [
                    "Parse starttime/endtime strictly as finite non-negative decimals",
                    "Reject NaN, infinity, missing, or negative values",
                    "If end >= start, retain midpoint/window behavior",
                    "If end < start, never swap/clamp/reorder/repair midpoint",
                    "If both endpoints strictly before WINDOW_START, record and exclude",
                    "If both endpoints at or after WINDOW_END, record and exclude",
                    "Otherwise fail closed as possibly window-relevant",
                    "Tolerated malformed elements never enter reference/scoring/cue/WER inputs",
                ],
                "shared_by": [
                    "phase-b/scripts/ami_common.py",
                    "phase-b/scripts/structural_preflight.py",
                    "phase-b/scripts/ami_transform.py",
                ],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (ROOT / "structural-preflight-schema.json").write_text(
        json.dumps(
            {
                "schema_revision": "voxproof-ami-structural-preflight-schema-v1",
                "report_file": "phase-b/structural-preflight-report.json",
                "required": [
                    "schema_revision",
                    "timestamp_policy_id",
                    "meeting_id",
                    "window",
                    "lexical_text_exposed",
                    "required_members_verified",
                    "tolerated_outside_window_anomalies",
                    "tolerated_anomaly_count",
                    "structural_errors",
                    "fail_closed",
                    "completed_at_utc",
                ],
                "anomaly_required": [
                    "member",
                    "element_id",
                    "tag",
                    "raw_starttime",
                    "raw_endtime",
                    "exclusion_reason",
                ],
                "forbidden_fields": ["text", "lexical_text", "matched_text", "cue_text"],
                "stage_binding": "structural_preflight_report_sha256 in every downstream stage detail",
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


def resolve_target() -> dict[str, object]:
    inv = json.loads((ROOT / "references/archive-member-inventories.json").read_text())
    auto_paths = {m["path"] for m in inv["ami_public_auto_1.5.1.zip"]}
    manual_paths = {m["path"] for m in inv["ami_public_manual_1.6.2.zip"]}
    signals = (ROOT / "attribution/pages/corpus_signals.shtml.html").read_text(
        encoding="utf-8", errors="replace"
    )
    durations = {
        mid: int(sec)
        for mid, sec in re.findall(
            r"<tr>\s*<td>([A-Z]{2}\d{4}[a-z])</td>.*?<td class=\"xl24\" align=\"right\">(\d+)</td>",
            signals,
            re.S,
        )
    }
    auto_prefix = "ASR/ASR_AS_CTM_v1.0_feb07/"
    pat = re.compile(rf"^{re.escape(auto_prefix)}([A-Z]{{2}}\d{{4}}[a-z])\.([A-D])\.words\.xml$")
    meetings = set()
    for path in auto_paths:
        match = pat.match(path)
        if match:
            meetings.add(match.group(1))
    excluded = {"ES2004a", "ES2004b"}
    ordered = sorted(mid for mid in meetings if mid > "ES2004a" and mid not in excluded)
    rows = []
    resolved = None
    for mid in ordered:
        req = [
            f"{auto_prefix}{mid}.{sp}.words.xml" for sp in "ABCD"
        ] + [f"{auto_prefix}{mid}.{sp}.segments.xml" for sp in "ABCD"] + [
            f"words/{mid}.{sp}.words.xml" for sp in "ABCD"
        ]
        present = {
            member: (
                member in auto_paths if member.startswith("ASR/") else member in manual_paths
            )
            for member in req
        }
        complete = all(present.values())
        duration = durations.get(mid)
        eligible = complete and duration is not None and duration >= 900
        row = {
            "meeting_id": mid,
            "complete_required_members": complete,
            "duration_seconds": duration,
            "eligible": eligible,
            "missing_members": [k for k, v in present.items() if not v],
            "required_members": req,
        }
        rows.append(row)
        if eligible and resolved is None:
            resolved = row
    if resolved is None or resolved["meeting_id"] != "ES2004c":
        raise SystemExit(f"target resolution failed: {resolved}")
    return {
        "resolved": resolved,
        "rows": rows,
        "eligible_count": sum(1 for row in rows if row["eligible"]),
    }


def write_metadata(target: dict[str, object]) -> None:
    resolved = target["resolved"]
    rule = {
        "schema_revision": "voxproof-ami-target-selection-rule-v1",
        "protocol_id": "voxproof-ami-authoritative-exact-evidence-v4",
        "rule_id": "lexicographic-after-ES2004a-complete-members-duration-ge-900-v1",
        "excluded_meeting_ids": ["ES2004a", "ES2004b"],
        "minimum_duration_seconds": 900,
        "window": {"start_inclusive": "300.000", "end_exclusive": "900.000"},
        "fail_closed": True,
        "reselection_on_structural_failure": False,
    }
    evidence = {
        "schema_revision": "voxproof-ami-target-selection-evidence-v1",
        "protocol_id": "voxproof-ami-authoritative-exact-evidence-v4",
        "resolved_meeting_id": resolved["meeting_id"],
        "resolved_duration_seconds": resolved["duration_seconds"],
        "resolved_required_members": resolved["required_members"],
        "eligible_count": target["eligible_count"],
        "candidate_scan_first_10": target["rows"][:10],
        "metadata_only_resolution": True,
        "es2004c_lexical_content_opened": False,
    }
    (ROOT / "target-selection-rule.json").write_text(json.dumps(rule, indent=2) + "\n", encoding="utf-8")
    (ROOT / "target-selection-evidence.json").write_text(
        json.dumps(evidence, indent=2) + "\n", encoding="utf-8"
    )
    source = json.loads((ROOT / "source-lock.json").read_text(encoding="utf-8"))
    source["protocol_id"] = "voxproof-ami-authoritative-exact-evidence-v4"
    source["meeting_id"] = "ES2004c"
    source["prior_artifacts_preserved"]["v3_phase_a_zip"] = (
        "voxproof-ami-authoritative-exact-evidence-v3-phase-a-20260716-050542.zip"
    )
    source["prior_artifacts_preserved"]["v3_phase_a_seal"] = (
        "package-seal-v3-phase-a-20260716-050542.json"
    )
    source["prior_artifacts_preserved"]["v3_failed_phase_b_study_root"] = (
        "/private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-a-correction"
    )
    (ROOT / "source-lock.json").write_text(json.dumps(source, indent=2) + "\n", encoding="utf-8")
    (ROOT / "pre-run-freeze.json").write_text(
        json.dumps(
            {
                "schema_revision": "voxproof-ami-pre-run-freeze-v1",
                "protocol_id": "voxproof-ami-authoritative-exact-evidence-v4",
                "meeting_id": "ES2004c",
                "window": {"start_inclusive": "300.000", "end_exclusive": "900.000"},
                "selection_rule_id": rule["rule_id"],
                "excluded_meeting_ids": rule["excluded_meeting_ids"],
                "timestamp_policy_id": "window-local-timestamp-integrity-v1",
                "structural_preflight_required": True,
                "es2004c_lexical_content_opened": False,
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


def write_phase_b_commands() -> None:
    (ROOT / "phase-b-commands.md").write_text(
        textwrap.dedent(
            f"""\
            # Phase B exact commands (V4 frozen executable envelope; do not execute in Phase A)

            ## Authoritative chronology
            1. verify repository, archive, script, and config hashes; build isolated binary
            2. structural-preflight on frozen target archives without lexical exposure
            3. cross target-content gate once by opening target ASR words/segments
            4. materialize hypothesis SRT and cue/token ledger
            5. invoke exact binary candidate probe and seal candidate inventory
            6. only then open manual/reference words content
            7. materialize reference/scoring layers; human reviewer creates ground truth and decision inputs
            8. validate decision binding; invoke authoritative review; verify candidate reproduction
            9. audit post-review materialization
            10. score; independently verify; package once; detached seal afterward

            ```sh
            export VOXPROOF_V3_STUDY_ROOT="{ROOT}"
            cd "$VOXPROOF_V3_STUDY_ROOT"

            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" preflight
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" build-binary
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" structural-preflight
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" hypothesis
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" probe-candidates
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" reference
            # human review inputs ...
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" validate-review-inputs
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" authoritative-review
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" audit-materialization
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" score
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" independent-verify
            python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" package
            ```

            ## Frozen target
            meeting_id=ES2004c
            window=[300.000, 900.000)
            """
        ),
        encoding="utf-8",
    )


def main() -> None:
    (SCRIPTS / "structural_preflight.py").write_text(STRUCTURAL_PREFLIGHT, encoding="utf-8")
    (TESTS / "test_timestamp_policy.py").write_text(TEST_TIMESTAMP_POLICY, encoding="utf-8")
    patch_ami_common()
    patch_study_config()
    patch_phase_b_runner()
    patch_package_builder()
    patch_correction_rehearsals()
    patch_run_full_pipeline()
    write_specs()
    target = resolve_target()
    write_metadata(target)
    write_phase_b_commands()
    print(json.dumps({"status": "implemented", "resolved_meeting": target["resolved"]["meeting_id"]}, indent=2))


if __name__ == "__main__":
    main()
