# VoxProof Authoritative Exact-Evidence V3 Phase A Correction

## Executable envelope correction
This correction packages the complete Phase B implementation under
`phase-b/scripts/`, byte-locked in `phase-b/script-lock.json`. The lock is
generated only during Phase A packaging; Phase B preflight reads and verifies it
without mutation.

`VOXPROOF_V3_STUDY_ROOT` selects one approved/extracted study root, defaulting to
this correction tree. Every binary, state, transform, review, scoring, report,
and package path derives from that root. The isolated product binary is
`phase-b/cargo-target-isolated/debug/vox-proof`.

`phase_b_runner.py` is the sole Phase B command surface: `preflight`,
`build-binary`, `hypothesis`, `probe-candidates`, `reference`,
`validate-review-inputs`, `authoritative-review`, `score`,
`independent-verify`, and `package`.

The hypothesis stage durably crosses the target-content gate before opening ASR
XML. It strictly parses words/segments, resolves href ranges, validates tags,
IDs and timestamps, and writes SRT/cue/token ledgers. Reference access requires
and records the sealed candidate-inventory hash before opening manual XML.
Failure after gate crossing is terminal and preserves persistent artifacts.

Human ground truth, candidate labels, and decisions are jointly validated
against inventory/reference hashes and one designated reviewer attestation.
No decision is derived automatically from the reference.

Raw and reviewed streams are scored independently. The primary scorer writes
both operation paths and count decompositions; the independent verifier does
not import primary alignment code and reconstructs both paths directly.

Reviewed scoring uses frozen policy
`cue-local-edit-global-midpoint-merge-v1`: each reviewed cue is aligned to its
original normalized cue tokens; mapped edits retain original token sort keys,
insertions receive deterministic before/after anchor keys, and all resulting
tokens are merged by original midpoint, speaker, element ID, token subindex,
and insertion tie key. Identity review must exactly reproduce the frozen raw
global stream, including overlapping speakers. Independent verification
duplicates this projection.

Unsafe acceptance uses frozen definition
`selected-false-or-unsupported-or-incorrect-materialization-v1`; the value is
derived from classification, replacement support, boundary support, and
materialization correctness, never accepted as an unconstrained reviewer flag.

Phase A and Phase B package modes are explicit. The Phase B runner builds the
deterministically named Phase B ZIP/seal and verifies closure after sealing.

## Target
- meeting_id: `ES2004b`
- window: `[300.000, 900.000)`
- terms frozen: see `session-terms/session-terms.txt`

## Chronology
See `phase-b-commands.md` for the authoritative runnable sequence.

## Preserved artifacts
- first V3 ZIP/seal unchanged: `voxproof-ami-authoritative-exact-evidence-v3-phase-a-20260716-031102.zip`
- c1 and exploratory v2 hashes recorded in `source-lock.json`

## Access boundary
ES2004b ASR/manual words/segments content remained unopened. Synthetic
auto/manual ZIPs with matching XML/member shape exercised the exact runner
chronology end to end for zero and nonzero paths.
