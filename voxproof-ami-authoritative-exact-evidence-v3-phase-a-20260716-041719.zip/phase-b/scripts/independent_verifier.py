#!/usr/bin/env python3
"""Independent alignment verification without importing primary backtrace."""

from __future__ import annotations

import json
import sys
import csv
import hashlib
import re
import unicodedata
from decimal import Decimal
from pathlib import Path
from typing import Any

REVIEWED_PROJECTION_POLICY_ID = "cue-local-edit-global-midpoint-merge-v1"
SPEAKERS = "ABCD"


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalized_tokens(text: str) -> list[str]:
    output: list[str] = []
    for piece in text.split():
        token = unicodedata.normalize("NFC", piece).casefold()
        token = "".join(
            char for char in token if not unicodedata.category(char).startswith("P")
        )
        if token:
            output.append(token)
    return output


def parse_srt_independent(path: Path) -> list[dict[str, Any]]:
    blocks = re.split(r"\r?\n\r?\n", path.read_text(encoding="utf-8").strip())
    result = []
    for block in blocks:
        lines = block.splitlines()
        if len(lines) < 3 or not lines[0].isdigit():
            raise ValueError("independent SRT parse failed")
        result.append({"index": int(lines[0]), "text": "\n".join(lines[2:])})
    return result


def project_cue_independent(
    original: list[tuple[str, tuple[Any, ...]]], reviewed: list[str]
) -> list[tuple[tuple[Any, ...], str]]:
    source = [item[0] for item in original]
    n, m = len(source), len(reviewed)
    matrix = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        matrix[i][0] = i
    for j in range(m + 1):
        matrix[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            substitution = matrix[i - 1][j - 1] + (source[i - 1] != reviewed[j - 1])
            matrix[i][j] = min(substitution, matrix[i - 1][j] + 1, matrix[i][j - 1] + 1)
    reverse: list[tuple[str, int, int]] = []
    i, j = n, m
    while i or j:
        if i and j and matrix[i][j] == matrix[i - 1][j - 1] + (
            source[i - 1] != reviewed[j - 1]
        ):
            reverse.append(("map", i - 1, j - 1))
            i -= 1
            j -= 1
        elif i and matrix[i][j] == matrix[i - 1][j] + 1:
            reverse.append(("delete", i - 1, j))
            i -= 1
        elif j and matrix[i][j] == matrix[i][j - 1] + 1:
            reverse.append(("insert", i, j - 1))
            j -= 1
        else:
            raise ValueError("independent cue projection backtrace failed")
    counts: dict[tuple[int, str], int] = {}
    output = []
    for operation, source_index, reviewed_index in reversed(reverse):
        if operation == "delete":
            continue
        if operation == "map":
            key = (*original[source_index][1], 0, 0)
        elif source_index == 0:
            count_key = (source_index, "before")
            counts[count_key] = counts.get(count_key, 0) + 1
            key = (*original[0][1], -1, counts[count_key])
        else:
            count_key = (source_index, "after")
            counts[count_key] = counts.get(count_key, 0) + 1
            key = (*original[source_index - 1][1], 1, counts[count_key])
        output.append((key, reviewed[reviewed_index]))
    return output


def independently_project_reviewed(phase_b: Path, raw: list[str]) -> list[str]:
    cues = json.loads((phase_b / "build-primary/parsed/asr_cues.json").read_text())["cues"]
    records = [
        json.loads(line)
        for line in (
            phase_b / "build-primary/parsed/hypothesis_tokens.jsonl"
        ).read_text().splitlines()
        if line
    ]
    by_id = {row["element_id"]: row for row in records}
    source_srt = parse_srt_independent(phase_b / "build-primary/input.srt")
    reviewed_srt = parse_srt_independent(phase_b / "review/reviewed-output.srt")
    if len(cues) != len(source_srt) or len(cues) != len(reviewed_srt):
        raise ValueError("independent cue count mismatch")
    merged = []
    identity = True
    for position, (cue, source, reviewed) in enumerate(
        zip(cues, source_srt, reviewed_srt), 1
    ):
        if source["index"] != position or reviewed["index"] != position:
            raise ValueError("independent cue index mismatch")
        if source["text"] != cue["text"]:
            raise ValueError("independent source cue text mismatch")
        original = []
        for token_id in cue["token_ids"]:
            row = by_id[token_id]
            if row["segment_id"] != cue["segment_id"]:
                raise ValueError("independent token/segment mismatch")
            base = (
                (Decimal(row["start"]) + Decimal(row["end"])) / 2,
                SPEAKERS.index(row["speaker"]),
                row["element_id"],
            )
            original.extend(
                (token, (*base, subindex))
                for subindex, token in enumerate(normalized_tokens(row["text"]))
            )
        source_tokens = [item[0] for item in original]
        if source_tokens != normalized_tokens(source["text"]):
            raise ValueError("independent source token reconstruction mismatch")
        reviewed_tokens = normalized_tokens(reviewed["text"])
        identity = identity and source_tokens == reviewed_tokens
        merged.extend(project_cue_independent(original, reviewed_tokens))
    merged.sort(key=lambda item: item[0])
    projected = [item[1] for item in merged]
    if identity and projected != raw:
        raise ValueError("independent identity projection differs from raw")
    return projected


def recompute_metrics(
    inventory: dict[str, Any],
    ground: dict[str, Any],
    labels: list[dict[str, Any]],
    decisions: list[str],
    alignment: dict[str, Any],
) -> dict[str, Any]:
    opportunities = ground.get("opportunities", [])
    candidates = inventory.get("candidates", [])
    true_labels = [row for row in labels if row.get("classification") == "selected_true"]
    false_labels = [row for row in labels if row.get("classification") == "selected_false"]
    matched = {row["matched_opportunity_id"] for row in true_labels}
    accepted = {i for i, value in enumerate(decisions) if value.startswith("a ")}
    corrected = {
        labels[i]["matched_opportunity_id"]
        for i in accepted
        if labels[i].get("classification") == "selected_true"
        and labels[i].get("materialized_correctly_if_accepted") is True
    }
    unsafe = {i for i in accepted if labels[i].get("unsafe_if_accepted") is True}

    def ratio(numerator: int, denominator: int) -> float | None:
        return None if denominator == 0 else numerator / denominator

    raw_wer = alignment["raw"]["wer"]
    reviewed_wer = alignment["reviewed"]["wer"]
    return {
        "schema_revision": "voxproof-ami-study-metrics-v1",
        "definitions_revision": "v3-phase-a-memo-section-4",
        "candidate_precision": {
            "numerator": len(true_labels),
            "denominator": len(candidates),
            "ratio": ratio(len(true_labels), len(candidates)),
        },
        "candidate_recall": {
            "numerator": len(matched),
            "denominator": len(opportunities),
            "ratio": ratio(len(matched), len(opportunities)),
        },
        "correction_recall": {
            "numerator": len(corrected),
            "denominator": len(opportunities),
            "ratio": ratio(len(corrected), len(opportunities)),
        },
        "false_positive_burden": len(false_labels),
        "unsafe_edit_rate": {
            "numerator": len(unsafe),
            "denominator": len(accepted),
            "ratio": ratio(len(unsafe), len(accepted)),
        },
        "raw_wer": raw_wer,
        "reviewed_wer": reviewed_wer,
        "raw_to_reviewed_wer_delta": (
            None if raw_wer is None or reviewed_wer is None else reviewed_wer - raw_wer
        ),
        "zero_denominator_rule": "ratio fields are JSON null when denominator is zero",
        "detector_miss_count": len(opportunities) - len(matched),
        "selected_true_candidate_count": len(true_labels),
        "selected_false_candidate_count": len(false_labels),
        "alignment": {
            key: alignment[key]
            for key in ("raw", "reviewed", "raw_to_reviewed_wer_delta")
        },
        "accepted_candidate_count": len(accepted),
    }


def independent_edit_distance(reference: list[str], hypothesis: list[str]) -> int:
    n = len(reference)
    m = len(hypothesis)
    previous = list(range(m + 1))
    for i in range(1, n + 1):
        current = [i]
        ref_token = reference[i - 1]
        for j in range(1, m + 1):
            cost_substitution = 0 if ref_token == hypothesis[j - 1] else 1
            current.append(
                min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost_substitution)
            )
        previous = current
    return previous[m]


def independent_backtrace_alternate_tie(
    reference: list[str], hypothesis: list[str]
) -> dict[str, int]:
    n = len(reference)
    m = len(hypothesis)
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        dp[i][0] = i
    for j in range(1, m + 1):
        dp[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if reference[i - 1] == hypothesis[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = 1 + min(dp[i - 1][j - 1], dp[i][j - 1], dp[i - 1][j])
    counts = {"match": 0, "substitution": 0, "deletion": 0, "insertion": 0}
    i = n
    j = m
    while i > 0 or j > 0:
        current = dp[i][j]
        if i > 0 and j > 0 and reference[i - 1] == hypothesis[j - 1] and current == dp[i - 1][j - 1]:
            counts["match"] += 1
            i -= 1
            j -= 1
            continue
        candidates: list[tuple[str, int, int]] = []
        if i > 0 and j > 0 and current == dp[i - 1][j - 1] + 1:
            candidates.append(("substitution", i - 1, j - 1))
        if j > 0 and current == dp[i][j - 1] + 1:
            candidates.append(("insertion", i, j - 1))
        if i > 0 and current == dp[i - 1][j] + 1:
            candidates.append(("deletion", i - 1, j))
        if not candidates:
            raise ValueError(f"alternate backtrace failed at ({i},{j})")
        op, ni, nj = candidates[0]
        counts[op] += 1
        i, j = ni, nj
    n_ref = len(reference)
    h_hyp = len(hypothesis)
    m_count = counts["match"]
    s_count = counts["substitution"]
    d_count = counts["deletion"]
    ins_count = counts["insertion"]
    if m_count + s_count + d_count != n_ref:
        raise ValueError("alternate decomposition failed M+S+D=N")
    if m_count + s_count + ins_count != h_hyp:
        raise ValueError("alternate decomposition failed M+S+I=H")
    if h_hyp != n_ref - d_count + ins_count:
        raise ValueError("alternate decomposition failed H=N-D+I")
    if dp[n][m] != s_count + d_count + ins_count:
        raise ValueError("alternate decomposition failed edit distance")
    counts["edit_distance"] = dp[n][m]
    counts["N_reference"] = n_ref
    counts["H_hypothesis"] = h_hyp
    counts["matches"] = counts.pop("match")
    counts["substitutions"] = counts.pop("substitution")
    counts["deletions"] = counts.pop("deletion")
    counts["insertions"] = counts.pop("insertion")
    return counts


def verify_operations(
    path: Path,
    reference: list[str],
    hypothesis: list[str],
    expected: dict[str, int],
) -> list[str]:
    errors: list[str] = []
    rows = list(csv.DictReader(path.open(encoding="utf-8"), delimiter="\t"))
    reconstructed_reference: list[str] = []
    reconstructed_hypothesis: list[str] = []
    counts = {"match": 0, "substitution": 0, "deletion": 0, "insertion": 0}
    ref_pos = hyp_pos = 0
    for ordinal, row in enumerate(rows):
        operation = row["operation"]
        if int(row["ordinal"]) != ordinal or operation not in counts:
            errors.append(f"{path.name}: invalid ordinal/operation at {ordinal}")
            continue
        if int(row["reference_coord_before"]) != ref_pos:
            errors.append(f"{path.name}: reference coordinate discontinuity at {ordinal}")
        if int(row["hypothesis_coord_before"]) != hyp_pos:
            errors.append(f"{path.name}: hypothesis coordinate discontinuity at {ordinal}")
        reference_token = row["reference_token"] or None
        hypothesis_token = row["hypothesis_token"] or None
        if operation in {"match", "substitution", "deletion"}:
            reconstructed_reference.append(reference_token or "")
            ref_pos += 1
        if operation in {"match", "substitution", "insertion"}:
            reconstructed_hypothesis.append(hypothesis_token or "")
            hyp_pos += 1
        if operation == "match" and reference_token != hypothesis_token:
            errors.append(f"{path.name}: unequal match at {ordinal}")
        if operation == "substitution" and reference_token == hypothesis_token:
            errors.append(f"{path.name}: equal substitution at {ordinal}")
        counts[operation] += 1
    if reconstructed_reference != reference:
        errors.append(f"{path.name}: reconstructed reference mismatch")
    if reconstructed_hypothesis != hypothesis:
        errors.append(f"{path.name}: reconstructed hypothesis mismatch")
    derived = {
        "N_reference": len(reference),
        "H_hypothesis": len(hypothesis),
        "matches": counts["match"],
        "substitutions": counts["substitution"],
        "deletions": counts["deletion"],
        "insertions": counts["insertion"],
        "edit_distance": counts["substitution"] + counts["deletion"] + counts["insertion"],
    }
    if derived != expected:
        errors.append(f"{path.name}: operation counts mismatch")
    if derived["matches"] + derived["substitutions"] + derived["deletions"] != len(reference):
        errors.append(f"{path.name}: M+S+D != N")
    if derived["matches"] + derived["substitutions"] + derived["insertions"] != len(hypothesis):
        errors.append(f"{path.name}: M+S+I != H")
    return errors


def verify_study_root(study_root: Path) -> dict[str, Any]:
    phase_b = study_root / "phase-b"
    scoring_path = phase_b / "build-primary/scoring_tokens.json"
    alignment_path = phase_b / "alignment-audit.json"
    metrics_path = phase_b / "metrics.json"
    errors: list[str] = []
    scoring = json.loads(scoring_path.read_text(encoding="utf-8"))
    alignment = json.loads(alignment_path.read_text(encoding="utf-8"))
    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    state = json.loads((phase_b / "stage-state.json").read_text(encoding="utf-8"))
    details = state.get("stage_details", {})
    disclosures: list[str] = []
    reference = list(scoring["reference_tokens"])
    streams = {
        "raw": list(scoring["hypothesis_tokens"]),
        "reviewed": list(alignment["reviewed_tokens"]),
    }
    for name, hypothesis in streams.items():
        audit = alignment[name]
        counts = audit["counts"]
        independent = independent_backtrace_alternate_tie(reference, hypothesis)
        distance = independent_edit_distance(reference, hypothesis)
        if distance != counts["edit_distance"]:
            errors.append(f"{name}: independent edit distance mismatch")
        if counts["matches"] + counts["substitutions"] + counts["deletions"] != len(reference):
            errors.append(f"{name}: primary M+S+D invariant mismatch")
        if counts["matches"] + counts["substitutions"] + counts["insertions"] != len(hypothesis):
            errors.append(f"{name}: primary M+S+I invariant mismatch")
        if counts["substitutions"] + counts["deletions"] + counts["insertions"] != distance:
            errors.append(f"{name}: primary decomposition is not optimal")
        if independent != counts:
            disclosures.append(
                f"{name}: alternate deterministic tie policy produced a different "
                "optimal S/D/I decomposition; primary operations remain authoritative"
            )
        expected_wer = None if not reference else counts["edit_distance"] / len(reference)
        if audit["wer"] != expected_wer:
            errors.append(f"{name}: scalar WER mismatch")
        errors.extend(
            verify_operations(
                phase_b / f"{name}-alignment-operations.tsv",
                reference,
                hypothesis,
                counts,
            )
        )
    if metrics.get("alignment") != {
        key: alignment[key] for key in ("raw", "reviewed", "raw_to_reviewed_wer_delta")
    }:
        errors.append("metrics alignment audit disagreement")
    inventory = json.loads((phase_b / "probe/candidate-inventory.json").read_text())
    ground_path = phase_b / "review/ground-truth.json"
    labels_path = phase_b / "review/candidate-labels.json"
    decisions_path = phase_b / "review/decision-inputs.json"
    ground = json.loads(ground_path.read_text())
    labels_payload = json.loads(labels_path.read_text())
    decisions_payload = json.loads(decisions_path.read_text())
    binding = json.loads(
        (phase_b / "review/authoritative-review-binding.json").read_text()
    )
    if not binding.get("reproduction_verified"):
        errors.append("review reproduction not verified")
    for field in ("binary_sha256", "transcript_revision", "candidate_count"):
        if binding.get(field) != inventory.get(field):
            errors.append(f"inventory/review binding mismatch: {field}")
    if binding.get("candidate_sequence_sha256") != inventory.get(
        "candidate_sequence_sha256"
    ):
        errors.append("inventory/review candidate sequence mismatch")
    if binding.get("decisions") != decisions_payload.get("decisions"):
        errors.append("authoritative binding decisions mismatch")
    independently_reviewed = independently_project_reviewed(
        phase_b, list(scoring["hypothesis_tokens"])
    )
    if alignment.get("reviewed_projection_policy_id") != REVIEWED_PROJECTION_POLICY_ID:
        errors.append("reviewed projection policy mismatch")
    if scoring.get("reviewed_projection_policy_id") != REVIEWED_PROJECTION_POLICY_ID:
        errors.append("scoring projection policy mismatch")
    if independently_reviewed != alignment.get("reviewed_tokens"):
        errors.append("independent reviewed-stream projection mismatch")
    expected_metrics = recompute_metrics(
        inventory,
        ground,
        labels_payload["labels"],
        decisions_payload["decisions"],
        alignment,
    )
    if metrics != expected_metrics:
        errors.append("independently recomputed study metrics mismatch")

    hash_checks = (
        (
            phase_b / "build-primary/input.srt",
            details.get("hypothesis", {}).get("input_srt_sha256"),
            "input SRT",
        ),
        (
            phase_b / "build-primary/parsed/hypothesis_tokens.jsonl",
            details.get("hypothesis", {}).get("hypothesis_tokens_sha256"),
            "hypothesis token ledger",
        ),
        (
            phase_b / "build-primary/parsed/asr_cues.json",
            details.get("hypothesis", {}).get("asr_cues_sha256"),
            "ASR cue ledger",
        ),
        (
            phase_b / "probe/candidate-inventory.json",
            details.get("probe-candidates", {}).get("candidate_inventory_sha256"),
            "probe inventory",
        ),
        (
            phase_b / "build-primary/reference-layer-manifest.json",
            details.get("reference", {}).get("reference_layer_sha256"),
            "reference layer",
        ),
        (
            phase_b / "build-primary/scoring_tokens.json",
            details.get("reference", {}).get("scoring_tokens_sha256"),
            "scoring tokens",
        ),
        (
            ground_path,
            details.get("validate-review-inputs", {}).get("ground_truth_sha256"),
            "ground truth",
        ),
        (
            labels_path,
            details.get("validate-review-inputs", {}).get("candidate_labels_sha256"),
            "candidate labels",
        ),
        (
            decisions_path,
            details.get("validate-review-inputs", {}).get("decision_inputs_sha256"),
            "decision inputs",
        ),
        (
            phase_b / "review/authoritative-review-binding.json",
            details.get("authoritative-review", {}).get(
                "authoritative_review_binding_sha256"
            ),
            "authoritative binding",
        ),
        (
            phase_b / "review/reviewed-output.srt",
            details.get("authoritative-review", {}).get("reviewed_output_sha256"),
            "reviewed output",
        ),
        (
            alignment_path,
            details.get("score", {}).get("alignment_audit_sha256"),
            "alignment audit",
        ),
        (
            metrics_path,
            details.get("score", {}).get("metrics_sha256"),
            "metrics",
        ),
    )
    for path, expected_hash, label in hash_checks:
        if not expected_hash or file_sha256(path) != expected_hash:
            errors.append(f"stage-detail hash mismatch: {label}")
    authoritative = details.get("authoritative-review", {})
    validated = details.get("validate-review-inputs", {})
    for field in (
        "candidate_inventory_sha256",
        "reference_layer_sha256",
        "scoring_tokens_sha256",
        "ground_truth_sha256",
        "candidate_labels_sha256",
        "decision_inputs_sha256",
    ):
        expected = (
            details.get("probe-candidates", {}).get(field)
            or details.get("reference", {}).get(field)
            or validated.get(field)
        )
        if authoritative.get(field) != expected:
            errors.append(f"authoritative immutable join mismatch: {field}")
    return {
        "status": "pass" if not errors else "fail",
        "errors": errors,
        "raw_independent_distance": independent_edit_distance(reference, streams["raw"]),
        "reviewed_independent_distance": independent_edit_distance(
            reference, streams["reviewed"]
        ),
        "ordering_policy": scoring.get("ordering_policy"),
        "reviewed_projection_policy_id": REVIEWED_PROJECTION_POLICY_ID,
        "tie_policy_disclosures": disclosures,
        "study_root": str(study_root),
    }


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: independent_verifier.py <study_root>", file=sys.stderr)
        return 2
    study_root = Path(sys.argv[1]).resolve()
    out = verify_study_root(study_root)
    output_path = study_root / "phase-b/reports/independent-verifier-output.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(out, indent=2))
    return 0 if out["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
