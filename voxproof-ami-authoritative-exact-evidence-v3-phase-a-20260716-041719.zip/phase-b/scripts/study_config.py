#!/usr/bin/env python3
"""Frozen V3 study constants with fixture-only environment overrides."""

from __future__ import annotations

import os
from decimal import Decimal
from pathlib import Path

DEFAULT_STUDY_ROOT = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/"
    "v3-exact-evidence-phase-a-correction"
)
FIXTURE_MODE = os.environ.get("VOXPROOF_V3_FIXTURE_MODE") == "1"
FROZEN_REPO_ROOT = Path("/Users/Ezra4/Coding/Repo/vox-proof")
FROZEN_MEETING_ID = "ES2004b"
FROZEN_WINDOW_START = "300.000"
FROZEN_WINDOW_END = "900.000"
FROZEN_AUTO_ZIP = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/phase-b/downloads/"
    "ami_public_auto_1.5.1.zip"
)
FROZEN_MANUAL_ZIP = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/phase-b/downloads/"
    "ami_public_manual_1.6.2.zip"
)
BEHAVIOR_OVERRIDE_VARS = (
    "VOXPROOF_V3_REPO_ROOT",
    "VOXPROOF_V3_MEETING_ID",
    "VOXPROOF_V3_WINDOW_START",
    "VOXPROOF_V3_WINDOW_END",
    "VOXPROOF_V3_AUTO_ZIP",
    "VOXPROOF_V3_MANUAL_ZIP",
)
if not FIXTURE_MODE:
    forbidden = [name for name in BEHAVIOR_OVERRIDE_VARS if name in os.environ]
    if forbidden:
        raise RuntimeError(
            "production behavior override(s) forbidden: " + ", ".join(forbidden)
        )

STUDY_ROOT = Path(os.environ.get("VOXPROOF_V3_STUDY_ROOT", DEFAULT_STUDY_ROOT)).resolve()
REPO_ROOT = Path(
    os.environ.get("VOXPROOF_V3_REPO_ROOT", FROZEN_REPO_ROOT)
).resolve()
REQUIRED_HEAD = "5286c1627e54852fc08f4766240ce7545269e982"
PROTOCOL_ID = "voxproof-ami-authoritative-exact-evidence-v3"
CLASSIFICATION = "prospective authoritative exact-evidence pre-outcome freeze"

MEETING_ID = os.environ.get("VOXPROOF_V3_MEETING_ID", FROZEN_MEETING_ID)
SPEAKERS = ("A", "B", "C", "D")
AUTO_PREFIX = "ASR/ASR_AS_CTM_v1.0_feb07/"
WINDOW_START = Decimal(os.environ.get("VOXPROOF_V3_WINDOW_START", FROZEN_WINDOW_START))
WINDOW_END = Decimal(os.environ.get("VOXPROOF_V3_WINDOW_END", FROZEN_WINDOW_END))

SESSION_TERMS_LINES = [
    "Project Manager | alias:PM",
    "Industrial Designer | alias:ID",
    "User Interface Designer | alias:UI | alias:UID",
    "Marketing Expert | alias:ME",
]
SESSION_TERMS_TEXT = "\n".join(SESSION_TERMS_LINES) + "\n"

PHASE_B_DIR = STUDY_ROOT / "phase-b"
ISOLATED_CARGO_TARGET = PHASE_B_DIR / "cargo-target-isolated"
ISOLATED_BINARY = ISOLATED_CARGO_TARGET / "debug/vox-proof"
BINARY_ATTESTATION_PATH = PHASE_B_DIR / "binary-attestation.json"
SCRIPT_LOCK_PATH = PHASE_B_DIR / "script-lock.json"
STAGE_STATE_PATH = PHASE_B_DIR / "stage-state.json"
SOURCE_LOCK_PATH = STUDY_ROOT / "source-lock.json"
TERMS_PATH = STUDY_ROOT / "session-terms/session-terms.txt"
BUILD_ROOT = PHASE_B_DIR / "build-primary"
PROBE_ROOT = PHASE_B_DIR / "probe"
REVIEW_ROOT = PHASE_B_DIR / "review"
FAILURES_ROOT = PHASE_B_DIR / "failures"
REPORTS_ROOT = PHASE_B_DIR / "reports"
PACKAGE_ROOT = PHASE_B_DIR / "package"

AUTO_ZIP = Path(os.environ.get("VOXPROOF_V3_AUTO_ZIP", FROZEN_AUTO_ZIP)).resolve()
MANUAL_ZIP = Path(os.environ.get("VOXPROOF_V3_MANUAL_ZIP", FROZEN_MANUAL_ZIP)).resolve()

MAX_CANDIDATE_BOUND = 512
TIE_POLICY_ID = "match-substitution-deletion-insertion-v1"
ORDERING_POLICY_ID = "meeting-time-midpoint-v1"
REVIEWED_PROJECTION_POLICY_ID = "cue-local-edit-global-midpoint-merge-v1"
UNSAFE_DEFINITION_ID = "selected-false-or-unsupported-or-incorrect-materialization-v1"

SCRIPT_NAMES = (
    "study_config.py",
    "common.py",
    "ami_common.py",
    "ami_transform.py",
    "binary_gate.py",
    "candidate_capture.py",
    "decision_workflow.py",
    "alignment_scorer.py",
    "independent_verifier.py",
    "metrics.py",
    "package_builder.py",
    "package_verifier.py",
    "phase_b_runner.py",
)

CHRONOLOGY_STEPS = (
    "verify_repository_archive_script_config_hashes_build_isolated_binary",
    "cross_target_content_gate_open_asr_words_segments",
    "materialize_hypothesis_srt_and_cue_token_ledger",
    "invoke_exact_binary_candidate_probe_seal_inventory",
    "open_manual_reference_words_content",
    "materialize_reference_scoring_layers_human_ground_truth_decisions",
    "validate_decision_binding_authoritative_review_verify_reproduction",
    "score_corrected_scorer_independent_verify_package_seal",
)
