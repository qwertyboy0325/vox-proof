#!/usr/bin/env python3
"""Frozen semantic labels and metric computation."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from common import ratio_or_null, write_json  # noqa: E402


def compute_study_metrics(
    *,
    inventory: dict[str, Any],
    ground_truth: dict[str, Any],
    labels: list[dict[str, Any]],
    decisions: list[str],
    alignment_audit: dict[str, Any],
) -> dict[str, Any]:
    opportunities = ground_truth.get("opportunities", [])
    candidates = inventory.get("candidates", [])
    true_candidates = [label for label in labels if label.get("classification") == "selected_true"]
    false_candidates = [label for label in labels if label.get("classification") == "selected_false"]
    matched_opportunity_ids = {
        label["matched_opportunity_id"]
        for label in true_candidates
        if label.get("matched_opportunity_id")
    }
    detector_misses = [
        opp
        for opp in opportunities
        if opp["opportunity_id"] not in matched_opportunity_ids
    ]
    accepted_indexes = {
        index for index, decision in enumerate(decisions) if decision.startswith("a ")
    }
    accepted_opportunities = {
        labels[index]["matched_opportunity_id"]
        for index in accepted_indexes
        if labels[index].get("classification") == "selected_true"
        and labels[index].get("materialized_correctly_if_accepted") is True
    }
    unsafe_indexes = {
        index
        for index in accepted_indexes
        if labels[index].get("unsafe_if_accepted") is True
    }
    raw_wer = alignment_audit["raw"]["wer"]
    reviewed_wer = alignment_audit["reviewed"]["wer"]

    return {
        "schema_revision": "voxproof-ami-study-metrics-v1",
        "definitions_revision": "v3-phase-a-memo-section-4",
        "candidate_precision": {
            "numerator": len(true_candidates),
            "denominator": len(candidates),
            "ratio": ratio_or_null(len(true_candidates), len(candidates)),
        },
        "candidate_recall": {
            "numerator": len(matched_opportunity_ids),
            "denominator": len(opportunities),
            "ratio": ratio_or_null(len(matched_opportunity_ids), len(opportunities)),
        },
        "correction_recall": {
            "numerator": len(accepted_opportunities),
            "denominator": len(opportunities),
            "ratio": ratio_or_null(
                len(accepted_opportunities),
                len(opportunities),
            ),
        },
        "false_positive_burden": len(false_candidates),
        "unsafe_edit_rate": {
            "numerator": len(unsafe_indexes),
            "denominator": len(accepted_indexes),
            "ratio": ratio_or_null(len(unsafe_indexes), len(accepted_indexes)),
        },
        "raw_wer": raw_wer,
        "reviewed_wer": reviewed_wer,
        "raw_to_reviewed_wer_delta": (
            None if raw_wer is None or reviewed_wer is None else reviewed_wer - raw_wer
        ),
        "zero_denominator_rule": "ratio fields are JSON null when denominator is zero",
        "detector_miss_count": len(detector_misses),
        "selected_true_candidate_count": len(true_candidates),
        "selected_false_candidate_count": len(false_candidates),
        "alignment": {
            key: alignment_audit[key]
            for key in ("raw", "reviewed", "raw_to_reviewed_wer_delta")
        },
        "accepted_candidate_count": len(accepted_indexes),
    }


def main() -> int:
    import argparse
    import json

    parser = argparse.ArgumentParser(description="Compute frozen study metrics")
    parser.add_argument("--inventory", required=True)
    parser.add_argument("--ground-truth", required=True)
    parser.add_argument("--labels", required=True)
    parser.add_argument("--decision-inputs", required=True)
    parser.add_argument("--scoring-tokens", required=True)
    parser.add_argument("--alignment-audit", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    inventory = json.loads(Path(args.inventory).read_text(encoding="utf-8"))
    ground_truth = json.loads(Path(args.ground_truth).read_text(encoding="utf-8"))
    labels_payload = json.loads(Path(args.labels).read_text(encoding="utf-8"))
    decisions_payload = json.loads(Path(args.decision_inputs).read_text(encoding="utf-8"))
    alignment_audit = json.loads(Path(args.alignment_audit).read_text(encoding="utf-8"))
    metrics = compute_study_metrics(
        inventory=inventory,
        ground_truth=ground_truth,
        labels=labels_payload["labels"],
        decisions=decisions_payload["decisions"],
        alignment_audit=alignment_audit,
    )
    write_json(Path(args.output), metrics)
    print(json.dumps({"status": "ok", "candidate_count": inventory["candidate_count"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
