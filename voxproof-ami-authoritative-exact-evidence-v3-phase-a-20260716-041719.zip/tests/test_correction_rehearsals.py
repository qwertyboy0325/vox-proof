#!/usr/bin/env python3
"""Exact fixture runner rehearsals and fail-closed negative tests."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "phase-b/scripts"
REPO = Path("/Users/Ezra4/Coding/Repo/vox-proof")
sys.path.insert(0, str(SCRIPTS))

from alignment_scorer import AlignmentResult  # noqa: E402
from binary_gate import verify_binary_hash_immediately_before_invocation  # noqa: E402
from candidate_capture import compare_candidate_sets  # noqa: E402
from common import is_unsafe_zip_path, sha256_file, write_json  # noqa: E402
from decision_workflow import validate_candidate_labels  # noqa: E402
from package_verifier import verify_package  # noqa: E402

TERMS = (
    "Project Manager | alias:PM\n"
    "Industrial Designer | alias:ID\n"
    "User Interface Designer | alias:UI | alias:UID\n"
    "Marketing Expert | alias:ME\n"
)
NITE = "http://nite.sourceforge.net/"


def words_xml(rows: list[tuple[str, str, str, str]]) -> bytes:
    elements = "".join(
        f'<w nite:id="{identifier}" starttime="{start}" endtime="{end}">{text}</w>'
        for identifier, start, end, text in rows
    )
    return f'<words xmlns:nite="{NITE}">{elements}</words>'.encode()


def segments_xml(
    meeting: str, speaker: str, first: str, last: str
) -> bytes:
    return (
        f'<segments xmlns:nite="{NITE}">'
        f'<segment nite:id="seg-{speaker}">'
        f'<child href="{meeting}.{speaker}.words.xml#id({first})..id({last})"/>'
        f"</segment></segments>"
    ).encode()


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class FixtureStudy:
    def __init__(self, root: Path, *, nonzero: bool, overlapping: bool = False) -> None:
        self.root = root
        self.nonzero = nonzero
        self.overlapping = overlapping
        self.meeting = "TS0001a" if nonzero else "TS0000a"
        self.auto = root / "fixtures/auto.zip"
        self.manual = root / "fixtures/manual.zip"
        self.env = {
            **os.environ,
            "VOXPROOF_V3_STUDY_ROOT": str(root),
            "VOXPROOF_V3_MEETING_ID": self.meeting,
            "VOXPROOF_V3_WINDOW_START": "0.000",
            "VOXPROOF_V3_WINDOW_END": "10.000",
            "VOXPROOF_V3_AUTO_ZIP": str(self.auto),
            "VOXPROOF_V3_MANUAL_ZIP": str(self.manual),
            "VOXPROOF_V3_FIXTURE_MODE": "1",
        }

    def setup(self) -> None:
        scripts = self.root / "phase-b/scripts"
        scripts.mkdir(parents=True)
        for source in SCRIPTS.glob("*.py"):
            shutil.copy2(source, scripts / source.name)
        terms = self.root / "session-terms/session-terms.txt"
        terms.parent.mkdir(parents=True)
        terms.write_text(TERMS, encoding="utf-8")
        self.auto.parent.mkdir(parents=True)
        with zipfile.ZipFile(self.auto, "w") as archive:
            for rank, speaker in enumerate("ABCD"):
                offset = rank * (0.1 if self.overlapping else 2)
                start = str(1 + offset)
                end = str(1.4 + offset)
                first = f"{speaker}-w1"
                last = f"{speaker}-w2"
                text = "PM" if self.nonzero and speaker == "A" else "hello"
                rows = [(first, start, end, text), (last, str(float(start) + 0.5), str(float(end) + 0.5), "plan")]
                prefix = "ASR/ASR_AS_CTM_v1.0_feb07/"
                archive.writestr(
                    f"{prefix}{self.meeting}.{speaker}.words.xml", words_xml(rows)
                )
                archive.writestr(
                    f"{prefix}{self.meeting}.{speaker}.segments.xml",
                    segments_xml(self.meeting, speaker, first, last),
                )
        with zipfile.ZipFile(self.manual, "w") as archive:
            for rank, speaker in enumerate("ABCD"):
                offset = rank * (0.1 if self.overlapping else 2)
                start = str(1 + offset)
                end = str(1.4 + offset)
                first = f"{speaker}-m1"
                second = f"{speaker}-m2"
                text = (
                    "Project Manager"
                    if self.nonzero and speaker == "A"
                    else "hello"
                )
                archive.writestr(
                    f"words/{self.meeting}.{speaker}.words.xml",
                    words_xml(
                        [
                            (first, start, end, text),
                            (
                                second,
                                str(float(start) + 0.5),
                                str(float(end) + 0.5),
                                "plan",
                            ),
                        ]
                    ),
                )
        script_rows = [
            {
                "path": f"phase-b/scripts/{path.name}",
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
            for path in sorted(scripts.glob("*.py"))
        ]
        write_json(
            self.root / "phase-b/script-lock.json",
            {"schema_revision": "voxproof-ami-script-lock-v1", "scripts": script_rows},
        )
        write_json(
            self.root / "source-lock.json",
            {
                "schema_revision": "voxproof-ami-source-lock-v2",
                "protocol_id": "voxproof-ami-authoritative-exact-evidence-v3",
                "meeting_id": self.meeting,
                "window": {
                    "start_inclusive": "0.000",
                    "end_exclusive": "10.000",
                },
                "archives": [
                    {
                        "name": "ami_public_auto_1.5.1.zip",
                        "sha256": sha256_file(self.auto),
                        "bytes": self.auto.stat().st_size,
                    },
                    {
                        "name": "ami_public_manual_1.6.2.zip",
                        "sha256": sha256_file(self.manual),
                        "bytes": self.manual.stat().st_size,
                    },
                ],
                "session_terms_sha256": sha256_file(terms),
                "repository": {
                    "cargo_lock_sha256": sha256_file(REPO / "Cargo.lock")
                },
            },
        )
        write_json(
            self.root / "phase-b/stage-state.json",
            {
                "schema_revision": "voxproof-ami-stage-state-v2",
                "completed": [],
                "access_gate_crossed": False,
                "terminal_failed": False,
                "failure_record": None,
                "stage_details": {},
            },
        )

    def run(self, stage: str, *, succeeds: bool = True) -> subprocess.CompletedProcess[str]:
        result = subprocess.run(
            [sys.executable, str(self.root / "phase-b/scripts/phase_b_runner.py"), stage],
            env=self.env,
            text=True,
            capture_output=True,
            check=False,
        )
        if succeeds and result.returncode:
            raise AssertionError(f"{stage} failed:\n{result.stdout}\n{result.stderr}")
        return result

    def write_review_inputs(self) -> None:
        inventory_path = self.root / "phase-b/probe/candidate-inventory.json"
        inventory = json.loads(inventory_path.read_text())
        reference_path = (
            self.root / "phase-b/build-primary/reference-layer-manifest.json"
        )
        reviewer = {
            "reviewer_id": "fixture-human-1",
            "display_name": "Fixture Human Reviewer",
            "attested_at_utc": "2026-07-16T00:00:00Z",
            "attestation": "Human-authored fixture judgment; no automatic reference decisions.",
        }
        opportunities = (
            [
                {
                    "opportunity_id": "opp-1",
                    "canonical_term": "Project Manager",
                    "source_rendering": "PM",
                    "speaker": "A",
                    "cue_index": 1,
                    "start": "1.0",
                    "end": "1.4",
                    "reference_token_ids": ["A-m1"],
                    "acceptable_variant": False,
                    "support_rationale": "Synthetic manual reference spells canonical term.",
                }
            ]
            if self.nonzero
            else []
        )
        ground = {
            "schema_revision": "voxproof-ami-ground-truth-v2",
            "reviewer": reviewer,
            "reference_layer_sha256": sha256_file(reference_path),
            "normalization_policy_id": "unicode-nfc-casefold-remove-punctuation-v1",
            "overlap_policy_id": "localized-time-and-cue-overlap-one-to-one-v1",
            "acceptable_variant_policy_id": "acceptable-variants-are-not-opportunities-v1",
            "opportunities": opportunities,
        }
        labels = []
        for index, candidate in enumerate(inventory["candidates"]):
            true = self.nonzero and index == 0
            labels.append(
                {
                    "candidate_fingerprint": candidate["fingerprint"],
                    "classification": "selected_true" if true else "selected_false",
                    "matched_opportunity_id": "opp-1" if true else None,
                    "replacement_supported": true,
                    "boundary_supported": true,
                    "materialized_correctly_if_accepted": true,
                    "unsafe_if_accepted": not true,
                    "unsafe_edit_rationale": (
                        "Supported synthetic correction."
                        if true
                        else "No matched opportunity; accepting would be unsafe."
                    ),
                }
            )
        inventory_hash = sha256_file(inventory_path)
        labels_payload = {
            "schema_revision": "voxproof-ami-candidate-labels-v2",
            "reviewer": reviewer,
            "unsafe_definition_id": "selected-false-or-unsupported-or-incorrect-materialization-v1",
            "reference_layer_sha256": sha256_file(reference_path),
            "inventory_sha256": inventory_hash,
            "labels": labels,
        }
        decisions = ["a 0"] if self.nonzero else []
        decisions_payload = {
            "schema_revision": "voxproof-ami-decision-inputs-v2",
            "reviewer": reviewer,
            "inventory_sha256": inventory_hash,
            "transcript_revision": inventory["transcript_revision"],
            "candidate_fingerprints": [
                candidate["fingerprint"] for candidate in inventory["candidates"]
            ],
            "decisions": decisions,
        }
        review = self.root / "phase-b/review"
        review.mkdir(parents=True)
        write_json(review / "ground-truth.json", ground)
        write_json(review / "candidate-labels.json", labels_payload)
        write_json(review / "decision-inputs.json", decisions_payload)

    def run_full(self) -> dict[str, object]:
        for stage in (
            "preflight",
            "build-binary",
            "hypothesis",
            "probe-candidates",
            "reference",
        ):
            self.run(stage)
        self.write_review_inputs()
        for stage in (
            "validate-review-inputs",
            "authoritative-review",
            "score",
            "independent-verify",
            "package",
        ):
            self.run(stage)
        return json.loads((self.root / "phase-b/metrics.json").read_text())


class CorrectionRehearsalTests(unittest.TestCase):
    def test_production_target_override_rejected(self) -> None:
        env = {**os.environ, "VOXPROOF_V3_MEETING_ID": "TS0001a"}
        env.pop("VOXPROOF_V3_FIXTURE_MODE", None)
        result = subprocess.run(
            [sys.executable, "-c", "import study_config"],
            cwd=SCRIPTS,
            env=env,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("production behavior override", result.stderr)

    def test_production_window_override_rejected(self) -> None:
        env = {**os.environ, "VOXPROOF_V3_WINDOW_START": "0"}
        env.pop("VOXPROOF_V3_FIXTURE_MODE", None)
        result = subprocess.run(
            [sys.executable, "-c", "import study_config"],
            cwd=SCRIPTS,
            env=env,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("production behavior override", result.stderr)

    def test_full_zero_candidate_runner(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=False)
            fixture.setup()
            metrics = fixture.run_full()
            self.assertEqual(metrics["candidate_precision"]["ratio"], None)
            self.assertTrue(
                (fixture.root / "phase-b/package/voxproof-ami-authoritative-exact-evidence-v3-phase-b-final.zip").exists()
            )

    def test_full_nonzero_accept_changes_reviewed_wer(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=True)
            fixture.setup()
            metrics = fixture.run_full()
            self.assertLess(metrics["reviewed_wer"], metrics["raw_wer"])
            self.assertLess(metrics["raw_to_reviewed_wer_delta"], 0)
            self.assertEqual(metrics["accepted_candidate_count"], 1)

    def test_overlapping_speaker_identity_projection(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=False, overlapping=True)
            fixture.setup()
            fixture.run_full()
            scoring = json.loads(
                (fixture.root / "phase-b/build-primary/scoring_tokens.json").read_text()
            )
            audit = json.loads(
                (fixture.root / "phase-b/alignment-audit.json").read_text()
            )
            self.assertEqual(audit["reviewed_tokens"], scoring["hypothesis_tokens"])
            self.assertTrue(audit["reviewed_projection"]["identity_review"])

    def test_inventory_mutation_before_reference_is_terminal(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=False)
            fixture.setup()
            for stage in ("preflight", "build-binary", "hypothesis", "probe-candidates"):
                fixture.run(stage)
            inventory = fixture.root / "phase-b/probe/candidate-inventory.json"
            inventory.write_text(inventory.read_text() + " ", encoding="utf-8")
            result = fixture.run("reference", succeeds=False)
            self.assertNotEqual(result.returncode, 0)
            state = json.loads((fixture.root / "phase-b/stage-state.json").read_text())
            self.assertTrue(state["terminal_failed"])

    def test_human_input_mutation_before_authoritative_review_is_terminal(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=False)
            fixture.setup()
            for stage in (
                "preflight",
                "build-binary",
                "hypothesis",
                "probe-candidates",
                "reference",
            ):
                fixture.run(stage)
            fixture.write_review_inputs()
            fixture.run("validate-review-inputs")
            labels = fixture.root / "phase-b/review/candidate-labels.json"
            labels.write_text(labels.read_text() + " ", encoding="utf-8")
            result = fixture.run("authoritative-review", succeeds=False)
            self.assertNotEqual(result.returncode, 0)

    def test_reference_mutation_before_score_is_terminal(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=False)
            fixture.setup()
            for stage in (
                "preflight",
                "build-binary",
                "hypothesis",
                "probe-candidates",
                "reference",
            ):
                fixture.run(stage)
            fixture.write_review_inputs()
            fixture.run("validate-review-inputs")
            fixture.run("authoritative-review")
            scoring = fixture.root / "phase-b/build-primary/scoring_tokens.json"
            scoring.write_text(scoring.read_text() + " ", encoding="utf-8")
            result = fixture.run("score", succeeds=False)
            self.assertNotEqual(result.returncode, 0)

    def test_unsafe_zip_paths_rejected(self) -> None:
        self.assertTrue(is_unsafe_zip_path(r"dir\file.txt"))
        self.assertTrue(is_unsafe_zip_path("dir/\x00file.txt"))
        self.assertTrue(is_unsafe_zip_path("../file.txt"))
        self.assertFalse(is_unsafe_zip_path("dir/file.txt"))

    def test_inconsistent_human_label_rejected(self) -> None:
        reviewer = {
            "reviewer_id": "r",
            "display_name": "R",
            "attested_at_utc": "2026-07-16T00:00:00Z",
            "attestation": "human",
        }
        payload = {
            "reviewer": reviewer,
            "reference_layer_sha256": "ref",
            "unsafe_definition_id": "selected-false-or-unsupported-or-incorrect-materialization-v1",
            "labels": [
                {
                    "candidate_fingerprint": "fp",
                    "classification": "selected_true",
                    "matched_opportunity_id": "opp",
                    "replacement_supported": False,
                    "boundary_supported": True,
                    "materialized_correctly_if_accepted": True,
                    "unsafe_if_accepted": False,
                    "unsafe_edit_rationale": "",
                }
            ],
        }
        inventory = {"candidate_count": 1, "candidates": [{"fingerprint": "fp"}]}
        ground = {"opportunities": [{"opportunity_id": "opp"}]}
        errors = validate_candidate_labels(payload, inventory, ground, "ref")
        self.assertTrue(any("replacement unsupported" in error for error in errors))
        self.assertTrue(any("unsafe_if_accepted inconsistent" in error for error in errors))

    def test_stage_rerun_after_access_gate_is_terminal(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=False)
            fixture.setup()
            for stage in ("preflight", "build-binary", "hypothesis"):
                fixture.run(stage)
            result = fixture.run("hypothesis", succeeds=False)
            self.assertNotEqual(result.returncode, 0)
            state = json.loads((fixture.root / "phase-b/stage-state.json").read_text())
            self.assertTrue(state["terminal_failed"])

    def test_script_lock_mutation_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=False)
            fixture.setup()
            with (fixture.root / "phase-b/scripts/common.py").open("a") as handle:
                handle.write("\n# mutation\n")
            self.assertNotEqual(fixture.run("preflight", succeeds=False).returncode, 0)

    def test_dirty_tracked_status_detection(self) -> None:
        import binary_gate

        clean_head = subprocess.check_output(
            ["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True
        )
        with patch.object(binary_gate.subprocess, "check_output", return_value=clean_head), patch.object(
            binary_gate.subprocess,
            "run",
            side_effect=[
                subprocess.CompletedProcess([], 1),
                subprocess.CompletedProcess([], 0),
            ],
        ):
            with self.assertRaises(RuntimeError):
                binary_gate.verify_repository_head()

    def test_candidate_mismatch_rejected(self) -> None:
        errors = compare_candidate_sets(
            [{"fingerprint": "a", "local_index": 0}],
            [{"fingerprint": "b", "local_index": 0}],
            frozen_revision="r1",
            reproduced_revision="r1",
        )
        self.assertTrue(errors)

    def test_binary_hash_mismatch_rejected(self) -> None:
        with tempfile.NamedTemporaryFile() as handle:
            path = Path(handle.name)
            with self.assertRaises(RuntimeError):
                verify_binary_hash_immediately_before_invocation(
                    path,
                    {"binary_path": str(path), "binary_sha256": "0" * 64},
                )

    def test_malformed_wer_decomposition_rejected(self) -> None:
        result = AlignmentResult(
            reference_tokens=("a",),
            hypothesis_tokens=("b",),
            operations=(),
            matches=0,
            substitutions=0,
            deletions=0,
            insertions=0,
            edit_distance=0,
        )
        self.assertTrue(result.validate_invariants())

    def test_manifest_corruption_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            zip_path = root / "bad.zip"
            with zipfile.ZipFile(zip_path, "w") as archive:
                archive.writestr("a.txt", b"ok")
                archive.writestr(
                    "manifest.json",
                    json.dumps(
                        {
                            "mode": "phase-a",
                            "entry_count": 1,
                            "files": [
                                {"path": "a.txt", "sha256": "bad", "bytes": 2}
                            ],
                        }
                    ),
                )
            seal_path = root / "seal.json"
            write_json(
                seal_path,
                {
                    "zip_sha256": sha256_file(zip_path),
                    "zip_entry_count": 2,
                    "embedded_manifest_sha256": "bad",
                    "entries": [],
                },
            )
            self.assertEqual(
                verify_package(root, zip_path, seal_path, "phase-a")["status"],
                "fail",
            )


if __name__ == "__main__":
    unittest.main(verbosity=2)
