# Phase B exact commands (frozen executable envelope; do not execute in Phase A)

## Authoritative chronology (8 steps)
1. verify repository, archive, script, and config hashes; build isolated binary
2. cross target-content gate once by opening target ASR words/segments
3. materialize hypothesis SRT and cue/token ledger
4. invoke exact binary candidate probe and seal candidate inventory
5. only then open manual/reference words content
6. materialize reference/scoring layers; human reviewer creates ground truth and decision inputs
7. validate decision binding; invoke authoritative review; verify candidate reproduction before promoting outputs
8. score with corrected operation-aware scorer; independently verify; package once; detached seal afterward

## Exact executable sequence

The approved/extracted correction tree is the future Phase B study root. Override
`VOXPROOF_V3_STUDY_ROOT` only when rehearsing an isolated synthetic fixture tree.

```sh
export VOXPROOF_V3_STUDY_ROOT="/private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-a-correction"
cd "$VOXPROOF_V3_STUDY_ROOT"

python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" preflight
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" build-binary
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" hypothesis
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" probe-candidates
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" reference

# A designated human reviewer now authors these three frozen-schema files:
# phase-b/review/ground-truth.json
# phase-b/review/candidate-labels.json
# phase-b/review/decision-inputs.json

python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" validate-review-inputs
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" authoritative-review
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" score
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" independent-verify
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" package
```

The final stage deterministically writes and verifies:

- `phase-b/package/voxproof-ami-authoritative-exact-evidence-v3-phase-b-final.zip`
- `phase-b/package/package-seal-v3-phase-b-final.json`

## Frozen target
meeting_id=ES2004b
window=[300.000, 900.000)
