from __future__ import annotations

import hashlib
import json
import shlex
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

HARNESS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HARNESS))

from single_request_protocol import (  # noqa: E402
    ProtocolFailure,
    invoke_one,
    request_identity,
)
import run_single_request_harness  # noqa: E402


REQUEST = {
    "schema_revision": "experimental-context-rank-request-v1",
    "session_description": "Sports commentary",
    "nearby_context": "The team played tennis.",
    "source_surface": "ten days",
    "candidates": [
        {
            "candidate_id": "experimental-1",
            "canonical_term": "tennis",
            "producer": "LatinNormalizedDistance",
            "source_representation": "ten days",
            "target_representation": "tennis",
            "distance": 1,
            "ratio_numerator": 8,
            "ratio_denominator": 9,
        }
    ],
}


def provider(script: str) -> list[str]:
    return [sys.executable, "-c", script]


def response_program(response_expression: str) -> str:
    return (
        "import json,sys; wrapper=json.load(sys.stdin); "
        f"response={response_expression}; "
        "sys.stdout.write(json.dumps(response,separators=(',',':')))"
    )


def valid_wrapper(identity_expression: str = "wrapper['request_identity']") -> str:
    return (
        "{'protocol_revision':'voxproof-single-request-identity-v1',"
        f"'request_identity':{identity_expression},"
        "'response':{'schema_revision':'experimental-context-rank-request-v1',"
        "'selected_candidate_id':'experimental-1','assessment':'strong',"
        "'reason_codes':['nearby_context_term_overlap'],'requires_review':True,"
        "'display_explanation':None}}"
    )


def write_expectation(
    root: Path,
    requests: list[dict],
    *,
    sha256: str | None = None,
    identities: list[str] | None = None,
    count: int | None = None,
) -> Path:
    raw = b"".join(
        json.dumps(request, separators=(",", ":")).encode("utf-8") + b"\n"
        for request in requests
    )
    path = root / "expectation.json"
    path.write_text(
        json.dumps(
            {
                "expected_request_count": len(requests) if count is None else count,
                "request_sha256": hashlib.sha256(raw).hexdigest() if sha256 is None else sha256,
                "expected_request_identities": (
                    [request_identity(request) for request in requests]
                    if identities is None
                    else identities
                ),
            }
        )
    )
    return path


class SingleRequestProtocolTests(unittest.TestCase):
    def invoke(self, command: list[str], request: dict = REQUEST):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        return invoke_one(request, command, Path(temporary.name), timeout_seconds=0.1)

    def assert_failure(self, code: str, command: list[str]) -> None:
        with self.assertRaises(ProtocolFailure) as raised:
            self.invoke(command)
        self.assertEqual(code, raised.exception.code)

    def run_harness(
        self,
        root: Path,
        request_file: Path,
        expectation: Path,
        command: str,
    ) -> subprocess.CompletedProcess:
        return subprocess.run(
            [
                sys.executable,
                str(HARNESS / "run_single_request_harness.py"),
                "--requests",
                str(request_file),
                "--expectation",
                str(expectation),
                "--command",
                command,
                "--artifact-dir",
                str(root / "artifacts"),
                "--timeout-seconds",
                "0.1",
                "--max-workers",
                "2",
            ],
            check=False,
        )

    def test_accepts_valid_correlated_response_and_preserves_raw_bytes(self) -> None:
        result = self.invoke(
            provider(response_program(valid_wrapper())),
        )
        self.assertEqual(request_identity(REQUEST), result.request_identity)
        self.assertEqual("experimental-1", result.inner_response["selected_candidate_id"])
        raw = result.raw_response_path.read_bytes()
        self.assertEqual(
            raw,
            json.dumps(
                {
                    "protocol_revision": "voxproof-single-request-identity-v1",
                    "request_identity": result.request_identity,
                    "response": result.inner_response,
                },
                separators=(",", ":"),
            ).encode("utf-8"),
        )

    def test_rejects_wrong_request_identity(self) -> None:
        self.assert_failure(
            "identity_mismatch",
            provider(response_program(valid_wrapper("'wrong-identity'"))),
        )

    def test_rejects_missing_display_explanation(self) -> None:
        expression = valid_wrapper().replace(",'display_explanation':None", "")
        self.assert_failure("malformed_response", provider(response_program(expression)))

    def test_accepts_null_display_explanation(self) -> None:
        result = self.invoke(provider(response_program(valid_wrapper())))
        self.assertIsNone(result.inner_response["display_explanation"])

    def test_rejects_explanation_longer_than_160_characters(self) -> None:
        expression = valid_wrapper().replace("None", "'x' * 161")
        self.assert_failure("invalid_response", provider(response_program(expression)))

    def test_rejects_non_string_selected_candidate(self) -> None:
        expression = valid_wrapper().replace("'experimental-1'", "123")
        self.assert_failure("malformed_response", provider(response_program(expression)))

    def test_unsupported_requires_no_candidate_supported(self) -> None:
        expression = (
            "{'protocol_revision':'voxproof-single-request-identity-v1',"
            "'request_identity':wrapper['request_identity'],"
            "'response':{'schema_revision':'experimental-context-rank-request-v1',"
            "'selected_candidate_id':None,'assessment':'unsupported',"
            "'reason_codes':['nearby_context_term_overlap'],'requires_review':True,"
            "'display_explanation':None}}"
        )
        self.assert_failure("invalid_response", provider(response_program(expression)))

    def test_ambiguous_requires_multiple_request_candidates(self) -> None:
        expression = (
            "{'protocol_revision':'voxproof-single-request-identity-v1',"
            "'request_identity':wrapper['request_identity'],"
            "'response':{'schema_revision':'experimental-context-rank-request-v1',"
            "'selected_candidate_id':None,'assessment':'ambiguous',"
            "'reason_codes':['multiple_candidates'],'requires_review':True,"
            "'display_explanation':None}}"
        )
        self.assert_failure("invalid_response", provider(response_program(expression)))

    def test_rejects_next_window_candidate_id(self) -> None:
        expression = valid_wrapper().replace("'experimental-1'", "'next-window-candidate'")
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(ProtocolFailure) as raised:
                invoke_one(
                    REQUEST,
                    provider(response_program(expression)),
                    Path(temporary),
                    timeout_seconds=0.1,
                )
            self.assertEqual("invalid_candidate_membership", raised.exception.code)
            metadata = json.loads(
                (Path(temporary) / "metadata" / f"{request_identity(REQUEST)}.json").read_text()
            )
            self.assertEqual("invalid_candidate_membership", metadata["failure"]["code"])

    def test_records_missing_response(self) -> None:
        self.assert_failure("missing_response", provider("import sys; sys.stdin.read()"))

    def test_records_duplicate_response(self) -> None:
        script = (
            "import json,sys; wrapper=json.load(sys.stdin); "
            f"response={valid_wrapper()}; "
            "encoded=json.dumps(response,separators=(',',':')); "
            "sys.stdout.write(encoded + encoded)"
        )
        self.assert_failure("duplicate_response", provider(script))

    def test_records_malformed_response(self) -> None:
        self.assert_failure(
            "malformed_response",
            provider("import sys; sys.stdin.read(); sys.stdout.write('{')"),
        )

    def test_records_timeout(self) -> None:
        self.assert_failure(
            "timeout",
            provider("import sys,time; sys.stdin.read(); time.sleep(1)"),
        )

    def test_accepts_null_selection_with_valid_correlation(self) -> None:
        expression = (
            "{'protocol_revision':'voxproof-single-request-identity-v1',"
            "'request_identity':wrapper['request_identity'],"
            "'response':{'schema_revision':'experimental-context-rank-request-v1',"
            "'selected_candidate_id':None,'assessment':'unsupported',"
            "'reason_codes':['no_candidate_supported'],'requires_review':True,"
            "'display_explanation':None}}"
        )
        result = self.invoke(provider(response_program(expression)))
        self.assertIsNone(result.inner_response["selected_candidate_id"])

    def test_invalid_response_cannot_become_adapter_output(self) -> None:
        script = response_program(valid_wrapper().replace("'experimental-1'", "'next-window-candidate'"))
        with tempfile.TemporaryDirectory() as temporary:
            command = [
                sys.executable,
                str(HARNESS / "identity_validated_adapter.py"),
            ]
            completed = subprocess.run(
                command,
                input=json.dumps(REQUEST).encode("utf-8"),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env={
                    "PATH": "/usr/bin:/bin",
                    "VOX_PROOF_SINGLE_REQUEST_COMMAND": (
                        f"{shlex.quote(sys.executable)} -c {shlex.quote(script)}"
                    ),
                    "VOX_PROOF_SINGLE_REQUEST_ARTIFACT_DIR": temporary,
                },
                check=False,
            )
            self.assertNotEqual(0, completed.returncode)
            self.assertEqual(b"", completed.stdout)
            self.assertIn(b"invalid_candidate_membership", completed.stderr)

    def test_partial_run_is_diagnostic_only(self) -> None:
        second_request = {**REQUEST, "source_surface": "next window"}
        provider_script = (
            "import json,sys; wrapper=json.load(sys.stdin); "
            "selected='experimental-1' if wrapper['request']['source_surface'] == 'ten days' "
            "else 'next-window-candidate'; "
            "response={'protocol_revision':'voxproof-single-request-identity-v1',"
            "'request_identity':wrapper['request_identity'],'response':"
            "{'schema_revision':'experimental-context-rank-request-v1',"
            "'selected_candidate_id':selected,'assessment':'strong',"
            "'reason_codes':['nearby_context_term_overlap'],'requires_review':True}}; "
            "sys.stdout.write(json.dumps(response,separators=(',',':')))"
        )
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            request_file = root / "requests.jsonl"
            request_file.write_text(
                "\n".join(
                    json.dumps(request, separators=(",", ":"))
                    for request in (REQUEST, second_request)
                )
                + "\n"
            )
            expectation = write_expectation(root, [REQUEST, second_request])
            completed = subprocess.run(
                [
                    sys.executable,
                    str(HARNESS / "run_single_request_harness.py"),
                    "--requests",
                    str(request_file),
                    "--expectation",
                    str(expectation),
                    "--command",
                    f"{shlex.quote(sys.executable)} -c {shlex.quote(provider_script)}",
                    "--artifact-dir",
                    str(root / "artifacts"),
                    "--timeout-seconds",
                    "0.1",
                    "--max-workers",
                    "2",
                ],
                check=False,
            )
            self.assertEqual(1, completed.returncode)
            summary = json.loads((root / "artifacts" / "run-summary.json").read_text())
            self.assertEqual("diagnostic_only_partial_protocol_run", summary["quality_comparison_status"])

    def test_truncated_request_corpus_is_not_eligible(self) -> None:
        second_request = {**REQUEST, "source_surface": "next window"}
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            request_file = root / "requests.jsonl"
            request_file.write_text(json.dumps(REQUEST, separators=(",", ":")) + "\n")
            expectation = write_expectation(root, [REQUEST, second_request])
            completed = self.run_harness(root, request_file, expectation, "unused-provider")
            self.assertEqual(1, completed.returncode)
            summary = json.loads((root / "artifacts" / "run-summary.json").read_text())
            self.assertFalse(summary["complete_identity_verified"])
            self.assertEqual("diagnostic_only_partial_protocol_run", summary["quality_comparison_status"])

    def test_wrong_request_file_sha_is_not_eligible(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            request_file = root / "requests.jsonl"
            request_file.write_text(json.dumps(REQUEST, separators=(",", ":")) + "\n")
            expectation = write_expectation(root, [REQUEST], sha256="0" * 64)
            completed = self.run_harness(root, request_file, expectation, "unused-provider")
            self.assertEqual(1, completed.returncode)
            summary = json.loads((root / "artifacts" / "run-summary.json").read_text())
            self.assertIn(
                "request_sha256_mismatch",
                [outcome["failure_code"] for outcome in summary["outcomes"]],
            )

    def test_duplicate_request_identity_is_not_eligible(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            request_file = root / "requests.jsonl"
            request_file.write_text(
                "\n".join(json.dumps(REQUEST, separators=(",", ":")) for _ in range(2)) + "\n"
            )
            identity = request_identity(REQUEST)
            expectation = write_expectation(root, [REQUEST, REQUEST], identities=[identity, identity])
            completed = self.run_harness(root, request_file, expectation, "unused-provider")
            self.assertEqual(1, completed.returncode)
            summary = json.loads((root / "artifacts" / "run-summary.json").read_text())
            self.assertIn(
                "duplicate_request_identity",
                [outcome["failure_code"] for outcome in summary["outcomes"]],
            )

    def test_provider_executable_not_found_writes_diagnostic_summary(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            request_file = root / "requests.jsonl"
            request_file.write_text(json.dumps(REQUEST, separators=(",", ":")) + "\n")
            expectation = write_expectation(root, [REQUEST])
            completed = self.run_harness(
                root,
                request_file,
                expectation,
                "voxproof-provider-that-does-not-exist",
            )
            self.assertEqual(1, completed.returncode)
            summary = json.loads((root / "artifacts" / "run-summary.json").read_text())
            self.assertEqual(request_identity(REQUEST), summary["outcomes"][0]["request_identity"])
            self.assertEqual("provider_spawn_failed", summary["outcomes"][0]["failure_code"])

    def test_unexpected_internal_error_writes_diagnostic_summary(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            request_file = root / "requests.jsonl"
            request_file.write_text(json.dumps(REQUEST, separators=(",", ":")) + "\n")
            expectation = write_expectation(root, [REQUEST])
            identity = request_identity(REQUEST)
            argv = [
                "run_single_request_harness.py",
                "--requests",
                str(request_file),
                "--expectation",
                str(expectation),
                "--command",
                "unused-provider",
                "--artifact-dir",
                str(root / "artifacts"),
                "--timeout-seconds",
                "0.1",
                "--max-workers",
                "1",
            ]
            with patch(
                "single_request_protocol.invoke_one",
                side_effect=RuntimeError("metadata write exploded outside protected block"),
            ):
                with patch.object(sys, "argv", argv):
                    with self.assertRaises(SystemExit) as raised:
                        run_single_request_harness.main()
            self.assertEqual(1, raised.exception.code)
            summary_path = root / "artifacts" / "run-summary.json"
            self.assertTrue(summary_path.exists())
            summary = json.loads(summary_path.read_text())
            self.assertEqual("diagnostic_only_partial_protocol_run", summary["quality_comparison_status"])
            self.assertFalse(summary["complete_identity_verified"])
            self.assertEqual(identity, summary["outcomes"][0]["request_identity"])
            self.assertEqual("unexpected_internal_error", summary["outcomes"][0]["failure_code"])


if __name__ == "__main__":
    unittest.main()
