# Phase B exact commands (frozen; do not execute in Phase A)

## Repository and build attestation
cd /Users/Ezra4/Coding/Repo/vox-proof
git rev-parse HEAD  # must equal 5286c1627e54852fc08f4766240ce7545269e982
CARGO_TARGET_DIR=/private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-b/cargo-target-isolated cargo build --locked
shasum -a 256 "$CARGO_TARGET_DIR/debug/vox-proof"

## Preflight (archives already on disk; no re-download unless hash mismatch)
python3 phase-b/scripts/run_phase_b.py preflight

## Target-content access gate (single crossing)
# Only after candidate-inventory freeze point definition is satisfied by protocol:
# 1. build hypothesis SRT from ASR words+segments
# 2. build reference token ledger from manual words
# 3. freeze candidate inventory before any reference-content-driven term changes

python3 phase-b/scripts/ami_transform.py hypothesis
python3 phase-b/scripts/candidate_inventory.py freeze
python3 phase-b/scripts/ami_transform.py reference

## Authoritative review (zero decisions expected path remains valid)
/Users/Ezra4/Coding/Repo/vox-proof/target/debug/vox-proof review \
  phase-b/build-primary/input.srt \
  session-terms/session-terms.txt \
  phase-b/review/reviewed-output.srt \
  phase-b/review/decision-log.txt \
  phase-b/review/session-summary.txt

## Scoring and verification
python3 phase-b/scripts/alignment_scorer.py score
python3 phase-b/scripts/independent_verifier.py /private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-b
python3 phase-b/scripts/package_verifier.py /private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-b

## Frozen target
meeting_id=ES2004b
window=[300.000, 900.000)
