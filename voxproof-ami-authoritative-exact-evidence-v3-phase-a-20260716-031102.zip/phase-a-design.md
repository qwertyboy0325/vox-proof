# VoxProof Authoritative Exact-Evidence V3 — Phase A Design

## Protocol
- **Protocol ID:** `voxproof-ami-authoritative-exact-evidence-v3`
- **Classification target:** prospective authoritative exact-evidence pre-outcome freeze
- **Phase:** A only (pre-outcome freeze)

## Governance
- c1 remains rejected forensic artifact (`3c78e8cf8c19df70aa7c67cf7ab7bb0df1abacd2c9e720359463d74444af0b80`)
- exploratory v2 remains post-hoc exploratory fixed-input negative-control evidence only (`20ee80eb97f5bbcd476e5a9511eda442ffcdb1c751e4bcd2330934dae4c447db`)
- No repository source edits, commit, or push in Phase A
- No external model/API calls

## Resolved prospective target
- **Meeting ID:** `ES2004b`
- **Window:** `[300.000, 900.000)` seconds
- **Duration metadata:** 2333 seconds (signals page snapshot)
- **Selection rule:** lexicographically first meeting after `ES2004a` with complete required archive members and duration >= 900s
- **Eligible set size:** 103

## Required archive members for target
- ASR/ASR_AS_CTM_v1.0_feb07/ES2004b.A.words.xml
- ASR/ASR_AS_CTM_v1.0_feb07/ES2004b.B.words.xml
- ASR/ASR_AS_CTM_v1.0_feb07/ES2004b.C.words.xml
- ASR/ASR_AS_CTM_v1.0_feb07/ES2004b.D.words.xml
- ASR/ASR_AS_CTM_v1.0_feb07/ES2004b.A.segments.xml
- ASR/ASR_AS_CTM_v1.0_feb07/ES2004b.B.segments.xml
- ASR/ASR_AS_CTM_v1.0_feb07/ES2004b.C.segments.xml
- ASR/ASR_AS_CTM_v1.0_feb07/ES2004b.D.segments.xml
- words/ES2004b.A.words.xml
- words/ES2004b.B.words.xml
- words/ES2004b.C.words.xml
- words/ES2004b.D.words.xml

## Session terms (frozen)
Project Manager | alias:PM
Industrial Designer | alias:ID
User Interface Designer | alias:UI | alias:UID
Marketing Expert | alias:ME
- SHA256: `82c6bbc79bd6495f1b413529aa5dfb982e2e059b5c7335cbffd00a02e0f798ac`

## Candidate inventory freeze point
Candidate inventory must be frozen after hypothesis SRT and cue ledger materialization and **before** manual/reference `words.xml` content is parsed for scoring or term derivation.

## Alignment scorer
Reuse corrected operation-aware scorer from exploratory v2:
- tie policy: `match > substitution > deletion > insertion`
- invariants: M+S+D=N, M+S+I=H, H=N-D+I, edit_distance=S+D+I, WER=(S+D+I)/N

## Phase B estimates
- Download required: **no** (archives already local and hash-verified)
- Local runtime estimate: **8–20 minutes**
- External API cost: **$0**

## Fail-closed
No fallback target, no retries, no output repair, no term/protocol mutation after target-content access gate.

## Access boundary
Target ASR/manual word content, candidate inventory, scoring, and reviewed output were **not** opened in Phase A. See `access-boundary-statement.json`.
