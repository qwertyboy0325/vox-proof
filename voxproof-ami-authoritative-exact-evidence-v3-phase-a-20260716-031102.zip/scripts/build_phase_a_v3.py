#!/usr/bin/env python3
"""Build VoxProof authoritative exact-evidence V3 Phase A freeze artifacts."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
REPO = Path("/Users/Ezra4/Coding/Repo/vox-proof")
REQUIRED_HEAD = "5286c1627e54852fc08f4766240ce7545269e982"
PROTOCOL_ID = "voxproof-ami-authoritative-exact-evidence-v3"
CLASSIFICATION = "prospective authoritative exact-evidence pre-outcome freeze"
EXCLUDED_MEETING = "ES2004a"
WINDOW = {"start_inclusive": "300.000", "end_exclusive": "900.000"}
SPEAKERS = ("A", "B", "C", "D")
AUTO_PREFIX = "ASR/ASR_AS_CTM_v1.0_feb07/"
SESSION_TERMS = [
    "Project Manager | alias:PM",
    "Industrial Designer | alias:ID",
    "User Interface Designer | alias:UI | alias:UID",
    "Marketing Expert | alias:ME",
]
C1_ZIP_SHA = "3c78e8cf8c19df70aa7c67cf7ab7bb0df1abacd2c9e720359463d74444af0b80"
C1_SEAL_SHA = "bb83ffa8c401480469c44e35bb4cb40c05ebc30f3ab48ba8a218a6f57e37c901"
V2_ZIP_SHA = "20ee80eb97f5bbcd476e5a9511eda442ffcdb1c751e4bcd2330934dae4c447db"
V2_SEAL_SHA = "38d62e0d4db33865f6be4915f6a5673a3156102680910cafcd2a1969b0deae0c"
PRIOR_SOURCE_LOCK = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/phase-b/source-lock.json"
)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def file_record(path: Path, base: Path = ROOT) -> dict[str, Any]:
    data = path.read_bytes()
    return {
        "path": str(path.relative_to(base)).replace("\\", "/"),
        "sha256": sha256_bytes(data),
        "bytes": len(data),
    }


def required_members(meeting_id: str) -> list[str]:
    auto = [
        f"{AUTO_PREFIX}{meeting_id}.{sp}.words.xml" for sp in SPEAKERS
    ] + [f"{AUTO_PREFIX}{meeting_id}.{sp}.segments.xml" for sp in SPEAKERS]
    manual = [f"words/{meeting_id}.{sp}.words.xml" for sp in SPEAKERS]
    return auto + manual


def resolve_target() -> dict[str, Any]:
    inv = json.loads((ROOT / "references/archive-member-inventories.json").read_text())
    auto_paths = {m["path"] for m in inv["ami_public_auto_1.5.1.zip"]}
    manual_paths = {m["path"] for m in inv["ami_public_manual_1.6.2.zip"]}
    signals = (ROOT / "attribution/pages/corpus_signals.shtml.html").read_text(
        encoding="utf-8", errors="replace"
    )
    durations = {
        mid: int(sec)
        for mid, sec in re.findall(
            r"<tr>\s*<td>([A-Z]{2}\d{4}[a-z])</td>.*?<td class=\"xl24\" align=\"right\">(\d+)</td>",
            signals,
            re.S,
        )
    }
    pat = re.compile(
        rf"^{re.escape(AUTO_PREFIX)}([A-Z]{{2}}\d{{4}}[a-z])\.([A-D])\.words\.xml$"
    )
    meetings = set()
    for p in auto_paths:
        m = pat.match(p)
        if m:
            meetings.add(m.group(1))
    ordered = sorted(mid for mid in meetings if mid > EXCLUDED_MEETING)
    rows = []
    resolved: dict[str, Any] | None = None
    for mid in ordered:
        req = required_members(mid)
        present = {
            r: (r in auto_paths if r.startswith("ASR/") else r in manual_paths) for r in req
        }
        complete = all(present.values())
        dur = durations.get(mid)
        eligible = complete and dur is not None and dur >= 900
        row = {
            "meeting_id": mid,
            "complete_required_members": complete,
            "duration_seconds": dur,
            "duration_source": "attribution/pages/corpus_signals.shtml.html",
            "eligible": eligible,
            "missing_members": [k for k, v in present.items() if not v],
            "required_members": req,
        }
        rows.append(row)
        if eligible and resolved is None:
            resolved = row
    if resolved is None or len([r for r in rows if r["eligible"]]) == 0:
        raise SystemExit("target selection failed closed: no eligible meeting resolved")
    return {
        "rule_id": "lexicographic-after-ES2004a-complete-members-duration-ge-900-v1",
        "excluded_meeting_id": EXCLUDED_MEETING,
        "minimum_duration_seconds": 900,
        "window": WINDOW,
        "resolved_meeting_id": resolved["meeting_id"],
        "resolved_evidence": resolved,
        "eligible_count": sum(1 for r in rows if r["eligible"]),
        "candidate_scan": rows[:10],
        "total_candidates_after_exclusion": len(rows),
    }


def script_provenance() -> list[dict[str, Any]]:
    rows = []
    for src in [
        Path(
            "/private/tmp/voxproof-ami-authoritative-study-2026-07/exploratory-v2-scoring/scripts/alignment_scorer.py"
        ),
        Path(
            "/private/tmp/voxproof-ami-authoritative-study-2026-07/exploratory-v2-scoring/scripts/independent_verifier.py"
        ),
        Path(
            "/private/tmp/voxproof-ami-authoritative-study-2026-07/phase-b/scripts/run_phase_b.py"
        ),
        Path(
            "/private/tmp/voxproof-ami-authoritative-study-2026-07/phase-b/scripts/ami_transform.py"
        ),
        Path(
            "/private/tmp/voxproof-ami-authoritative-study-2026-07/phase-b/scripts/candidate_inventory.py"
        ),
    ]:
        rows.append(
            {
                "source_path": str(src),
                "sha256": sha256_file(src),
                "bytes": src.stat().st_size,
                "copied_into_phase_a": src.name
                if (ROOT / "scripts" / src.name).exists()
                else None,
                "trust_status": "recorded_reference_not_auto_trusted",
            }
        )
    return rows


def run_rehearsals() -> dict[str, Any]:
    cycles: list[dict[str, Any]] = []
    # cycle 1: target resolution sanity
    target = resolve_target()
    cycles.append(
        {
            "cycle": 1,
            "kind": "target-resolution-metadata-only",
            "status": "pass",
            "resolved_meeting_id": target["resolved_meeting_id"],
        }
    )
    # cycle 2: disclosed exploratory-v2 fixture scorer tests
    fixture = ROOT / "tests/fixture-exploratory-v2-scoring_tokens.json"
    sys.path.insert(0, str(ROOT / "scripts"))
    from alignment_scorer import align_tokens, load_frozen_streams

    ref, hyp, _ = load_frozen_streams(fixture)
    result = align_tokens(ref, hyp)
    if result.edit_distance != 374:
        raise SystemExit("fixture rehearsal failed: edit distance mismatch")
    cycles.append(
        {
            "cycle": 2,
            "kind": "disclosed-exploratory-v2-fixture-scorer",
            "status": "pass",
            "edit_distance": result.edit_distance,
            "counts": result.counts(),
        }
    )
    # cycle 3: unit tests
    proc = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", str(ROOT / "tests"), "-v"],
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    cycles.append(
        {
            "cycle": 3,
            "kind": "alignment-scorer-unit-tests",
            "status": "pass" if proc.returncode == 0 else "fail",
            "exit_code": proc.returncode,
            "stdout": proc.stdout,
            "stderr": proc.stderr,
        }
    )
    if proc.returncode != 0:
        raise SystemExit("alignment scorer unit tests failed")
    # cycle 4: locked cargo tests
    cargo = subprocess.run(
        ["cargo", "test", "--locked"],
        cwd=REPO,
        capture_output=True,
        text=True,
    )
    cycles.append(
        {
            "cycle": 4,
            "kind": "repository-cargo-test-locked",
            "status": "pass" if cargo.returncode == 0 else "fail",
            "exit_code": cargo.returncode,
            "summary_lines": [
                line
                for line in cargo.stdout.splitlines()
                if "running" in line or "test result" in line
            ],
        }
    )
    if cargo.returncode != 0:
        raise SystemExit("cargo test failed")
    return {
        "internal_cycle_count": len(cycles),
        "cycles": cycles,
        "failures_found": [],
        "fixes_applied": [
            "consolidated one-shot Phase A build after metadata-only target resolution and synthetic rehearsals"
        ],
        "final_status": "pass",
    }


def write_phase_b_commands(meeting_id: str) -> str:
    return f"""# Phase B exact commands (frozen; do not execute in Phase A)

## Repository and build attestation
cd {REPO}
git rev-parse HEAD  # must equal {REQUIRED_HEAD}
CARGO_TARGET_DIR=/private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-b/cargo-target-isolated cargo build --locked
shasum -a 256 "$CARGO_TARGET_DIR/debug/vox-proof"

## Preflight (archives already on disk; no re-download unless hash mismatch)
python3 phase-b/scripts/run_phase_b.py preflight

## Target-content access gate (single crossing)
# Only after candidate-inventory freeze point definition is satisfied by protocol:
# 1. build hypothesis SRT from ASR words+segments
# 2. build reference token ledger from manual words
# 3. freeze candidate inventory before any reference-content-driven term changes

python3 phase-b/scripts/ami_transform.py hypothesis
python3 phase-b/scripts/candidate_inventory.py freeze
python3 phase-b/scripts/ami_transform.py reference

## Authoritative review (zero decisions expected path remains valid)
{REPO}/target/debug/vox-proof review \\
  phase-b/build-primary/input.srt \\
  session-terms/session-terms.txt \\
  phase-b/review/reviewed-output.srt \\
  phase-b/review/decision-log.txt \\
  phase-b/review/session-summary.txt

## Scoring and verification
python3 phase-b/scripts/alignment_scorer.py score
python3 phase-b/scripts/independent_verifier.py /private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-b
python3 phase-b/scripts/package_verifier.py /private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-b

## Frozen target
meeting_id={meeting_id}
window=[{WINDOW['start_inclusive']}, {WINDOW['end_exclusive']})
"""


def main() -> int:
    target = resolve_target()
    meeting_id = target["resolved_meeting_id"]
    prior = json.loads(PRIOR_SOURCE_LOCK.read_text())
    archives = prior["archives"]
    local_auto = Path(
        "/private/tmp/voxproof-ami-authoritative-study-2026-07/phase-b/downloads/ami_public_auto_1.5.1.zip"
    )
    local_manual = Path(
        "/private/tmp/voxproof-ami-authoritative-study-2026-07/phase-b/downloads/ami_public_manual_1.6.2.zip"
    )
    for arc, path in zip(archives, [local_auto, local_manual]):
        actual = sha256_file(path)
        if actual != arc["sha256"]:
            raise SystemExit(f"archive hash mismatch for {arc['name']}: {actual}")

    session_terms_path = ROOT / "session-terms/session-terms.txt"
    session_terms_sha = sha256_file(session_terms_path)
    rehearsal = run_rehearsals()

    target_rule = {
        "schema_revision": "voxproof-ami-target-selection-rule-v1",
        "protocol_id": PROTOCOL_ID,
        "rule_id": target["rule_id"],
        "excluded_meeting_ids": [EXCLUDED_MEETING],
        "exclusion_reason": "target content already accessed by rejected c1 forensic artifact",
        "selection_inputs_allowed": [
            "archive member inventory filenames",
            "archive byte lengths and sha256",
            "official signals page duration metadata snapshot",
        ],
        "selection_inputs_forbidden": [
            "ASR words.xml content",
            "manual words.xml content",
            "reference transcript outcomes",
            "candidate outcomes",
            "WER or scoring outcomes",
            "content-based reselection",
            "fallback targets",
        ],
        "required_members_per_meeting": {
            "auto_words": [f"{AUTO_PREFIX}<MEETING>.<SPEAKER>.words.xml" for SPEAKER in SPEAKERS],
            "auto_segments": [
                f"{AUTO_PREFIX}<MEETING>.<SPEAKER>.segments.xml" for SPEAKER in SPEAKERS
            ],
            "manual_words": [f"words/<MEETING>.<SPEAKER>.words.xml" for SPEAKER in SPEAKERS],
        },
        "minimum_duration_seconds": 900,
        "window": WINDOW,
        "tie_break": "lexicographically smallest meeting_id greater than ES2004a among eligible set",
        "fail_closed": "abort if eligible set empty or more than one unresolved tie remains",
    }
    (ROOT / "target-selection-rule.json").write_text(
        json.dumps(target_rule, indent=2) + "\n", encoding="utf-8"
    )
    evidence = {
        "schema_revision": "voxproof-ami-target-selection-evidence-v1",
        "protocol_id": PROTOCOL_ID,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "archive_inventory_source": "references/archive-member-inventories.json",
        "duration_metadata_source": "attribution/pages/corpus_signals.shtml.html",
        "resolved_meeting_id": meeting_id,
        "resolved_duration_seconds": target["resolved_evidence"]["duration_seconds"],
        "resolved_required_members": target["resolved_evidence"]["required_members"],
        "eligible_count": target["eligible_count"],
        "candidate_scan_first_10": target["candidate_scan"],
        "target_content_opened": False,
    }
    (ROOT / "target-selection-evidence.json").write_text(
        json.dumps(evidence, indent=2) + "\n", encoding="utf-8"
    )

    source_lock = {
        "schema_revision": "voxproof-ami-source-lock-v1",
        "protocol_id": PROTOCOL_ID,
        "locked_at_utc": datetime.now(timezone.utc).isoformat(),
        "archives": archives,
        "local_archive_paths": {
            "ami_public_auto_1.5.1.zip": str(local_auto),
            "ami_public_manual_1.6.2.zip": str(local_manual),
        },
        "archive_hash_verification": "pass",
        "meeting_id": meeting_id,
        "window": WINDOW,
        "prior_artifacts_preserved": {
            "c1_zip_sha256": C1_ZIP_SHA,
            "c1_seal_sha256": C1_SEAL_SHA,
            "exploratory_v2_zip_sha256": V2_ZIP_SHA,
            "exploratory_v2_seal_sha256": V2_SEAL_SHA,
        },
    }
    (ROOT / "source-lock.json").write_text(json.dumps(source_lock, indent=2) + "\n", encoding="utf-8")

    pre_run = {
        "schema_revision": "voxproof-ami-pre-run-freeze-v1",
        "protocol_id": PROTOCOL_ID,
        "classification_target": CLASSIFICATION,
        "repository": {
            "path": str(REPO),
            "required_head": REQUIRED_HEAD,
            "branch": "main",
            "tracked_diff_required": "none",
            "cargo_lock_sha256": sha256_file(REPO / "Cargo.lock"),
            "cargo_lock_bytes": (REPO / "Cargo.lock").stat().st_size,
            "binary_build_plan": {
                "command": "CARGO_TARGET_DIR=/private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-b/cargo-target-isolated cargo build --locked",
                "record_binary_sha256": True,
                "forbidden": ["reuse unbound repository target/debug without attestation"],
            },
        },
        "target": {
            "meeting_id": meeting_id,
            "window": WINDOW,
            "selection_rule_id": target["rule_id"],
        },
        "session_terms": {
            "entries": SESSION_TERMS,
            "sha256": session_terms_sha,
            "freeze_before_target_lexical_exposure": True,
            "target_derived_terms_forbidden": True,
        },
        "candidate_inventory_freeze_point": "after hypothesis SRT and parsed cue ledger are materialized; before manual/reference words.xml content is parsed for scoring or term derivation",
        "reference_access_rule": "manual words.xml parsed only after candidate inventory JSON is frozen on disk",
        "ordering_policy_id": "meeting-time-midpoint-v1",
        "alignment_scorer": {
            "module": "scripts/alignment_scorer.py",
            "tie_policy_id": "match-substitution-deletion-insertion-v1",
            "invariants": [
                "M+S+D=N",
                "M+S+I=H",
                "H=N-D+I",
                "edit_distance=S+D+I",
                "WER=(S+D+I)/N",
            ],
        },
        "authoritative_command": "vox-proof review <input.srt> <session-terms.txt> <reviewed-output.srt> <decision-log.txt> <session-summary.txt>",
        "forbidden_commands": ["vox-proof review-experiment", "external-command contextual ranking"],
        "zero_candidate_interpretation": "valid exact-evidence outcome; no target/window/term/protocol change permitted",
        "phase_b_estimates": {
            "download_required": False,
            "download_size_bytes_if_required": 0,
            "local_runtime_minutes_authored_estimate": "8-20",
            "external_api_cost_usd": 0,
        },
        "fail_closed_gates": [
            "archive hash mismatch",
            "missing required members",
            "target-content opened before inventory freeze",
            "term or protocol mutation after access gate",
            "alignment invariant violation",
            "automatic retry or fallback sample",
            "output repair in place after frozen execution failure",
        ],
        "package_allowlist_prefixes": [
            "phase-a/",
            "phase-b/protocol/",
            "phase-b/attribution/",
            "phase-b/preflight/",
            "phase-b/build-primary/",
            "phase-b/review/",
            "phase-b/scripts/",
            "phase-b/metrics.json",
            "phase-b/reports/",
        ],
        "package_exclusions": [
            "audio",
            "archive zips",
            ".bin",
            "environments",
            "caches",
            "prior reviewer zips",
            "experimental sidecars",
        ],
    }
    (ROOT / "pre-run-freeze.json").write_text(json.dumps(pre_run, indent=2) + "\n", encoding="utf-8")

    access_boundary = {
        "schema_revision": "voxproof-ami-access-boundary-v1",
        "protocol_id": PROTOCOL_ID,
        "opened_before_seal": [
            "references/archive-member-inventories.json",
            "attribution/pages/corpus_signals.shtml.html",
            "attribution/license-record.json",
            "attribution/manual-release-provenance.json",
            "attribution/LICENCE.txt",
            "phase-b/source-lock.json (prior hashes only)",
            "exploratory-v2 disclosed fixture scoring_tokens.json",
            "repository Cargo.lock and cargo test output",
            "script source files by path/hash only",
        ],
        "confirmed_unopened_target_content": [
            f"ASR/ASR_AS_CTM_v1.0_feb07/{meeting_id}.*.words.xml",
            f"ASR/ASR_AS_CTM_v1.0_feb07/{meeting_id}.*.segments.xml",
            f"words/{meeting_id}.*.words.xml",
            "candidate inventory for target",
            "target scoring outputs",
            "target reviewed SRT",
        ],
        "no_candidate_generation": True,
        "no_target_scoring": True,
        "no_model_api_calls": True,
        "no_repository_modification": True,
    }
    (ROOT / "access-boundary-statement.json").write_text(
        json.dumps(access_boundary, indent=2) + "\n", encoding="utf-8"
    )

    (ROOT / "phase-b-commands.md").write_text(write_phase_b_commands(meeting_id), encoding="utf-8")
    (ROOT / "internal-debugging-record.json").write_text(
        json.dumps(rehearsal, indent=2) + "\n", encoding="utf-8"
    )
    (ROOT / "script-provenance.json").write_text(
        json.dumps({"scripts": script_provenance()}, indent=2) + "\n", encoding="utf-8"
    )

    repo_status = subprocess.run(
        ["git", "status", "--short"],
        cwd=REPO,
        capture_output=True,
        text=True,
    )
    repo_head = subprocess.run(
        ["git", "rev-parse", "HEAD"], cwd=REPO, capture_output=True, text=True
    )
    diff_check = subprocess.run(
        ["git", "diff", "--check"], cwd=REPO, capture_output=True, text=True
    )
    status = {
        "required_head": REQUIRED_HEAD,
        "actual_head": repo_head.stdout.strip(),
        "head_matches": repo_head.stdout.strip() == REQUIRED_HEAD,
        "porcelain": repo_status.stdout,
        "tracked_diff": "none" if not repo_status.stdout.strip().startswith(("M", "A", "D", "R")) else "present",
        "diff_check_exit_code": diff_check.returncode,
        "diff_check_pass": diff_check.returncode == 0,
        "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    (ROOT / "repository-status-evidence.json").write_text(
        json.dumps(status, indent=2) + "\n", encoding="utf-8"
    )

    design = f"""# VoxProof Authoritative Exact-Evidence V3 — Phase A Design

## Protocol
- **Protocol ID:** `{PROTOCOL_ID}`
- **Classification target:** {CLASSIFICATION}
- **Phase:** A only (pre-outcome freeze)

## Governance
- c1 remains rejected forensic artifact (`{C1_ZIP_SHA}`)
- exploratory v2 remains post-hoc exploratory fixed-input negative-control evidence only (`{V2_ZIP_SHA}`)
- No repository source edits, commit, or push in Phase A
- No external model/API calls

## Resolved prospective target
- **Meeting ID:** `{meeting_id}`
- **Window:** `[{WINDOW['start_inclusive']}, {WINDOW['end_exclusive']})` seconds
- **Duration metadata:** {target['resolved_evidence']['duration_seconds']} seconds (signals page snapshot)
- **Selection rule:** lexicographically first meeting after `ES2004a` with complete required archive members and duration >= 900s
- **Eligible set size:** {target['eligible_count']}

## Required archive members for target
{chr(10).join('- ' + m for m in target['resolved_evidence']['required_members'])}

## Session terms (frozen)
{chr(10).join(SESSION_TERMS)}
- SHA256: `{session_terms_sha}`

## Candidate inventory freeze point
Candidate inventory must be frozen after hypothesis SRT and cue ledger materialization and **before** manual/reference `words.xml` content is parsed for scoring or term derivation.

## Alignment scorer
Reuse corrected operation-aware scorer from exploratory v2:
- tie policy: `match > substitution > deletion > insertion`
- invariants: M+S+D=N, M+S+I=H, H=N-D+I, edit_distance=S+D+I, WER=(S+D+I)/N

## Phase B estimates
- Download required: **no** (archives already local and hash-verified)
- Local runtime estimate: **8–20 minutes**
- External API cost: **$0**

## Fail-closed
No fallback target, no retries, no output repair, no term/protocol mutation after target-content access gate.

## Access boundary
Target ASR/manual word content, candidate inventory, scoring, and reviewed output were **not** opened in Phase A. See `access-boundary-statement.json`.
"""
    (ROOT / "phase-a-design.md").write_text(design, encoding="utf-8")

    schemas = {
        "metrics.json": {
            "required_fields": [
                "classification",
                "counts",
                "wer",
                "ordering_policy",
                "tie_policy_id",
                "immutable_inputs",
            ],
            "counts_fields": [
                "N_reference",
                "H_hypothesis",
                "matches",
                "substitutions",
                "deletions",
                "insertions",
                "edit_distance",
            ],
        },
        "candidate-inventory.json": {
            "required_fields": ["candidate_count", "candidates", "transcript_revision"],
        },
        "invariant-report.json": {
            "required_invariants": [
                "M_plus_S_plus_D_equals_N",
                "M_plus_S_plus_I_equals_H",
                "H_equals_N_minus_D_plus_I",
                "edit_distance_equals_S_plus_D_plus_I",
            ],
        },
    }
    (ROOT / "schemas/expected-schemas.json").write_text(
        json.dumps(schemas, indent=2) + "\n", encoding="utf-8"
    )
    (ROOT / "schemas/invariant-definitions.json").write_text(
        json.dumps(
            {
                "invariants": [
                    {"id": "M+S+D=N", "formula": "matches + substitutions + deletions == N_reference"},
                    {"id": "M+S+I=H", "formula": "matches + substitutions + insertions == H_hypothesis"},
                    {"id": "H=N-D+I", "formula": "H_hypothesis == N_reference - deletions + insertions"},
                    {"id": "edit_distance=S+D+I", "formula": "edit_distance == substitutions + deletions + insertions"},
                    {"id": "WER", "formula": "(substitutions + deletions + insertions) / N_reference"},
                ]
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    summary = {
        "protocol_id": PROTOCOL_ID,
        "resolved_meeting_id": meeting_id,
        "session_terms_sha256": session_terms_sha,
        "archive_hashes_verified": True,
        "internal_cycles": rehearsal["internal_cycle_count"],
        "build_status": "pass",
    }
    (ROOT / "outputs/build-summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
