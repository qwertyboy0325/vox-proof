#!/usr/bin/env python3
"""Package V3 Phase A reviewer ZIP and detached seal."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "package"
STAMP = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
ZIP_NAME = f"voxproof-ami-authoritative-exact-evidence-v3-phase-a-{STAMP}.zip"
SEAL_NAME = f"package-seal-v3-phase-a-{STAMP}.json"
EXCLUDE_SUFFIXES = {".zip", ".pyc"}
EXCLUDE_DIRS = {"__pycache__"}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def should_include(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDE_DIRS for part in rel.parts):
        return False
    if path.suffix in EXCLUDE_SUFFIXES:
        return False
    if rel.parts and rel.parts[0] == "package":
        return False
    return True


def collect_files() -> list[Path]:
    return sorted(
        p for p in ROOT.rglob("*") if p.is_file() and should_include(p)
    )


def build_zip(files: list[Path], zip_path: Path) -> list[dict[str, Any]]:
    import zipfile

    entries = []
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in files:
            arc = str(path.relative_to(ROOT)).replace("\\", "/")
            data = path.read_bytes()
            zf.writestr(arc, data)
            entries.append({"path": arc, "sha256": sha256_bytes(data), "bytes": len(data)})
    return entries


def main() -> int:
    files = collect_files()
    manifest_path = ROOT / "manifest.json"
    manifest = {
        "package": "voxproof-ami-authoritative-exact-evidence-v3-phase-a",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "entry_count": len(files),
        "note": "manifest embedded without final zip hash; detached seal written after zip build",
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    files = collect_files()
    manifest["entry_count"] = len(files)
    manifest["files"] = [
        {
            "path": str(p.relative_to(ROOT)).replace("\\", "/"),
            "sha256": sha256_file(p),
            "bytes": p.stat().st_size,
        }
        for p in files
    ]
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    files = collect_files()
    zip_path = PACKAGE / ZIP_NAME
    entries = build_zip(files, zip_path)

    verify = subprocess.run(
        [
            sys.executable,
            str(ROOT / "scripts/verify_phase_a_package.py"),
            str(ROOT),
            str(zip_path),
            str(manifest_path),
        ],
        capture_output=True,
        text=True,
    )
    if verify.returncode != 0:
        print(verify.stdout)
        print(verify.stderr, file=sys.stderr)
        raise SystemExit(verify.returncode)
    verification = json.loads((ROOT / "outputs/package-verification-output.json").read_text())

    seal = {
        "package": manifest["package"],
        "zip_filename": ZIP_NAME,
        "zip_sha256": verification["zip_sha256"],
        "entry_count": verification["entry_count"],
        "embedded_manifest_sha256": verification["embedded_manifest_sha256"],
        "entries": entries,
        "verification": verification,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
    }
    seal_path = PACKAGE / SEAL_NAME
    seal_path.write_text(json.dumps(seal, indent=2) + "\n", encoding="utf-8")

    summary = {
        "zip_filename": ZIP_NAME,
        "zip_sha256": verification["zip_sha256"],
        "entry_count": verification["entry_count"],
        "seal_filename": SEAL_NAME,
        "seal_sha256": sha256_file(seal_path),
        "verification_status": verification["status"],
        "verify_exit_code": verify.returncode,
    }
    (PACKAGE / "package-summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0 if verification["status"] == "pass" and verify.returncode == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
