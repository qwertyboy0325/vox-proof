#!/usr/bin/env python3
"""Verify V3 Phase A reviewer package closure and hashes."""

from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from pathlib import Path
from typing import Any


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def verify_package(root: Path, zip_path: Path, manifest_path: Path) -> dict[str, Any]:
    errors: list[str] = []
    with zipfile.ZipFile(zip_path) as zf:
        names = sorted(zf.namelist())
        for name in names:
            if ".." in Path(name).parts or name.startswith("/"):
                errors.append(f"unsafe zip path: {name}")
        if "manifest.json" not in names:
            errors.append("missing embedded manifest.json")
        embedded = json.loads(zf.read("manifest.json"))
        rows = []
        for name in names:
            data = zf.read(name)
            rows.append({"path": name, "sha256": sha256_bytes(data), "bytes": len(data)})
        if embedded.get("entry_count") != len(names):
            errors.append("manifest entry_count mismatch")
        required = [
            "phase-a-design.md",
            "pre-run-freeze.json",
            "source-lock.json",
            "target-selection-rule.json",
            "target-selection-evidence.json",
            "session-terms/session-terms.txt",
            "phase-b-commands.md",
            "access-boundary-statement.json",
            "repository-status-evidence.json",
            "internal-debugging-record.json",
        ]
        for req in required:
            if req not in names:
                errors.append(f"missing required entry: {req}")
        target = json.loads(zf.read("target-selection-evidence.json"))
        if target.get("target_content_opened"):
            errors.append("target content marked opened")
        if target.get("resolved_meeting_id") != "ES2004b":
            errors.append("unexpected resolved meeting")

    manifest_sha = sha256_file(manifest_path)
    zip_sha = sha256_file(zip_path)
    return {
        "status": "pass" if not errors else "fail",
        "errors": errors,
        "zip_sha256": zip_sha,
        "entry_count": len(names),
        "embedded_manifest_sha256": manifest_sha,
        "entries": rows,
    }


def main() -> int:
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
    zip_path = Path(sys.argv[2]).resolve()
    manifest_path = Path(sys.argv[3]).resolve()
    out = verify_package(root, zip_path, manifest_path)
    output = root / "outputs" / "package-verification-output.json"
    output.write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": out["status"], "zip_sha256": out["zip_sha256"], "entry_count": out["entry_count"]}, indent=2))
    return 0 if out["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
