#!/usr/bin/env python3
"""Tests for exploratory v2 alignment scorer."""

from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "phase-b/scripts"))

from alignment_scorer import (  # noqa: E402
    AlignmentOperation,
    AlignmentResult,
    align_tokens,
    backtrace_alignment,
    load_frozen_streams,
)


class AlignmentScorerTests(unittest.TestCase):
    def test_exact_match(self) -> None:
        result = align_tokens(["a", "b", "c"], ["a", "b", "c"])
        self.assertEqual(result.edit_distance, 0)
        self.assertEqual(result.validate_invariants(), [])

    def test_frozen_v2_regression(self) -> None:
        fixture = ROOT / "tests/fixture-exploratory-v2-scoring_tokens.json"
        reference, hypothesis, _ = load_frozen_streams(fixture)
        result = align_tokens(reference, hypothesis)
        self.assertEqual(result.edit_distance, 374)
        self.assertEqual(len(reference), 705)
        self.assertEqual(len(hypothesis), 699)

    def test_malformed_transition_rejected(self) -> None:
        with self.assertRaises(ValueError):
            backtrace_alignment(["a"], ["b"], [[0, 99]])

    def test_inconsistent_counts_rejected(self) -> None:
        result = AlignmentResult(
            reference_tokens=("a", "b"),
            hypothesis_tokens=("a", "b"),
            operations=(),
            matches=1,
            substitutions=0,
            deletions=0,
            insertions=0,
            edit_distance=0,
        )
        self.assertTrue(any("M+S+D != N" in err for err in result.validate_invariants()))


if __name__ == "__main__":
    unittest.main(verbosity=2)
