#!/usr/bin/env python3
"""Synthetic full-pipeline rehearsals and negative-path fail-closed tests."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "phase-b/scripts"
sys.path.insert(0, str(SCRIPTS))

from alignment_scorer import AlignmentResult, align_tokens, verify_metrics_file  # noqa: E402
from binary_gate import build_isolated_binary, load_attestation, verify_binary_hash_immediately_before_invocation  # noqa: E402
from candidate_capture import (  # noqa: E402
    compare_candidate_sets,
    parse_review_stdout,
    run_authoritative_review,
    run_candidate_probe,
)
from common import sha256_file, write_json  # noqa: E402
from study_config import CORRECTION_ROOT, ISOLATED_BINARY  # noqa: E402


class CorrectionRehearsalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.binary, cls.attestation = build_isolated_binary()
        cls.terms = CORRECTION_ROOT / "session-terms/session-terms.txt"

    def test_zero_candidate_fixture_probe(self) -> None:
        fixture = CORRECTION_ROOT / "fixtures/zero-candidate"
        out = fixture / "test-out"
        if out.exists():
            shutil.rmtree(out)
        inventory = run_candidate_probe(
            binary=self.binary,
            attestation=self.attestation,
            input_srt=fixture / "input.srt",
            terms_path=self.terms,
            output_dir=out,
        )
        self.assertEqual(inventory["candidate_count"], 0)

    def test_nonzero_accept_reject_fixture(self) -> None:
        fixture = CORRECTION_ROOT / "fixtures/nonzero-candidate"
        out = fixture / "test-out"
        if out.exists():
            shutil.rmtree(out)
        inventory = run_candidate_probe(
            binary=self.binary,
            attestation=self.attestation,
            input_srt=fixture / "input.srt",
            terms_path=self.terms,
            output_dir=out,
        )
        self.assertGreater(inventory["candidate_count"], 0)
        decisions = ["a 0", "r"] + ["d"] * (inventory["candidate_count"] - 2)
        binding = run_authoritative_review(
            binary=self.binary,
            attestation=self.attestation,
            input_srt=fixture / "input.srt",
            terms_path=self.terms,
            decisions=decisions,
            frozen_inventory=inventory,
            canonical_output_dir=out / "authoritative",
        )
        self.assertTrue(binding["reproduction_verified"])

    def test_candidate_review_mismatch_rejected(self) -> None:
        frozen = [{"fingerprint": "a", "local_index": 0}]
        reproduced = [{"fingerprint": "b", "local_index": 0}]
        errors = compare_candidate_sets(frozen, reproduced, frozen_revision="r1", reproduced_revision="r1")
        self.assertTrue(errors)

    def test_binary_hash_mismatch_rejected(self) -> None:
        bad = dict(self.attestation)
        bad["binary_sha256"] = "0" * 64
        with self.assertRaises(RuntimeError):
            verify_binary_hash_immediately_before_invocation(self.binary, bad)

    def test_malformed_wer_decomposition_rejected(self) -> None:
        result = AlignmentResult(
            reference_tokens=("a",),
            hypothesis_tokens=("b",),
            operations=(),
            matches=0,
            substitutions=0,
            deletions=0,
            insertions=0,
            edit_distance=0,
        )
        self.assertTrue(result.validate_invariants())

    def test_package_manifest_corruption_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "a.txt").write_text("ok\n", encoding="utf-8")
            manifest = {
                "schema_revision": "voxproof-ami-phase-a-package-manifest-v1",
                "package": "test",
                "entry_count": 1,
                "files": [{"path": "a.txt", "sha256": "deadbeef", "bytes": 3}],
            }
            zip_path = root / "pkg.zip"
            seal_path = root / "seal.json"
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.writestr("a.txt", "ok\n")
                zf.writestr("manifest.json", json.dumps(manifest))
            seal = {
                "schema_revision": "voxproof-ami-phase-a-detached-seal-v1",
                "zip_filename": "pkg.zip",
                "zip_sha256": sha256_file(zip_path),
                "zip_entry_count": 2,
                "embedded_manifest_sha256": "deadbeef",
                "entries": [],
            }
            write_json(seal_path, seal)
            proc = subprocess.run(
                [sys.executable, str(SCRIPTS / "package_verifier.py"), str(root), str(zip_path), str(seal_path)],
                capture_output=True,
                text=True,
            )
            self.assertNotEqual(proc.returncode, 0)

    def test_phase_b_dry_run(self) -> None:
        proc = subprocess.run(
            [sys.executable, str(SCRIPTS / "phase_b_runner.py"), "dry-run"],
            capture_output=True,
            text=True,
        )
        self.assertEqual(proc.returncode, 0, proc.stderr)
        envelope = json.loads((CORRECTION_ROOT / "outputs/phase-b-dry-run-envelope.json").read_text())
        self.assertEqual(len(envelope["commands"]), 2)

    def test_v2_scoring_cli_regression(self) -> None:
        fixture = ROOT / "tests/fixture-exploratory-v2-scoring_tokens.json"
        metrics_path = CORRECTION_ROOT / "outputs/test-metrics.json"
        ops_path = CORRECTION_ROOT / "outputs/test-operations.tsv"
        proc = subprocess.run(
            [
                sys.executable,
                str(SCRIPTS / "alignment_scorer.py"),
                "score",
                "--scoring-tokens",
                str(fixture),
                "--output-metrics",
                str(metrics_path),
                "--output-operations",
                str(ops_path),
            ],
            capture_output=True,
            text=True,
        )
        self.assertEqual(proc.returncode, 0, proc.stderr)
        errors = verify_metrics_file(metrics_path, fixture)
        self.assertEqual(errors, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
