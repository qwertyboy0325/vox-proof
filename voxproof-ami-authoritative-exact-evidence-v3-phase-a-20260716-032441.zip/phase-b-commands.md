# Phase B exact commands (frozen executable envelope; do not execute in Phase A)

## Authoritative chronology (8 steps)
1. verify repository, archive, script, and config hashes; build isolated binary
2. cross target-content gate once by opening target ASR words/segments
3. materialize hypothesis SRT and cue/token ledger
4. invoke exact binary candidate probe and seal candidate inventory
5. only then open manual/reference words content
6. materialize reference/scoring layers; human reviewer creates ground truth and decision inputs
7. validate decision binding; invoke authoritative review; verify candidate reproduction before promoting outputs
8. score with corrected operation-aware scorer; independently verify; package once; detached seal afterward

## Repository and build attestation
cd /Users/Ezra4/Coding/Repo/vox-proof
git rev-parse HEAD  # must equal 5286c1627e54852fc08f4766240ce7545269e982
python3 phase-b/scripts/phase_b_runner.py preflight
python3 phase-b/scripts/phase_b_runner.py build-binary

## Target-content access gate (single crossing)
python3 phase-b/scripts/ami_transform.py hypothesis --build-root phase-b/build-primary
python3 phase-b/scripts/candidate_capture.py probe --input-srt phase-b/build-primary/input.srt --terms session-terms/session-terms.txt --output-dir phase-b/probe
python3 phase-b/scripts/ami_transform.py reference --build-root phase-b/build-primary

## Authoritative review
python3 phase-b/scripts/decision_workflow.py validate-decisions --decision-inputs phase-b/review/decision-inputs.json --inventory phase-b/probe/candidate-inventory.json
python3 phase-b/scripts/candidate_capture.py review --input-srt phase-b/build-primary/input.srt --terms session-terms/session-terms.txt --inventory phase-b/probe/candidate-inventory.json --decisions phase-b/review/decision-inputs.json --output-dir phase-b/review

## Scoring and verification
python3 phase-b/scripts/alignment_scorer.py score --scoring-tokens phase-b/build-primary/scoring_tokens.json --output-metrics phase-b/metrics.json --output-operations phase-b/alignment-operations.tsv
python3 phase-b/scripts/independent_verifier.py /private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-b
python3 phase-b/scripts/package_verifier.py /private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-b <package.zip> <seal.json>

## Frozen target
meeting_id=ES2004b
window=[300.000, 900.000)
