#!/usr/bin/env python3
"""Independent alignment verification without importing primary backtrace."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any


def independent_edit_distance(reference: list[str], hypothesis: list[str]) -> int:
    n = len(reference)
    m = len(hypothesis)
    previous = list(range(m + 1))
    for i in range(1, n + 1):
        current = [i]
        ref_token = reference[i - 1]
        for j in range(1, m + 1):
            cost_substitution = 0 if ref_token == hypothesis[j - 1] else 1
            current.append(
                min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost_substitution)
            )
        previous = current
    return previous[m]


def independent_backtrace_alternate_tie(
    reference: list[str], hypothesis: list[str]
) -> dict[str, int]:
    n = len(reference)
    m = len(hypothesis)
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        dp[i][0] = i
    for j in range(1, m + 1):
        dp[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if reference[i - 1] == hypothesis[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = 1 + min(dp[i - 1][j - 1], dp[i][j - 1], dp[i - 1][j])
    counts = {"match": 0, "substitution": 0, "deletion": 0, "insertion": 0}
    i = n
    j = m
    while i > 0 or j > 0:
        current = dp[i][j]
        if i > 0 and j > 0 and reference[i - 1] == hypothesis[j - 1] and current == dp[i - 1][j - 1]:
            counts["match"] += 1
            i -= 1
            j -= 1
            continue
        candidates: list[tuple[str, int, int]] = []
        if i > 0 and j > 0 and current == dp[i - 1][j - 1] + 1:
            candidates.append(("substitution", i - 1, j - 1))
        if j > 0 and current == dp[i][j - 1] + 1:
            candidates.append(("insertion", i, j - 1))
        if i > 0 and current == dp[i - 1][j] + 1:
            candidates.append(("deletion", i - 1, j))
        if not candidates:
            raise ValueError(f"alternate backtrace failed at ({i},{j})")
        op, ni, nj = candidates[0]
        counts[op] += 1
        i, j = ni, nj
    n_ref = len(reference)
    h_hyp = len(hypothesis)
    m_count = counts["match"]
    s_count = counts["substitution"]
    d_count = counts["deletion"]
    ins_count = counts["insertion"]
    if m_count + s_count + d_count != n_ref:
        raise ValueError("alternate decomposition failed M+S+D=N")
    if m_count + s_count + ins_count != h_hyp:
        raise ValueError("alternate decomposition failed M+S+I=H")
    if h_hyp != n_ref - d_count + ins_count:
        raise ValueError("alternate decomposition failed H=N-D+I")
    if dp[n][m] != s_count + d_count + ins_count:
        raise ValueError("alternate decomposition failed edit distance")
    counts["edit_distance"] = dp[n][m]
    counts["N_reference"] = n_ref
    counts["H_hypothesis"] = h_hyp
    return counts


def verify_study_root(study_root: Path) -> dict[str, Any]:
    script_dir = study_root / "phase-b/scripts"
    sys.path.insert(0, str(script_dir))
    from alignment_scorer import align_tokens, load_frozen_streams

    scoring_path = study_root / "inputs" / "scoring_tokens.json"
    if not scoring_path.exists():
        scoring_path = study_root / "tests" / "fixture-exploratory-v2-scoring_tokens.json"
    metrics_path = study_root / "outputs" / "metrics.json"
    operations_tsv = study_root / "outputs" / "alignment-operations.tsv"
    invariant_report_path = study_root / "reports" / "invariant-report.json"
    errors: list[str] = []

    reference, hypothesis, payload = load_frozen_streams(scoring_path)
    result = align_tokens(reference, hypothesis)
    oracle_distance = independent_edit_distance(reference, hypothesis)
    if oracle_distance != result.edit_distance:
        errors.append(
            f"independent distance mismatch: oracle={oracle_distance} primary={result.edit_distance}"
        )

    if metrics_path.exists():
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        for key, expected in result.counts().items():
            actual = metrics.get("counts", {}).get(key)
            if actual != expected:
                errors.append(f"metrics counts.{key} mismatch: {actual} != {expected}")
        wer = result.wer()
        if wer is None:
            if metrics.get("wer") is not None:
                errors.append("metrics.wer should be null when N=0")
        elif abs(metrics["wer"] - wer) > 1e-12:
            errors.append(f"metrics.wer mismatch: {metrics['wer']} != {wer}")

    for err in result.validate_invariants():
        errors.append(err)

    if operations_tsv.exists():
        tsv_lines = operations_tsv.read_text(encoding="utf-8").strip().splitlines()
        if len(tsv_lines) != len(result.operations) + 1:
            errors.append("operations.tsv row count mismatch")

    if invariant_report_path.exists():
        inv = json.loads(invariant_report_path.read_text(encoding="utf-8"))
        if inv.get("status") != "pass":
            errors.append("invariant report not pass")

    alternate = independent_backtrace_alternate_tie(reference, hypothesis)
    return {
        "status": "pass" if not errors else "fail",
        "errors": errors,
        "oracle_edit_distance": oracle_distance,
        "primary_edit_distance": result.edit_distance,
        "tie_difference": {
            "alternate_policy": "match-substitution-insertion-deletion-v1",
            "primary_policy": result.tie_policy_id,
            "edit_distance_agreement": alternate["edit_distance"] == result.edit_distance,
        },
        "ordering_policy": payload.get("ordering_policy"),
        "study_root": str(study_root),
    }


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: independent_verifier.py <study_root>", file=sys.stderr)
        return 2
    study_root = Path(sys.argv[1]).resolve()
    out = verify_study_root(study_root)
    output_path = study_root / "outputs" / "independent-verifier-output.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(out, indent=2))
    return 0 if out["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
