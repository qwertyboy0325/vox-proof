#!/usr/bin/env python3
"""Exact-binary candidate probe, stdout parser, inventory seal, reproduction check."""

from __future__ import annotations

import re
import sys
import tempfile
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from binary_gate import (  # noqa: E402
    build_isolated_binary,
    load_attestation,
    verify_binary_hash_immediately_before_invocation,
)
from common import (  # noqa: E402
    canonical_json_hash,
    capture_command,
    fail_record,
    sha256_file,
    sha256_text,
    utc_now,
    write_json,
)
from study_config import BINARY_ATTESTATION_PATH, ISOLATED_BINARY, MAX_CANDIDATE_BOUND  # noqa: E402

CASE_HEADER_RE = re.compile(r"^case_id:\s+local:(\d+)$")
FIELD_RE = {
    "source_segment_position": re.compile(r"^source_segment_position:\s+(\d+)$"),
    "cue_index": re.compile(r"^cue_index:\s+(\d+)$"),
    "cue_text": re.compile(r"^cue_text:\s+(.*)$"),
    "matched_text": re.compile(r"^matched_text:\s+(.*)$"),
    "evidence": re.compile(r"^evidence:\s+(.*)$"),
}
ALT_RE = re.compile(r"^\s+(\d+):\s+(.*)$")
REVISION_RE = re.compile(r"^transcript_revision:\s+(rev:sha256-v1:[0-9a-f]{64})$")
CASES_RAISED_RE = re.compile(r"^review_cases_raised:\s+(\d+)$")


def parse_review_stdout(stdout: str) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    in_alternatives = False
    for line in stdout.splitlines():
        m = CASE_HEADER_RE.match(line)
        if m:
            if current is not None:
                candidates.append(current)
            current = {
                "local_index": int(m.group(1)),
                "alternatives": [],
            }
            in_alternatives = False
            continue
        if current is None:
            continue
        if line.strip() == "alternatives:":
            in_alternatives = True
            continue
        if in_alternatives:
            alt = ALT_RE.match(line)
            if alt:
                current["alternatives"].append(
                    {"index": int(alt.group(1)), "replacement_text": alt.group(2)}
                )
                continue
            in_alternatives = False
        for key, pattern in FIELD_RE.items():
            fm = pattern.match(line)
            if fm:
                value: Any = int(fm.group(1)) if key in {"source_segment_position", "cue_index"} else fm.group(1)
                current[key] = value
                break
    if current is not None:
        candidates.append(current)
    return candidates


def parse_session_summary(summary_text: str) -> dict[str, Any]:
    revision = None
    cases_raised = None
    for line in summary_text.splitlines():
        rm = REVISION_RE.match(line)
        if rm:
            revision = rm.group(1)
        cm = CASES_RAISED_RE.match(line)
        if cm:
            cases_raised = int(cm.group(1))
    if revision is None:
        raise ValueError("session summary missing transcript_revision")
    if cases_raised is None:
        raise ValueError("session summary missing review_cases_raised")
    return {"transcript_revision": revision, "review_cases_raised": cases_raised}


def candidate_fingerprint(candidate: dict[str, Any], transcript_revision: str) -> str:
    payload = {
        "transcript_revision": transcript_revision,
        "local_index": candidate["local_index"],
        "source_segment_position": candidate["source_segment_position"],
        "cue_index": candidate["cue_index"],
        "cue_text": candidate["cue_text"],
        "matched_text": candidate["matched_text"],
        "evidence": candidate["evidence"],
        "alternatives": candidate["alternatives"],
    }
    return canonical_json_hash(payload)


def build_candidate_records(
    parsed: list[dict[str, Any]],
    transcript_revision: str,
) -> list[dict[str, Any]]:
    records = []
    for candidate in parsed:
        records.append(
            {
                **candidate,
                "fingerprint": candidate_fingerprint(candidate, transcript_revision),
            }
        )
    return records


def compare_candidate_sets(
    frozen: list[dict[str, Any]],
    reproduced: list[dict[str, Any]],
    *,
    frozen_revision: str,
    reproduced_revision: str,
) -> list[str]:
    errors: list[str] = []
    if frozen_revision != reproduced_revision:
        errors.append(
            f"transcript revision mismatch: frozen={frozen_revision} reproduced={reproduced_revision}"
        )
    if len(frozen) != len(reproduced):
        errors.append(f"candidate count mismatch: frozen={len(frozen)} reproduced={len(reproduced)}")
    for idx, (a, b) in enumerate(zip(frozen, reproduced)):
        if a.get("fingerprint") != b.get("fingerprint"):
            errors.append(f"fingerprint mismatch at ordered index {idx}")
        for key in (
            "local_index",
            "source_segment_position",
            "cue_index",
            "cue_text",
            "matched_text",
            "evidence",
            "alternatives",
        ):
            if a.get(key) != b.get(key):
                errors.append(f"field {key} mismatch at ordered index {idx}")
    frozen_multiset = sorted(c["fingerprint"] for c in frozen)
    reproduced_multiset = sorted(c["fingerprint"] for c in reproduced)
    if frozen_multiset != reproduced_multiset:
        errors.append("candidate multiset hash mismatch")
    return errors


def run_candidate_probe(
    *,
    binary: Path,
    attestation: dict[str, Any],
    input_srt: Path,
    terms_path: Path,
    output_dir: Path,
) -> dict[str, Any]:
    verify_binary_hash_immediately_before_invocation(binary, attestation)
    output_dir.mkdir(parents=True, exist_ok=True)
    reviewed = output_dir / "probe-reviewed-output.srt"
    decision_log = output_dir / "probe-decision-log.txt"
    summary_path = output_dir / "probe-session-summary.txt"
    env = attestation["sanitized_environment"]
    defer_input = "\n".join(["d"] * MAX_CANDIDATE_BOUND) + "\n"
    capture = capture_command(
        [
            str(binary),
            "review",
            str(input_srt),
            str(terms_path),
            str(reviewed),
            str(decision_log),
            str(summary_path),
        ],
        input_text=defer_input,
    )
    parsed_probe = parse_review_stdout(capture["stdout"])
    if "no review cases found" in capture["stdout"]:
        if capture["exit_code"] != 0:
            raise RuntimeError(f"zero-candidate probe failed: {capture['stderr']}")
        parsed_probe = []
    else:
        if capture["exit_code"] != 0:
            raise RuntimeError(f"candidate probe failed: {capture['stderr']}")
        if len(parsed_probe) > MAX_CANDIDATE_BOUND:
            raise RuntimeError(
                f"candidate count {len(parsed_probe)} exceeds frozen bound {MAX_CANDIDATE_BOUND}"
            )
    if not summary_path.exists():
        raise RuntimeError("probe did not write session summary")
    summary = parse_session_summary(summary_path.read_text(encoding="utf-8"))
    if summary["review_cases_raised"] != len(parsed_probe):
        raise RuntimeError(
            "candidate count disagrees with session summary: "
            f"stdout={len(parsed_probe)} summary={summary['review_cases_raised']}"
        )
    records = build_candidate_records(parsed_probe, summary["transcript_revision"])
    inventory = {
        "schema_revision": "voxproof-ami-candidate-inventory-v1",
        "sealed_at_utc": utc_now(),
        "binary_sha256": attestation["binary_sha256"],
        "input_srt_sha256": sha256_file(input_srt),
        "terms_sha256": sha256_file(terms_path),
        "transcript_revision": summary["transcript_revision"],
        "candidate_count": len(records),
        "candidate_multiset_sha256": canonical_json_hash(
            [record["fingerprint"] for record in records]
        ),
        "candidate_sequence_sha256": canonical_json_hash(records),
        "candidates": records,
        "probe_only": True,
        "probe_decisions_non_authoritative": True,
        "artifact_hashes": {
            "stdout_sha256": sha256_text(capture["stdout"]),
            "stderr_sha256": sha256_text(capture["stderr"]),
            "decision_log_sha256": sha256_file(decision_log) if decision_log.exists() else None,
            "session_summary_sha256": sha256_file(summary_path),
            "reviewed_output_sha256": sha256_file(reviewed) if reviewed.exists() else None,
        },
    }
    write_json(output_dir / "candidate-inventory.json", inventory)
    write_json(output_dir / "probe-cli-capture.json", capture)
    return inventory


def run_authoritative_review(
    *,
    binary: Path,
    attestation: dict[str, Any],
    input_srt: Path,
    terms_path: Path,
    decisions: list[str],
    frozen_inventory: dict[str, Any],
    canonical_output_dir: Path,
) -> dict[str, Any]:
    verify_binary_hash_immediately_before_invocation(binary, attestation)
    if len(decisions) != frozen_inventory["candidate_count"]:
        raise RuntimeError(
            f"decision count {len(decisions)} != frozen candidate count {frozen_inventory['candidate_count']}"
        )
    with tempfile.TemporaryDirectory(prefix="voxproof-review-temp-") as tmp:
        temp_dir = Path(tmp)
        reviewed = temp_dir / "reviewed-output.srt"
        decision_log = temp_dir / "decision-log.txt"
        summary_path = temp_dir / "session-summary.txt"
        stdin_data = "\n".join(decisions) + ("\n" if decisions else "")
        capture = capture_command(
            [
                str(binary),
                "review",
                str(input_srt),
                str(terms_path),
                str(reviewed),
                str(decision_log),
                str(summary_path),
            ],
            input_text=stdin_data,
        )
        if capture["exit_code"] != 0:
            failure = fail_record(
                "authoritative_review",
                "review_command_failed",
                capture["stderr"],
                [str(temp_dir)],
            )
            write_json(temp_dir / "failure-record.json", failure)
            raise RuntimeError(f"authoritative review failed: {capture['stderr']}")
        reproduced = parse_review_stdout(capture["stdout"])
        summary = parse_session_summary(summary_path.read_text(encoding="utf-8"))
        reproduced_records = build_candidate_records(reproduced, summary["transcript_revision"])
        errors = compare_candidate_sets(
            frozen_inventory["candidates"],
            reproduced_records,
            frozen_revision=frozen_inventory["transcript_revision"],
            reproduced_revision=summary["transcript_revision"],
        )
        if errors:
            failure = fail_record(
                "authoritative_review",
                "candidate_reproduction_mismatch",
                "; ".join(errors),
                [str(temp_dir)],
            )
            write_json(temp_dir / "failure-record.json", failure)
            write_json(temp_dir / "reproduction-mismatch.json", {"errors": errors})
            raise RuntimeError("candidate reproduction mismatch: " + "; ".join(errors))
        canonical_output_dir.mkdir(parents=True, exist_ok=True)
        for src_name, dest_name in [
            ("reviewed-output.srt", "reviewed-output.srt"),
            ("decision-log.txt", "decision-log.txt"),
            ("session-summary.txt", "session-summary.txt"),
        ]:
            (canonical_output_dir / dest_name).write_bytes((temp_dir / src_name).read_bytes())
        binding = {
            "schema_revision": "voxproof-ami-authoritative-review-binding-v1",
            "recorded_at_utc": utc_now(),
            "binary_sha256": attestation["binary_sha256"],
            "transcript_revision": summary["transcript_revision"],
            "candidate_count": len(reproduced_records),
            "candidate_sequence_sha256": canonical_json_hash(reproduced_records),
            "candidate_multiset_sha256": canonical_json_hash(
                [record["fingerprint"] for record in reproduced_records]
            ),
            "frozen_inventory_sha256": canonical_json_hash(frozen_inventory),
            "reproduction_verified": True,
            "decisions": decisions,
            "artifact_hashes": {
                "stdout_sha256": sha256_text(capture["stdout"]),
                "reviewed_output_sha256": sha256_file(canonical_output_dir / "reviewed-output.srt"),
                "decision_log_sha256": sha256_file(canonical_output_dir / "decision-log.txt"),
                "session_summary_sha256": sha256_file(canonical_output_dir / "session-summary.txt"),
            },
        }
        write_json(canonical_output_dir / "authoritative-review-binding.json", binding)
        write_json(canonical_output_dir / "cli-capture.json", capture)
        return binding


def main() -> int:
    import argparse
    import json

    parser = argparse.ArgumentParser(description="Candidate probe and authoritative review helpers")
    sub = parser.add_subparsers(dest="command", required=True)
    probe = sub.add_parser("probe")
    probe.add_argument("--input-srt", required=True)
    probe.add_argument("--terms", required=True)
    probe.add_argument("--output-dir", required=True)
    review = sub.add_parser("review")
    review.add_argument("--input-srt", required=True)
    review.add_argument("--terms", required=True)
    review.add_argument("--inventory", required=True)
    review.add_argument("--decisions", required=True)
    review.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    binary, attestation = (
        (ISOLATED_BINARY, load_attestation())
        if ISOLATED_BINARY.exists() and BINARY_ATTESTATION_PATH.exists()
        else build_isolated_binary()
    )
    if args.command == "probe":
        inventory = run_candidate_probe(
            binary=binary,
            attestation=attestation,
            input_srt=Path(args.input_srt),
            terms_path=Path(args.terms),
            output_dir=Path(args.output_dir),
        )
        print(json.dumps({"candidate_count": inventory["candidate_count"]}, indent=2))
        return 0
    inventory = json.loads(Path(args.inventory).read_text(encoding="utf-8"))
    decisions = json.loads(Path(args.decisions).read_text(encoding="utf-8"))["decisions"]
    binding = run_authoritative_review(
        binary=binary,
        attestation=attestation,
        input_srt=Path(args.input_srt),
        terms_path=Path(args.terms),
        decisions=decisions,
        frozen_inventory=inventory,
        canonical_output_dir=Path(args.output_dir),
    )
    print(json.dumps({"reproduction_verified": binding["reproduction_verified"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
