#!/usr/bin/env python3
"""Frozen study constants, paths, and limits for V3 exact-evidence Phase A/B."""

from __future__ import annotations

from decimal import Decimal
from pathlib import Path

CORRECTION_ROOT = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-a-correction"
)
PHASE_B_ROOT = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-b"
)
REPO_ROOT = Path("/Users/Ezra4/Coding/Repo/vox-proof")
REQUIRED_HEAD = "5286c1627e54852fc08f4766240ce7545269e982"
PROTOCOL_ID = "voxproof-ami-authoritative-exact-evidence-v3"
CLASSIFICATION = "prospective authoritative exact-evidence pre-outcome freeze"

MEETING_ID = "ES2004b"
SPEAKERS = ("A", "B", "C", "D")
AUTO_PREFIX = "ASR/ASR_AS_CTM_v1.0_feb07/"
WINDOW_START = Decimal("300.000")
WINDOW_END = Decimal("900.000")

SESSION_TERMS_LINES = [
    "Project Manager | alias:PM",
    "Industrial Designer | alias:ID",
    "User Interface Designer | alias:UI | alias:UID",
    "Marketing Expert | alias:ME",
]
SESSION_TERMS_TEXT = "\n".join(SESSION_TERMS_LINES) + "\n"

ISOLATED_CARGO_TARGET = CORRECTION_ROOT / "cargo-target-isolated"
ISOLATED_BINARY = ISOLATED_CARGO_TARGET / "debug/vox-proof"
BINARY_ATTESTATION_PATH = CORRECTION_ROOT / "phase-b/binary-attestation.json"
SCRIPT_LOCK_PATH = CORRECTION_ROOT / "phase-b/script-lock.json"
STAGE_STATE_PATH = CORRECTION_ROOT / "phase-b/stage-state.json"

AUTO_ZIP = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/phase-b/downloads/ami_public_auto_1.5.1.zip"
)
MANUAL_ZIP = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/phase-b/downloads/ami_public_manual_1.6.2.zip"
)

MAX_CANDIDATE_BOUND = 512
TIE_POLICY_ID = "match-substitution-deletion-insertion-v1"
ORDERING_POLICY_ID = "meeting-time-midpoint-v1"

SCRIPT_NAMES = (
    "study_config.py",
    "common.py",
    "ami_transform.py",
    "binary_gate.py",
    "candidate_capture.py",
    "decision_workflow.py",
    "alignment_scorer.py",
    "independent_verifier.py",
    "metrics.py",
    "package_builder.py",
    "package_verifier.py",
    "phase_b_runner.py",
)

CHRONOLOGY_STEPS = (
    "verify_repository_archive_script_config_hashes_build_isolated_binary",
    "cross_target_content_gate_open_asr_words_segments",
    "materialize_hypothesis_srt_and_cue_token_ledger",
    "invoke_exact_binary_candidate_probe_seal_inventory",
    "open_manual_reference_words_content",
    "materialize_reference_scoring_layers_human_ground_truth_decisions",
    "validate_decision_binding_authoritative_review_verify_reproduction",
    "score_corrected_scorer_independent_verify_package_seal",
)
