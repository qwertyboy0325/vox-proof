#!/usr/bin/env python3
"""Ground-truth and decision-input schema validation and stdin rendering."""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from common import read_json, write_json  # noqa: E402

ALLOWED_DECISION_RE = re.compile(r"^(a \d+|r|d|m)$")
GROUND_TRUTH_REQUIRED = (
    "schema_revision",
    "opportunities",
    "normalization_policy_id",
    "overlap_policy_id",
)
DECISION_INPUTS_REQUIRED = ("schema_revision", "transcript_revision", "decisions", "candidate_fingerprints")
LABELS_REQUIRED = ("schema_revision", "labels")


def validate_ground_truth(payload: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    for field in GROUND_TRUTH_REQUIRED:
        if field not in payload:
            errors.append(f"missing ground_truth.{field}")
    for idx, opp in enumerate(payload.get("opportunities", [])):
        for key in ("opportunity_id", "canonical_term", "source_rendering", "window"):
            if key not in opp:
                errors.append(f"opportunity[{idx}] missing {key}")
    return errors


def validate_decision_inputs(
    payload: dict[str, Any],
    inventory: dict[str, Any],
) -> list[str]:
    errors: list[str] = []
    for field in DECISION_INPUTS_REQUIRED:
        if field not in payload:
            errors.append(f"missing decision_inputs.{field}")
    if payload.get("transcript_revision") != inventory.get("transcript_revision"):
        errors.append("decision transcript_revision mismatch with inventory")
    decisions = payload.get("decisions", [])
    candidates = inventory.get("candidates", [])
    if len(decisions) != len(candidates):
        errors.append(
            f"decision count {len(decisions)} != candidate count {len(candidates)}"
        )
    fingerprints = payload.get("candidate_fingerprints", [])
    if fingerprints != [c.get("fingerprint") for c in candidates]:
        errors.append("candidate_fingerprints do not match frozen inventory order")
    for idx, decision in enumerate(decisions):
        if not ALLOWED_DECISION_RE.match(decision):
            errors.append(f"invalid decision syntax at index {idx}: {decision!r}")
        if decision.startswith("a "):
            alt_index = int(decision.split()[1])
            alts = candidates[idx].get("alternatives", [])
            if alt_index >= len(alts):
                errors.append(f"accept index out of range at {idx}")
    return errors


def validate_candidate_labels(
    payload: dict[str, Any],
    inventory: dict[str, Any],
    ground_truth: dict[str, Any],
) -> list[str]:
    errors: list[str] = []
    for field in LABELS_REQUIRED:
        if field not in payload:
            errors.append(f"missing labels.{field}")
    labels = payload.get("labels", [])
    if len(labels) != inventory.get("candidate_count", 0):
        errors.append("label count mismatch")
    opportunity_ids = {o["opportunity_id"] for o in ground_truth.get("opportunities", [])}
    for idx, label in enumerate(labels):
        if "candidate_fingerprint" not in label:
            errors.append(f"label[{idx}] missing candidate_fingerprint")
        elif label["candidate_fingerprint"] != inventory["candidates"][idx]["fingerprint"]:
            errors.append(f"label[{idx}] fingerprint mismatch")
        if label.get("classification") not in {
            "selected_true",
            "selected_false",
            "detector_miss",
        }:
            errors.append(f"label[{idx}] invalid classification")
        if label.get("matched_opportunity_id") and label["matched_opportunity_id"] not in opportunity_ids:
            errors.append(f"label[{idx}] unknown opportunity id")
    return errors


def render_stdin_decisions(decisions: list[str]) -> str:
    return "\n".join(decisions) + ("\n" if decisions else "")


def main() -> int:
    import argparse
    import json

    parser = argparse.ArgumentParser(description="Validate ground truth and decision inputs")
    sub = parser.add_subparsers(dest="command", required=True)
    gt = sub.add_parser("validate-ground-truth")
    gt.add_argument("--ground-truth", required=True)
    di = sub.add_parser("validate-decisions")
    di.add_argument("--decision-inputs", required=True)
    di.add_argument("--inventory", required=True)
    cl = sub.add_parser("validate-labels")
    cl.add_argument("--labels", required=True)
    cl.add_argument("--inventory", required=True)
    cl.add_argument("--ground-truth", required=True)
    render = sub.add_parser("render-stdin")
    render.add_argument("--decision-inputs", required=True)
    args = parser.parse_args()

    if args.command == "validate-ground-truth":
        errors = validate_ground_truth(read_json(Path(args.ground_truth)))
    elif args.command == "validate-decisions":
        inventory = read_json(Path(args.inventory))
        errors = validate_decision_inputs(read_json(Path(args.decision_inputs)), inventory)
    elif args.command == "validate-labels":
        errors = validate_candidate_labels(
            read_json(Path(args.labels)),
            read_json(Path(args.inventory)),
            read_json(Path(args.ground_truth)),
        )
    else:
        decisions = read_json(Path(args.decision_inputs))["decisions"]
        sys.stdout.write(render_stdin_decisions(decisions))
        return 0

    status = "pass" if not errors else "fail"
    print(json.dumps({"status": status, "errors": errors}, indent=2))
    return 0 if status == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
