#!/usr/bin/env python3
"""Phase A reviewer package builder with manifest/seal closure rules."""

from __future__ import annotations

import json
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from common import sha256_bytes, sha256_file, utc_now, write_json  # noqa: E402
from study_config import CORRECTION_ROOT  # noqa: E402

EXCLUDE_SUFFIXES = {".zip", ".pyc"}
EXCLUDE_DIRS = {"__pycache__", "cargo-target-isolated"}


def should_include(path: Path, root: Path) -> bool:
    rel = path.relative_to(root)
    if any(part in EXCLUDE_DIRS for part in rel.parts):
        return False
    if path.suffix in EXCLUDE_SUFFIXES:
        return False
    if rel.parts and rel.parts[0] == "package":
        return False
    if rel.name == "manifest.json":
        return False
    return True


def collect_package_files(root: Path) -> list[Path]:
    return sorted(p for p in root.rglob("*") if p.is_file() and should_include(p, root))


def build_manifest(root: Path, files: list[Path]) -> dict[str, Any]:
    return {
        "schema_revision": "voxproof-ami-phase-a-package-manifest-v1",
        "package": "voxproof-ami-authoritative-exact-evidence-v3-phase-a-correction",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "entry_count": len(files),
        "files": [
            {
                "path": str(path.relative_to(root)).replace("\\", "/"),
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
            for path in files
        ],
    }


def build_zip(root: Path, files: list[Path], zip_path: Path, manifest: dict[str, Any]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in files:
            arc = str(path.relative_to(root)).replace("\\", "/")
            data = path.read_bytes()
            zf.writestr(arc, data)
            entries.append({"path": arc, "sha256": sha256_bytes(data), "bytes": len(data)})
        manifest_bytes = json.dumps(manifest, indent=2, sort_keys=True).encode("utf-8") + b"\n"
        zf.writestr("manifest.json", manifest_bytes)
        entries.append({"path": "manifest.json", "sha256": sha256_bytes(manifest_bytes), "bytes": len(manifest_bytes)})
    return entries


def build_detached_seal(zip_path: Path, entries: list[dict[str, Any]], manifest_sha: str) -> dict[str, Any]:
    return {
        "schema_revision": "voxproof-ami-phase-a-detached-seal-v1",
        "zip_filename": zip_path.name,
        "zip_sha256": sha256_file(zip_path),
        "zip_entry_count": len(entries),
        "embedded_manifest_filename": "manifest.json",
        "embedded_manifest_sha256": manifest_sha,
        "entries": entries,
        "sealed_at_utc": utc_now(),
        "note": "Detached seal lists every ZIP entry including manifest.json",
    }


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description="Build corrected Phase A reviewer package")
    parser.add_argument("--root", default=str(CORRECTION_ROOT))
    parser.add_argument("--output-dir", default=str(CORRECTION_ROOT / "package"))
    parser.add_argument("--stamp", required=True)
    args = parser.parse_args()
    root = Path(args.root)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    files = collect_package_files(root)
    manifest = build_manifest(root, files)
    manifest_path = root / "manifest.json"
    write_json(manifest_path, manifest)
    files = collect_package_files(root)
    manifest = build_manifest(root, files)
    write_json(manifest_path, manifest)
    zip_name = f"voxproof-ami-authoritative-exact-evidence-v3-phase-a-{args.stamp}.zip"
    seal_name = f"package-seal-v3-phase-a-{args.stamp}.json"
    zip_path = output_dir / zip_name
    entries = build_zip(root, files, zip_path, manifest)
    manifest_sha = sha256_file(manifest_path)
    seal = build_detached_seal(zip_path, entries, manifest_sha)
    seal_path = output_dir / seal_name
    write_json(seal_path, seal)
    summary = {
        "zip_filename": zip_name,
        "zip_sha256": seal["zip_sha256"],
        "entry_count": len(entries),
        "seal_filename": seal_name,
        "seal_sha256": sha256_file(seal_path),
        "manifest_entry_count_excluding_self": len(files),
    }
    write_json(output_dir / "package-summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
