#!/usr/bin/env python3
"""AMI hypothesis/reference/scoring transforms parameterized by frozen study config."""

from __future__ import annotations

import argparse
import sys
import zipfile
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from common import write_json  # noqa: E402
from study_config import AUTO_PREFIX, AUTO_ZIP, MANUAL_ZIP, MEETING_ID, SPEAKERS  # noqa: E402


def required_auto_members() -> list[str]:
    return [
        f"{AUTO_PREFIX}{MEETING_ID}.{speaker}.words.xml" for speaker in SPEAKERS
    ] + [f"{AUTO_PREFIX}{MEETING_ID}.{speaker}.segments.xml" for speaker in SPEAKERS]


def required_manual_members() -> list[str]:
    return [f"words/{MEETING_ID}.{speaker}.words.xml" for speaker in SPEAKERS]


def verify_archive_members(zip_path: Path, members: list[str]) -> list[str]:
    with zipfile.ZipFile(zip_path) as zf:
        names = set(zf.namelist())
    return [member for member in members if member not in names]


def build_hypothesis_manifest(build_root: Path) -> dict[str, object]:
    missing = verify_archive_members(AUTO_ZIP, required_auto_members())
    if missing:
        raise RuntimeError(f"hypothesis build blocked: missing auto members {missing}")
    manifest = {
        "schema_revision": "voxproof-ami-hypothesis-layer-manifest-v1",
        "meeting_id": MEETING_ID,
        "archive": str(AUTO_ZIP),
        "required_members": required_auto_members(),
        "build_root": str(build_root),
        "note": "Phase B only: parses ASR words/segments after target-content gate",
    }
    write_json(build_root / "layer_manifest.json", manifest)
    return manifest


def build_reference_manifest(build_root: Path) -> dict[str, object]:
    missing = verify_archive_members(MANUAL_ZIP, required_manual_members())
    if missing:
        raise RuntimeError(f"reference build blocked: missing manual members {missing}")
    manifest = {
        "schema_revision": "voxproof-ami-reference-layer-manifest-v1",
        "meeting_id": MEETING_ID,
        "archive": str(MANUAL_ZIP),
        "required_members": required_manual_members(),
        "build_root": str(build_root),
        "note": "Phase B only: parses manual words after candidate inventory freeze",
    }
    write_json(build_root / "reference_layer_manifest.json", manifest)
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description="AMI layer transforms (Phase B)")
    parser.add_argument("layer", choices=["hypothesis", "reference", "scoring"])
    parser.add_argument("--build-root", required=True)
    args = parser.parse_args()
    build_root = Path(args.build_root)
    build_root.mkdir(parents=True, exist_ok=True)
    if args.layer == "hypothesis":
        build_hypothesis_manifest(build_root)
    elif args.layer == "reference":
        build_reference_manifest(build_root)
    else:
        write_json(
            build_root / "scoring_manifest.json",
            {
                "schema_revision": "voxproof-ami-scoring-layer-manifest-v1",
                "requires": ["hypothesis", "reference"],
            },
        )
    print(f"ok:{args.layer}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
