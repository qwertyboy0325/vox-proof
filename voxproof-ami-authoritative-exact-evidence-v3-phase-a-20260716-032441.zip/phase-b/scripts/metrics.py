#!/usr/bin/env python3
"""Frozen semantic labels and metric computation."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from common import ratio_or_null, write_json  # noqa: E402


def compute_study_metrics(
    *,
    inventory: dict[str, Any],
    ground_truth: dict[str, Any],
    labels: list[dict[str, Any]],
    decisions: list[str],
    raw_wer: float | None,
    reviewed_wer: float | None,
) -> dict[str, Any]:
    opportunities = ground_truth.get("opportunities", [])
    candidates = inventory.get("candidates", [])
    true_candidates = [label for label in labels if label.get("classification") == "selected_true"]
    false_candidates = [label for label in labels if label.get("classification") == "selected_false"]
    matched_opportunity_ids = {
        label["matched_opportunity_id"]
        for label in true_candidates
        if label.get("matched_opportunity_id")
    }
    detector_misses = [
        opp
        for opp in opportunities
        if opp["opportunity_id"] not in matched_opportunity_ids
    ]
    accepted = [d for d in decisions if d.startswith("a ")]
    unsafe_edits = [label for label in labels if label.get("unsafe_edit") is True and label.get("accepted") is True]

    return {
        "schema_revision": "voxproof-ami-study-metrics-v1",
        "definitions_revision": "v3-phase-a-memo-section-4",
        "candidate_precision": {
            "numerator": len(true_candidates),
            "denominator": len(candidates),
            "ratio": ratio_or_null(len(true_candidates), len(candidates)),
        },
        "candidate_recall": {
            "numerator": len(matched_opportunity_ids),
            "denominator": len(opportunities),
            "ratio": ratio_or_null(len(matched_opportunity_ids), len(opportunities)),
        },
        "correction_recall": {
            "numerator": sum(1 for label in labels if label.get("materialized_correctly") is True),
            "denominator": len(opportunities),
            "ratio": ratio_or_null(
                sum(1 for label in labels if label.get("materialized_correctly") is True),
                len(opportunities),
            ),
        },
        "false_positive_burden": len(false_candidates),
        "unsafe_edit_rate": {
            "numerator": len(unsafe_edits),
            "denominator": len(accepted),
            "ratio": ratio_or_null(len(unsafe_edits), len(accepted)),
        },
        "raw_wer": raw_wer,
        "reviewed_wer": reviewed_wer,
        "raw_to_reviewed_wer_delta": (
            None if raw_wer is None or reviewed_wer is None else reviewed_wer - raw_wer
        ),
        "zero_denominator_rule": "ratio fields are JSON null when denominator is zero",
        "detector_miss_count": len(detector_misses),
        "selected_true_candidate_count": len(true_candidates),
        "selected_false_candidate_count": len(false_candidates),
    }


def main() -> int:
    import argparse
    import json

    from alignment_scorer import align_tokens, load_frozen_streams

    parser = argparse.ArgumentParser(description="Compute frozen study metrics")
    parser.add_argument("--inventory", required=True)
    parser.add_argument("--ground-truth", required=True)
    parser.add_argument("--labels", required=True)
    parser.add_argument("--decision-inputs", required=True)
    parser.add_argument("--scoring-tokens", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    inventory = json.loads(Path(args.inventory).read_text(encoding="utf-8"))
    ground_truth = json.loads(Path(args.ground_truth).read_text(encoding="utf-8"))
    labels_payload = json.loads(Path(args.labels).read_text(encoding="utf-8"))
    decisions_payload = json.loads(Path(args.decision_inputs).read_text(encoding="utf-8"))
    reference, hypothesis, _ = load_frozen_streams(Path(args.scoring_tokens))
    raw = align_tokens(reference, hypothesis)
    metrics = compute_study_metrics(
        inventory=inventory,
        ground_truth=ground_truth,
        labels=labels_payload["labels"],
        decisions=decisions_payload["decisions"],
        raw_wer=raw.wer(),
        reviewed_wer=raw.wer(),
    )
    write_json(Path(args.output), metrics)
    print(json.dumps({"status": "ok", "candidate_count": inventory["candidate_count"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
