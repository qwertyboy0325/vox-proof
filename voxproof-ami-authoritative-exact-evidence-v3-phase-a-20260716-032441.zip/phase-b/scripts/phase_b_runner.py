#!/usr/bin/env python3
"""Explicit Phase B subcommands with stage-state gates and fixture dry-run."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from binary_gate import build_isolated_binary, load_attestation, verify_repository_head  # noqa: E402
from candidate_capture import run_authoritative_review, run_candidate_probe  # noqa: E402
from common import read_json, sha256_file, utc_now, write_json  # noqa: E402
from study_config import (  # noqa: E402
    AUTO_ZIP,
    BINARY_ATTESTATION_PATH,
    CHRONOLOGY_STEPS,
    CORRECTION_ROOT,
    ISOLATED_BINARY,
    MANUAL_ZIP,
    SCRIPT_LOCK_PATH,
    SCRIPT_NAMES,
    STAGE_STATE_PATH,
)


STAGE_ORDER = [
    "preflight",
    "build_binary",
    "target_content_gate",
    "hypothesis",
    "probe_candidates",
    "reference_access",
    "ground_truth",
    "authoritative_review",
    "score",
    "verify",
    "package",
]


def load_stage_state() -> dict[str, Any]:
    if STAGE_STATE_PATH.exists():
        return read_json(STAGE_STATE_PATH)
    return {"schema_revision": "voxproof-ami-stage-state-v1", "completed": []}


def require_stage(completed: list[str], required: str) -> None:
    if required not in completed:
        raise RuntimeError(f"stage gate blocked: requires completed stage {required!r}")


def mark_stage(stage: str, detail: str) -> None:
    state = load_stage_state()
    if stage not in state["completed"]:
        state["completed"].append(stage)
    state["last_stage"] = stage
    state["last_detail"] = detail
    state["updated_at_utc"] = utc_now()
    write_json(STAGE_STATE_PATH, state)


def verify_script_lock() -> list[dict[str, Any]]:
    rows = []
    for name in SCRIPT_NAMES:
        path = SCRIPT_DIR / name
        rows.append({"path": f"phase-b/scripts/{name}", "sha256": sha256_file(path), "bytes": path.stat().st_size})
    write_json(SCRIPT_LOCK_PATH, {"schema_revision": "voxproof-ami-script-lock-v1", "scripts": rows})
    return rows


def cmd_preflight() -> dict[str, Any]:
    verify_repository_head()
    scripts = verify_script_lock()
    for archive in (AUTO_ZIP, MANUAL_ZIP):
        if not archive.exists():
            raise RuntimeError(f"missing archive: {archive}")
    mark_stage("preflight", "repository, archives, script lock verified")
    return {"status": "pass", "script_count": len(scripts)}


def cmd_build_binary() -> dict[str, Any]:
    require_stage(load_stage_state()["completed"], "preflight")
    _, attestation = build_isolated_binary()
    mark_stage("build_binary", attestation["binary_sha256"])
    return {"status": "pass", "binary_sha256": attestation["binary_sha256"]}


def cmd_dry_run(fixture_root: Path) -> dict[str, Any]:
    """Fixture-only rehearsal of exact Phase B command envelope."""
    verify_script_lock()
    binary, attestation = (
        (ISOLATED_BINARY, load_attestation())
        if ISOLATED_BINARY.exists() and BINARY_ATTESTATION_PATH.exists()
        else build_isolated_binary()
    )
    terms = CORRECTION_ROOT / "session-terms/session-terms.txt"
    commands: list[dict[str, str]] = []
    for name in ("zero-candidate", "nonzero-candidate"):
        fixture = fixture_root / name
        out = fixture / "rehearsal"
        out.mkdir(parents=True, exist_ok=True)
        inventory = run_candidate_probe(
            binary=binary,
            attestation=attestation,
            input_srt=fixture / "input.srt",
            terms_path=terms,
            output_dir=out,
        )
        commands.append(
            {
                "fixture": name,
                "probe_command": (
                    f"{binary} review {fixture / 'input.srt'} {terms} "
                    f"{out / 'probe-reviewed-output.srt'} {out / 'probe-decision-log.txt'} "
                    f"{out / 'probe-session-summary.txt'}"
                ),
                "candidate_count": str(inventory["candidate_count"]),
            }
        )
        if inventory["candidate_count"] > 0:
            decisions = ["a 0", "r"] + ["d"] * (inventory["candidate_count"] - 2)
            decision_path = out / "decision-inputs.json"
            write_json(
                decision_path,
                {
                    "schema_revision": "voxproof-ami-decision-inputs-v1",
                    "transcript_revision": inventory["transcript_revision"],
                    "candidate_fingerprints": [c["fingerprint"] for c in inventory["candidates"]],
                    "decisions": decisions,
                },
            )
            run_authoritative_review(
                binary=binary,
                attestation=attestation,
                input_srt=fixture / "input.srt",
                terms_path=terms,
                decisions=decisions,
                frozen_inventory=inventory,
                canonical_output_dir=out / "authoritative",
            )
    envelope = {
        "schema_revision": "voxproof-ami-phase-b-dry-run-v1",
        "chronology_steps": list(CHRONOLOGY_STEPS),
        "fixture_root": str(fixture_root),
        "binary_path": str(binary),
        "binary_sha256": attestation["binary_sha256"],
        "script_lock": str(SCRIPT_LOCK_PATH),
        "commands": commands,
        "exact_subcommands": [
            "phase_b_runner.py preflight",
            "phase_b_runner.py build-binary",
            "ami_transform.py hypothesis --build-root <build-primary>",
            "candidate_capture.py probe --input-srt <srt> --terms <terms> --output-dir <probe>",
            "ami_transform.py reference --build-root <build-primary>",
            "decision_workflow.py validate-decisions --decision-inputs <json> --inventory <json>",
            "candidate_capture.py review --input-srt <srt> --terms <terms> --inventory <json> --decisions <json> --output-dir <review>",
            "alignment_scorer.py score --scoring-tokens <json> --output-metrics <json> --output-operations <tsv>",
            "independent_verifier.py <study_root>",
            "package_verifier.py <study_root> <zip> <seal>",
        ],
    }
    write_json(CORRECTION_ROOT / "outputs/phase-b-dry-run-envelope.json", envelope)
    return envelope


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description="Phase B runner with stage gates")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("preflight")
    sub.add_parser("build-binary")
    sub.add_parser("verify-scripts")
    dry = sub.add_parser("dry-run")
    dry.add_argument("--fixture-root", default=str(CORRECTION_ROOT / "fixtures"))
    args = parser.parse_args()

    if args.command == "preflight":
        out = cmd_preflight()
    elif args.command == "build-binary":
        out = cmd_build_binary()
    elif args.command == "verify-scripts":
        out = {"scripts": verify_script_lock()}
    else:
        out = cmd_dry_run(Path(args.fixture_root))
    print(json.dumps(out, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
