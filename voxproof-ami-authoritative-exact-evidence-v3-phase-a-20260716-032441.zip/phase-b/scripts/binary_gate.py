#!/usr/bin/env python3
"""Isolated binary build, attestation, and immediate pre-invocation hash checks."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from common import sha256_file, utc_now, write_json  # noqa: E402
from study_config import (  # noqa: E402
    BINARY_ATTESTATION_PATH,
    CORRECTION_ROOT,
    ISOLATED_BINARY,
    ISOLATED_CARGO_TARGET,
    REPO_ROOT,
    REQUIRED_HEAD,
)


def sanitized_build_env() -> dict[str, str]:
    env = {
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "HOME": os.environ.get("HOME", str(Path.home())),
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "CARGO_TARGET_DIR": str(ISOLATED_CARGO_TARGET),
    }
    for key, value in os.environ.items():
        if key.startswith("VOX_PROOF_EXPERIMENT"):
            continue
        if key not in env:
            env[key] = value
    return env


def verify_repository_head() -> str:
    head = subprocess.check_output(
        ["git", "-C", str(REPO_ROOT), "rev-parse", "HEAD"], text=True
    ).strip()
    if head != REQUIRED_HEAD:
        raise RuntimeError(f"repository head mismatch: expected {REQUIRED_HEAD}, got {head}")
    status = subprocess.check_output(
        ["git", "-C", str(REPO_ROOT), "status", "--porcelain=v1"], text=True
    )
    tracked_changes = [
        line
        for line in status.splitlines()
        if line and line[0] in {"M", "A", "D", "R", "C", "U"}
    ]
    if tracked_changes:
        raise RuntimeError(f"repository has tracked working tree changes: {tracked_changes!r}")
    return head


def build_isolated_binary(*, force_rebuild: bool = False) -> tuple[Path, dict[str, Any]]:
    verify_repository_head()
    env = sanitized_build_env()
    if force_rebuild and ISOLATED_CARGO_TARGET.exists():
        shutil.rmtree(ISOLATED_CARGO_TARGET)
    ISOLATED_CARGO_TARGET.mkdir(parents=True, exist_ok=True)
    build_cmd = ["cargo", "build", "--locked"]
    proc = subprocess.run(
        build_cmd,
        cwd=REPO_ROOT,
        text=True,
        capture_output=True,
        env=env,
        check=False,
    )
    head = subprocess.check_output(
        ["git", "-C", str(REPO_ROOT), "rev-parse", "HEAD"], text=True
    ).strip()
    tree = subprocess.check_output(
        ["git", "-C", str(REPO_ROOT), "rev-parse", "HEAD^{tree}"], text=True
    ).strip()
    status = subprocess.check_output(
        ["git", "-C", str(REPO_ROOT), "status", "--porcelain=v1"], text=True
    )
    rustc = subprocess.check_output(["rustc", "--version"], text=True).strip()
    cargo = subprocess.check_output(["cargo", "--version"], text=True).strip()
    attestation: dict[str, Any] = {
        "schema_revision": "voxproof-ami-binary-attestation-v1",
        "recorded_at_utc": utc_now(),
        "repository_head": head,
        "required_head": REQUIRED_HEAD,
        "repository_tree": tree,
        "repository_status_porcelain": status,
        "build_command": " ".join(build_cmd),
        "cargo_target_dir": str(ISOLATED_CARGO_TARGET),
        "binary_path": str(ISOLATED_BINARY),
        "rustc_version": rustc,
        "cargo_version": cargo,
        "cargo_lock_sha256": sha256_file(REPO_ROOT / "Cargo.lock"),
        "sanitized_environment": {k: env[k] for k in sorted(env)},
        "build_exit_code": proc.returncode,
        "build_stdout_tail": proc.stdout[-4000:],
        "build_stderr_tail": proc.stderr[-4000:],
        "binary_sha256": sha256_file(ISOLATED_BINARY) if ISOLATED_BINARY.exists() else None,
        "reused_repository_target_debug": False,
    }
    write_json(BINARY_ATTESTATION_PATH, attestation)
    if proc.returncode != 0 or not ISOLATED_BINARY.exists():
        raise RuntimeError(f"isolated cargo build failed: {proc.stderr}")
    return ISOLATED_BINARY, attestation


def load_attestation(path: Path | None = None) -> dict[str, Any]:
    target = path or BINARY_ATTESTATION_PATH
    if not target.exists():
        raise FileNotFoundError(f"missing binary attestation: {target}")
    return __import__("json").loads(target.read_text(encoding="utf-8"))


def verify_binary_hash_immediately_before_invocation(
    binary: Path,
    attestation: dict[str, Any],
) -> str:
    expected = attestation.get("binary_sha256")
    if not expected:
        raise RuntimeError("attestation missing binary_sha256")
    if str(binary) != attestation.get("binary_path"):
        raise RuntimeError(
            f"binary path mismatch: attested={attestation.get('binary_path')} actual={binary}"
        )
    actual = sha256_file(binary)
    if actual != expected:
        raise RuntimeError(
            f"binary hash mismatch immediately before invocation: expected {expected}, got {actual}"
        )
    return actual


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description="Build or verify isolated vox-proof binary")
    parser.add_argument("command", choices=["build", "verify-hash"])
    parser.add_argument("--force-rebuild", action="store_true")
    args = parser.parse_args()
    if args.command == "build":
        _, attestation = build_isolated_binary(force_rebuild=args.force_rebuild)
        print(attestation["binary_sha256"])
        return 0
    verify_binary_hash_immediately_before_invocation(ISOLATED_BINARY, load_attestation())
    print("pass")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
