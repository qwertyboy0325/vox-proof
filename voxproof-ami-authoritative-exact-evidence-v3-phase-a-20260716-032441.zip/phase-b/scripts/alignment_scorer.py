#!/usr/bin/env python3
"""Primary deterministic token alignment scorer for exploratory v2."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


TIE_POLICY_ID = "match-substitution-deletion-insertion-v1"
TIE_POLICY_ORDER = ["match", "substitution", "deletion", "insertion"]


@dataclass(frozen=True)
class AlignmentOperation:
    ordinal: int
    operation: str
    reference_index: int | None
    hypothesis_index: int | None
    reference_token: str | None
    hypothesis_token: str | None
    reference_coord_before: int
    hypothesis_coord_before: int
    reference_coord_after: int
    hypothesis_coord_after: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "ordinal": self.ordinal,
            "operation": self.operation,
            "reference_index": self.reference_index,
            "hypothesis_index": self.hypothesis_index,
            "reference_token": self.reference_token,
            "hypothesis_token": self.hypothesis_token,
            "reference_coord_before": self.reference_coord_before,
            "hypothesis_coord_before": self.hypothesis_coord_before,
            "reference_coord_after": self.reference_coord_after,
            "hypothesis_coord_after": self.hypothesis_coord_after,
        }


@dataclass(frozen=True)
class AlignmentResult:
    reference_tokens: tuple[str, ...]
    hypothesis_tokens: tuple[str, ...]
    operations: tuple[AlignmentOperation, ...]
    matches: int
    substitutions: int
    deletions: int
    insertions: int
    edit_distance: int
    tie_policy_id: str = TIE_POLICY_ID

    @property
    def N(self) -> int:
        return len(self.reference_tokens)

    @property
    def H(self) -> int:
        return len(self.hypothesis_tokens)

    def counts(self) -> dict[str, int]:
        return {
            "N_reference": self.N,
            "H_hypothesis": self.H,
            "matches": self.matches,
            "substitutions": self.substitutions,
            "deletions": self.deletions,
            "insertions": self.insertions,
            "edit_distance": self.edit_distance,
        }

    def wer(self) -> float | None:
        if self.N == 0:
            return None
        return self.edit_distance / self.N

    def validate_invariants(self) -> list[str]:
        errors: list[str] = []
        m, s, d, i = self.matches, self.substitutions, self.deletions, self.insertions
        n, h = self.N, self.H
        if m + s + d != n:
            errors.append(f"M+S+D != N: {m}+{s}+{d} != {n}")
        if m + s + i != h:
            errors.append(f"M+S+I != H: {m}+{s}+{i} != {h}")
        if h != n - d + i:
            errors.append(f"H != N-D+I: {h} != {n}-{d}+{i}")
        if self.edit_distance != s + d + i:
            errors.append(
                f"edit_distance != S+D+I: {self.edit_distance} != {s}+{d}+{i}"
            )
        if not self.operations:
            if n != 0 or h != 0:
                errors.append("empty operation path for non-empty streams")
            return errors
        if (
            self.operations[0].reference_coord_before != 0
            or self.operations[0].hypothesis_coord_before != 0
        ):
            errors.append("path does not begin at (0,0)")
        last = self.operations[-1]
        if last.reference_coord_after != n or last.hypothesis_coord_after != h:
            errors.append(f"path does not end at ({n},{h})")
        prev_ref = 0
        prev_hyp = 0
        for op in self.operations:
            if op.reference_coord_before != prev_ref or op.hypothesis_coord_before != prev_hyp:
                errors.append(f"non-monotonic transition at ordinal {op.ordinal}")
            if op.operation in {"match", "substitution", "deletion"}:
                if op.reference_coord_after != op.reference_coord_before + 1:
                    errors.append(f"reference index not advanced at ordinal {op.ordinal}")
            else:
                if op.reference_coord_after != op.reference_coord_before:
                    errors.append(f"reference index advanced on insertion at ordinal {op.ordinal}")
            if op.operation in {"match", "substitution", "insertion"}:
                if op.hypothesis_coord_after != op.hypothesis_coord_before + 1:
                    errors.append(f"hypothesis index not advanced at ordinal {op.ordinal}")
            else:
                if op.hypothesis_coord_after != op.hypothesis_coord_before:
                    errors.append(f"hypothesis index advanced on deletion at ordinal {op.ordinal}")
            prev_ref = op.reference_coord_after
            prev_hyp = op.hypothesis_coord_after
        ref_recon: list[str] = []
        hyp_recon: list[str] = []
        for op in self.operations:
            if op.operation == "match":
                if op.reference_token != op.hypothesis_token:
                    errors.append(f"match with unequal tokens at ordinal {op.ordinal}")
                ref_recon.append(op.reference_token or "")
                hyp_recon.append(op.hypothesis_token or "")
            elif op.operation == "substitution":
                if op.reference_token == op.hypothesis_token:
                    errors.append(
                        f"substitution with equal tokens at ordinal {op.ordinal}"
                    )
                ref_recon.append(op.reference_token or "")
                hyp_recon.append(op.hypothesis_token or "")
            elif op.operation == "deletion":
                if op.hypothesis_token is not None:
                    errors.append(f"deletion consumed hypothesis at ordinal {op.ordinal}")
                ref_recon.append(op.reference_token or "")
            elif op.operation == "insertion":
                if op.reference_token is not None:
                    errors.append(f"insertion consumed reference at ordinal {op.ordinal}")
                hyp_recon.append(op.hypothesis_token or "")
            else:
                errors.append(f"unknown operation {op.operation}")
        if tuple(ref_recon) != self.reference_tokens:
            errors.append("reconstructed reference tokens mismatch")
        if tuple(hyp_recon) != self.hypothesis_tokens:
            errors.append("reconstructed hypothesis tokens mismatch")
        return errors


def build_distance_matrix(reference: list[str], hypothesis: list[str]) -> list[list[int]]:
    n = len(reference)
    m = len(hypothesis)
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        dp[i][0] = i
    for j in range(1, m + 1):
        dp[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if reference[i - 1] == hypothesis[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = 1 + min(dp[i - 1][j - 1], dp[i - 1][j], dp[i][j - 1])
    return dp


def backtrace_alignment(
    reference: list[str],
    hypothesis: list[str],
    dp: list[list[int]] | None = None,
) -> list[AlignmentOperation]:
    n = len(reference)
    m = len(hypothesis)
    if dp is None:
        dp = build_distance_matrix(reference, hypothesis)
    if len(dp) != n + 1 or any(len(row) != m + 1 for row in dp):
        raise ValueError("malformed distance matrix dimensions")
    i = n
    j = m
    raw_ops: list[
        tuple[str, int | None, int | None, str | None, str | None, int, int, int, int]
    ] = []
    while i > 0 or j > 0:
        current = dp[i][j]
        ref_before = n - i
        hyp_before = m - j
        chosen: str | None = None
        for op_name in TIE_POLICY_ORDER:
            if op_name == "match" and i > 0 and j > 0 and reference[i - 1] == hypothesis[j - 1]:
                if current == dp[i - 1][j - 1]:
                    chosen = "match"
                    raw_ops.append(
                        (
                            "match",
                            i - 1,
                            j - 1,
                            reference[i - 1],
                            hypothesis[j - 1],
                            ref_before,
                            hyp_before,
                            ref_before + 1,
                            hyp_before + 1,
                        )
                    )
                    i -= 1
                    j -= 1
                    break
            elif op_name == "substitution" and i > 0 and j > 0:
                if current == dp[i - 1][j - 1] + 1:
                    chosen = "substitution"
                    raw_ops.append(
                        (
                            "substitution",
                            i - 1,
                            j - 1,
                            reference[i - 1],
                            hypothesis[j - 1],
                            ref_before,
                            hyp_before,
                            ref_before + 1,
                            hyp_before + 1,
                        )
                    )
                    i -= 1
                    j -= 1
                    break
            elif op_name == "deletion" and i > 0:
                if current == dp[i - 1][j] + 1:
                    chosen = "deletion"
                    raw_ops.append(
                        (
                            "deletion",
                            i - 1,
                            None,
                            reference[i - 1],
                            None,
                            ref_before,
                            hyp_before,
                            ref_before + 1,
                            hyp_before,
                        )
                    )
                    i -= 1
                    break
            elif op_name == "insertion" and j > 0:
                if current == dp[i][j - 1] + 1:
                    chosen = "insertion"
                    raw_ops.append(
                        (
                            "insertion",
                            None,
                            j - 1,
                            None,
                            hypothesis[j - 1],
                            ref_before,
                            hyp_before,
                            ref_before,
                            hyp_before + 1,
                        )
                    )
                    j -= 1
                    break
        if chosen is None:
            raise ValueError(f"backtrace failed at coordinates ({i},{j})")
    raw_ops.reverse()
    operations: list[AlignmentOperation] = []
    ref_pos = 0
    hyp_pos = 0
    for idx, (op, ri, hi, rt, ht, _rb, _hb, _ra, _ha) in enumerate(raw_ops):
        if op in {"match", "substitution", "deletion"}:
            ref_after = ref_pos + 1
        else:
            ref_after = ref_pos
        if op in {"match", "substitution", "insertion"}:
            hyp_after = hyp_pos + 1
        else:
            hyp_after = hyp_pos
        operations.append(
            AlignmentOperation(
                ordinal=idx,
                operation=op,
                reference_index=ri,
                hypothesis_index=hi,
                reference_token=rt,
                hypothesis_token=ht,
                reference_coord_before=ref_pos,
                hypothesis_coord_before=hyp_pos,
                reference_coord_after=ref_after,
                hypothesis_coord_after=hyp_after,
            )
        )
        ref_pos = ref_after
        hyp_pos = hyp_after
    return operations


def align_tokens(reference: list[str], hypothesis: list[str]) -> AlignmentResult:
    dp = build_distance_matrix(reference, hypothesis)
    operations = tuple(backtrace_alignment(reference, hypothesis, dp))
    counts = {"match": 0, "substitution": 0, "deletion": 0, "insertion": 0}
    for op in operations:
        counts[op.operation] += 1
    edit_distance = dp[len(reference)][len(hypothesis)]
    result = AlignmentResult(
        reference_tokens=tuple(reference),
        hypothesis_tokens=tuple(hypothesis),
        operations=operations,
        matches=counts["match"],
        substitutions=counts["substitution"],
        deletions=counts["deletion"],
        insertions=counts["insertion"],
        edit_distance=edit_distance,
    )
    errors = result.validate_invariants()
    if errors:
        raise ValueError("; ".join(errors))
    return result


def load_frozen_streams(path: Path) -> tuple[list[str], list[str], dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    reference = list(payload["reference_tokens"])
    hypothesis = list(payload["hypothesis_tokens"])
    return reference, hypothesis, payload


def write_operations_tsv(path: Path, result: AlignmentResult) -> None:
    lines = [
        "ordinal\toperation\treference_index\thypothesis_index\treference_token\thypothesis_token\treference_coord_before\thypothesis_coord_before\treference_coord_after\thypothesis_coord_after"
    ]
    for op in result.operations:
        lines.append(
            "\t".join(
                [
                    str(op.ordinal),
                    op.operation,
                    "" if op.reference_index is None else str(op.reference_index),
                    "" if op.hypothesis_index is None else str(op.hypothesis_index),
                    "" if op.reference_token is None else op.reference_token,
                    "" if op.hypothesis_token is None else op.hypothesis_token,
                    str(op.reference_coord_before),
                    str(op.hypothesis_coord_before),
                    str(op.reference_coord_after),
                    str(op.hypothesis_coord_after),
                ]
            )
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_metrics_payload(
    result: AlignmentResult,
    scoring_payload: dict[str, Any],
    *,
    input_srt_sha256: str,
    reviewed_output_srt_sha256: str,
) -> dict[str, Any]:
    wer = result.wer()
    return {
        "schema_revision": "voxproof-ami-metrics-v1",
        "classification": "operation-aware-alignment",
        "counts": result.counts(),
        "wer": wer,
        "ordering_policy": scoring_payload.get("ordering_policy", {}).get("policy_id"),
        "tie_policy_id": result.tie_policy_id,
        "immutable_inputs": {
            "input_srt_sha256": input_srt_sha256,
            "reviewed_output_srt_sha256": reviewed_output_srt_sha256,
            "scoring_tokens_sha256": None,
        },
    }


def verify_metrics_file(metrics_path: Path, scoring_path: Path) -> list[str]:
    reference, hypothesis, payload = load_frozen_streams(scoring_path)
    result = align_tokens(reference, hypothesis)
    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    errors: list[str] = []
    for key, expected in result.counts().items():
        actual = metrics.get("counts", {}).get(key)
        if actual != expected:
            errors.append(f"counts.{key}: {actual} != {expected}")
    wer = result.wer()
    if wer is None:
        if metrics.get("wer") is not None:
            errors.append("wer should be null when N=0")
    elif abs(metrics["wer"] - wer) > 1e-12:
        errors.append(f"wer mismatch: {metrics['wer']} != {wer}")
    if metrics.get("tie_policy_id") != result.tie_policy_id:
        errors.append("tie_policy_id mismatch")
    if metrics.get("ordering_policy") != payload.get("ordering_policy", {}).get("policy_id"):
        errors.append("ordering_policy mismatch")
    return errors


def main() -> int:
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="Corrected operation-aware alignment scorer")
    sub = parser.add_subparsers(dest="command", required=True)
    score = sub.add_parser("score", help="Score frozen token streams")
    score.add_argument("--scoring-tokens", required=True)
    score.add_argument("--output-metrics", required=True)
    score.add_argument("--output-operations", required=True)
    score.add_argument("--input-srt-sha256", default="fixture")
    score.add_argument("--reviewed-srt-sha256", default="fixture")
    verify = sub.add_parser("verify-metrics", help="Verify an existing metrics.json")
    verify.add_argument("--scoring-tokens", required=True)
    verify.add_argument("--metrics", required=True)
    args = parser.parse_args()

    if args.command == "score":
        scoring_path = Path(args.scoring_tokens)
        reference, hypothesis, payload = load_frozen_streams(scoring_path)
        result = align_tokens(reference, hypothesis)
        metrics = build_metrics_payload(
            result,
            payload,
            input_srt_sha256=args.input_srt_sha256,
            reviewed_output_srt_sha256=args.reviewed_srt_sha256,
        )
        write_operations_tsv(Path(args.output_operations), result)
        Path(args.output_metrics).write_text(json.dumps(metrics, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({"edit_distance": result.edit_distance, "wer": result.wer()}, indent=2))
        return 0

    errors = verify_metrics_file(Path(args.metrics), Path(args.scoring_tokens))
    if errors:
        print(json.dumps({"status": "fail", "errors": errors}, indent=2))
        return 1
    print(json.dumps({"status": "pass"}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
