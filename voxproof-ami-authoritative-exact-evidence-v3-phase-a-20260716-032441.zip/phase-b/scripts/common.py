#!/usr/bin/env python3
"""Canonical JSON, hashing, path safety, subprocess capture, invariant helpers."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

UNSAFE_PATH_RE = re.compile(r"(^/|\.\./|\\\\)")


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def canonical_json(payload: Any) -> str:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def canonical_json_hash(payload: Any) -> str:
    return sha256_text(canonical_json(payload))


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def is_unsafe_zip_path(name: str) -> bool:
    if not name or name.endswith("/"):
        return False
    parts = Path(name).parts
    return any(part in {"..", ""} for part in parts) or name.startswith("/")


def safe_zip_inventory(zip_path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            rows.append(
                {
                    "path": info.filename,
                    "bytes": info.file_size,
                    "compressed_bytes": info.compress_size,
                    "unsafe": is_unsafe_zip_path(info.filename),
                }
            )
    return sorted(rows, key=lambda row: row["path"])


def capture_command(cmd: list[str], *, cwd: Path | None = None, input_text: str = "") -> dict[str, Any]:
    proc = subprocess.run(
        cmd,
        cwd=cwd,
        input=input_text,
        text=True,
        capture_output=True,
        check=False,
    )
    return {
        "command": cmd,
        "exit_code": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
        "stdin": input_text,
    }


def ratio_or_null(numerator: int, denominator: int) -> float | None:
    if denominator == 0:
        return None
    return numerator / denominator


def fail_record(stage: str, gate: str, detail: str, artifacts: list[str] | None = None) -> dict[str, Any]:
    return {
        "schema_revision": "voxproof-ami-failure-record-v1",
        "failed_at_utc": utc_now(),
        "stage": stage,
        "gate": gate,
        "detail": detail,
        "artifacts": artifacts or [],
    }
