# VoxProof Authoritative Exact-Evidence V3 Phase A Correction

## Executable envelope correction
This correction packages exact Phase B scripts under `phase-b/scripts/`, byte-locked in `phase-b/script-lock.json`, with explicit subcommands and stage gates in `phase_b_runner.py`.

## Target
- meeting_id: `ES2004b`
- window: `[300.000, 900.000)`
- terms frozen: see `session-terms/session-terms.txt`

## Chronology
See `phase-b-commands.md` for the authoritative eight-step order.

## Preserved artifacts
- first V3 ZIP/seal unchanged: `voxproof-ami-authoritative-exact-evidence-v3-phase-a-20260716-031102.zip`
- c1 and exploratory v2 hashes recorded in `source-lock.json`

## Access boundary
ES2004b ASR/manual words/segments content remained unopened. Only fixture rehearsals used the isolated binary.
