#!/usr/bin/env python3
"""Frozen window-local timestamp policy and structural-preflight tests."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
import zipfile
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "phase-b/scripts"
REPO = Path("/Users/Ezra4/Coding/Repo/vox-proof")
sys.path.insert(0, str(SCRIPTS))

from ami_common import (  # noqa: E402
    TIMESTAMP_POLICY_ID,
    classify_timestamp_interval,
    parse_timestamp_attributes,
    parse_tokens,
)
from common import sha256_file, write_json  # noqa: E402
from structural_preflight import run_structural_preflight  # noqa: E402

NITE = "http://nite.sourceforge.net/"
V3_STUDY = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/v3-exact-evidence-phase-a-correction"
)
V3_FORENSIC = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/v3-phase-b-forensic-diagnosis-20260716"
)
FORENSIC_ZIP = V3_FORENSIC / "package/voxproof-phase-b-forensic-diagnosis-20260716.zip"
FORENSIC_SEAL = V3_FORENSIC / "package/package-seal-phase-b-forensic-diagnosis-20260716.json"
V3_STAGE_STATE = V3_STUDY / "phase-b/stage-state.json"
V3_FAILURE = (
    V3_STUDY
    / "phase-b/failures/20260716-073922-999959-reference/failure-record.json"
)

PRESERVED_HASHES = {
    "v3_stage_state": "b19b022df63a3737acfee1019e1ffe3d803bb1b656af6898fbf254f27ea054a2",
    "v3_failure_record": "8078f9e1bcd5eceb396276d734c6aaf0f3400ddf75358e339ac9977f159d641f",
    "forensic_zip": "543185326470b1ffde569be67282e2b2da27a3086a55080ae792c1e1c80fdf42",
    "forensic_seal": "6eb6ae180362b729f48e489ce800a6040ab2b5b8130c23e93c9dd2c6ccd448a2",
}


def element_xml(tag: str, element_id: str, start: str, end: str, text: str = "x") -> str:
    if tag == "w":
        return f'<w nite:id="{element_id}" starttime="{start}" endtime="{end}">{text}</w>'
    return f'<{tag} nite:id="{element_id}" starttime="{start}" endtime="{end}"/>'


def words_root(*elements: str) -> bytes:
    body = "".join(elements)
    return f'<words xmlns:nite="{NITE}">{body}</words>'.encode()


class TimestampPolicyTests(unittest.TestCase):
    def test_es2004b_words1260_regression_recorded_and_excluded(self) -> None:
        xml = words_root(
            element_xml("disfmarker", "ES2004b.A.words1260", "2329.81", "2329.68")
        )
        root = ET.fromstring(xml)
        excluded: list[dict[str, object]] = []
        tokens = parse_tokens(
            root,
            speaker="A",
            member="words/ES2004b.A.words.xml",
            allowed_tags={"w", "disfmarker", "gap", "vocalsound"},
            excluded_collector=excluded,
        )
        self.assertEqual(tokens, [])
        self.assertEqual(len(excluded), 1)
        row = excluded[0]
        self.assertEqual(row["element_id"], "ES2004b.A.words1260")
        self.assertEqual(row["tag"], "disfmarker")
        self.assertEqual(row["raw_starttime"], "2329.81")
        self.assertEqual(row["raw_endtime"], "2329.68")
        self.assertEqual(
            row["exclusion_reason"], "both_endpoints_at_or_after_window_end"
        )
        self.assertNotIn("text", row)

    def test_reversed_lexical_after_window_excluded(self) -> None:
        excluded: list[dict[str, object]] = []
        root = ET.fromstring(
            words_root(element_xml("w", "t1", "950.00", "940.00", "alpha"))
        )
        tokens = parse_tokens(
            root,
            speaker="A",
            member="m",
            allowed_tags={"w"},
            excluded_collector=excluded,
        )
        self.assertEqual(tokens, [])
        self.assertEqual(excluded[0]["exclusion_reason"], "both_endpoints_at_or_after_window_end")

    def test_reversed_lexical_before_window_excluded(self) -> None:
        excluded: list[dict[str, object]] = []
        root = ET.fromstring(
            words_root(element_xml("w", "t1", "120.00", "110.00", "beta"))
        )
        tokens = parse_tokens(
            root,
            speaker="A",
            member="m",
            allowed_tags={"w"},
            excluded_collector=excluded,
        )
        self.assertEqual(tokens, [])
        self.assertEqual(
            excluded[0]["exclusion_reason"], "both_endpoints_strictly_before_window_start"
        )

    def test_reversed_inside_window_fails(self) -> None:
        root = ET.fromstring(
            words_root(element_xml("w", "t1", "500.00", "400.00", "gamma"))
        )
        with self.assertRaisesRegex(ValueError, "possibly window-relevant"):
            parse_tokens(root, speaker="A", member="m", allowed_tags={"w"})

    def test_reversed_straddling_boundary_fails(self) -> None:
        root = ET.fromstring(
            words_root(element_xml("w", "t1", "850.00", "250.00", "delta"))
        )
        with self.assertRaisesRegex(ValueError, "possibly window-relevant"):
            parse_tokens(root, speaker="A", member="m", allowed_tags={"w"})

    def test_negative_timestamp_fails(self) -> None:
        with self.assertRaises(ValueError):
            parse_timestamp_attributes("-1.0", "2.0")

    def test_nan_infinite_timestamp_fails(self) -> None:
        with self.assertRaises(ValueError):
            parse_timestamp_attributes("NaN", "1.0")
        with self.assertRaises(ValueError):
            parse_timestamp_attributes("1.0", "Infinity")

    def test_tolerated_malformed_never_in_reference_ledgers(self) -> None:
        excluded: list[dict[str, object]] = []
        root = ET.fromstring(
            words_root(
                element_xml("w", "ok", "400.00", "401.00", "keep"),
                element_xml("disfmarker", "bad", "2329.81", "2329.68"),
            )
        )
        tokens = parse_tokens(
            root,
            speaker="A",
            member="m",
            allowed_tags={"w", "disfmarker"},
            excluded_collector=excluded,
        )
        self.assertEqual([token.element_id for token in tokens], ["ok"])
        self.assertEqual(len(excluded), 1)

    def test_structural_preflight_report_has_no_lexical_fields(self) -> None:
        from test_correction_rehearsals import FixtureStudy

        with tempfile.TemporaryDirectory() as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=False)
            fixture.setup()
            fixture.run("preflight")
            fixture.run("build-binary")
            fixture.run("structural-preflight")
            report_path = fixture.root / "phase-b/structural-preflight-report.json"
            payload = json.loads(report_path.read_text(encoding="utf-8"))
            self.assertTrue(payload["target_member_bytes_opened"])
            self.assertFalse(payload["lexical_text_fields_inspected"])
            self.assertFalse(payload["lexical_text_emitted"])
            forbidden = {"text", "lexical_text", "matched_text", "cue_text", "lexical_text_exposed"}
            for key in ("auto_tolerated_outside_window_anomalies", "manual_tolerated_outside_window_anomalies"):
                for anomaly in payload.get(key, []):
                    self.assertTrue(forbidden.isdisjoint(anomaly.keys()))

    def test_structural_preflight_mutation_blocks_hypothesis(self) -> None:
        from test_correction_rehearsals import FixtureStudy

        with tempfile.TemporaryDirectory() as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=False)
            fixture.setup()
            for stage in ("preflight", "build-binary", "structural-preflight"):
                fixture.run(stage)
            report = fixture.root / "phase-b/structural-preflight-report.json"
            report.write_text(report.read_text() + " ", encoding="utf-8")
            result = fixture.run("hypothesis", succeeds=False)
            self.assertNotEqual(result.returncode, 0)

    def test_target_override_after_structural_failure_rejected(self) -> None:
        from test_correction_rehearsals import FixtureStudy

        with tempfile.TemporaryDirectory() as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=False)
            fixture.setup()
            for stage in ("preflight", "build-binary"):
                fixture.run(stage)
            bad_member = f"words/{fixture.meeting}.A.words.xml"
            bad_xml = words_root(element_xml("w", "bad", "5.00", "4.00", "fail"))
            fixture.mutate_manual_member(bad_member, bad_xml)
            result = fixture.run("structural-preflight", succeeds=False)
            self.assertNotEqual(result.returncode, 0)
            env = {**fixture.env, "VOXPROOF_V3_MEETING_ID": "TS0002a"}
            env.pop("VOXPROOF_V3_FIXTURE_MODE", None)
            check = subprocess.run(
                [sys.executable, "-c", "import study_config"],
                cwd=fixture.root / "phase-b/scripts",
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertNotEqual(check.returncode, 0)

    def test_v3_failed_tree_and_forensic_hashes_unchanged(self) -> None:
        self.assertTrue(V3_STAGE_STATE.exists())
        self.assertTrue(V3_FAILURE.exists())
        self.assertTrue(FORENSIC_ZIP.exists())
        self.assertTrue(FORENSIC_SEAL.exists())
        self.assertEqual(sha256_file(V3_STAGE_STATE), PRESERVED_HASHES["v3_stage_state"])
        self.assertEqual(sha256_file(V3_FAILURE), PRESERVED_HASHES["v3_failure_record"])
        self.assertEqual(sha256_file(FORENSIC_ZIP), PRESERVED_HASHES["forensic_zip"])
        self.assertEqual(sha256_file(FORENSIC_SEAL), PRESERVED_HASHES["forensic_seal"])


if __name__ == "__main__":
    raise SystemExit(unittest.main())
