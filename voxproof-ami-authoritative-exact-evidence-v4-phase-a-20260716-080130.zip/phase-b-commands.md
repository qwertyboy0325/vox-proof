# Phase B exact commands (V4 frozen executable envelope; do not execute in Phase A)

## Authoritative chronology
1. verify repository, archive, script, and config hashes; build isolated binary
2. structural-preflight on frozen target archives without lexical exposure
3. cross target-content gate once by opening target ASR words/segments
4. materialize hypothesis SRT and cue/token ledger
5. invoke exact binary candidate probe and seal candidate inventory
6. only then open manual/reference words content
7. materialize reference/scoring layers; human reviewer creates ground truth and decision inputs
8. validate decision binding; invoke authoritative review; verify candidate reproduction
9. audit post-review materialization
10. score; independently verify; package once; detached seal afterward

```sh
export VOXPROOF_V3_STUDY_ROOT="/private/tmp/voxproof-ami-authoritative-study-2026-07/v4-exact-evidence-phase-a"
cd "$VOXPROOF_V3_STUDY_ROOT"

python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" preflight
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" build-binary
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" structural-preflight
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" hypothesis
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" probe-candidates
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" reference
# human review inputs ...
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" validate-review-inputs
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" authoritative-review
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" audit-materialization
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" score
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" independent-verify
python3 "$VOXPROOF_V3_STUDY_ROOT/phase-b/scripts/phase_b_runner.py" package
```

## Frozen target
meeting_id=ES2004c
window=[300.000, 900.000)
