#!/usr/bin/env python3
"""Build and verify VoxProof authoritative exact-evidence V4 Phase A package."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import re
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
SCRIPTS = ROOT / "phase-b/scripts"
REPO = Path("/Users/Ezra4/Coding/Repo/vox-proof")
BASELINE_ZIP = Path(
    "/Users/Ezra4/Coding/Repo/vox-proof/"
    "voxproof-ami-authoritative-exact-evidence-v3-phase-a-20260716-050542.zip"
)
BASELINE_SEAL_SHA256 = (
    "d0ea9323e20c6e5695830b83f2de79c8471ea824990f1951d62a3c900e348d56"
)
BASELINE_ZIP_SHA256 = (
    "e2a1eef20f059b66422e0f0f90c292a17fc55db08ecb94f46ef263e186058508"
)
BASELINE_ROOT = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/"
    "v3-exact-evidence-phase-a-correction"
)
sys.path.insert(0, str(SCRIPTS))

from common import sha256_file, write_json  # noqa: E402
from package_builder import build_package  # noqa: E402
from package_verifier import verify_package  # noqa: E402
from study_config import SCRIPT_NAMES  # noqa: E402

REQUIRED_HEAD = "5286c1627e54852fc08f4766240ce7545269e982"


def run(command: list[str], *, cwd: Path = ROOT) -> dict[str, Any]:
    process = subprocess.run(
        command, cwd=cwd, text=True, capture_output=True, check=False
    )
    return {
        "command": command,
        "exit_code": process.returncode,
        "stdout": process.stdout,
        "stderr": process.stderr,
    }


def require(result: dict[str, Any], name: str) -> None:
    if result["exit_code"] != 0:
        raise RuntimeError(
            f"{name} failed\n{result['stdout']}\n{result['stderr']}"
        )


def generate_script_lock() -> dict[str, Any]:
    rows = []
    for name in SCRIPT_NAMES:
        path = SCRIPTS / name
        rows.append(
            {
                "path": f"phase-b/scripts/{name}",
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
        )
    payload = {
        "schema_revision": "voxproof-ami-script-lock-v2",
        "generation_scope": "phase-a-build-only",
        "scripts": rows,
    }
    write_json(ROOT / "phase-b/script-lock.json", payload)
    return payload


def reset_phase_b_state() -> None:
    write_json(
        ROOT / "phase-b/stage-state.json",
        {
            "schema_revision": "voxproof-ami-stage-state-v2",
            "completed": [],
            "access_gate_crossed": False,
            "terminal_failed": False,
            "failure_record": None,
            "stage_details": {},
        },
    )
    attestation = ROOT / "phase-b/binary-attestation.json"
    if attestation.exists():
        attestation.unlink()


def implementation_diff() -> dict[str, Any]:
    excluded = {"package", "cargo-target-isolated", "__pycache__", "test-out", "rehearsal"}

    def inventory(root: Path) -> dict[str, str]:
        return {
            path.relative_to(root).as_posix(): sha256_file(path)
            for path in root.rglob("*")
            if path.is_file()
            and path.suffix not in {".zip", ".pyc"}
            and not any(part in excluded for part in path.relative_to(root).parts)
        }

    before = inventory(BASELINE_ROOT)
    after = inventory(ROOT)
    payload = {
        "schema_revision": "voxproof-ami-v4-phase-a-diff-v1",
        "baseline_root": str(BASELINE_ROOT),
        "v4_root": str(ROOT),
        "added": sorted(set(after) - set(before)),
        "removed": sorted(set(before) - set(after)),
        "changed": sorted(
            path
            for path in set(before) & set(after)
            if before[path] != after[path]
        ),
    }
    write_json(ROOT / "implementation-diff-vs-first-v3.json", payload)
    return payload


def generate_incremental_diff_from_baseline() -> dict[str, Any]:
    if sha256_file(BASELINE_ZIP) != BASELINE_ZIP_SHA256:
        raise RuntimeError("050542 baseline ZIP hash mismatch; refusing to overwrite")
    baseline_seal = Path(
        "/Users/Ezra4/Coding/Repo/vox-proof/package-seal-v3-phase-a-20260716-050542.json"
    )
    if sha256_file(baseline_seal) != BASELINE_SEAL_SHA256:
        raise RuntimeError("050542 baseline seal hash mismatch; refusing to overwrite")
    reports = ROOT / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    patch_path = reports / "incremental-diff-from-050542.patch"
    with tempfile.TemporaryDirectory(prefix="voxproof-044927-baseline-") as tmp:
        baseline_root = Path(tmp) / "baseline"
        current_root = Path(tmp) / "current"
        with zipfile.ZipFile(BASELINE_ZIP) as archive:
            archive.extractall(baseline_root)
        for path in ROOT.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(ROOT)
            if rel.parts[0] in {"package", "outputs", "cargo-target-isolated"}:
                continue
            if path.suffix in {".zip", ".pyc"}:
                continue
            if "test-out" in rel.parts or "rehearsal" in rel.parts:
                continue
            target = current_root / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
        result = subprocess.run(
            ["diff", "-ruN", str(baseline_root), str(current_root)],
            text=True,
            capture_output=True,
            check=False,
        )
        patch_path.write_text(result.stdout, encoding="utf-8")
    payload = {
        "schema_revision": "voxproof-ami-v4-phase-a-incremental-diff-v1",
        "baseline_zip": BASELINE_ZIP.name,
        "baseline_zip_sha256": BASELINE_ZIP_SHA256,
        "baseline_seal_sha256": BASELINE_SEAL_SHA256,
        "patch_path": str(patch_path.relative_to(ROOT)),
        "patch_sha256": sha256_file(patch_path),
        "patch_bytes": patch_path.stat().st_size,
        "diff_exit_code": result.returncode,
    }
    write_json(reports / "incremental-diff-from-044927.json", payload)
    return payload


def main() -> int:
    output_dir = ROOT / "outputs"
    output_dir.mkdir(exist_ok=True)
    script_lock = generate_script_lock()
    reset_phase_b_state()

    cycles: list[dict[str, Any]] = []
    compile_result = run(
        [
            sys.executable,
            "-m",
            "compileall",
            "-q",
            str(SCRIPTS),
            str(ROOT / "tests"),
        ]
    )
    require(compile_result, "Python compile")
    cycles.append({"cycle": 1, "name": "python-compile", **compile_result})

    tests = run(
        [
            sys.executable,
            "-m",
            "unittest",
            "discover",
            "-s",
            str(ROOT / "tests"),
            "-v",
        ]
    )
    require(tests, "Python tests")
    test_match = re.search(r"Ran (\d+) tests?", tests["stderr"])
    if not test_match:
        raise RuntimeError("could not determine Python test count")
    python_test_count = int(test_match.group(1))
    cycles.append({"cycle": 2, "name": "python-tests", **tests})
    (output_dir / "python-test-output.txt").write_text(
        tests["stdout"] + tests["stderr"], encoding="utf-8"
    )

    rehearsal = run(
        [sys.executable, str(ROOT / "tests/run_full_pipeline_rehearsal.py")]
    )
    require(rehearsal, "full fixture rehearsal")
    cycles.append({"cycle": 3, "name": "exact-fixture-runner-rehearsal", **rehearsal})

    cargo_commands = [
        ["cargo", "fmt", "--all", "--", "--check"],
        [
            "cargo",
            "clippy",
            "--all-targets",
            "--all-features",
            "--",
            "-D",
            "warnings",
        ],
        ["cargo", "test", "--locked", "--all-targets"],
    ]
    for command in cargo_commands:
        result = run(command, cwd=REPO)
        require(result, " ".join(command))
        cycles.append(
            {
                "cycle": len(cycles) + 1,
                "name": " ".join(command),
                **result,
            }
        )

    command_check = run(
        [sys.executable, str(SCRIPTS / "phase_b_runner.py"), "self-check-commands"]
    )
    require(command_check, "command self-check")
    parsed_check = json.loads(command_check["stdout"])
    if parsed_check["result"]["status"] != "pass":
        raise RuntimeError(f"command self-check failed: {parsed_check}")
    cycles.append(
        {
            "cycle": len(cycles) + 1,
            "name": "command-reference-self-check",
            **command_check,
        }
    )

    head = subprocess.check_output(
        ["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True
    ).strip()
    tracked_diff = subprocess.run(
        ["git", "-C", str(REPO), "diff", "--quiet"], check=False
    ).returncode
    staged_diff = subprocess.run(
        ["git", "-C", str(REPO), "diff", "--cached", "--quiet"], check=False
    ).returncode
    diff_check = run(["git", "diff", "--check"], cwd=REPO)
    if head != REQUIRED_HEAD or tracked_diff or staged_diff or diff_check["exit_code"]:
        raise RuntimeError("repository HEAD/clean tracked state/diff-check gate failed")
    write_json(
        ROOT / "repository-status-evidence.json",
        {
            "required_head": REQUIRED_HEAD,
            "actual_head": head,
            "head_matches": True,
            "tracked_diff": False,
            "staged_diff": False,
            "diff_check_pass": True,
        },
    )

    access = json.loads((ROOT / "access-boundary-statement.json").read_text(encoding="utf-8"))
    access["protocol_id"] = "voxproof-ami-authoritative-exact-evidence-v4"
    access["frozen_target"] = {
        "meeting_id": "ES2004c",
        "window": {"start_inclusive": "300.000", "end_exclusive": "900.000"},
        "excluded_meeting_ids": ["ES2004a", "ES2004b"],
    }
    access["es2004c_lexical_content_opened"] = False
    access["phase_a_structural_preflight_on_production_target"] = False
    write_json(ROOT / "access-boundary-statement.json", access)
    stale_manifest = ROOT / "manifest.json"
    if stale_manifest.exists():
        stale_manifest.unlink()

    reset_phase_b_state()
    diff = implementation_diff()
    incremental_diff = generate_incremental_diff_from_baseline()
    debug = {
        "schema_revision": "voxproof-ami-internal-debug-v2",
        "internal_cycle_count": len(cycles),
        "cycles": cycles,
        "strong_audit_failures_found": [
            "commands rooted in repository instead of study root",
            "split correction/phase-b roots",
            "stub AMI transform",
            "incomplete runner stages and unsafe rehearsal state",
            "mutable script lock and incomplete preflight",
            "attested environment omitted from product invocations",
            "ephemeral review failure artifacts",
            "reviewed WER copied from raw WER",
            "incomplete human evaluation bindings",
            "independent verifier imported primary scorer",
            "missing executable Phase B package mode",
            "non-full synthetic rehearsal",
            "stale package contents and documentation",
            "initial rewritten independent verifier used singular count keys",
            "production behavior-affecting environment overrides were accepted",
            "stage state retained only the latest detail without immutable joins",
            "reviewed cue-order scoring was invalid for overlapping speakers",
            "independent verification did not recompute every study metric",
            "human labels did not enforce frozen unsafe consistency",
            "ZIP path checks allowed backslashes and NUL",
            "independent verification required identical tie decompositions",
            "phase-a packaging could retain stale runtime artifacts",
            "human labels carried pre-review materialization predictions used by metrics",
            "correction_recall and unsafe_edit_rate were not tied to reviewed output",
        ],
        "fixes_applied": [
            "implemented one environment-derived study root and exact runner-only commands",
            "implemented strict AMI XML/SRT/reference/scoring transformations",
            "implemented terminal stage state, persistent failures, immutable script verification",
            "bound product invocations to attested environment and immediate hashes",
            "implemented joint human review validation and independent raw/reviewed scoring",
            "implemented independent operation reconstruction without primary imports",
            "implemented explicit Phase A/Phase B package build and verification",
            "ran exact synthetic zero/nonzero runner chronologies and negative gates",
            "froze production target, window, repository, and source archives",
            "added stage_details and re-hash joins at every downstream stage",
            "implemented and independently duplicated global reviewed-stream projection",
            "independently recomputed and compared the complete study metric payload",
            "hardened ZIP paths, tie-policy disclosure, and phase-a exclusions",
            "added overlapping-speaker full runner rehearsal and mutation tests",
            "split candidate truth from post-review materialization audit",
            "removed pre-review materialization fields from candidate-labels.json",
            "added audit-materialization runner stage and materialization-audit.json output",
            "rebased correction_recall and unsafe_edit_rate on materialization audit only",
            "strengthened ground-truth.json frozen coverage validation",
            "required full_window attestation completed is exactly true",
            "bound candidate occurrence resolution without occurrence guessing",
            "verified joint multi-candidate cue replacements with utf-8 byte offsets",
            "independent verifier recomputes materialization audit without primary import",
            "audit-materialization fails closed on ambiguity overlap timing and index mutation",
            "v4 frozen window-local timestamp integrity policy shared by structural-preflight and runtime parsers",
            "v4 structural-preflight stage added before hypothesis with report hash binding",
            "v4 target reselected to ES2004c with ES2004a and ES2004b excluded",
        ],
        "semantic_correction_cycle": {
            "cycle_id": "v4-phase-a-structural-preflight-timestamp-integrity-v1",
            "preserved_zip": BASELINE_ZIP.name,
            "preserved_seal": "package-seal-v3-phase-a-20260716-050542.json",
            "preserved_zip_sha256": BASELINE_ZIP_SHA256,
            "preserved_seal_sha256": BASELINE_SEAL_SHA256,
            "incremental_diff_patch": incremental_diff["patch_path"],
            "incremental_diff_sha256": incremental_diff["patch_sha256"],
            "es2004c_lexical_content_opened": False,
            "v3_failed_tree_preserved": True,
        },
        "validation_failures": [],
        "final_status": "pass",
    }
    write_json(ROOT / "internal-debugging-record.json", debug)

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    summary = build_package(
        root=ROOT,
        output_dir=ROOT / "package",
        mode="phase-a",
        name_suffix=stamp,
    )
    verification = verify_package(
        ROOT,
        Path(summary["zip_path"]),
        Path(summary["seal_path"]),
        "phase-a",
    )
    if verification["status"] != "pass":
        raise RuntimeError("; ".join(verification["errors"]))
    write_json(output_dir / "package-verification-output.json", verification)
    write_json(ROOT / "package/package-summary.json", summary)

    shutil.copy2(summary["zip_path"], REPO / summary["zip_filename"])
    shutil.copy2(summary["seal_path"], REPO / summary["seal_filename"])
    final = {
        **summary,
        "verification_status": "pass",
        "python_tests": python_test_count,
        "internal_cycles": len(cycles),
        "script_lock": script_lock,
        "implementation_diff_counts": {
            key: len(diff[key]) for key in ("added", "removed", "changed")
        },
        "incremental_diff": incremental_diff,
        "es2004c_lexical_content_opened": False,
        "repository_head": head,
    }
    write_json(output_dir / "build-summary.json", final)
    print(json.dumps(final, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
