#!/usr/bin/env python3
"""Strict deterministic AMI parsing and scoring-stream utilities."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR
from pathlib import Path
from typing import Any

from study_config import (
    MEETING_ID,
    ORDERING_POLICY_ID,
    SPEAKERS,
    REVIEWED_PROJECTION_POLICY_ID,
    WINDOW_END,
    WINDOW_START,
)

NITE_NS = "{http://nite.sourceforge.net/}"
HREF_RE = re.compile(r"^.*#id\(([^)]+)\)\.\.id\(([^)]+)\)$")
ALLOWED_ASR_TAGS = {"w", "sil"}
ALLOWED_MANUAL_TAGS = {"w", "disfmarker", "gap", "vocalsound"}
MANUAL_EVENT_TAGS = ALLOWED_MANUAL_TAGS - {"w"}
TIMESTAMP_POLICY_ID = "window-local-timestamp-integrity-v1"


def parse_timestamp_attributes(raw_start: str, raw_end: str) -> tuple[Decimal, Decimal, bool, bool]:
    start = strict_decimal(raw_start, "starttime")
    end = strict_decimal(raw_end, "endtime")
    return start, end, True, True


def classify_timestamp_interval(start: Decimal, end: Decimal) -> str:
    if end >= start:
        return "valid"
    if end < WINDOW_START and start < WINDOW_START:
        return "excluded_before_window"
    if start >= WINDOW_END and end >= WINDOW_END:
        return "excluded_after_window"
    return "fail_closed_possibly_window_relevant"


def exclusion_reason_for(classification: str) -> str:
    return {
        "excluded_before_window": "both_endpoints_strictly_before_window_start",
        "excluded_after_window": "both_endpoints_at_or_after_window_end",
    }[classification]


ORDERING_POLICY = {
    "policy_id": ORDERING_POLICY_ID,
    "primary_key": "token_midpoint_seconds",
    "tie_breakers": ["speaker_channel", "element_id"],
    "speaker_channel_order": list(SPEAKERS),
}


@dataclass(frozen=True)
class Token:
    speaker: str
    member: str
    element_id: str
    tag: str
    start: Decimal
    end: Decimal
    text: str


def local_name(tag: str) -> str:
    return tag.split("}")[-1]


def strict_decimal(value: str, field: str) -> Decimal:
    try:
        parsed = Decimal(value)
    except InvalidOperation as error:
        raise ValueError(f"invalid decimal {field}: {value!r}") from error
    if not parsed.is_finite() or parsed < 0:
        raise ValueError(f"invalid non-finite/negative {field}: {value!r}")
    return parsed


def load_xml_member(zf: zipfile.ZipFile, member: str) -> ET.Element:
    try:
        data = zf.read(member)
    except KeyError as error:
        raise ValueError(f"missing archive member: {member}") from error
    try:
        return ET.fromstring(data)
    except ET.ParseError as error:
        raise ValueError(f"malformed XML member {member}: {error}") from error


def parse_tokens(
    root: ET.Element,
    *,
    speaker: str,
    member: str,
    allowed_tags: set[str],
    excluded_collector: list[dict[str, str]] | None = None,
) -> list[Token]:
    records: list[Token] = []
    seen: set[str] = set()
    for element in root:
        tag = local_name(element.tag)
        if tag not in allowed_tags:
            raise ValueError(f"unknown tag {tag!r} in {member}")
        element_id = element.attrib.get(f"{NITE_NS}id")
        if not element_id:
            raise ValueError(f"missing nite:id on {tag} in {member}")
        if element_id in seen:
            raise ValueError(f"duplicate nite:id {element_id} in {member}")
        seen.add(element_id)
        if "starttime" not in element.attrib or "endtime" not in element.attrib:
            raise ValueError(f"missing timestamps for {element_id} in {member}")
        start, end, _, _ = parse_timestamp_attributes(
            element.attrib["starttime"], element.attrib["endtime"]
        )
        classification = classify_timestamp_interval(start, end)
        if classification != "valid":
            if classification in {
                "excluded_before_window",
                "excluded_after_window",
            }:
                if excluded_collector is not None:
                    excluded_collector.append(
                        {
                            "member": member,
                            "element_id": element_id,
                            "tag": tag,
                            "raw_starttime": element.attrib["starttime"],
                            "raw_endtime": element.attrib["endtime"],
                            "exclusion_reason": exclusion_reason_for(classification),
                        }
                    )
                continue
            raise ValueError(
                f"possibly window-relevant reversed interval for {element_id} in {member}"
            )
        text = "".join(element.itertext()).strip() if tag == "w" else ""
        if tag == "w" and not text:
            raise ValueError(f"empty lexical token {element_id} in {member}")
        records.append(Token(speaker, member, element_id, tag, start, end, text))
    return records


def token_midpoint(token: Token) -> Decimal:
    return (token.start + token.end) / Decimal(2)


def in_window(token: Token) -> bool:
    return WINDOW_START <= token_midpoint(token) < WINDOW_END


def floor_ms(seconds: Decimal) -> int:
    return int((seconds * 1000).to_integral_value(rounding=ROUND_FLOOR))


def ceil_ms(seconds: Decimal) -> int:
    return int((seconds * 1000).to_integral_value(rounding=ROUND_CEILING))


def format_timestamp(total_ms: int) -> str:
    hours, rem = divmod(total_ms, 3_600_000)
    minutes, rem = divmod(rem, 60_000)
    seconds, millis = divmod(rem, 1000)
    return f"{hours:02}:{minutes:02}:{seconds:02},{millis:03}"


def compute_revision(segments: list[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    digest.update(b"voxproof-transcript-rev-v1\x00")
    digest.update(len(segments).to_bytes(8, "little"))
    for segment in segments:
        digest.update(int(segment["index"]).to_bytes(4, "little"))
        digest.update(int(segment["start_ms"]).to_bytes(8, "little"))
        digest.update(int(segment["end_ms"]).to_bytes(8, "little"))
        text = segment["text"].encode()
        digest.update(len(text).to_bytes(8, "little"))
        digest.update(text)
    return "rev:sha256-v1:" + digest.hexdigest()


def normalize_token(token: str) -> str | None:
    normalized = unicodedata.normalize("NFC", token).casefold()
    normalized = "".join(
        char for char in normalized if not unicodedata.category(char).startswith("P")
    )
    return normalized or None


def scoring_tokens(text: str) -> list[str]:
    return [normalized for piece in text.split() if (normalized := normalize_token(piece))]


def build_ordered_stream(records: list[dict[str, Any]]) -> list[str]:
    selected = [record for record in records if record["tag"] == "w" and record["in_window"]]
    selected.sort(
        key=lambda record: (
            (Decimal(record["start"]) + Decimal(record["end"])) / 2,
            SPEAKERS.index(record["speaker"]),
            record["element_id"],
        )
    )
    return [token for record in selected for token in scoring_tokens(record["text"])]


SRT_TIMING_RE = re.compile(
    r"^(\d{2}):(\d{2}):(\d{2}),(\d{3}) --> "
    r"(\d{2}):(\d{2}):(\d{2}),(\d{3})$"
)


def _timing_to_ms(match: re.Match[str]) -> tuple[int, int]:
    start_ms = (
        int(match.group(1)) * 3_600_000
        + int(match.group(2)) * 60_000
        + int(match.group(3)) * 1_000
        + int(match.group(4))
    )
    end_ms = (
        int(match.group(5)) * 3_600_000
        + int(match.group(6)) * 60_000
        + int(match.group(7)) * 1_000
        + int(match.group(8))
    )
    return start_ms, end_ms


def utf8_byte_length(text: str) -> int:
    return len(text.encode("utf-8"))


def is_utf8_byte_boundary(text: str, byte_offset: int) -> bool:
    total = utf8_byte_length(text)
    if byte_offset < 0 or byte_offset > total:
        return False
    if byte_offset in {0, total}:
        return True
    position = 0
    for char in text:
        char_end = position + len(char.encode("utf-8"))
        if position == byte_offset:
            return True
        position = char_end
    return False


def slice_utf8_bytes(text: str, start_byte: int, end_byte: int) -> str:
    if not is_utf8_byte_boundary(text, start_byte) or not is_utf8_byte_boundary(
        text, end_byte
    ):
        raise ValueError("utf-8 slice requires boundary-aligned byte offsets")
    encoded = text.encode("utf-8")
    return encoded[start_byte:end_byte].decode("utf-8")


def replace_utf8_span(
    text: str, start_byte: int, end_byte: int, replacement: str
) -> str:
    if not is_utf8_byte_boundary(text, start_byte) or not is_utf8_byte_boundary(
        text, end_byte
    ):
        raise ValueError("utf-8 replacement requires boundary-aligned byte offsets")
    encoded = text.encode("utf-8")
    merged = encoded[:start_byte] + replacement.encode("utf-8") + encoded[end_byte:]
    return merged.decode("utf-8")


def find_substring_byte_occurrences(text: str, needle: str) -> list[tuple[int, int]]:
    if not needle:
        return []
    haystack = text.encode("utf-8")
    needle_bytes = needle.encode("utf-8")
    positions: list[tuple[int, int]] = []
    start = 0
    while True:
        index = haystack.find(needle_bytes, start)
        if index < 0:
            break
        end_byte = index + len(needle_bytes)
        if not (
            is_utf8_byte_boundary(text, index)
            and is_utf8_byte_boundary(text, end_byte)
        ):
            raise ValueError("matched-text occurrence is not utf-8 boundary aligned")
        positions.append((index, end_byte))
        start = index + 1
    return positions


def parse_srt_strict(text: str) -> list[dict[str, Any]]:
    blocks = re.split(r"\r?\n\r?\n", text.strip())
    segments: list[dict[str, Any]] = []
    for block in blocks:
        lines = block.splitlines()
        if len(lines) < 3 or not lines[0].isdigit():
            raise ValueError("malformed SRT block")
        timing_match = SRT_TIMING_RE.match(lines[1])
        if not timing_match:
            raise ValueError("malformed SRT timing line")
        start_ms, end_ms = _timing_to_ms(timing_match)
        segments.append(
            {
                "index": int(lines[0]),
                "timing_line": lines[1],
                "start_ms": start_ms,
                "end_ms": end_ms,
                "text": "\n".join(lines[2:]),
            }
        )
    return segments


def parse_srt_text(text: str) -> list[dict[str, Any]]:
    return [
        {"index": segment["index"], "text": segment["text"]}
        for segment in parse_srt_strict(text)
    ]


def verify_srt_structure(
    input_segments: list[dict[str, Any]],
    reviewed_segments: list[dict[str, Any]],
) -> dict[str, Any]:
    if len(input_segments) != len(reviewed_segments):
        return {
            "pass": False,
            "detail": "input/reviewed cue count mismatch",
            "cue_count": len(input_segments),
            "reviewed_cue_count": len(reviewed_segments),
        }
    for position, (source, reviewed) in enumerate(
        zip(input_segments, reviewed_segments), start=1
    ):
        if source["index"] != position:
            return {
                "pass": False,
                "detail": f"input cue index mutation at position {position}",
                "cue_index": source["index"],
            }
        if reviewed["index"] != position:
            return {
                "pass": False,
                "detail": f"reviewed cue index mutation at position {position}",
                "cue_index": reviewed["index"],
            }
        if source["timing_line"] != reviewed["timing_line"]:
            return {
                "pass": False,
                "detail": f"timing mutation at cue {position}",
                "input_timing_line": source["timing_line"],
                "reviewed_timing_line": reviewed["timing_line"],
            }
        if source["start_ms"] != reviewed["start_ms"] or source["end_ms"] != reviewed["end_ms"]:
            return {
                "pass": False,
                "detail": f"timing mutation at cue {position}",
                "input_start_ms": source["start_ms"],
                "reviewed_start_ms": reviewed["start_ms"],
            }
    return {
        "pass": True,
        "detail": "cue count, cue indices, and timing unchanged",
        "cue_count": len(input_segments),
    }


def srt_scoring_stream(path: Path) -> list[str]:
    return [
        token
        for segment in parse_srt_text(path.read_text(encoding="utf-8"))
        for token in scoring_tokens(segment["text"])
    ]


def _local_edit_projection(
    original: list[tuple[str, tuple[Any, ...]]], reviewed: list[str]
) -> list[tuple[tuple[Any, ...], str]]:
    """Map cue-local reviewed tokens onto original global sort keys."""
    source = [token for token, _ in original]
    n, m = len(source), len(reviewed)
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        dp[i][0] = i
    for j in range(1, m + 1):
        dp[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            dp[i][j] = (
                dp[i - 1][j - 1]
                if source[i - 1] == reviewed[j - 1]
                else 1 + min(dp[i - 1][j - 1], dp[i - 1][j], dp[i][j - 1])
            )
    operations: list[tuple[str, int, int]] = []
    i, j = n, m
    while i or j:
        current = dp[i][j]
        if (
            i
            and j
            and source[i - 1] == reviewed[j - 1]
            and current == dp[i - 1][j - 1]
        ):
            operations.append(("mapped", i - 1, j - 1))
            i -= 1
            j -= 1
        elif i and j and current == dp[i - 1][j - 1] + 1:
            operations.append(("mapped", i - 1, j - 1))
            i -= 1
            j -= 1
        elif i and current == dp[i - 1][j] + 1:
            operations.append(("deletion", i - 1, j))
            i -= 1
        elif j and current == dp[i][j - 1] + 1:
            operations.append(("insertion", i, j - 1))
            j -= 1
        else:
            raise ValueError("cue-local reviewed projection backtrace failed")
    operations.reverse()
    output: list[tuple[tuple[Any, ...], str]] = []
    insertion_counts: dict[tuple[int, str], int] = {}
    for operation, source_index, reviewed_index in operations:
        if operation == "deletion":
            continue
        if operation == "mapped":
            base = original[source_index][1]
            key = (*base, 0, 0)
        elif source_index == 0:
            base = original[0][1]
            ordinal_key = (source_index, "before")
            insertion_counts[ordinal_key] = insertion_counts.get(ordinal_key, 0) + 1
            key = (*base, -1, insertion_counts[ordinal_key])
        else:
            base = original[source_index - 1][1]
            ordinal_key = (source_index, "after")
            insertion_counts[ordinal_key] = insertion_counts.get(ordinal_key, 0) + 1
            key = (*base, 1, insertion_counts[ordinal_key])
        output.append((key, reviewed[reviewed_index]))
    return output


def project_reviewed_stream(
    *,
    input_srt: Path,
    reviewed_srt: Path,
    cues_path: Path,
    hypothesis_tokens_path: Path,
    frozen_raw_stream: list[str],
) -> tuple[list[str], dict[str, Any]]:
    """Project cue-local edits back into frozen global meeting-time order."""
    input_segments = parse_srt_text(input_srt.read_text(encoding="utf-8"))
    reviewed_segments = parse_srt_text(reviewed_srt.read_text(encoding="utf-8"))
    cues = json.loads(cues_path.read_text(encoding="utf-8"))["cues"]
    records = [
        json.loads(line)
        for line in hypothesis_tokens_path.read_text(encoding="utf-8").splitlines()
        if line
    ]
    by_id = {record["element_id"]: record for record in records}
    if len(input_segments) != len(cues) or len(reviewed_segments) != len(cues):
        raise ValueError("SRT/cue ledger segment count mismatch")
    projected: list[tuple[tuple[Any, ...], str]] = []
    identity = True
    for position, (input_segment, reviewed_segment, cue) in enumerate(
        zip(input_segments, reviewed_segments, cues), 1
    ):
        if input_segment["index"] != position or reviewed_segment["index"] != position:
            raise ValueError(f"non-canonical SRT cue index at position {position}")
        if input_segment["text"] != cue["text"]:
            raise ValueError(f"input SRT/cue text mismatch at position {position}")
        original: list[tuple[str, tuple[Any, ...]]] = []
        reconstructed: list[str] = []
        for token_id in cue["token_ids"]:
            record = by_id.get(token_id)
            if record is None or record.get("segment_id") != cue["segment_id"]:
                raise ValueError(f"cue token id binding mismatch: {token_id}")
            base = (
                (Decimal(record["start"]) + Decimal(record["end"])) / 2,
                SPEAKERS.index(record["speaker"]),
                record["element_id"],
            )
            normalized = scoring_tokens(record["text"])
            reconstructed.extend(normalized)
            original.extend((token, (*base, subindex)) for subindex, token in enumerate(normalized))
        if reconstructed != scoring_tokens(input_segment["text"]):
            raise ValueError(f"input SRT token-id reconstruction mismatch at cue {position}")
        reviewed = scoring_tokens(reviewed_segment["text"])
        identity = identity and reviewed == reconstructed
        projected.extend(_local_edit_projection(original, reviewed))
    projected.sort(key=lambda item: item[0])
    stream = [token for _, token in projected]
    if identity and stream != frozen_raw_stream:
        raise ValueError("identity reviewed projection differs from frozen raw stream")
    return stream, {
        "policy_id": REVIEWED_PROJECTION_POLICY_ID,
        "identity_review": identity,
        "cue_count": len(cues),
        "projected_token_count": len(stream),
    }


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

