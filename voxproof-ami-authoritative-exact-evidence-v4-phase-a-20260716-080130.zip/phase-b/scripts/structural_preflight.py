#!/usr/bin/env python3
"""Structural preflight: archive/member verification without lexical exposure."""

from __future__ import annotations

import json
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from ami_common import (  # noqa: E402
    ALLOWED_ASR_TAGS,
    ALLOWED_MANUAL_TAGS,
    HREF_RE,
    NITE_NS,
    TIMESTAMP_POLICY_ID,
    classify_timestamp_interval,
    local_name,
    parse_timestamp_attributes,
)
from ami_transform import required_auto_members, required_manual_members  # noqa: E402
from common import sha256_file, utc_now, write_json  # noqa: E402
from study_config import (  # noqa: E402
    AUTO_ZIP,
    BUILD_ROOT,
    MANUAL_ZIP,
    MEETING_ID,
    PHASE_B_DIR,
    WINDOW_END,
    WINDOW_START,
)

FORBIDDEN_REPORT_KEYS = {"text", "lexical_text", "matched_text", "cue_text"}


def _scan_words_member(
    archive: zipfile.ZipFile,
    member: str,
    *,
    allowed_tags: set[str],
    tolerated: list[dict[str, Any]],
    errors: list[str],
) -> int:
    root = ET.fromstring(archive.read(member))
    seen: set[str] = set()
    scanned = 0
    for element in root:
        tag = local_name(element.tag)
        if tag not in allowed_tags:
            errors.append(f"unknown tag {tag!r} in {member}")
            continue
        element_id = element.attrib.get(f"{NITE_NS}id")
        if not element_id:
            errors.append(f"missing nite:id on {tag} in {member}")
            continue
        if element_id in seen:
            errors.append(f"duplicate nite:id {element_id} in {member}")
            continue
        seen.add(element_id)
        if "starttime" not in element.attrib or "endtime" not in element.attrib:
            errors.append(f"missing timestamps for {element_id} in {member}")
            continue
        try:
            start, end, start_ok, end_ok = parse_timestamp_attributes(
                element.attrib["starttime"], element.attrib["endtime"]
            )
        except ValueError as error:
            errors.append(f"{element_id} in {member}: {error}")
            continue
        if not start_ok or not end_ok:
            errors.append(f"non-finite/negative timestamp for {element_id} in {member}")
            continue
        classification = classify_timestamp_interval(start, end)
        scanned += 1
        if classification == "valid":
            continue
        if classification in {
            "excluded_before_window",
            "excluded_after_window",
        }:
            tolerated.append(
                {
                    "member": member,
                    "element_id": element_id,
                    "tag": tag,
                    "raw_starttime": element.attrib["starttime"],
                    "raw_endtime": element.attrib["endtime"],
                    "exclusion_reason": (
                        "both_endpoints_strictly_before_window_start"
                        if classification == "excluded_before_window"
                        else "both_endpoints_at_or_after_window_end"
                    ),
                }
            )
            continue
        errors.append(
            f"fail-closed possibly window-relevant reversed interval for {element_id} in {member}"
        )
    return scanned


def _scan_segments_member(archive: zipfile.ZipFile, member: str, *, errors: list[str]) -> int:
    root = ET.fromstring(archive.read(member))
    scanned = 0
    for segment in root:
        if local_name(segment.tag) != "segment":
            errors.append(f"unexpected root child {local_name(segment.tag)!r} in {member}")
            continue
        for child in segment:
            if local_name(child.tag) != "child":
                errors.append(
                    f"unexpected segment child {local_name(child.tag)!r} in {member}"
                )
                continue
            href = child.attrib.get("href", "")
            if not HREF_RE.match(href):
                errors.append(f"malformed child href in {member}: {href!r}")
                continue
            scanned += 1
    return scanned


def run_structural_preflight() -> dict[str, Any]:
    tolerated: list[dict[str, Any]] = []
    errors: list[str] = []
    member_results: list[dict[str, Any]] = []
    timestamped_elements = 0
    segment_hrefs = 0
    with zipfile.ZipFile(AUTO_ZIP) as auto_archive, zipfile.ZipFile(MANUAL_ZIP) as manual_archive:
        auto_names = set(auto_archive.namelist())
        manual_names = set(manual_archive.namelist())
        for member in required_auto_members():
            if member not in auto_names:
                errors.append(f"missing auto member: {member}")
                continue
            if member.endswith(".words.xml"):
                count = _scan_words_member(
                    auto_archive,
                    member,
                    allowed_tags=ALLOWED_ASR_TAGS,
                    tolerated=tolerated,
                    errors=errors,
                )
                timestamped_elements += count
                member_results.append({"member": member, "archive": AUTO_ZIP.name, "timestamped_elements": count})
            else:
                count = _scan_segments_member(auto_archive, member, errors=errors)
                segment_hrefs += count
                member_results.append({"member": member, "archive": AUTO_ZIP.name, "segment_child_hrefs": count})
        for member in required_manual_members():
            if member not in manual_names:
                errors.append(f"missing manual member: {member}")
                continue
            count = _scan_words_member(
                manual_archive,
                member,
                allowed_tags=ALLOWED_MANUAL_TAGS,
                tolerated=tolerated,
                errors=errors,
            )
            timestamped_elements += count
            member_results.append({"member": member, "archive": MANUAL_ZIP.name, "timestamped_elements": count})
    report = {
        "schema_revision": "voxproof-ami-structural-preflight-report-v1",
        "timestamp_policy_id": TIMESTAMP_POLICY_ID,
        "meeting_id": MEETING_ID,
        "window": {
            "start_inclusive": str(WINDOW_START),
            "end_exclusive": str(WINDOW_END),
        },
        "lexical_text_exposed": False,
        "required_members_verified": not any("missing" in err for err in errors),
        "timestamped_element_count": timestamped_elements,
        "segment_child_href_count": segment_hrefs,
        "member_results": member_results,
        "tolerated_outside_window_anomalies": tolerated,
        "tolerated_anomaly_count": len(tolerated),
        "structural_error_count": len(errors),
        "structural_errors": errors,
        "fail_closed": bool(errors),
        "completed_at_utc": utc_now(),
    }
    for key in FORBIDDEN_REPORT_KEYS:
        if key in report:
            raise RuntimeError(f"forbidden lexical field in structural report: {key}")
    out = BUILD_ROOT.parent / "structural-preflight-report.json"
    write_json(out, report)
    if errors:
        raise RuntimeError("; ".join(errors))
    return {
        "structural_preflight_report_sha256": sha256_file(out),
        "report_path": str(out),
        "tolerated_anomaly_count": len(tolerated),
        "timestamped_element_count": timestamped_elements,
        "lexical_text_exposed": False,
    }


def main() -> int:
    try:
        result = run_structural_preflight()
    except Exception as error:
        print(json.dumps({"status": "fail", "error": str(error)}, indent=2))
        return 1
    print(json.dumps({"status": "pass", "result": result}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
