#!/usr/bin/env python3
import hashlib, json, sys, zipfile
from pathlib import Path

LOCKED = {
    'human-input/human-review-record.json': '1464db9f8aa58d26e2c3ee123feb473483aaa24673089f9eb71feab560c8f142',
    'human-input/human-final.srt': '98345810e0859e7b10531cad86f3e442c2faedf09e8822c61b9fecb7ff0a66f6',
    'human-input/human-review-completion.json': 'bcc6cf543db9de3b5349e028add298aa6cafdc9b56d1194fb75a722cc5e4e503',
    'human-input/.finalized.lock': '31eaaee0db123bbea2b2698e2ac60bb8daeb110361caf3eb1a967e1e6d6a49ad',
    'post-review/reviewer-disclosure-clarification.json': '333397bbfea795d03bf70c1d61b11f6a21b56769d49d33c6f21a2fc7092fd352',
    'final-human-review-handoff.md': '0f81638ff10c29fd47af9641a0b0002f7ba3486a8c2cca0ff7cf033b75911d23',
}
MISSING_PATCH = 'calibration-comparison-v0.patch'
checks = []


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def check(name, ok, detail=''):
    checks.append({'name': name, 'pass': bool(ok), 'detail': detail})


def main():
    if len(sys.argv) != 4:
        print('usage: verify_package_closure.py <zip> <seal.json> <out.json>', file=sys.stderr)
        return 2
    zip_path = Path(sys.argv[1])
    seal_path = Path(sys.argv[2])
    out_path = Path(sys.argv[3])
    seal = json.loads(seal_path.read_text())
    zbytes = zip_path.read_bytes()
    check('zip_sha', sha256_bytes(zbytes) == seal['package_sha256'])
    check('zip_bytes', len(zbytes) == seal['package_bytes'])
    with zipfile.ZipFile(zip_path) as zf:
        names = zf.namelist()
        check('entry_count_matches', len(names) == seal['entry_count'])
        manifest = json.loads(zf.comment.decode('utf-8'))
        manifest_sha = sha256_bytes(
            json.dumps(manifest, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
        )
        check('manifest_sha', manifest_sha == seal['entry_manifest_sha256'])
        manifest_paths = {e['path'] for e in manifest['entries']}
        check('manifest_paths_match', manifest_paths == set(names))
        check('no_undeclared_entries', manifest_paths == set(names))
        for entry in manifest['entries']:
            data = zf.read(entry['path'])
            check(f"size_{entry['path']}", len(data) == entry['bytes'])
            check(f"hash_{entry['path']}", sha256_bytes(data) == entry['sha256'])
        check('missing_patch_absent', MISSING_PATCH not in names)
        for rel, expected in LOCKED.items():
            check(f'locked_{rel}', sha256_bytes(zf.read(rel)) == expected)
        incident = json.loads(zf.read('post-review/artifact-loss-incident.json'))
        check('incident_filename', incident['missing_artifact']['filename'] == MISSING_PATCH)
        check('incident_size', incident['expected_historical_properties']['bytes'] == 42536)
        check(
            'incident_sha',
            incident['expected_historical_properties']['sha256']
            == '67552483588a464219f992b6492e94c7a006a77a6b2981c8089f220a6e9cda4e',
        )
        inv = incident['inventory_interpretation']
        check('inventory_paths_51', inv['expected_verification_paths'] == 51)
        check('inventory_physical_50', inv['physical_files_present_pre_package'] == 50)
        reviewed = zf.read('authoritative-review/reviewed-output.srt').decode('utf-8')
        check('reviewed_contains_asus', 'ASUS' in reviewed)
        check('decision_log_exists', 'authoritative-review/decision-log.txt' in names)
        check('session_summary_exists', 'authoritative-review/session-summary.txt' in names)
        report_hashes = json.loads(zf.read('reports/report-hashes.json'))
        for name, expected in report_hashes.items():
            check(f'report_hash_{name}', sha256_bytes(zf.read(f'reports/{name}')) == expected)
        gates = json.loads(zf.read('post-review/md007-gate-evaluation.json'))
        check('md007_all_pass', all(gate['result'] == 'PASS' for gate in gates['gates']))
        claim_boundary = json.loads(zf.read('metadata/claim-boundary.json'))
        check(
            'inventory_language_no_51_physical',
            claim_boundary['inventory_language']['does_not_claim_51_physical_files'] is True,
        )
        check('claim_boundary_blocks_v0_1', 'v0.1 release or establishment' in claim_boundary['does_not_establish'])
    result = {
        'schema': 'voxproof-owner-human-review-closure-verification-v1',
        'all_pass': all(item['pass'] for item in checks),
        'check_count': len(checks),
        'package_sha256': seal['package_sha256'],
        'seal_sha256': sha256_bytes(seal_path.read_bytes()),
        'checks': checks,
    }
    out_path.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    return 0 if result['all_pass'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
