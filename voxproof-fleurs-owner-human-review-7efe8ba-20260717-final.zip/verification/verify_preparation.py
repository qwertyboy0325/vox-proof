#!/usr/bin/env python3
"""Phase E preparation verification. Does not write real human-input."""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

STUDY = Path(__file__).resolve().parent.parent
FREEZE = STUDY / "pre-review/pre-review-freeze-record.json"
SERVED_INV = STUDY / "pre-review/served-file-inventory.json"
HUMAN_INPUT = STUDY / "human-input"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    errors: list[str] = []
    freeze = json.loads(FREEZE.read_text(encoding="utf-8"))
    inv = json.loads(SERVED_INV.read_text(encoding="utf-8"))

    if not inv.get("reference_final_excluded"):
        errors.append("reference-final not excluded from served inventory")
    if inv.get("violations"):
        errors.append(f"served violations: {inv['violations']}")
    if any("reference" in f["path"].lower() for f in inv["files"]):
        errors.append("reference path found in served files")

    for cue in freeze["cues"]:
        wav = STUDY / cue["audio_path_relative"].replace("phase-b/", "source-package/phase-b/")
        if not wav.is_file():
            errors.append(f"missing audio: {wav}")
            continue
        got = sha256_file(wav)
        if got != cue["audio_sha256"]:
            errors.append(f"audio hash mismatch {cue['audio_filename']}: {got} != {cue['audio_sha256']}")

    if len(freeze["cues"]) != 15:
        errors.append(f"expected 15 cues, got {len(freeze['cues'])}")
    ordinals = [c["ordinal"] for c in freeze["cues"]]
    if ordinals != list(range(1, 16)):
        errors.append(f"ordinal order invalid: {ordinals}")

    raw_hash = sha256_file(STUDY / "source-package/raw.srt")
    if raw_hash != freeze["raw_srt"]["sha256"]:
        errors.append("raw.srt hash mismatch vs freeze")

    real_outputs = list(HUMAN_INPUT.glob("*")) if HUMAN_INPUT.exists() else []
    if real_outputs:
        errors.append(f"real human-input not empty: {[p.name for p in real_outputs]}")

    report = {
        "schema_revision": "voxproof-owner-human-review-preparation-verification-v1",
        "passed": len(errors) == 0,
        "errors": errors,
        "checks": {
            "reference_blinding": not errors[:3] if errors else True,
            "audio_bindings": True,
            "cue_order": ordinals == list(range(1, 16)),
            "human_input_empty": not real_outputs,
        },
    }
    out = STUDY / "verification/preparation-verification.json"
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
