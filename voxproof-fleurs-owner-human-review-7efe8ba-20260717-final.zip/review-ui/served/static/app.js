(() => {
  "use strict";

  const state = {
    startedAtUtc: new Date().toISOString(),
    cues: [],
    byOrdinal: {},
  };

  const progressEl = document.getElementById("progress");
  const listEl = document.getElementById("cue-list");
  const finalizeBtn = document.getElementById("finalize");
  const statusEl = document.getElementById("status");
  const confirmListening = document.getElementById("confirm-listening");
  const ackAsus = document.getElementById("ack-asus");

  function utcNow() {
    return new Date().toISOString();
  }

  function updateProgress() {
    const listened = state.cues.filter((c) => c.playback_completed).length;
    const adjudicated = state.cues.filter((c) => c.adjudication_choice).length;
    const unresolved = 15 - adjudicated;
    progressEl.textContent =
      `Listened: ${listened}/15 | Adjudicated: ${adjudicated}/15 | Unresolved: ${unresolved}`;
    const ready =
      listened === 15 &&
      adjudicated === 15 &&
      unresolved === 0 &&
      state.cues.every((c) => c.final_human_text.trim().length > 0) &&
      confirmListening.checked &&
      ackAsus.checked;
    finalizeBtn.disabled = !ready;
  }

  function markAdjudicated(ordinal) {
    const cue = state.byOrdinal[ordinal];
    if (!cue.adjudication_choice) return;
    if (!cue.final_human_text.trim()) return;
    cue.adjudicated_at_utc = utcNow();
    updateProgress();
  }

  function renderCue(cue) {
    const card = document.createElement("article");
    card.className = "cue-card";
    card.dataset.ordinal = String(cue.ordinal);

    const listenedClass = cue.playback_completed ? "listened-yes" : "listened-no";
    const listenedLabel = cue.playback_completed ? "Listened" : "Not listened yet";

    card.innerHTML = `
      <h2>Cue ${cue.ordinal} / 15 — SRT index ${cue.cue_index}</h2>
      <div class="meta">${cue.start_ms_timing} --> ${cue.end_ms_timing} | <span class="${listenedClass}" id="listened-${cue.ordinal}">${listenedLabel}</span></div>
      <div><strong>Raw ASR text</strong></div>
      <div class="raw-text" id="raw-${cue.ordinal}"></div>
      <audio controls preload="metadata" id="audio-${cue.ordinal}" src="/audio/${cue.audio_filename}"></audio>
      <div style="margin-top:0.75rem"><label>Human-final text (blank until you enter it)</label>
        <input type="text" id="final-${cue.ordinal}" autocomplete="off" spellcheck="false"></div>
      <button type="button" class="secondary" id="copy-raw-${cue.ordinal}">Copy raw text into field</button>
      <div class="choice-row">
        <label><input type="radio" name="choice-${cue.ordinal}" value="raw_confirmed"> Raw text confirmed</label>
        <label><input type="radio" name="choice-${cue.ordinal}" value="correction_entered"> Correction entered</label>
      </div>
      <label>Optional reviewer note<textarea id="note-${cue.ordinal}" rows="2"></textarea></label>
    `;

    listEl.appendChild(card);
    document.getElementById(`raw-${cue.ordinal}`).textContent = cue.raw_text;

    const audio = document.getElementById(`audio-${cue.ordinal}`);
    audio.addEventListener("ended", () => {
      cue.playback_completed = true;
      cue.playback_completed_at_utc = utcNow();
      document.getElementById(`listened-${cue.ordinal}`).textContent = "Listened";
      document.getElementById(`listened-${cue.ordinal}`).className = "listened-yes";
      updateProgress();
    });

    document.getElementById(`copy-raw-${cue.ordinal}`).addEventListener("click", () => {
      document.getElementById(`final-${cue.ordinal}`).value = cue.raw_text;
      cue.final_human_text = cue.raw_text;
      updateProgress();
    });

    document.getElementById(`final-${cue.ordinal}`).addEventListener("input", (e) => {
      cue.final_human_text = e.target.value;
      markAdjudicated(cue.ordinal);
    });

    card.querySelectorAll(`input[name="choice-${cue.ordinal}"]`).forEach((el) => {
      el.addEventListener("change", (e) => {
        cue.adjudication_choice = e.target.value;
        markAdjudicated(cue.ordinal);
      });
    });

    document.getElementById(`note-${cue.ordinal}`).addEventListener("input", (e) => {
      cue.reviewer_note = e.target.value;
    });
  }

  async function init() {
    const resp = await fetch("/api/cues");
    const data = await resp.json();
    state.cues = data.cues.map((c) => ({
      ...c,
      final_human_text: "",
      adjudication_choice: "",
      playback_completed: false,
      playback_completed_at_utc: null,
      adjudicated_at_utc: null,
      reviewer_note: "",
    }));
    state.cues.forEach((c) => {
      state.byOrdinal[c.ordinal] = c;
      renderCue(c);
    });
    updateProgress();
  }

  confirmListening.addEventListener("change", updateProgress);
  ackAsus.addEventListener("change", updateProgress);

  finalizeBtn.addEventListener("click", async () => {
    statusEl.textContent = "Finalizing...";
    finalizeBtn.disabled = true;
    try {
      const resp = await fetch("/api/finalize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          started_at_utc: state.startedAtUtc,
          confirm_listening_decisions: confirmListening.checked,
          acknowledge_asus_prior_exposure: ackAsus.checked,
          cues: state.cues,
        }),
      });
      const result = await resp.json();
      if (!resp.ok) {
        statusEl.textContent = `Finalize blocked: ${result.error || resp.status}`;
        updateProgress();
        return;
      }
      statusEl.textContent = `Finalized revision ${result.revision}. Files written under human-input/.`;
    } catch (err) {
      statusEl.textContent = `Error: ${err}`;
      updateProgress();
    }
  });

  init();
})();
