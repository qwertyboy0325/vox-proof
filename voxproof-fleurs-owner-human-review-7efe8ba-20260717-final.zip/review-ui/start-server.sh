#!/bin/bash
set -euo pipefail
STUDY="$(cd "$(dirname "$0")/.." && pwd)"
PIDFILE="$STUDY/review-ui/server.pid"
LOG="$STUDY/review-ui/server.log"
PORT="${VOXPROOF_REVIEW_PORT:-17871}"
export VOXPROOF_REVIEW_PORT="$PORT"
if [[ -f "$PIDFILE" ]]; then
  oldpid=$(cat "$PIDFILE")
  if kill -0 "$oldpid" 2>/dev/null; then
    echo "Server already running PID $oldpid on http://127.0.0.1:$PORT/"
    exit 0
  fi
fi
nohup python3 "$STUDY/review-ui/server.py" >"$LOG" 2>&1 &
echo $! >"$PIDFILE"
echo "Started PID $(cat "$PIDFILE") on http://127.0.0.1:$PORT/"
