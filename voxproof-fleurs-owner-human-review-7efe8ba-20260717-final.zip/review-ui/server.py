#!/usr/bin/env python3
"""Study-local MD-007 owner human-review server. Stdlib only; 127.0.0.1 only."""

from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import tempfile
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

STUDY_ROOT = Path(__file__).resolve().parent.parent
SERVED = Path(__file__).resolve().parent / "served"
HUMAN_INPUT = STUDY_ROOT / "human-input"
FREEZE_PATH = STUDY_ROOT / "pre-review" / "pre-review-freeze-record.json"
SOURCE_PACKAGE = STUDY_ROOT / "source-package"
PORT = int(os.environ.get("VOXPROOF_REVIEW_PORT", "17871"))
HOST = "127.0.0.1"

SAFE_WAV_NAME = re.compile(r"^[0-9]+\.wav$")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def atomic_write(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def load_freeze() -> dict:
    return json.loads(FREEZE_PATH.read_text(encoding="utf-8"))


def build_audio_map() -> dict[str, tuple[Path, str, int]]:
    freeze = load_freeze()
    package_root = SOURCE_PACKAGE.resolve()
    mapping: dict[str, tuple[Path, str, int]] = {}
    for cue in freeze["cues"]:
        filename = cue["audio_filename"]
        if not SAFE_WAV_NAME.fullmatch(filename):
            raise SystemExit(f"unsafe audio filename in freeze record: {filename!r}")
        rel = cue["audio_path_relative"].replace("phase-b/", "source-package/phase-b/")
        path = (STUDY_ROOT / rel).resolve()
        if not str(path).startswith(str(package_root)):
            raise SystemExit(f"audio path escapes source-package: {path}")
        if filename in mapping:
            raise SystemExit(f"duplicate audio filename in freeze record: {filename}")
        mapping[filename] = (path, cue["audio_sha256"], cue["audio_bytes"])
    return mapping


AUDIO_MAP = build_audio_map()


def finalized_paths(revision: int | None = None) -> dict[str, Path]:
    suffix = "" if revision is None else f".rev{revision}"
    return {
        "record": HUMAN_INPUT / f"human-review-record{suffix}.json",
        "srt": HUMAN_INPUT / f"human-final{suffix}.srt",
        "completion": HUMAN_INPUT / f"human-review-completion{suffix}.json",
        "lock": HUMAN_INPUT / ".finalized.lock",
    }


def latest_revision() -> int:
    rev = 0
    for p in HUMAN_INPUT.glob("human-review-record.rev*.json"):
        m = re.search(r"\.rev(\d+)\.json$", p.name)
        if m:
            rev = max(rev, int(m.group(1)))
    if (HUMAN_INPUT / "human-review-record.json").exists():
        rev = max(rev, 1)
    return rev


def is_finalized() -> bool:
    lock = HUMAN_INPUT / ".finalized.lock"
    return lock.exists() or (HUMAN_INPUT / "human-review-record.json").exists()


def build_srt(cues: list[dict]) -> str:
    blocks = []
    for cue in cues:
        blocks.append(
            f"{cue['cue_index']}\n"
            f"{cue['start_ms_timing']} --> {cue['end_ms_timing']}\n"
            f"{cue['final_human_text']}\n"
        )
    return "\n".join(blocks) + "\n"


def parse_byte_range(range_header: str, file_size: int) -> tuple[int, int] | None:
    if not range_header.startswith("bytes="):
        return None
    spec = range_header[6:].strip()
    if not spec or "," in spec:
        return None
    if spec.startswith("-"):
        suffix = int(spec[1:])
        if suffix <= 0:
            return None
        start = max(0, file_size - suffix)
        end = file_size - 1
    else:
        start_str, _, end_str = spec.partition("-")
        start = int(start_str)
        end = file_size - 1 if end_str == "" else int(end_str)
    if start < 0 or start >= file_size or end < start:
        return None
    end = min(end, file_size - 1)
    return start, end


class ReviewHandler(BaseHTTPRequestHandler):
    server_version = "VoxProofOwnerHumanReview/1.1"

    def log_message(self, fmt: str, *args) -> None:
        sys.stderr.write("%s - [%s] %s\n" % (self.address_string(), self.log_date_time_string(), fmt % args))

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if not getattr(self, "_head_only", False):
            self.wfile.write(body)

    def _send_bytes(self, status: int, body: bytes, content_type: str, extra_headers: dict[str, str] | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        if extra_headers:
            for key, value in extra_headers.items():
                self.send_header(key, value)
        self.end_headers()
        if not getattr(self, "_head_only", False):
            self.wfile.write(body)

    def do_HEAD(self) -> None:
        self._head_only = True
        try:
            self.do_GET()
        finally:
            self._head_only = False

    def _serve_frozen_audio(self, rel: str) -> None:
        prefix = "audio/"
        if not rel.startswith(prefix):
            self.send_error(404)
            return
        filename = unquote(rel[len(prefix) :])
        if "/" in filename or "\\" in filename or ".." in filename:
            self.send_error(403)
            return
        if not SAFE_WAV_NAME.fullmatch(filename):
            self.send_error(404)
            return
        entry = AUDIO_MAP.get(filename)
        if entry is None:
            self.send_error(404)
            return
        path, _expected_sha, expected_bytes = entry
        if not path.is_file():
            self.send_error(404)
            return
        file_size = path.stat().st_size
        if file_size != expected_bytes:
            self.send_error(500, "audio byte length mismatch")
            return

        range_header = self.headers.get("Range")
        if range_header:
            parsed = parse_byte_range(range_header, file_size)
            if parsed is None:
                self.send_error(416)
                return
            start, end = parsed
            length = end - start + 1
            with path.open("rb") as f:
                f.seek(start)
                body = f.read(length)
            extra = {
                "Accept-Ranges": "bytes",
                "Content-Range": f"bytes {start}-{end}/{file_size}",
            }
            self._send_bytes(206, body, "audio/wav", extra)
            return

        body = path.read_bytes()
        self._send_bytes(200, body, "audio/wav", {"Accept-Ranges": "bytes"})

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        rel = parsed.path.lstrip("/")
        if rel == "" or rel == "index.html":
            rel = "index.html"
        if rel == "api/status":
            finalized = is_finalized()
            rev = latest_revision()
            self._send_json(
                200,
                {
                    "finalized": finalized,
                    "revision": rev,
                    "human_input_dir": str(HUMAN_INPUT),
                },
            )
            return
        if rel == "api/cues":
            data = json.loads((SERVED / "cues.json").read_text(encoding="utf-8"))
            self._send_json(200, data)
            return
        if rel.startswith("audio/"):
            self._serve_frozen_audio(rel)
            return
        target = (SERVED / rel).resolve()
        if not str(target).startswith(str(SERVED.resolve())):
            self.send_error(403)
            return
        if not target.is_file():
            self.send_error(404)
            return
        if target.suffix == ".wav":
            self.send_error(403)
            return
        if target.suffix == ".html":
            ctype = "text/html; charset=utf-8"
        elif target.suffix == ".css":
            ctype = "text/css; charset=utf-8"
        elif target.suffix == ".js":
            ctype = "application/javascript; charset=utf-8"
        elif target.suffix == ".json":
            ctype = "application/json; charset=utf-8"
        else:
            ctype = "application/octet-stream"
        self._send_bytes(200, target.read_bytes(), ctype)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path != "/api/finalize":
            self.send_error(404)
            return
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length)
        try:
            payload = json.loads(body.decode("utf-8"))
        except json.JSONDecodeError:
            self._send_json(400, {"error": "invalid_json"})
            return

        if payload.get("reset") and is_finalized():
            rev = latest_revision() + 1
        elif is_finalized() and not payload.get("reset"):
            self._send_json(409, {"error": "already_finalized", "revision": latest_revision()})
            return
        else:
            rev = None

        paths = finalized_paths(rev)
        freeze = load_freeze()
        cues_in = payload.get("cues", [])
        if len(cues_in) != 15:
            self._send_json(400, {"error": "expected_15_cues", "received": len(cues_in)})
            return

        listened = sum(1 for c in cues_in if c.get("playback_completed"))
        adjudicated = sum(1 for c in cues_in if c.get("adjudication_choice") in ("raw_confirmed", "correction_entered"))
        unresolved = 15 - adjudicated
        empty_final = [c for c in cues_in if not str(c.get("final_human_text", "")).strip()]

        if listened != 15:
            self._send_json(400, {"error": "incomplete_listening", "listened": listened})
            return
        if adjudicated != 15 or unresolved != 0:
            self._send_json(400, {"error": "incomplete_adjudication", "adjudicated": adjudicated, "unresolved": unresolved})
            return
        if empty_final:
            self._send_json(400, {"error": "empty_final_text", "cue_indexes": [c.get("cue_index") for c in empty_final]})
            return
        if not payload.get("confirm_listening_decisions"):
            self._send_json(400, {"error": "missing_listening_confirmation"})
            return
        if not payload.get("acknowledge_asus_prior_exposure"):
            self._send_json(400, {"error": "missing_asus_exposure_acknowledgement"})
            return

        started_at = payload.get("started_at_utc") or utc_now()
        finalized_at = utc_now()

        record_cues = []
        for cue in cues_in:
            raw = cue["raw_text"]
            final = cue["final_human_text"]
            choice = cue["adjudication_choice"]
            classification = "unchanged" if choice == "raw_confirmed" and final == raw else "corrected"
            record_cues.append(
                {
                    "ordinal": cue["ordinal"],
                    "cue_index": cue["cue_index"],
                    "start_ms_timing": cue["start_ms_timing"],
                    "end_ms_timing": cue["end_ms_timing"],
                    "raw_text": raw,
                    "final_human_text": final,
                    "classification": classification,
                    "adjudication_choice": choice,
                    "playback_completed_at_utc": cue.get("playback_completed_at_utc"),
                    "adjudicated_at_utc": cue.get("adjudicated_at_utc"),
                    "reviewer_note": cue.get("reviewer_note", ""),
                    "audio_filename": cue["audio_filename"],
                    "audio_sha256": cue["audio_sha256"],
                }
            )

        review_record = {
            "schema_revision": "voxproof-owner-human-review-record-v1",
            "freeze_record_sha256": sha256_file(FREEZE_PATH),
            "reviewer": freeze["reviewer"],
            "reviewer_role": freeze["reviewer_role"],
            "started_at_utc": started_at,
            "finalized_at_utc": finalized_at,
            "revision": rev or 1,
            "cues": record_cues,
        }

        srt_cues = [
            {
                "cue_index": c["cue_index"],
                "start_ms_timing": c["start_ms_timing"],
                "end_ms_timing": c["end_ms_timing"],
                "final_human_text": c["final_human_text"],
            }
            for c in record_cues
        ]
        human_final_srt = build_srt(srt_cues)
        terms_path = STUDY_ROOT / freeze["session_terms"]["path"]
        terms_hash = sha256_file(terms_path)
        raw_hash = freeze["raw_srt"]["sha256"]

        record_bytes = (json.dumps(review_record, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
        srt_bytes = human_final_srt.encode("utf-8")
        completion = {
            "schema_revision": "voxproof-owner-human-review-completion-v1",
            "reviewer": freeze["reviewer"],
            "reviewer_role": freeze["reviewer_role"],
            "started_at_utc": started_at,
            "finalized_at_utc": finalized_at,
            "revision": rev or 1,
            "listened_count": listened,
            "adjudicated_count": adjudicated,
            "unresolved_count": unresolved,
            "prior_exposure_acknowledged": True,
            "reference_blinding_declaration": {
                "reference_final_excluded_from_ui": True,
                "community_sentence_excluded_from_ui": True,
                "session_not_fully_blinded": True,
                "asus_prior_exposure_disclosed": True,
            },
            "hashes": {
                "raw_srt_sha256": raw_hash,
                "session_terms_sha256": terms_hash,
                "human_review_record_sha256": sha256_bytes(record_bytes),
                "human_final_srt_sha256": sha256_bytes(srt_bytes),
            },
        }
        completion_bytes = (json.dumps(completion, indent=2, ensure_ascii=False) + "\n").encode("utf-8")

        HUMAN_INPUT.mkdir(parents=True, exist_ok=True)
        atomic_write(paths["record"], record_bytes)
        atomic_write(paths["srt"], srt_bytes)
        atomic_write(paths["completion"], completion_bytes)
        lock_body = json.dumps(
            {
                "finalized_at_utc": finalized_at,
                "revision": rev or 1,
                "record": str(paths["record"].name),
            },
            indent=2,
        ).encode("utf-8")
        atomic_write(paths["lock"], lock_body)

        self._send_json(
            200,
            {
                "ok": True,
                "revision": rev or 1,
                "files": {
                    "human_review_record": str(paths["record"]),
                    "human_final_srt": str(paths["srt"]),
                    "human_review_completion": str(paths["completion"]),
                },
            },
        )


def main() -> None:
    if not FREEZE_PATH.is_file():
        raise SystemExit(f"missing freeze record: {FREEZE_PATH}")
    HUMAN_INPUT.mkdir(parents=True, exist_ok=True)
    httpd = ThreadingHTTPServer((HOST, PORT), ReviewHandler)
    print(f"Serving on http://{HOST}:{PORT}/", flush=True)
    print(f"PID {os.getpid()}", flush=True)
    httpd.serve_forever()


if __name__ == "__main__":
    main()
