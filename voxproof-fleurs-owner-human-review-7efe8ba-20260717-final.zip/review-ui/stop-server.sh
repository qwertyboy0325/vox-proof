#!/bin/bash
set -euo pipefail
STUDY="$(cd "$(dirname "$0")/.." && pwd)"
PIDFILE="$STUDY/review-ui/server.pid"
if [[ ! -f "$PIDFILE" ]]; then
  echo "No PID file"
  exit 1
fi
pid=$(cat "$PIDFILE")
if kill -0 "$pid" 2>/dev/null; then
  kill "$pid"
  echo "Stopped PID $pid"
else
  echo "Process $pid not running"
fi
rm -f "$PIDFILE"
