# Study-local temporary review tooling

This directory contains temporary study-local tooling used to collect owner human-review input.
It is not VoxProof product functionality or a product GUI claim.
