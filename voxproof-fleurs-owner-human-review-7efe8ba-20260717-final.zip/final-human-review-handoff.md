# FLEURS Owner Human Review — Final Handoff

Study root: `/private/tmp/voxproof-fleurs-owner-human-review-7efe8ba-20260717T073817Z`  
Repository baseline: `7efe8bad77dc2d9f37f613a1660703c0bcf9653c`  
Handoff generated: `2026-07-17T08:26:12.810682+00:00`

## Classification

Qualifying owner-operated real-speech human-correction mechanism evidence under MD-007.

**Not claimed:** product effectiveness, precision/recall, general ASR quality, external-user validation, community-reference correctness adjudication, or automatic v0.1 establishment.

Human-final and reviewed outputs are **owner-operated ASR post-edit output**, not independent blind transcription or objective ground truth.

---

## Provenance chain

1. Frozen source package + pre-review freeze (`pre-review/pre-review-freeze-record.json`)
2. Study-local review UI (temporary; not VoxProof product functionality)
3. Audio playback repair (`post-review/audio-playback-repair-provenance.json`) — pre-finalization only
4. Revision-1 human finalize (`human-input/`, locked)
5. Authoritative CLI review (`authoritative-review/`, binary `f0cf3a52…dbcca`)
6. Compare/evaluate calibration reports (`reports/`)

---

## UI repair disclosure

- **Root cause:** `served/audio/*.wav` symlinks resolved outside `review-ui/served/`, triggering HTTP 403.
- **Changed:** `review-ui/server.py` only (`a5e38e2a…2803` → `1ac4c1c2…ff0f3`)
- **Unchanged:** UI HTML/JS/CSS, frozen inputs, repository
- **Verification:** 15/15 audio routes hash-identical; reference blinding intact; no human decisions before repair

---

## Locked revision-1 human input

| Artifact | SHA-256 |
|---|---|
| human-review-record.json | `1464db9f8aa58d26e2c3ee123feb473483aaa24673089f9eb71feab560c8f142` |
| human-final.srt | `98345810e0859e7b10531cad86f3e442c2faedf09e8822c61b9fecb7ff0a66f6` |
| human-review-completion.json | `bcc6cf543db9de3b5349e028add298aa6cafdc9b56d1194fb75a722cc5e4e503` |
| .finalized.lock | `31eaaee0db123bbea2b2698e2ac60bb8daeb110361caf3eb1a967e1e6d6a49ad` |

- **Finalized:** true, revision 1
- **Listened/adjudicated/unresolved:** 15/15/0
- **Unchanged/corrected cues:** 14/1 (cue 2: ASIS→ASUS)
- **Review duration:** ~911s

Bindings: `post-review/finalized-human-input-binding.json`, `post-review/human-input-verification.json`

---

## Disclosure and clarification (revision 1 untouched)

**Original disclosure** (preserved verbatim): `post-review/human-input-verification.json#additional_reviewer_disclosure`

**Clarification** (`post-review/reviewer-disclosure-clarification.json`):
- Recorded: `2026-07-17T08:22:55.991682+00:00`
- Content SHA-256: `e7ad5bd2a1a61cb4bb8f5b1def284a2f11cbfd6637ffa72c3545187754385766`
- Supersedes only the inaccurate claim that anchoring "contributed to retaining ASIS"
- Valid limitations: possible raw-text anchoring influence; known ASUS exposure; revision 1 records **ASUS** for cue 2

---

## Authoritative CLI review (no rerun)

| Field | Value |
|---|---|
| case_id | local:0 |
| cue_index | 2 |
| decision | `a 0` |
| alternative | ASUS |
| timestamp | 2026-07-17T08:23:46Z |

**ReviewCases raised:** 1 (phonetic_similarity ASIS→ASUS)  
**Decision log:** `authoritative-review/decision-log.txt`  
**Session summary:** `authoritative-review/session-summary.txt`

---

## Materialization verification (Phase 4)

- Skeleton preserved: 15/15 cues, all indices/timings match raw
- **Only authorized text change:** cue 2, ASIS→ASUS at matched anchor
- Unauthorized changes: 0
- `human-final.srt` vs `reviewed-output.srt`:
  - **Byte-identical:** False
  - **Text-identical:** yes (all 15 cue texts match)
  - **Byte diff inventory:** human-final has trailing `0x0a` at offset 2390 (2391 vs 2390 bytes); no cue text difference
- reviewed-output SHA-256: `99363ebdcb95fe17a55d1f0fbbc237e6d91640301647e35bb63d3767d6c0b0b0`

Artifact: `post-review/materialization-verification.json`

---

## Compare determinism (Phase 5)

| Pair | Run1 SHA-256 | Run2 match | Exit |
|---|---|---|---|
| raw vs human-final | `b0473373b0968097…` | yes | 0 |
| raw vs reviewed | `208734586321762b…` | yes | 0 |

Summaries (both pairs): 15 cues, 14 unchanged, 1 text_changed (cue 2).

---

## Evaluate determinism (Phase 6)

| Run | SHA-256 | stderr |
|---|---|---|
| run1 | `d64d5c1fe5642c6f428dbad0b8d69e4e0e81a6a0f2f747939f18e50740bcfbf4` | empty |
| run2 | `d64d5c1fe5642c6f428dbad0b8d69e4e0e81a6a0f2f747939f18e50740bcfbf4` | empty |

- Identities bind raw, human-final, canonical-only terms
- 1 local replacement edit (cue 2, I→U within ASIS/ASUS)
- 1 review case (local:0), 1 candidate_edit_overlap relation
- 0 insertion correspondence; 0 mechanically unclassified edits
- Summaries independently recomputed from detail records

---

## Descriptive distributions (Phase 7)

See `post-review/descriptive-distributions.json`.

**Raw vs owner human-final:** 1 replacement edit (cue 2)  
**Canonical ReviewCase:** phonetic_similarity / ASUS / Accept alt 0 / materialized  
**Correspondence:** 1 candidate_edit_overlap; 0 ambiguous; 0 unclassified  
**Reviewer vs community reference:** 11 text disagreements on shared skeleton — labelled disagreement only (`reports/reviewer-reference-disagreement-inventory.json`)

---

## MD-007 gate evaluation (Phase 8)

Evaluated: `2026-07-17T08:25:55.041069+00:00`  
**All ten gates:** PASS

| # | Gate | Result | Evidence |
|---|------|--------|----------|
| 1 | 100% cues adjudicated | PASS | 15/15 — human-input/human-review-record.json |
| 2 | Zero unresolved | PASS | 0/15 — human-input/human-review-completion.json unresolved_count=0 |
| 3 | 100% skeleton preservation | PASS | 15/15 — post-review/materialization-verification.json |
| 4 | 100% canonical decisions recorded/input-bound | PASS | 1/1 — authoritative-review/decision-log.txt + interactive-decisions.json |
| 5 | 100% accepted alternatives exactly materialized | PASS | 1/1 — authoritative-review/reviewed-output.srt cue 2 |
| 6 | 100% rejected alternatives preserve source anchor | PASS | 0/0 — zero rejected decisions; vacuous pass |
| 7 | Zero unauthorized/silent edits | PASS | 15/15 — post-review/materialization-verification.json |
| 8 | Repeated compare/evaluate reports byte-identical | PASS | 3/3 — reports/report-hashes.json |
| 9 | Every summary recomputes from detailed records | PASS | 3/3 — compare x2 + evaluate verified in phase script |
| 10 | Distributions descriptive without forbidden claims | PASS | 1/1 — no forbidden metric fields in compare/evaluate reports |

Full artifact: `post-review/md007-gate-evaluation.json`

**v0.1 NOT established.** Blockers:
- Mixed zh-EN fixture still separately required under MD-007
- Explicit later establishment decision not yet made
- Final release audit/tag has not occurred

---

## Repository preservation (Phase 9)

- **HEAD:** `7efe8bad77dc2d9f37f613a1660703c0bcf9653c` (unchanged)
- **Tracked modifications:** none
- **Research artifacts rehashed:** 51 (46 baseline + 5 additional)
- **Baseline inventory match:** False (1 missing: `calibration-comparison-v0.patch` not present in repo root)
- **No package/seal/commit/push/tag performed**

Artifact: `post-review/research-artifact-rehash.json`

---

## Study artifacts index

| Phase | Path |
|---|---|
| Human input verification | post-review/human-input-verification.json |
| Human input binding | post-review/finalized-human-input-binding.json |
| Repair provenance | post-review/audio-playback-repair-provenance.json |
| Disclosure clarification | post-review/reviewer-disclosure-clarification.json |
| Materialization | post-review/materialization-verification.json |
| CLI decisions | authoritative-review/interactive-decisions.json |
| Distributions | post-review/descriptive-distributions.json |
| MD-007 gates | post-review/md007-gate-evaluation.json |
| Reference disagreement | reports/reviewer-reference-disagreement-inventory.json |
| Report hashes | reports/report-hashes.json |

---

## Stop point

Phases 4–9 complete. Ready for ChatGPT review. Do not seal or release.
