#!/usr/bin/env python3
"""Tests for exploratory v2 alignment scorer."""

from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from alignment_scorer import (  # noqa: E402
    AlignmentOperation,
    align_tokens,
    backtrace_alignment,
    build_distance_matrix,
    load_frozen_streams,
)


class AlignmentScorerTests(unittest.TestCase):
    def test_exact_match(self) -> None:
        result = align_tokens(["a", "b", "c"], ["a", "b", "c"])
        self.assertEqual(result.matches, 3)
        self.assertEqual(result.substitutions, 0)
        self.assertEqual(result.deletions, 0)
        self.assertEqual(result.insertions, 0)
        self.assertEqual(result.edit_distance, 0)
        self.assertEqual(result.wer(), 0.0)
        self.assertEqual(result.validate_invariants(), [])

    def test_substitution_only(self) -> None:
        result = align_tokens(["a", "b"], ["x", "y"])
        self.assertEqual(result.matches, 0)
        self.assertEqual(result.substitutions, 2)
        self.assertEqual(result.deletions, 0)
        self.assertEqual(result.insertions, 0)
        self.assertEqual(result.edit_distance, 2)
        self.assertEqual(result.wer(), 1.0)

    def test_deletion_only(self) -> None:
        result = align_tokens(["a", "b", "c"], [])
        self.assertEqual(result.matches, 0)
        self.assertEqual(result.substitutions, 0)
        self.assertEqual(result.deletions, 3)
        self.assertEqual(result.insertions, 0)
        self.assertEqual(result.edit_distance, 3)

    def test_insertion_only(self) -> None:
        result = align_tokens([], ["a", "b"])
        self.assertEqual(result.matches, 0)
        self.assertEqual(result.substitutions, 0)
        self.assertEqual(result.deletions, 0)
        self.assertEqual(result.insertions, 2)
        self.assertEqual(result.edit_distance, 2)

    def test_mixed_operations(self) -> None:
        result = align_tokens(["a", "b", "c", "d"], ["a", "x", "d", "e"])
        self.assertEqual(result.matches, 1)
        self.assertEqual(result.substitutions, 3)
        self.assertEqual(result.deletions, 0)
        self.assertEqual(result.insertions, 0)
        self.assertEqual(result.edit_distance, 3)
        self.assertEqual(result.validate_invariants(), [])

    def test_repeated_token_tie_case(self) -> None:
        result = align_tokens(["a", "a", "b"], ["a", "b", "b"])
        self.assertEqual(result.edit_distance, 1)
        self.assertEqual(result.matches, 2)
        self.assertEqual(result.substitutions, 1)
        self.assertEqual(result.deletions, 0)
        self.assertEqual(result.insertions, 0)
        self.assertEqual(result.validate_invariants(), [])

    def test_frozen_c1_regression_input(self) -> None:
        scoring_path = ROOT / "inputs" / "scoring_tokens.json"
        reference, hypothesis, _ = load_frozen_streams(scoring_path)
        self.assertEqual(len(reference), 705)
        self.assertEqual(len(hypothesis), 699)
        result = align_tokens(reference, hypothesis)
        self.assertEqual(result.edit_distance, 374)
        self.assertEqual(result.matches + result.substitutions + result.deletions, 705)
        self.assertEqual(result.matches + result.substitutions + result.insertions, 699)
        self.assertEqual(699, 705 - result.deletions + result.insertions)
        self.assertAlmostEqual(result.wer() or 0.0, 374 / 705)
        self.assertEqual(result.validate_invariants(), [])

    def test_inconsistent_counts_rejected(self) -> None:
        from alignment_scorer import AlignmentResult

        result = AlignmentResult(
            reference_tokens=("a", "b"),
            hypothesis_tokens=("a", "b"),
            operations=(),
            matches=1,
            substitutions=0,
            deletions=0,
            insertions=0,
            edit_distance=0,
        )
        errors = result.validate_invariants()
        self.assertTrue(any("M+S+D != N" in err for err in errors))

    def test_malformed_transition_rejected(self) -> None:
        with self.assertRaises(ValueError):
            backtrace_alignment(["a"], ["b"], [[0, 99]])

    def test_token_reconstruction_mismatch_rejected(self) -> None:
        from alignment_scorer import AlignmentResult

        op = AlignmentOperation(
            ordinal=0,
            operation="match",
            reference_index=0,
            hypothesis_index=0,
            reference_token="a",
            hypothesis_token="a",
            reference_coord_before=0,
            hypothesis_coord_before=0,
            reference_coord_after=1,
            hypothesis_coord_after=1,
        )
        result = AlignmentResult(
            reference_tokens=("b",),
            hypothesis_tokens=("a",),
            operations=(op,),
            matches=1,
            substitutions=0,
            deletions=0,
            insertions=0,
            edit_distance=0,
        )
        self.assertIn("reconstructed reference tokens mismatch", result.validate_invariants()[0])


if __name__ == "__main__":
    unittest.main(verbosity=2)
