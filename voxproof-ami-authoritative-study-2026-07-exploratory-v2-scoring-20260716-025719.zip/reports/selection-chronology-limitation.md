# Selection and Chronology Limitation

ES2004a `[300,600)` selection chronology is **not independently proven** from preserved artifacts.

- Phase A/source-lock records in c1 were created and sealed post-outcome.
- This sample must not be described as pre-registered, unbiased, or confirmatory.
- This run does not complete the originally described ten-minute protocol.
- Valid output, if any, is limited to reproducible behavior for this disclosed five-minute fixed input and the zero-candidate/no-edit path.
- This is **not** accepted research evidence and **not** an authoritative performance result.
