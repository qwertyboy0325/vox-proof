# Exploratory V2 Scoring Report

## Classification
post-hoc exploratory fixed-input negative-control evidence

## Frozen Input Verification
- scoring_tokens.json SHA256: `a2053f8c7b936fa4941732c378a94dd0e2fcdd7f1fbbf0f0d8a6d4d6409c2241`
- reference tokens (N): 705
- hypothesis tokens (H): 699

## Corrected Counts
- matches (M): 381
- substitutions (S): 268
- deletions (D): 56
- insertions (I): 50
- edit distance: 374
- WER: 374/705 = 0.530496453901

## c1 Rejected Metrics (forensic only)
- c1 reported S=310, D=0, I=64 (invalid decomposition; violates H=N-D+I)
- c1 ZIP SHA preserved: `3c78e8cf8c19df70aa7c67cf7ab7bb0df1abacd2c9e720359463d74444af0b80`
- c1 seal SHA preserved: `bb83ffa8c401480469c44e35bb4cb40c05ebc30f3ab48ba8a218a6f57e37c901`

## Tie Policy
`match > substitution > deletion > insertion`

## Test Status
pass (exit 0)

## Interpretation Guardrails
- exploratory fixed-input negative-control evidence only
- zero-candidate/no-edit path only
- never accepted research evidence until ChatGPT review
- never authoritative performance result
- never pre-outcome frozen selection

# Selection and Chronology Limitation

ES2004a `[300,600)` selection chronology is **not independently proven** from preserved artifacts.

- Phase A/source-lock records in c1 were created and sealed post-outcome.
- This sample must not be described as pre-registered, unbiased, or confirmatory.
- This run does not complete the originally described ten-minute protocol.
- Valid output, if any, is limited to reproducible behavior for this disclosed five-minute fixed input and the zero-candidate/no-edit path.
- This is **not** accepted research evidence and **not** an authoritative performance result.

