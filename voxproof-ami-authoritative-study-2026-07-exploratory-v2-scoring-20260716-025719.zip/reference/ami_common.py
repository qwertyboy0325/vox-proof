#!/usr/bin/env python3
"""Shared utilities for AMI authoritative Phase B execution."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from pathlib import Path
from typing import Any, Iterable
import zipfile
import xml.etree.ElementTree as ET

STUDY_ROOT = Path("/private/tmp/voxproof-ami-authoritative-study-2026-07")
REPO_ROOT = Path("/Users/Ezra4/Coding/Repo/vox-proof")
REQUIRED_HEAD = "5286c1627e54852fc08f4766240ce7545269e982"
NITE_NS = "{http://nite.sourceforge.net/}"
WINDOW_START = Decimal("300.000")
WINDOW_END = Decimal("600.000")
MEETING_ID = "ES2004a"
SPEAKERS = ("A", "B", "C", "D")
HREF_RE = re.compile(r"#id\(([^)]+)\)\.\.id\(([^)]+)\)")
ALLOWED_ASR_TAGS = {"w", "sil"}
ALLOWED_MANUAL_TAGS = {"w", "disfmarker", "gap", "vocalsound"}
MANUAL_TYPED_EVENT_TAGS = {"disfmarker", "gap", "vocalsound"}
GLOSSARY_DETECTOR_ID = "glossary-alias-match"
GLOSSARY_DETECTOR_VERSION = "0.1.0"
OBSERVED_ERROR_FORM_DETECTOR_ID = "observed-error-form-match"
OBSERVED_ERROR_FORM_DETECTOR_VERSION = "0.1.0"
FROZEN_SESSION_TERMS = """Project Manager | alias:PM
Industrial Designer | alias:ID
User Interface Designer | alias:UI | alias:UID
Marketing Expert | alias:ME
"""
MEETING_TIME_ORDERING_POLICY = {
    "policy_id": "meeting-time-midpoint-v1",
    "primary_key": "token_midpoint_seconds",
    "tie_breakers": ["speaker_channel", "element_id"],
    "speaker_channel_order": list(SPEAKERS),
    "description": (
        "Both hypothesis and reference scoring streams sort in-window lexical tokens by "
        "midpoint time, then speaker channel A<B<C<D, then element_id."
    ),
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def floor_ms(seconds: Decimal) -> int:
    ms = (seconds * Decimal(1000)).to_integral_value(rounding=ROUND_FLOOR)
    return int(ms)


def ceil_ms(seconds: Decimal) -> int:
    ms = (seconds * Decimal(1000)).to_integral_value(rounding=ROUND_CEILING)
    return int(ms)


def format_timestamp(total_ms: int) -> str:
    hours = total_ms // 3_600_000
    rem = total_ms % 3_600_000
    minutes = rem // 60_000
    rem %= 60_000
    seconds = rem // 1000
    millis = rem % 1000
    return f"{hours:02}:{minutes:02}:{seconds:02},{millis:03}"


def compute_revision(segments: list[dict[str, Any]]) -> str:
    hasher = hashlib.sha256()
    hasher.update(b"voxproof-transcript-rev-v1")
    hasher.update(b"\x00")
    hasher.update(len(segments).to_bytes(8, "little"))
    for segment in segments:
        hasher.update(int(segment["index"]).to_bytes(4, "little"))
        hasher.update(int(segment["start_ms"]).to_bytes(8, "little"))
        hasher.update(int(segment["end_ms"]).to_bytes(8, "little"))
        text = segment["text"].encode("utf-8")
        hasher.update(len(text).to_bytes(8, "little"))
        hasher.update(text)
    return "rev:sha256-v1:" + hasher.hexdigest()


def parse_session_terms(text: str) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    canonical_lines: dict[str, int] = {}
    source_form_lines: dict[str, tuple[str, int]] = {}
    for line_index, raw_line in enumerate(text.splitlines(), start=1):
        trimmed = raw_line.strip()
        if not trimmed or trimmed.startswith("#"):
            continue
        fields = [part.strip() for part in raw_line.split("|")]
        canonical = fields[0]
        if not canonical:
            raise ValueError(f"empty canonical at line {line_index}")
        if len(fields) == 1:
            raise ValueError(f"missing source form at line {line_index}")
        if canonical in canonical_lines:
            raise ValueError(f"duplicate canonical {canonical}")
        aliases: list[str] = []
        observed: list[str] = []
        for field in fields[1:]:
            if ":" not in field:
                raise ValueError(f"unprefixed field at line {line_index}: {field}")
            prefix, value = field.split(":", 1)
            prefix = prefix.strip()
            value = value.strip()
            if prefix == "alias":
                kind = "alias"
            elif prefix == "error":
                kind = "error"
            else:
                raise ValueError(f"unknown prefix {prefix}")
            if not value:
                raise ValueError(f"empty {kind} at line {line_index}")
            if value in source_form_lines:
                raise ValueError(f"duplicate source form {value}")
            source_form_lines[value] = (kind, line_index)
            if kind == "alias":
                aliases.append(value)
            else:
                observed.append(value)
        canonical_lines[canonical] = line_index
        entries.append(
            {
                "canonical_term": canonical,
                "aliases": aliases,
                "observed_error_forms": observed,
            }
        )
    return entries


@dataclass(frozen=True)
class TokenRecord:
    speaker: str
    archive_member: str
    element_id: str
    tag: str
    start: Decimal
    end: Decimal
    text: str


@dataclass(frozen=True)
class SegmentRecord:
    speaker: str
    archive_member: str
    segment_id: str
    participant: str
    child_href: str
    token_ids: tuple[str, ...]


def load_xml_member(zf: zipfile.ZipFile, member: str) -> ET.Element:
    return ET.fromstring(zf.read(member))


def ordered_ids(root: ET.Element) -> list[str]:
    ids: list[str] = []
    for el in root:
        element_id = el.attrib.get(f"{NITE_NS}id")
        if element_id:
            ids.append(element_id)
    return ids


def build_token_map(root: ET.Element, allowed_tags: set[str]) -> dict[str, TokenRecord]:
    tokens: dict[str, TokenRecord] = {}
    for el in root:
        tag = el.tag.split("}")[-1]
        if tag not in allowed_tags:
            continue
        element_id = el.attrib.get(f"{NITE_NS}id")
        if not element_id:
            continue
        start = Decimal(el.attrib["starttime"])
        end = Decimal(el.attrib["endtime"])
        text = "".join(el.itertext()) if tag == "w" else ""
        tokens[element_id] = TokenRecord(
            speaker="",
            archive_member="",
            element_id=element_id,
            tag=tag,
            start=start,
            end=end,
            text=text,
        )
    return tokens


def token_midpoint(token: TokenRecord) -> Decimal:
    return (token.start + token.end) / Decimal(2)


def token_midpoint_from_record(rec: dict[str, Any]) -> Decimal:
    return (Decimal(rec["start"]) + Decimal(rec["end"])) / Decimal(2)


def in_window(token: TokenRecord) -> bool:
    mid = token_midpoint(token)
    return WINDOW_START <= mid < WINDOW_END


def in_window_record(rec: dict[str, Any]) -> bool:
    return bool(rec.get("in_window"))


def meeting_time_sort_key(rec: dict[str, Any]) -> tuple[Any, ...]:
    speaker_rank = SPEAKERS.index(rec["speaker"]) if rec["speaker"] in SPEAKERS else 99
    return (token_midpoint_from_record(rec), speaker_rank, rec.get("element_id", ""))


def safe_zip_inventory(zpath: Path) -> list[dict[str, Any]]:
    inventory: list[dict[str, Any]] = []
    with zipfile.ZipFile(zpath) as zf:
        for info in zf.infolist():
            name = info.filename
            unsafe = (".." in name) or name.startswith("/") or ("\\" in name)
            inventory.append(
                {
                    "path": name,
                    "bytes": info.file_size,
                    "compressed_bytes": info.compress_size,
                    "unsafe": unsafe,
                }
            )
    return inventory


def normalize_scoring_token(token: str) -> str | None:
    token = unicodedata.normalize("NFC", token)
    token = "".join(ch for ch in token.casefold() if not unicodedata.category(ch).startswith("P"))
    if not token:
        return None
    return token


def scoring_tokens(text: str) -> list[str]:
    out: list[str] = []
    for piece in text.split():
        normalized = normalize_scoring_token(piece)
        if normalized is not None:
            out.append(normalized)
    return out


def build_ordered_scoring_stream(records: list[dict[str, Any]]) -> list[str]:
    selected = [
        rec for rec in records if rec.get("tag") == "w" and in_window_record(rec)
    ]
    selected.sort(key=meeting_time_sort_key)
    stream: list[str] = []
    for rec in selected:
        stream.extend(scoring_tokens(rec["text"]))
    return stream


def levenshtein_counts(ref: list[str], hyp: list[str]) -> tuple[int, int, int, int]:
    n = len(ref)
    m = len(hyp)
    dp: list[list[tuple[int, int, int]]] = [
        [(0, 0, 0) for _ in range(m + 1)] for _ in range(n + 1)
    ]
    for i in range(1, n + 1):
        dp[i][0] = (i, i, 0)
    for j in range(1, m + 1):
        dp[0][j] = (j, 0, j)
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if ref[i - 1] == hyp[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                sub = dp[i - 1][j - 1]
                delete = dp[i - 1][j]
                insert = dp[i][j - 1]
                candidates = [
                    (sub[0] + 1, sub[1] + 1, sub[2]),
                    (delete[0] + 1, delete[1] + 1, delete[2]),
                    (insert[0] + 1, insert[1], insert[2] + 1),
                ]
                dp[i][j] = min(candidates, key=lambda item: (item[0], item[1], item[2]))
    dist, subs, ins = dp[n][m]
    return subs, delete_count(dp, n, m), ins, n


def delete_count(dp: list[list[tuple[int, int, int]]], n: int, m: int) -> int:
    dist, subs, ins = dp[n][m]
    return dist - subs - ins
