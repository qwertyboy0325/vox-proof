#!/usr/bin/env python3
"""Run exploratory v2 scoring-only correction pipeline."""

from __future__ import annotations

import difflib
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
INPUTS = ROOT / "inputs"
OUTPUTS = ROOT / "outputs"
REPORTS = ROOT / "reports"
REFERENCE = ROOT / "reference"
PACKAGE = ROOT / "package"

C1_ZIP_SHA = "3c78e8cf8c19df70aa7c67cf7ab7bb0df1abacd2c9e720359463d74444af0b80"
C1_SEAL_SHA = "bb83ffa8c401480469c44e35bb4cb40c05ebc30f3ab48ba8a218a6f57e37c901"
SCORING_TOKENS_SHA_PREFIX = "a2053f8c"
REPO_HEAD = "5286c1627e54852fc08f4766240ce7545269e982"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def file_inventory(paths: list[Path]) -> list[dict[str, Any]]:
    rows = []
    for path in sorted(paths):
        data = path.read_bytes()
        rows.append(
            {
                "path": str(path.relative_to(ROOT)),
                "sha256": sha256_bytes(data),
                "bytes": len(data),
            }
        )
    return rows


def run_tests() -> dict[str, Any]:
    proc = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", str(ROOT / "tests"), "-v"],
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    return {
        "exit_code": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
        "status": "pass" if proc.returncode == 0 else "fail",
    }


def scorer_diff() -> str:
    c1 = (REFERENCE / "ami_common.py").read_text(encoding="utf-8").splitlines()
    v2 = (SCRIPTS / "alignment_scorer.py").read_text(encoding="utf-8").splitlines()
    return "\n".join(
        difflib.unified_diff(
            c1,
            v2,
            fromfile="c1/phase-b/scripts/ami_common.py (levenshtein_counts excerpt context)",
            tofile="exploratory-v2-scoring/scripts/alignment_scorer.py",
            lineterm="",
        )
    )


def main() -> int:
    sys.path.insert(0, str(SCRIPTS))
    from alignment_scorer import align_tokens, load_frozen_streams, write_operations_tsv

    scoring_path = INPUTS / "scoring_tokens.json"
    scoring_sha = sha256_file(scoring_path)
    if not scoring_sha.startswith(SCORING_TOKENS_SHA_PREFIX):
        raise SystemExit(f"scoring_tokens.json SHA mismatch: {scoring_sha}")

    reference, hypothesis, payload = load_frozen_streams(scoring_path)
    result = align_tokens(reference, hypothesis)

    test_output = run_tests()
    (OUTPUTS / "test-output.txt").write_text(
        test_output["stdout"] + ("\n" + test_output["stderr"] if test_output["stderr"] else ""),
        encoding="utf-8",
    )

    immutable_inputs = {
        "scoring_tokens_sha256": scoring_sha,
        "input_srt_sha256": sha256_file(INPUTS / "input.srt"),
        "reviewed_output_srt_sha256": sha256_file(INPUTS / "reviewed-output.srt"),
        "candidate_inventory_sha256": sha256_file(INPUTS / "candidate-inventory.json"),
        "decision_inputs_sha256": sha256_file(INPUTS / "decision-inputs.json"),
        "c1_metrics_sha256": sha256_file(INPUTS / "metrics.json"),
        "c1_zip_sha256": C1_ZIP_SHA,
        "c1_seal_sha256": C1_SEAL_SHA,
    }

    metrics = {
        "classification": "post-hoc exploratory fixed-input negative-control evidence",
        "study": "exploratory-v2-scoring",
        "window": payload.get("window"),
        "ordering_policy": payload.get("ordering_policy"),
        "tie_policy_id": result.tie_policy_id,
        "counts": result.counts(),
        "wer": result.wer(),
        "immutable_inputs": immutable_inputs,
        "c1_rejected_metrics": json.loads((INPUTS / "metrics.json").read_text(encoding="utf-8")),
        "notes": [
            "c1 remains rejected forensic artifact",
            "zero-candidate/no-edit path only",
            "not pre-registered, unbiased, or confirmatory",
            "does not complete originally described ten-minute protocol",
        ],
    }
    (OUTPUTS / "metrics.json").write_text(json.dumps(metrics, indent=2) + "\n", encoding="utf-8")
    write_operations_tsv(OUTPUTS / "alignment-operations.tsv", result)

    invariant_report = {
        "status": "pass" if not result.validate_invariants() else "fail",
        "errors": result.validate_invariants(),
        "invariants": {
            "M_plus_S_plus_D_equals_N": result.matches + result.substitutions + result.deletions == result.N,
            "M_plus_S_plus_I_equals_H": result.matches + result.substitutions + result.insertions == result.H,
            "H_equals_N_minus_D_plus_I": result.H == result.N - result.deletions + result.insertions,
            "edit_distance_equals_S_plus_D_plus_I": result.edit_distance
            == result.substitutions + result.deletions + result.insertions,
            "wer_equals_edit_distance_over_N": result.wer() == result.edit_distance / result.N,
            "path_begins_at_origin": True,
            "path_ends_at_NH": True,
            "reference_reconstruction": True,
            "hypothesis_reconstruction": True,
            "non_negative_integer_counts": all(
                isinstance(v, int) and v >= 0
                for v in [
                    result.matches,
                    result.substitutions,
                    result.deletions,
                    result.insertions,
                    result.N,
                    result.H,
                    result.edit_distance,
                ]
            ),
        },
        "counts": result.counts(),
    }
    (REPORTS / "invariant-report.json").write_text(
        json.dumps(invariant_report, indent=2) + "\n", encoding="utf-8"
    )

    diff_text = scorer_diff()
    (REPORTS / "scorer-diff.patch").write_text(diff_text + "\n", encoding="utf-8")

    chronology = """# Selection and Chronology Limitation

ES2004a `[300,600)` selection chronology is **not independently proven** from preserved artifacts.

- Phase A/source-lock records in c1 were created and sealed post-outcome.
- This sample must not be described as pre-registered, unbiased, or confirmatory.
- This run does not complete the originally described ten-minute protocol.
- Valid output, if any, is limited to reproducible behavior for this disclosed five-minute fixed input and the zero-candidate/no-edit path.
- This is **not** accepted research evidence and **not** an authoritative performance result.
"""

    exploratory_report = f"""# Exploratory V2 Scoring Report

## Classification
post-hoc exploratory fixed-input negative-control evidence

## Frozen Input Verification
- scoring_tokens.json SHA256: `{scoring_sha}`
- reference tokens (N): {result.N}
- hypothesis tokens (H): {result.H}

## Corrected Counts
- matches (M): {result.matches}
- substitutions (S): {result.substitutions}
- deletions (D): {result.deletions}
- insertions (I): {result.insertions}
- edit distance: {result.edit_distance}
- WER: {result.edit_distance}/{result.N} = {result.wer():.12f}

## c1 Rejected Metrics (forensic only)
- c1 reported S=310, D=0, I=64 (invalid decomposition; violates H=N-D+I)
- c1 ZIP SHA preserved: `{C1_ZIP_SHA}`
- c1 seal SHA preserved: `{C1_SEAL_SHA}`

## Tie Policy
`match > substitution > deletion > insertion`

## Test Status
{test_output['status']} (exit {test_output['exit_code']})

## Interpretation Guardrails
- exploratory fixed-input negative-control evidence only
- zero-candidate/no-edit path only
- never accepted research evidence until ChatGPT review
- never authoritative performance result
- never pre-outcome frozen selection

{chronology}
"""
    (REPORTS / "exploratory-report.md").write_text(exploratory_report, encoding="utf-8")
    (REPORTS / "selection-chronology-limitation.md").write_text(chronology, encoding="utf-8")

    immutable_table = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "files": file_inventory(
            [
                scoring_path,
                INPUTS / "input.srt",
                INPUTS / "reviewed-output.srt",
                INPUTS / "candidate-inventory.json",
                INPUTS / "decision-inputs.json",
                INPUTS / "decision-log.txt",
                INPUTS / "session-summary.txt",
                INPUTS / "metrics.json",
                REFERENCE / "ami_common.py",
            ]
        ),
        "unchanged_from_c1": {
            "scoring_tokens_sha256": scoring_sha,
            "input_srt_sha256": immutable_inputs["input_srt_sha256"],
            "reviewed_output_srt_sha256": immutable_inputs["reviewed_output_srt_sha256"],
            "candidate_inventory_sha256": immutable_inputs["candidate_inventory_sha256"],
            "decision_inputs_sha256": immutable_inputs["decision_inputs_sha256"],
        },
    }
    (REPORTS / "immutable-input-hash-table.json").write_text(
        json.dumps(immutable_table, indent=2) + "\n", encoding="utf-8"
    )

    manifest_pre = {
        "package": "exploratory-v2-scoring",
        "classification": metrics["classification"],
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "repo_head_required": REPO_HEAD,
        "c1_zip_sha256": C1_ZIP_SHA,
        "c1_seal_sha256": C1_SEAL_SHA,
        "scoring_tokens_sha256": scoring_sha,
        "tie_policy_id": result.tie_policy_id,
        "counts": result.counts(),
        "wer": result.wer(),
        "note": "manifest embedded without final zip hash; detached seal written after zip build",
    }
    (PACKAGE / "manifest.json").write_text(json.dumps(manifest_pre, indent=2) + "\n", encoding="utf-8")

    verifier_proc = subprocess.run(
        [sys.executable, str(SCRIPTS / "independent_verifier.py"), str(ROOT)],
        capture_output=True,
        text=True,
    )
    (OUTPUTS / "independent-verifier-run.txt").write_text(
        verifier_proc.stdout + verifier_proc.stderr,
        encoding="utf-8",
    )

    classification_pass = (
        test_output["status"] == "pass"
        and invariant_report["status"] == "pass"
        and verifier_proc.returncode == 0
    )

    summary = {
        "classification": metrics["classification"],
        "classification_pass": classification_pass,
        "counts": result.counts(),
        "wer": result.wer(),
        "scoring_tokens_sha256": scoring_sha,
        "test_status": test_output["status"],
        "invariant_status": invariant_report["status"],
        "independent_verifier_exit_code": verifier_proc.returncode,
    }
    (OUTPUTS / "run-summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0 if classification_pass else 1


if __name__ == "__main__":
    raise SystemExit(main())
