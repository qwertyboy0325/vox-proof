#!/usr/bin/env python3
"""Package exploratory v2 scoring artifacts with detached seal."""

from __future__ import annotations

import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
PACKAGE_DIR = ROOT / "package"
STAMP = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
ZIP_NAME = f"voxproof-ami-authoritative-study-2026-07-exploratory-v2-scoring-{STAMP}.zip"
SEAL_NAME = f"package-seal-exploratory-v2-scoring-{STAMP}.json"

EXCLUDE_SUFFIXES = {
    ".zip",
    ".bin",
    ".pyc",
}
EXCLUDE_DIRS = {
    "__pycache__",
    ".git",
    ".venv",
    "venv",
    "node_modules",
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def should_include(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDE_DIRS for part in rel.parts):
        return False
    if path.suffix in EXCLUDE_SUFFIXES:
        return False
    if path.name.startswith("voxproof-") and path.suffix == ".zip":
        return False
    if path.parent == PACKAGE_DIR and path.suffix == ".zip":
        return False
    return True


def collect_files() -> list[Path]:
    files: list[Path] = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        if not should_include(path):
            continue
        files.append(path)
    return files


def build_zip(files: list[Path], zip_path: Path) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in files:
            arcname = str(path.relative_to(ROOT)).replace("\\", "/")
            data = path.read_bytes()
            zf.writestr(arcname, data)
            entries.append(
                {
                    "path": arcname,
                    "sha256": sha256_bytes(data),
                    "bytes": len(data),
                }
            )
    return entries


def verify_zip(zip_path: Path, manifest_path: Path, entries: list[dict[str, Any]]) -> dict[str, Any]:
    zip_sha = sha256_file(zip_path)
    manifest_sha = sha256_file(manifest_path)
    with zipfile.ZipFile(zip_path) as zf:
        names = sorted(zf.namelist())
        embedded_manifest = json.loads(zf.read("package/manifest.json"))
        recomputed = []
        for name in names:
            data = zf.read(name)
            recomputed.append(
                {"path": name, "sha256": sha256_bytes(data), "bytes": len(data)}
            )
    entry_map = {e["path"]: e for e in entries}
    mismatches = []
    for row in recomputed:
        expected = entry_map.get(row["path"])
        if not expected or expected["sha256"] != row["sha256"] or expected["bytes"] != row["bytes"]:
            mismatches.append(row["path"])
    return {
        "zip_sha256": zip_sha,
        "entry_count": len(names),
        "embedded_manifest_sha256": manifest_sha,
        "manifest_matches_embedded": embedded_manifest.get("entry_count") == len(names),
        "entry_hash_mismatches": mismatches,
        "status": "pass" if not mismatches else "fail",
    }


def main() -> int:
    files = collect_files()
    manifest_path = PACKAGE_DIR / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["packaged_files"] = [
        {
            "path": str(p.relative_to(ROOT)).replace("\\", "/"),
            "sha256": sha256_file(p),
            "bytes": p.stat().st_size,
        }
        for p in files
        if p != manifest_path
    ]
    manifest["entry_count"] = len(files)
    manifest["note"] = "manifest embedded without final zip hash; detached seal written after zip build"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    zip_path = PACKAGE_DIR / ZIP_NAME
    entries = build_zip(files, zip_path)
    verification = verify_zip(zip_path, manifest_path, entries)

    seal = {
        "package": "exploratory-v2-scoring",
        "classification": manifest["classification"],
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "zip_filename": ZIP_NAME,
        "zip_sha256": verification["zip_sha256"],
        "entry_count": verification["entry_count"],
        "embedded_manifest_sha256": verification["embedded_manifest_sha256"],
        "entries": entries,
        "verification": verification,
        "c1_zip_sha256": manifest["c1_zip_sha256"],
        "c1_seal_sha256": manifest["c1_seal_sha256"],
        "scoring_tokens_sha256": manifest["scoring_tokens_sha256"],
        "counts": manifest["counts"],
        "wer": manifest["wer"],
        "tie_policy_id": manifest["tie_policy_id"],
    }
    seal_path = PACKAGE_DIR / SEAL_NAME
    seal_path.write_text(json.dumps(seal, indent=2) + "\n", encoding="utf-8")
    seal_sha = sha256_file(seal_path)

    summary = {
        "zip_filename": ZIP_NAME,
        "zip_sha256": verification["zip_sha256"],
        "entry_count": verification["entry_count"],
        "seal_filename": SEAL_NAME,
        "seal_sha256": seal_sha,
        "verification_status": verification["status"],
    }
    (PACKAGE_DIR / "package-summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0 if verification["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
