#!/usr/bin/env python3
"""Parse authoritative vox-proof review stdout into a deterministic inventory."""

from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

CASE_START = re.compile(r"^case_id:\s+local:(\d+)$")
FIELD = re.compile(r"^([a-z_]+):\s*(.*)$")


def parse_cases(stdout: str) -> list[dict[str, object]]:
    cases: list[dict[str, object]] = []
    current: dict[str, object] | None = None
    in_alternatives = False

    for raw_line in stdout.splitlines():
        line = raw_line.rstrip("\n")
        if not line.strip():
            continue

        case_match = CASE_START.match(line)
        if case_match:
            if current is not None:
                cases.append(current)
            current = {"case_id": f"local:{case_match.group(1)}"}
            in_alternatives = False
            continue

        if current is None:
            continue

        if line.startswith("alternatives:"):
            current["alternatives"] = []
            in_alternatives = True
            continue

        if in_alternatives:
            alt_match = re.match(r"^\s+(\d+):\s*(.*)$", line)
            if alt_match:
                current["alternatives"].append(
                    {
                        "index": int(alt_match.group(1)),
                        "replacement_text": alt_match.group(2),
                    }
                )
            continue

        field_match = FIELD.match(line)
        if field_match:
            key, value = field_match.group(1), field_match.group(2)
            current[key] = value
            continue

        if line.startswith("Decision "):
            current["decision_prompt"] = line

    if current is not None:
        cases.append(current)

    return cases


def classify_case(case: dict[str, object]) -> str:
    evidence = str(case.get("evidence", ""))
    if evidence.startswith("glossary alias"):
        return "exact_alias"
    if evidence.startswith("observed error form"):
        return "observed_error_form"
    if evidence.startswith("phonetic similarity"):
        return "phonetic"
    return "unknown"


def parse_phonetic_fields(case: dict[str, object]) -> dict[str, object | None]:
    out: dict[str, object | None] = {
        "observed_surface": None,
        "target_surface": None,
        "target_kind": None,
        "canonical_owner": None,
        "source_normalized_letters": None,
        "source_primary_key": None,
        "source_alternate_key": None,
        "target_normalized_letters": None,
        "target_primary_key": None,
        "target_alternate_key": None,
        "edit_distance": None,
        "ratio_numerator": None,
        "ratio_denominator": None,
        "ratio_permille": None,
        "matched_key": None,
        "detector_config_id": None,
        "detector_config_version": None,
        "algorithm_id": None,
        "algorithm_version": None,
    }

    evidence = str(case.get("evidence", ""))
    phonetic = re.match(
        r"phonetic similarity '([^']*)' -> '([^']*)' \(([^)]*)\) for '([^']*)'",
        evidence,
    )
    if phonetic:
        out["observed_surface"] = phonetic.group(1)
        out["target_surface"] = phonetic.group(2)
        out["target_kind"] = phonetic.group(3)
        out["canonical_owner"] = phonetic.group(4)

    source = str(case.get("phonetic_source", ""))
    source_match = re.match(
        r"normalized='([^']*)' primary='([^']*)' alternate='([^']*)'",
        source,
    )
    if source_match:
        out["source_normalized_letters"] = source_match.group(1)
        out["source_primary_key"] = source_match.group(2)
        out["source_alternate_key"] = source_match.group(3)

    target = str(case.get("phonetic_target", ""))
    target_match = re.match(
        r"normalized='([^']*)' primary='([^']*)' alternate='([^']*)'",
        target,
    )
    if target_match:
        out["target_normalized_letters"] = target_match.group(1)
        out["target_primary_key"] = target_match.group(2)
        out["target_alternate_key"] = target_match.group(3)

    score = str(case.get("phonetic_score", ""))
    score_match = re.match(
        r"distance=(\d+) ratio=(\d+)/(\d+) permille=(\d+) matched_key='([^']*)'",
        score,
    )
    if score_match:
        out["edit_distance"] = int(score_match.group(1))
        out["ratio_numerator"] = int(score_match.group(2))
        out["ratio_denominator"] = int(score_match.group(3))
        out["ratio_permille"] = int(score_match.group(4))
        out["matched_key"] = score_match.group(5)

    identity = str(case.get("phonetic_identity", ""))
    identity_match = re.match(
        r"config=([^/]+)/([^ ]+) algorithm=([^/]+)/(.+)$",
        identity,
    )
    if identity_match:
        out["detector_config_id"] = identity_match.group(1)
        out["detector_config_version"] = identity_match.group(2)
        out["algorithm_id"] = identity_match.group(3)
        out["algorithm_version"] = identity_match.group(4)

    return out


def reference_support(
    case: dict[str, object],
    reference_by_cue: dict[int, str],
) -> dict[str, object]:
    cue_index = case.get("cue_index")
    if cue_index is None:
        return {
            "reference_text": None,
            "reference_supported": None,
            "localization_note": "missing cue_index in prompt block",
        }

    try:
        cue = int(str(cue_index))
    except ValueError:
        return {
            "reference_text": None,
            "reference_supported": None,
            "localization_note": "non-integer cue_index",
        }

    reference_text = reference_by_cue.get(cue)
    if reference_text is None:
        return {
            "reference_text": None,
            "reference_supported": None,
            "localization_note": "cue_index outside reference map",
        }

    canonical_owner = None
    target_surface = None
    evidence = str(case.get("evidence", ""))
    phonetic = re.match(
        r"phonetic similarity '([^']*)' -> '([^']*)' \(([^)]*)\) for '([^']*)'",
        evidence,
    )
    alias = re.match(r"glossary alias '([^']*)' for '([^']*)'", evidence)
    error = re.match(r"observed error form '([^']*)' for '([^']*)'", evidence)
    if phonetic:
        target_surface = phonetic.group(2)
        canonical_owner = phonetic.group(4)
    elif alias:
        target_surface = alias.group(1)
        canonical_owner = alias.group(2)
    elif error:
        target_surface = error.group(1)
        canonical_owner = error.group(2)

    matched_text = str(case.get("matched_text", ""))
    supported = None
    note = None
    if canonical_owner and canonical_owner.lower() in reference_text.lower():
        supported = True
        note = "canonical owner substring present in frozen reference"
    elif target_surface and target_surface.lower() in reference_text.lower():
        supported = True
        note = "target surface substring present in frozen reference"
    elif matched_text and matched_text in reference_text:
        supported = False
        note = "observed surface localized; canonical/target not found as substring"
    else:
        supported = None
        note = "cannot localize deterministically from rendered fields"

    return {
        "reference_text": reference_text,
        "reference_supported": supported,
        "localization_note": note,
    }


def load_reference_by_cue(reference_srt: Path) -> dict[int, str]:
    text = reference_srt.read_text(encoding="utf-8")
    blocks = [block.strip() for block in text.strip().split("\n\n") if block.strip()]
    out: dict[int, str] = {}
    for block in blocks:
        lines = block.splitlines()
        if len(lines) < 3:
            continue
        cue_index = int(lines[0])
        out[cue_index] = "\n".join(lines[2:])
    return out


def summarize(cases: list[dict[str, object]]) -> dict[str, object]:
    kinds = {"exact_alias": 0, "observed_error_form": 0, "phonetic": 0, "unknown": 0}
    anchors: list[str] = []
    for case in cases:
        kind = classify_case(case)
        kinds[kind] += 1
        anchor = f"{case.get('source_segment_position')}:{case.get('matched_text')}"
        anchors.append(anchor)

    duplicate_anchors = sorted(
        {a for a in anchors if anchors.count(a) > 1}
    )

    return {
        "total_review_cases": len(cases),
        "exact_alias_count": kinds["exact_alias"],
        "observed_error_form_count": kinds["observed_error_form"],
        "phonetic_count": kinds["phonetic"],
        "unknown_count": kinds["unknown"],
        "unique_anchors": len(set(anchors)),
        "duplicate_anchors": duplicate_anchors,
    }


def main() -> None:
    stdout_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    reference_srt = Path(sys.argv[3])

    stdout = stdout_path.read_text(encoding="utf-8")
    reference_by_cue = load_reference_by_cue(reference_srt)
    parsed_cases = parse_cases(stdout)

    inventory_cases: list[dict[str, object]] = []
    for case in parsed_cases:
        kind = classify_case(case)
        item: dict[str, object] = {
            "case_id": case.get("case_id"),
            "source_segment_position": case.get("source_segment_position"),
            "cue_index": case.get("cue_index"),
            "previous_cue_index": case.get("previous_cue_index"),
            "previous_cue_text": case.get("previous_cue_text"),
            "cue_text": case.get("cue_text"),
            "following_cue_index": case.get("following_cue_index"),
            "following_cue_text": case.get("following_cue_text"),
            "matched_text": case.get("matched_text"),
            "evidence_kind": kind,
            "evidence": case.get("evidence"),
            "alternatives": case.get("alternatives", []),
            "detector_id": None,
            "detector_version": None,
            "notes": [
                "detector_id/version are not rendered by authoritative review prompts; left null"
            ],
        }
        if kind == "phonetic":
            item.update(parse_phonetic_fields(case))
        item.update(reference_support(case, reference_by_cue))
        inventory_cases.append(item)

    payload = {
        "parser_path": str(Path(__file__).resolve()),
        "parser_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "source_stdout": str(stdout_path),
        "summary": summarize(inventory_cases),
        "cases": inventory_cases,
    }
    output_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
