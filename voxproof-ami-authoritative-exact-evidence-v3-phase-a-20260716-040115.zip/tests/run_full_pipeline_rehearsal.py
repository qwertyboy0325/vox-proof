#!/usr/bin/env python3
"""Run both exact fixture chronologies and retain only a compact audit record."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

from test_correction_rehearsals import FixtureStudy

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    runs = []
    for name, nonzero in (("zero-candidate", False), ("nonzero-accept", True)):
        with tempfile.TemporaryDirectory(prefix=f"voxproof-{name}-") as tmp:
            fixture = FixtureStudy(Path(tmp), nonzero=nonzero)
            fixture.setup()
            metrics = fixture.run_full()
            state = json.loads(
                (fixture.root / "phase-b/stage-state.json").read_text(encoding="utf-8")
            )
            package_summary = state["last_detail"]
            runs.append(
                {
                    "name": name,
                    "status": "pass",
                    "runner_stages": state["completed"],
                    "candidate_count": metrics["candidate_precision"]["denominator"],
                    "raw_wer": metrics["raw_wer"],
                    "reviewed_wer": metrics["reviewed_wer"],
                    "wer_delta": metrics["raw_to_reviewed_wer_delta"],
                    "phase_b_package_sha256": package_summary["zip_sha256"],
                    "phase_b_package_entry_count": package_summary["entry_count"],
                }
            )
    output = {
        "schema_revision": "voxproof-ami-full-fixture-rehearsal-v1",
        "fixture_only": True,
        "es2004b_content_opened": False,
        "exact_runner_chronology": [
            "preflight",
            "build-binary",
            "hypothesis",
            "probe-candidates",
            "reference",
            "validate-review-inputs",
            "authoritative-review",
            "score",
            "independent-verify",
            "package",
        ],
        "runs": runs,
    }
    path = ROOT / "outputs/full-pipeline-rehearsal.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
