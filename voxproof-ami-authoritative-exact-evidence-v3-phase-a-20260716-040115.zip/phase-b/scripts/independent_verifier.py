#!/usr/bin/env python3
"""Independent alignment verification without importing primary backtrace."""

from __future__ import annotations

import json
import sys
import csv
from pathlib import Path
from typing import Any


def independent_edit_distance(reference: list[str], hypothesis: list[str]) -> int:
    n = len(reference)
    m = len(hypothesis)
    previous = list(range(m + 1))
    for i in range(1, n + 1):
        current = [i]
        ref_token = reference[i - 1]
        for j in range(1, m + 1):
            cost_substitution = 0 if ref_token == hypothesis[j - 1] else 1
            current.append(
                min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost_substitution)
            )
        previous = current
    return previous[m]


def independent_backtrace_alternate_tie(
    reference: list[str], hypothesis: list[str]
) -> dict[str, int]:
    n = len(reference)
    m = len(hypothesis)
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        dp[i][0] = i
    for j in range(1, m + 1):
        dp[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if reference[i - 1] == hypothesis[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = 1 + min(dp[i - 1][j - 1], dp[i][j - 1], dp[i - 1][j])
    counts = {"match": 0, "substitution": 0, "deletion": 0, "insertion": 0}
    i = n
    j = m
    while i > 0 or j > 0:
        current = dp[i][j]
        if i > 0 and j > 0 and reference[i - 1] == hypothesis[j - 1] and current == dp[i - 1][j - 1]:
            counts["match"] += 1
            i -= 1
            j -= 1
            continue
        candidates: list[tuple[str, int, int]] = []
        if i > 0 and j > 0 and current == dp[i - 1][j - 1] + 1:
            candidates.append(("substitution", i - 1, j - 1))
        if i > 0 and current == dp[i - 1][j] + 1:
            candidates.append(("deletion", i - 1, j))
        if j > 0 and current == dp[i][j - 1] + 1:
            candidates.append(("insertion", i, j - 1))
        if not candidates:
            raise ValueError(f"alternate backtrace failed at ({i},{j})")
        op, ni, nj = candidates[0]
        counts[op] += 1
        i, j = ni, nj
    n_ref = len(reference)
    h_hyp = len(hypothesis)
    m_count = counts["match"]
    s_count = counts["substitution"]
    d_count = counts["deletion"]
    ins_count = counts["insertion"]
    if m_count + s_count + d_count != n_ref:
        raise ValueError("alternate decomposition failed M+S+D=N")
    if m_count + s_count + ins_count != h_hyp:
        raise ValueError("alternate decomposition failed M+S+I=H")
    if h_hyp != n_ref - d_count + ins_count:
        raise ValueError("alternate decomposition failed H=N-D+I")
    if dp[n][m] != s_count + d_count + ins_count:
        raise ValueError("alternate decomposition failed edit distance")
    counts["edit_distance"] = dp[n][m]
    counts["N_reference"] = n_ref
    counts["H_hypothesis"] = h_hyp
    counts["matches"] = counts.pop("match")
    counts["substitutions"] = counts.pop("substitution")
    counts["deletions"] = counts.pop("deletion")
    counts["insertions"] = counts.pop("insertion")
    return counts


def verify_operations(
    path: Path,
    reference: list[str],
    hypothesis: list[str],
    expected: dict[str, int],
) -> list[str]:
    errors: list[str] = []
    rows = list(csv.DictReader(path.open(encoding="utf-8"), delimiter="\t"))
    reconstructed_reference: list[str] = []
    reconstructed_hypothesis: list[str] = []
    counts = {"match": 0, "substitution": 0, "deletion": 0, "insertion": 0}
    ref_pos = hyp_pos = 0
    for ordinal, row in enumerate(rows):
        operation = row["operation"]
        if int(row["ordinal"]) != ordinal or operation not in counts:
            errors.append(f"{path.name}: invalid ordinal/operation at {ordinal}")
            continue
        if int(row["reference_coord_before"]) != ref_pos:
            errors.append(f"{path.name}: reference coordinate discontinuity at {ordinal}")
        if int(row["hypothesis_coord_before"]) != hyp_pos:
            errors.append(f"{path.name}: hypothesis coordinate discontinuity at {ordinal}")
        reference_token = row["reference_token"] or None
        hypothesis_token = row["hypothesis_token"] or None
        if operation in {"match", "substitution", "deletion"}:
            reconstructed_reference.append(reference_token or "")
            ref_pos += 1
        if operation in {"match", "substitution", "insertion"}:
            reconstructed_hypothesis.append(hypothesis_token or "")
            hyp_pos += 1
        if operation == "match" and reference_token != hypothesis_token:
            errors.append(f"{path.name}: unequal match at {ordinal}")
        if operation == "substitution" and reference_token == hypothesis_token:
            errors.append(f"{path.name}: equal substitution at {ordinal}")
        counts[operation] += 1
    if reconstructed_reference != reference:
        errors.append(f"{path.name}: reconstructed reference mismatch")
    if reconstructed_hypothesis != hypothesis:
        errors.append(f"{path.name}: reconstructed hypothesis mismatch")
    derived = {
        "N_reference": len(reference),
        "H_hypothesis": len(hypothesis),
        "matches": counts["match"],
        "substitutions": counts["substitution"],
        "deletions": counts["deletion"],
        "insertions": counts["insertion"],
        "edit_distance": counts["substitution"] + counts["deletion"] + counts["insertion"],
    }
    if derived != expected:
        errors.append(f"{path.name}: operation counts mismatch")
    if derived["matches"] + derived["substitutions"] + derived["deletions"] != len(reference):
        errors.append(f"{path.name}: M+S+D != N")
    if derived["matches"] + derived["substitutions"] + derived["insertions"] != len(hypothesis):
        errors.append(f"{path.name}: M+S+I != H")
    return errors


def verify_study_root(study_root: Path) -> dict[str, Any]:
    phase_b = study_root / "phase-b"
    scoring_path = phase_b / "build-primary/scoring_tokens.json"
    alignment_path = phase_b / "alignment-audit.json"
    metrics_path = phase_b / "metrics.json"
    errors: list[str] = []
    scoring = json.loads(scoring_path.read_text(encoding="utf-8"))
    alignment = json.loads(alignment_path.read_text(encoding="utf-8"))
    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    reference = list(scoring["reference_tokens"])
    streams = {
        "raw": list(scoring["hypothesis_tokens"]),
        "reviewed": list(alignment["reviewed_tokens"]),
    }
    for name, hypothesis in streams.items():
        audit = alignment[name]
        counts = audit["counts"]
        independent = independent_backtrace_alternate_tie(reference, hypothesis)
        if independent != counts:
            errors.append(f"{name}: independent decomposition mismatch")
        if independent_edit_distance(reference, hypothesis) != counts["edit_distance"]:
            errors.append(f"{name}: independent edit distance mismatch")
        expected_wer = None if not reference else counts["edit_distance"] / len(reference)
        if audit["wer"] != expected_wer:
            errors.append(f"{name}: scalar WER mismatch")
        errors.extend(
            verify_operations(
                phase_b / f"{name}-alignment-operations.tsv",
                reference,
                hypothesis,
                counts,
            )
        )
    if metrics.get("alignment") != {
        key: alignment[key] for key in ("raw", "reviewed", "raw_to_reviewed_wer_delta")
    }:
        errors.append("metrics alignment audit disagreement")
    inventory = json.loads((phase_b / "probe/candidate-inventory.json").read_text())
    binding = json.loads(
        (phase_b / "review/authoritative-review-binding.json").read_text()
    )
    if not binding.get("reproduction_verified"):
        errors.append("review reproduction not verified")
    for field in ("binary_sha256", "transcript_revision", "candidate_count"):
        if binding.get(field) != inventory.get(field):
            errors.append(f"inventory/review binding mismatch: {field}")
    if binding.get("candidate_sequence_sha256") != inventory.get(
        "candidate_sequence_sha256"
    ):
        errors.append("inventory/review candidate sequence mismatch")
    return {
        "status": "pass" if not errors else "fail",
        "errors": errors,
        "raw_independent_distance": independent_edit_distance(reference, streams["raw"]),
        "reviewed_independent_distance": independent_edit_distance(
            reference, streams["reviewed"]
        ),
        "ordering_policy": scoring.get("ordering_policy"),
        "study_root": str(study_root),
    }


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: independent_verifier.py <study_root>", file=sys.stderr)
        return 2
    study_root = Path(sys.argv[1]).resolve()
    out = verify_study_root(study_root)
    output_path = study_root / "phase-b/reports/independent-verifier-output.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(out, indent=2))
    return 0 if out["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
