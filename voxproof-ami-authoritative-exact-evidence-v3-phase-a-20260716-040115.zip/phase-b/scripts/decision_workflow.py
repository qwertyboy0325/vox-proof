#!/usr/bin/env python3
"""Joint human-review input validation against frozen inventory/reference layers."""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from common import read_json, sha256_file  # noqa: E402

ALLOWED_DECISION_RE = re.compile(r"^(a \d+|r|d|m)$")
POLICIES = {
    "normalization_policy_id": "unicode-nfc-casefold-remove-punctuation-v1",
    "overlap_policy_id": "localized-time-and-cue-overlap-one-to-one-v1",
    "acceptable_variant_policy_id": "acceptable-variants-are-not-opportunities-v1",
}


def validate_reviewer(payload: dict[str, Any], prefix: str) -> list[str]:
    errors: list[str] = []
    reviewer = payload.get("reviewer")
    if not isinstance(reviewer, dict):
        return [f"{prefix}.reviewer missing"]
    for field in ("reviewer_id", "display_name", "attested_at_utc", "attestation"):
        if not isinstance(reviewer.get(field), str) or not reviewer[field].strip():
            errors.append(f"{prefix}.reviewer.{field} missing")
    return errors


def validate_ground_truth(
    payload: dict[str, Any], reference_layer_sha256: str
) -> list[str]:
    errors = validate_reviewer(payload, "ground_truth")
    if payload.get("reference_layer_sha256") != reference_layer_sha256:
        errors.append("ground_truth reference_layer_sha256 mismatch")
    for field, expected in POLICIES.items():
        if payload.get(field) != expected:
            errors.append(f"ground_truth {field} mismatch")
    seen: set[str] = set()
    for idx, opp in enumerate(payload.get("opportunities", [])):
        for key in (
            "opportunity_id",
            "canonical_term",
            "source_rendering",
            "speaker",
            "cue_index",
            "start",
            "end",
            "reference_token_ids",
            "acceptable_variant",
            "support_rationale",
        ):
            if key not in opp:
                errors.append(f"opportunity[{idx}] missing {key}")
        opportunity_id = opp.get("opportunity_id")
        if opportunity_id in seen:
            errors.append(f"duplicate opportunity_id {opportunity_id}")
        seen.add(opportunity_id)
        if opp.get("acceptable_variant") is not False:
            errors.append(f"opportunity[{idx}] acceptable_variant must be false")
        if not opp.get("reference_token_ids"):
            errors.append(f"opportunity[{idx}] requires localized reference token ids")
    return errors


def validate_decision_inputs(
    payload: dict[str, Any],
    inventory: dict[str, Any],
) -> list[str]:
    errors: list[str] = []
    errors.extend(validate_reviewer(payload, "decision_inputs"))
    if payload.get("transcript_revision") != inventory.get("transcript_revision"):
        errors.append("decision transcript_revision mismatch with inventory")
    decisions = payload.get("decisions", [])
    candidates = inventory.get("candidates", [])
    if len(decisions) != len(candidates):
        errors.append(
            f"decision count {len(decisions)} != candidate count {len(candidates)}"
        )
    fingerprints = payload.get("candidate_fingerprints", [])
    if fingerprints != [c.get("fingerprint") for c in candidates]:
        errors.append("candidate_fingerprints do not match frozen inventory order")
    for idx, decision in enumerate(decisions):
        if not ALLOWED_DECISION_RE.match(decision):
            errors.append(f"invalid decision syntax at index {idx}: {decision!r}")
        if decision.startswith("a "):
            alt_index = int(decision.split()[1])
            alts = candidates[idx].get("alternatives", [])
            if alt_index >= len(alts):
                errors.append(f"accept index out of range at {idx}")
    return errors


def validate_candidate_labels(
    payload: dict[str, Any],
    inventory: dict[str, Any],
    ground_truth: dict[str, Any],
    reference_layer_sha256: str,
) -> list[str]:
    errors = validate_reviewer(payload, "candidate_labels")
    if payload.get("reference_layer_sha256") != reference_layer_sha256:
        errors.append("candidate_labels reference_layer_sha256 mismatch")
    labels = payload.get("labels", [])
    if len(labels) != inventory.get("candidate_count", 0):
        errors.append("label count mismatch")
    opportunity_ids = {o["opportunity_id"] for o in ground_truth.get("opportunities", [])}
    matched: set[str] = set()
    for idx, label in enumerate(labels):
        if "candidate_fingerprint" not in label:
            errors.append(f"label[{idx}] missing candidate_fingerprint")
        elif label["candidate_fingerprint"] != inventory["candidates"][idx]["fingerprint"]:
            errors.append(f"label[{idx}] fingerprint mismatch")
        if label.get("classification") not in {"selected_true", "selected_false"}:
            errors.append(f"label[{idx}] invalid classification")
        opportunity = label.get("matched_opportunity_id")
        if label.get("classification") == "selected_true":
            if opportunity not in opportunity_ids:
                errors.append(f"label[{idx}] missing/unknown opportunity id")
            elif opportunity in matched:
                errors.append(f"duplicate one-to-one opportunity match: {opportunity}")
            else:
                matched.add(opportunity)
        elif opportunity is not None:
            errors.append(f"label[{idx}] false candidate must not match opportunity")
        for field in (
            "replacement_supported",
            "boundary_supported",
            "materialized_correctly_if_accepted",
            "unsafe_if_accepted",
            "unsafe_edit_rationale",
        ):
            if field not in label:
                errors.append(f"label[{idx}] missing {field}")
    return errors


def validate_review_inputs(
    *,
    ground_truth: dict[str, Any],
    labels: dict[str, Any],
    decisions: dict[str, Any],
    inventory: dict[str, Any],
    reference_layer_path: Path,
) -> list[str]:
    reference_hash = sha256_file(reference_layer_path)
    errors = validate_ground_truth(ground_truth, reference_hash)
    errors.extend(
        validate_candidate_labels(labels, inventory, ground_truth, reference_hash)
    )
    errors.extend(validate_decision_inputs(decisions, inventory))
    reviewer_ids = {
        payload.get("reviewer", {}).get("reviewer_id")
        for payload in (ground_truth, labels, decisions)
    }
    if len(reviewer_ids) != 1:
        errors.append("designated human reviewer identity differs across inputs")
    for payload_name, payload in (
        ("candidate_labels", labels),
        ("decision_inputs", decisions),
    ):
        if payload.get("inventory_sha256") != sha256_file(
            Path(inventory["_inventory_path"])
        ):
            errors.append(f"{payload_name} inventory_sha256 mismatch")
    return errors


def render_stdin_decisions(decisions: list[str]) -> str:
    return "\n".join(decisions) + ("\n" if decisions else "")


def main() -> int:
    import argparse
    import json

    parser = argparse.ArgumentParser(description="Validate human-authored review inputs")
    sub = parser.add_subparsers(dest="command", required=True)
    gt = sub.add_parser("validate-ground-truth")
    gt.add_argument("--ground-truth", required=True)
    di = sub.add_parser("validate-decisions")
    di.add_argument("--decision-inputs", required=True)
    di.add_argument("--inventory", required=True)
    cl = sub.add_parser("validate-labels")
    cl.add_argument("--labels", required=True)
    cl.add_argument("--inventory", required=True)
    cl.add_argument("--ground-truth", required=True)
    render = sub.add_parser("render-stdin")
    render.add_argument("--decision-inputs", required=True)
    combined = sub.add_parser("validate-review-inputs")
    combined.add_argument("--ground-truth", required=True)
    combined.add_argument("--labels", required=True)
    combined.add_argument("--decision-inputs", required=True)
    combined.add_argument("--inventory", required=True)
    combined.add_argument("--reference-layer", required=True)
    args = parser.parse_args()

    if args.command == "validate-ground-truth":
        errors = validate_ground_truth(read_json(Path(args.ground_truth)), "")
    elif args.command == "validate-decisions":
        inventory = read_json(Path(args.inventory))
        errors = validate_decision_inputs(read_json(Path(args.decision_inputs)), inventory)
    elif args.command == "validate-labels":
        errors = validate_candidate_labels(
            read_json(Path(args.labels)),
            read_json(Path(args.inventory)),
            read_json(Path(args.ground_truth)),
            "",
        )
    elif args.command == "render-stdin":
        decisions = read_json(Path(args.decision_inputs))["decisions"]
        sys.stdout.write(render_stdin_decisions(decisions))
        return 0
    else:
        inventory_path = Path(args.inventory)
        inventory = read_json(inventory_path)
        inventory["_inventory_path"] = str(inventory_path)
        errors = validate_review_inputs(
            ground_truth=read_json(Path(args.ground_truth)),
            labels=read_json(Path(args.labels)),
            decisions=read_json(Path(args.decision_inputs)),
            inventory=inventory,
            reference_layer_path=Path(args.reference_layer),
        )

    status = "pass" if not errors else "fail"
    print(json.dumps({"status": status, "errors": errors}, indent=2))
    return 0 if status == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
