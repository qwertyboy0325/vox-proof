#!/usr/bin/env python3
"""Frozen fail-closed V3 Phase B runner; all target stages execute here."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from alignment_scorer import align_tokens, write_operations_tsv  # noqa: E402
from ami_common import srt_scoring_stream  # noqa: E402
from ami_transform import build_hypothesis_layers, build_reference_layers  # noqa: E402
from binary_gate import build_isolated_binary, load_attestation, verify_repository_head  # noqa: E402
from candidate_capture import run_authoritative_review, run_candidate_probe  # noqa: E402
from common import fail_record, read_json, sha256_file, utc_now, write_json  # noqa: E402
from decision_workflow import validate_review_inputs  # noqa: E402
from independent_verifier import verify_study_root  # noqa: E402
from metrics import compute_study_metrics  # noqa: E402
from package_builder import build_package  # noqa: E402
from package_verifier import verify_package  # noqa: E402
from study_config import (  # noqa: E402
    AUTO_ZIP,
    BINARY_ATTESTATION_PATH,
    BUILD_ROOT,
    FAILURES_ROOT,
    FIXTURE_MODE,
    ISOLATED_BINARY,
    MANUAL_ZIP,
    MEETING_ID,
    PACKAGE_ROOT,
    PHASE_B_DIR,
    PROBE_ROOT,
    PROTOCOL_ID,
    REPORTS_ROOT,
    REPO_ROOT,
    REVIEW_ROOT,
    SCRIPT_LOCK_PATH,
    SCRIPT_NAMES,
    SOURCE_LOCK_PATH,
    STAGE_STATE_PATH,
    STUDY_ROOT,
    TERMS_PATH,
    WINDOW_END,
    WINDOW_START,
)

TARGET_STAGES = (
    "hypothesis",
    "probe-candidates",
    "reference",
    "validate-review-inputs",
    "authoritative-review",
    "score",
    "independent-verify",
    "package",
)
PREREQUISITE = {
    "build-binary": "preflight",
    "hypothesis": "build-binary",
    "probe-candidates": "hypothesis",
    "reference": "probe-candidates",
    "validate-review-inputs": "reference",
    "authoritative-review": "validate-review-inputs",
    "score": "authoritative-review",
    "independent-verify": "score",
    "package": "independent-verify",
}


def initial_state() -> dict[str, Any]:
    return {
        "schema_revision": "voxproof-ami-stage-state-v2",
        "completed": [],
        "access_gate_crossed": False,
        "terminal_failed": False,
        "failure_record": None,
    }


def load_state() -> dict[str, Any]:
    return read_json(STAGE_STATE_PATH) if STAGE_STATE_PATH.exists() else initial_state()


def save_state(state: dict[str, Any]) -> None:
    write_json(STAGE_STATE_PATH, state)


def persistent_failure(stage: str, error: Exception) -> None:
    state = load_state()
    FAILURES_ROOT.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-%f")
    failure_dir = FAILURES_ROOT / f"{stamp}-{stage}"
    failure_dir.mkdir()
    record = fail_record(stage, "stage_execution", str(error), [str(failure_dir)])
    write_json(failure_dir / "failure-record.json", record)
    if state.get("access_gate_crossed"):
        state["terminal_failed"] = True
        state["failure_record"] = str(failure_dir / "failure-record.json")
        save_state(state)


def gate(stage: str) -> dict[str, Any]:
    state = load_state()
    if state.get("terminal_failed"):
        raise RuntimeError(f"terminal failed state: {state.get('failure_record')}")
    if stage in state["completed"]:
        raise RuntimeError(f"stage rerun forbidden: {stage}")
    required = PREREQUISITE.get(stage)
    if required and required not in state["completed"]:
        raise RuntimeError(f"stage {stage} requires {required}")
    if stage == "hypothesis":
        if state["access_gate_crossed"]:
            raise RuntimeError("target access gate already crossed")
        state["access_gate_crossed"] = True
        state["access_gate_crossed_at_utc"] = utc_now()
        save_state(state)  # persist before opening any target ASR content
    return state


def complete(stage: str, detail: dict[str, Any]) -> dict[str, Any]:
    state = load_state()
    state["completed"].append(stage)
    state["last_stage"] = stage
    state["last_detail"] = detail
    state["updated_at_utc"] = utc_now()
    save_state(state)
    return detail


def run_stage(stage: str, action: Callable[[], dict[str, Any]]) -> dict[str, Any]:
    try:
        gate(stage)
        return complete(stage, action())
    except Exception as error:
        persistent_failure(stage, error)
        raise


def verify_script_lock() -> list[dict[str, Any]]:
    lock = read_json(SCRIPT_LOCK_PATH)
    rows = lock.get("scripts", [])
    expected_paths = {f"phase-b/scripts/{name}" for name in SCRIPT_NAMES}
    actual_paths = {row.get("path") for row in rows}
    if actual_paths != expected_paths or len(rows) != len(expected_paths):
        raise RuntimeError("script lock exact set mismatch")
    for row in rows:
        path = STUDY_ROOT / row["path"]
        if not path.is_file():
            raise RuntimeError(f"locked script missing: {row['path']}")
        if path.stat().st_size != row["bytes"] or sha256_file(path) != row["sha256"]:
            raise RuntimeError(f"locked script mutated: {row['path']}")
    return rows


def preflight_action() -> dict[str, Any]:
    verify_repository_head()
    source = read_json(SOURCE_LOCK_PATH)
    if source.get("protocol_id") != PROTOCOL_ID:
        raise RuntimeError("protocol id mismatch")
    if source.get("meeting_id") != MEETING_ID:
        raise RuntimeError("meeting id mismatch")
    expected_window = {
        "start_inclusive": str(WINDOW_START),
        "end_exclusive": str(WINDOW_END),
    }
    if source.get("window") != expected_window:
        raise RuntimeError("window mismatch")
    archive_by_name = {row["name"]: row for row in source["archives"]}
    for path, name in (
        (AUTO_ZIP, "ami_public_auto_1.5.1.zip"),
        (MANUAL_ZIP, "ami_public_manual_1.6.2.zip"),
    ):
        row = archive_by_name[name]
        if path.stat().st_size != row["bytes"] or sha256_file(path) != row["sha256"]:
            raise RuntimeError(f"archive hash/bytes mismatch: {name}")
    if sha256_file(TERMS_PATH) != source["session_terms_sha256"]:
        raise RuntimeError("session terms hash mismatch")
    if sha256_file(REPO_ROOT / "Cargo.lock") != source["repository"]["cargo_lock_sha256"]:
        raise RuntimeError("Cargo.lock hash mismatch")
    scripts = verify_script_lock()
    return {
        "script_count": len(scripts),
        "archives_verified": 2,
        "fixture_mode": FIXTURE_MODE,
    }


def build_binary_action() -> dict[str, Any]:
    _, attestation = build_isolated_binary(force_rebuild=True)
    return {
        "binary_path": attestation["binary_path"],
        "binary_sha256": attestation["binary_sha256"],
    }


def hypothesis_action() -> dict[str, Any]:
    manifest = build_hypothesis_layers(AUTO_ZIP, BUILD_ROOT)
    return {"layer_manifest_sha256": sha256_file(BUILD_ROOT / "layer_manifest.json"), **manifest}


def probe_action() -> dict[str, Any]:
    inventory = run_candidate_probe(
        binary=ISOLATED_BINARY,
        attestation=load_attestation(),
        input_srt=BUILD_ROOT / "input.srt",
        terms_path=TERMS_PATH,
        output_dir=PROBE_ROOT,
    )
    return {
        "candidate_count": inventory["candidate_count"],
        "candidate_inventory_sha256": sha256_file(PROBE_ROOT / "candidate-inventory.json"),
    }


def reference_action() -> dict[str, Any]:
    inventory_path = PROBE_ROOT / "candidate-inventory.json"
    inventory_hash = sha256_file(inventory_path)
    state = load_state()
    state["candidate_inventory_sha256_before_reference_access"] = inventory_hash
    state["manual_reference_opened_at_utc"] = utc_now()
    save_state(state)  # hash is durable before first manual-content read
    manifest = build_reference_layers(MANUAL_ZIP, BUILD_ROOT, inventory_hash)
    return {
        "reference_layer_sha256": sha256_file(
            BUILD_ROOT / "reference-layer-manifest.json"
        ),
        **manifest,
    }


def review_input_paths() -> tuple[Path, Path, Path]:
    return (
        REVIEW_ROOT / "ground-truth.json",
        REVIEW_ROOT / "candidate-labels.json",
        REVIEW_ROOT / "decision-inputs.json",
    )


def validate_review_action() -> dict[str, Any]:
    ground_path, labels_path, decisions_path = review_input_paths()
    inventory_path = PROBE_ROOT / "candidate-inventory.json"
    inventory = read_json(inventory_path)
    inventory["_inventory_path"] = str(inventory_path)
    errors = validate_review_inputs(
        ground_truth=read_json(ground_path),
        labels=read_json(labels_path),
        decisions=read_json(decisions_path),
        inventory=inventory,
        reference_layer_path=BUILD_ROOT / "reference-layer-manifest.json",
    )
    report = {
        "schema_revision": "voxproof-ami-review-input-validation-v1",
        "status": "pass" if not errors else "fail",
        "errors": errors,
        "ground_truth_sha256": sha256_file(ground_path),
        "candidate_labels_sha256": sha256_file(labels_path),
        "decision_inputs_sha256": sha256_file(decisions_path),
    }
    write_json(REVIEW_ROOT / "review-input-validation.json", report)
    if errors:
        raise RuntimeError("; ".join(errors))
    return report


def authoritative_review_action() -> dict[str, Any]:
    inventory = read_json(PROBE_ROOT / "candidate-inventory.json")
    decisions = read_json(REVIEW_ROOT / "decision-inputs.json")["decisions"]
    human_files = {
        name: (REVIEW_ROOT / name).read_bytes()
        for name in ("ground-truth.json", "candidate-labels.json", "decision-inputs.json")
    }
    staging = REVIEW_ROOT.with_name("review-output")
    binding = run_authoritative_review(
        binary=ISOLATED_BINARY,
        attestation=load_attestation(),
        input_srt=BUILD_ROOT / "input.srt",
        terms_path=TERMS_PATH,
        decisions=decisions,
        frozen_inventory=inventory,
        canonical_output_dir=staging,
        failure_root=FAILURES_ROOT,
    )
    for name, data in human_files.items():
        (staging / name).write_bytes(data)
    validation = REVIEW_ROOT / "review-input-validation.json"
    (staging / validation.name).write_bytes(validation.read_bytes())
    if REVIEW_ROOT.exists():
        for path in REVIEW_ROOT.iterdir():
            path.unlink()
        REVIEW_ROOT.rmdir()
    staging.replace(REVIEW_ROOT)
    return binding


def score_action() -> dict[str, Any]:
    scoring = read_json(BUILD_ROOT / "scoring_tokens.json")
    reference = list(scoring["reference_tokens"])
    raw_tokens = list(scoring["hypothesis_tokens"])
    reviewed_tokens = srt_scoring_stream(REVIEW_ROOT / "reviewed-output.srt")
    raw = align_tokens(reference, raw_tokens)
    reviewed = align_tokens(reference, reviewed_tokens)
    write_operations_tsv(PHASE_B_DIR / "raw-alignment-operations.tsv", raw)
    write_operations_tsv(PHASE_B_DIR / "reviewed-alignment-operations.tsv", reviewed)
    alignment = {
        "schema_revision": "voxproof-ami-alignment-audit-v1",
        "tie_policy_id": raw.tie_policy_id,
        "ordering_policy": scoring["ordering_policy"],
        "raw": {"counts": raw.counts(), "wer": raw.wer()},
        "reviewed": {"counts": reviewed.counts(), "wer": reviewed.wer()},
        "reviewed_tokens": reviewed_tokens,
        "raw_to_reviewed_wer_delta": (
            None
            if raw.wer() is None or reviewed.wer() is None
            else reviewed.wer() - raw.wer()
        ),
    }
    write_json(PHASE_B_DIR / "alignment-audit.json", alignment)
    ground = read_json(REVIEW_ROOT / "ground-truth.json")
    labels = read_json(REVIEW_ROOT / "candidate-labels.json")
    decisions = read_json(REVIEW_ROOT / "decision-inputs.json")
    inventory = read_json(PROBE_ROOT / "candidate-inventory.json")
    metrics = compute_study_metrics(
        inventory=inventory,
        ground_truth=ground,
        labels=labels["labels"],
        decisions=decisions["decisions"],
        alignment_audit=alignment,
    )
    write_json(PHASE_B_DIR / "metrics.json", metrics)
    return {
        "raw_wer": raw.wer(),
        "reviewed_wer": reviewed.wer(),
        "delta": alignment["raw_to_reviewed_wer_delta"],
    }


def independent_action() -> dict[str, Any]:
    result = verify_study_root(STUDY_ROOT)
    REPORTS_ROOT.mkdir(parents=True, exist_ok=True)
    write_json(REPORTS_ROOT / "independent-verifier-output.json", result)
    if result["status"] != "pass":
        raise RuntimeError("; ".join(result["errors"]))
    return result


def package_action() -> dict[str, Any]:
    summary = build_package(
        root=STUDY_ROOT,
        output_dir=PACKAGE_ROOT,
        mode="phase-b",
        name_suffix="final",
    )
    verified = verify_package(
        STUDY_ROOT,
        Path(summary["zip_path"]),
        Path(summary["seal_path"]),
        "phase-b",
    )
    write_json(REPORTS_ROOT / "package-verification-output.json", verified)
    if verified["status"] != "pass":
        raise RuntimeError("; ".join(verified["errors"]))
    return summary


ACTIONS: dict[str, Callable[[], dict[str, Any]]] = {
    "preflight": preflight_action,
    "build-binary": build_binary_action,
    "hypothesis": hypothesis_action,
    "probe-candidates": probe_action,
    "reference": reference_action,
    "validate-review-inputs": validate_review_action,
    "authoritative-review": authoritative_review_action,
    "score": score_action,
    "independent-verify": independent_action,
    "package": package_action,
}


def self_check_commands() -> dict[str, Any]:
    missing = [name for name in ACTIONS if name not in ACTIONS]
    required_scripts = [
        "phase_b_runner.py",
        "ami_transform.py",
        "candidate_capture.py",
        "decision_workflow.py",
        "alignment_scorer.py",
        "independent_verifier.py",
        "package_builder.py",
        "package_verifier.py",
    ]
    missing += [name for name in required_scripts if not (SCRIPT_DIR / name).is_file()]
    return {"status": "pass" if not missing else "fail", "missing": missing, "stages": list(ACTIONS)}


def main() -> int:
    parser = argparse.ArgumentParser(description="V3 Phase B exact stage runner")
    parser.add_argument("stage", choices=[*ACTIONS, "self-check-commands"])
    args = parser.parse_args()
    try:
        result = (
            self_check_commands()
            if args.stage == "self-check-commands"
            else run_stage(args.stage, ACTIONS[args.stage])
        )
    except Exception as error:
        print(json.dumps({"status": "fail", "stage": args.stage, "error": str(error)}, indent=2))
        return 1
    print(json.dumps({"status": "pass", "stage": args.stage, "result": result}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
