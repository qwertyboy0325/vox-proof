#!/usr/bin/env python3
"""Strict deterministic AMI parsing and scoring-stream utilities."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR
from pathlib import Path
from typing import Any

from study_config import (
    MEETING_ID,
    ORDERING_POLICY_ID,
    SPEAKERS,
    WINDOW_END,
    WINDOW_START,
)

NITE_NS = "{http://nite.sourceforge.net/}"
HREF_RE = re.compile(r"^.*#id\(([^)]+)\)\.\.id\(([^)]+)\)$")
ALLOWED_ASR_TAGS = {"w", "sil"}
ALLOWED_MANUAL_TAGS = {"w", "disfmarker", "gap", "vocalsound"}
MANUAL_EVENT_TAGS = ALLOWED_MANUAL_TAGS - {"w"}
ORDERING_POLICY = {
    "policy_id": ORDERING_POLICY_ID,
    "primary_key": "token_midpoint_seconds",
    "tie_breakers": ["speaker_channel", "element_id"],
    "speaker_channel_order": list(SPEAKERS),
}


@dataclass(frozen=True)
class Token:
    speaker: str
    member: str
    element_id: str
    tag: str
    start: Decimal
    end: Decimal
    text: str


def local_name(tag: str) -> str:
    return tag.split("}")[-1]


def strict_decimal(value: str, field: str) -> Decimal:
    try:
        parsed = Decimal(value)
    except InvalidOperation as error:
        raise ValueError(f"invalid decimal {field}: {value!r}") from error
    if not parsed.is_finite() or parsed < 0:
        raise ValueError(f"invalid non-finite/negative {field}: {value!r}")
    return parsed


def load_xml_member(zf: zipfile.ZipFile, member: str) -> ET.Element:
    try:
        data = zf.read(member)
    except KeyError as error:
        raise ValueError(f"missing archive member: {member}") from error
    try:
        return ET.fromstring(data)
    except ET.ParseError as error:
        raise ValueError(f"malformed XML member {member}: {error}") from error


def parse_tokens(
    root: ET.Element, *, speaker: str, member: str, allowed_tags: set[str]
) -> list[Token]:
    records: list[Token] = []
    seen: set[str] = set()
    for element in root:
        tag = local_name(element.tag)
        if tag not in allowed_tags:
            raise ValueError(f"unknown tag {tag!r} in {member}")
        element_id = element.attrib.get(f"{NITE_NS}id")
        if not element_id:
            raise ValueError(f"missing nite:id on {tag} in {member}")
        if element_id in seen:
            raise ValueError(f"duplicate nite:id {element_id} in {member}")
        seen.add(element_id)
        if "starttime" not in element.attrib or "endtime" not in element.attrib:
            raise ValueError(f"missing timestamps for {element_id} in {member}")
        start = strict_decimal(element.attrib["starttime"], "starttime")
        end = strict_decimal(element.attrib["endtime"], "endtime")
        if end < start:
            raise ValueError(f"end before start for {element_id} in {member}")
        text = "".join(element.itertext()).strip() if tag == "w" else ""
        if tag == "w" and not text:
            raise ValueError(f"empty lexical token {element_id} in {member}")
        records.append(Token(speaker, member, element_id, tag, start, end, text))
    return records


def token_midpoint(token: Token) -> Decimal:
    return (token.start + token.end) / Decimal(2)


def in_window(token: Token) -> bool:
    return WINDOW_START <= token_midpoint(token) < WINDOW_END


def floor_ms(seconds: Decimal) -> int:
    return int((seconds * 1000).to_integral_value(rounding=ROUND_FLOOR))


def ceil_ms(seconds: Decimal) -> int:
    return int((seconds * 1000).to_integral_value(rounding=ROUND_CEILING))


def format_timestamp(total_ms: int) -> str:
    hours, rem = divmod(total_ms, 3_600_000)
    minutes, rem = divmod(rem, 60_000)
    seconds, millis = divmod(rem, 1000)
    return f"{hours:02}:{minutes:02}:{seconds:02},{millis:03}"


def compute_revision(segments: list[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    digest.update(b"voxproof-transcript-rev-v1\x00")
    digest.update(len(segments).to_bytes(8, "little"))
    for segment in segments:
        digest.update(int(segment["index"]).to_bytes(4, "little"))
        digest.update(int(segment["start_ms"]).to_bytes(8, "little"))
        digest.update(int(segment["end_ms"]).to_bytes(8, "little"))
        text = segment["text"].encode()
        digest.update(len(text).to_bytes(8, "little"))
        digest.update(text)
    return "rev:sha256-v1:" + digest.hexdigest()


def normalize_token(token: str) -> str | None:
    normalized = unicodedata.normalize("NFC", token).casefold()
    normalized = "".join(
        char for char in normalized if not unicodedata.category(char).startswith("P")
    )
    return normalized or None


def scoring_tokens(text: str) -> list[str]:
    return [normalized for piece in text.split() if (normalized := normalize_token(piece))]


def build_ordered_stream(records: list[dict[str, Any]]) -> list[str]:
    selected = [record for record in records if record["tag"] == "w" and record["in_window"]]
    selected.sort(
        key=lambda record: (
            (Decimal(record["start"]) + Decimal(record["end"])) / 2,
            SPEAKERS.index(record["speaker"]),
            record["element_id"],
        )
    )
    return [token for record in selected for token in scoring_tokens(record["text"])]


def parse_srt_text(text: str) -> list[dict[str, Any]]:
    blocks = re.split(r"\r?\n\r?\n", text.strip())
    segments: list[dict[str, Any]] = []
    timing = re.compile(
        r"^(\d{2}):(\d{2}):(\d{2}),(\d{3}) --> "
        r"(\d{2}):(\d{2}):(\d{2}),(\d{3})$"
    )
    for block in blocks:
        lines = block.splitlines()
        if len(lines) < 3 or not lines[0].isdigit() or not timing.match(lines[1]):
            raise ValueError("malformed SRT block")
        segments.append({"index": int(lines[0]), "text": "\n".join(lines[2:])})
    return segments


def srt_scoring_stream(path: Path) -> list[str]:
    return [
        token
        for segment in parse_srt_text(path.read_text(encoding="utf-8"))
        for token in scoring_tokens(segment["text"])
    ]


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

