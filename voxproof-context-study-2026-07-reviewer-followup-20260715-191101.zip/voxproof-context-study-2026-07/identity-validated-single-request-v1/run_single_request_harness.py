#!/usr/bin/env python3
"""Run an identity-validated study harness without positional aggregation."""

from __future__ import annotations

import argparse
import hashlib
import json
import shlex
from collections import Counter
from pathlib import Path

from single_request_protocol import ProtocolFailure, ProtocolResult, invoke_many, request_identity


def write_summary(
    artifact_dir: Path,
    expected_count: int | None,
    request_sha256: str | None,
    preflight_failures: list[ProtocolFailure],
    outcomes: list[ProtocolResult | ProtocolFailure],
) -> None:
    failures = preflight_failures + [
        outcome for outcome in outcomes if isinstance(outcome, ProtocolFailure)
    ]
    accepted = [outcome for outcome in outcomes if isinstance(outcome, ProtocolResult)]
    eligible = (
        not failures
        and expected_count is not None
        and len(accepted) == expected_count
    )
    summary = {
        "protocol_revision": "voxproof-single-request-identity-v1",
        "expected_request_count": expected_count,
        "request_file_sha256": request_sha256,
        "accepted_count": len(accepted),
        "failure_count": len(failures),
        "complete_identity_verified": eligible,
        "quality_comparison_status": (
            "eligible"
            if eligible
            else "diagnostic_only_partial_protocol_run"
        ),
        "outcomes": [
            *[
                {
                    "request_identity": failure.request_identity or "__unknown__",
                    "outcome": "failed",
                    "failure_code": failure.code,
                    "detail": str(failure),
                }
                for failure in failures
            ],
            *[
                {
                    "request_identity": outcome.request_identity,
                    "outcome": "accepted",
                    "raw_response_path": str(outcome.raw_response_path),
                }
                for outcome in accepted
            ],
        ],
    }
    artifact_dir.mkdir(parents=True, exist_ok=True)
    (artifact_dir / "run-summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )


def corpus_failure(code: str, detail: str) -> ProtocolFailure:
    return ProtocolFailure(code, detail, "__corpus__")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--requests", required=True, type=Path)
    parser.add_argument("--expectation", required=True, type=Path)
    parser.add_argument("--command", required=True)
    parser.add_argument("--artifact-dir", required=True, type=Path)
    parser.add_argument("--timeout-seconds", required=True, type=float)
    parser.add_argument("--max-workers", required=True, type=int)
    arguments = parser.parse_args()

    failures: list[ProtocolFailure] = []
    requests: list[dict] = []
    expected_count: int | None = None
    request_sha256: str | None = None
    try:
        expectation = json.loads(arguments.expectation.read_text(encoding="utf-8"))
        expected_count = expectation["expected_request_count"]
        expected_sha256 = expectation["request_sha256"]
        expected_identities = expectation["expected_request_identities"]
        if (
            not isinstance(expected_count, int)
            or expected_count < 0
            or not isinstance(expected_sha256, str)
            or not isinstance(expected_identities, list)
            or any(not isinstance(identity, str) for identity in expected_identities)
        ):
            raise ValueError("expectation fields have invalid types")
        if len(expected_identities) != expected_count:
            raise ValueError("expected identity count does not match expected request count")
        if len(set(expected_identities)) != len(expected_identities):
            raise ValueError("expected identity list contains duplicates")
    except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as error:
        failures.append(corpus_failure("invalid_expectation", str(error)))
        expected_identities = []
        expected_sha256 = ""

    try:
        request_bytes = arguments.requests.read_bytes()
        request_sha256 = hashlib.sha256(request_bytes).hexdigest()
        requests = [
            json.loads(line)
            for line in request_bytes.decode("utf-8").splitlines()
            if line.strip()
        ]
        if any(not isinstance(request, dict) for request in requests):
            raise ValueError("request corpus contains a non-object request")
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, TypeError, ValueError) as error:
        failures.append(corpus_failure("invalid_request_corpus", str(error)))

    identities: list[str] = []
    if not failures or all(failure.code != "invalid_request_corpus" for failure in failures):
        try:
            identities = [request_identity(request) for request in requests]
        except (TypeError, ValueError) as error:
            failures.append(corpus_failure("invalid_request_corpus", str(error)))
    if request_sha256 is not None and request_sha256 != expected_sha256:
        failures.append(corpus_failure("request_sha256_mismatch", "request file SHA-256 does not match"))
    if expected_count is not None and len(requests) != expected_count:
        failures.append(corpus_failure("request_count_mismatch", "request count does not match expectation"))
    if len(set(identities)) != len(identities):
        failures.append(corpus_failure("duplicate_request_identity", "request corpus contains duplicates"))
    if identities != expected_identities:
        failures.append(
            corpus_failure("request_identity_mismatch", "request identities do not match expectation")
        )

    if failures:
        write_summary(arguments.artifact_dir, expected_count, request_sha256, failures, [])
        raise SystemExit(1)

    outcomes = invoke_many(
        requests=requests,
        command=shlex.split(arguments.command),
        artifact_dir=arguments.artifact_dir,
        timeout_seconds=arguments.timeout_seconds,
        max_workers=arguments.max_workers,
    )
    write_summary(arguments.artifact_dir, expected_count, request_sha256, [], outcomes)
    if any(isinstance(outcome, ProtocolFailure) for outcome in outcomes):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
