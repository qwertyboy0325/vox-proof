"""Study-only identity-validated single-request ranking protocol.

This wrapper deliberately leaves the product's
``experimental-context-rank-request-v1`` payload unchanged. It binds one
external model subprocess to one canonical request and returns an inner product
response only after the wrapper response has passed protocol validation.
"""

from __future__ import annotations

import hashlib
import json
import subprocess
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


PROTOCOL_REVISION = "voxproof-single-request-identity-v1"
RANKING_SCHEMA_REVISION = "experimental-context-rank-request-v1"
ASSESSMENTS = {"strong", "plausible", "ambiguous", "unsupported"}
REASON_CODES = {
    "session_description_term_overlap",
    "nearby_context_term_overlap",
    "lowest_deterministic_distance",
    "multiple_candidates",
    "no_candidate_supported",
}
RESPONSE_FIELDS = {
    "schema_revision",
    "selected_candidate_id",
    "assessment",
    "reason_codes",
    "requires_review",
    "display_explanation",
}
WRAPPER_FIELDS = {"protocol_revision", "request_identity", "response"}


class ProtocolFailure(RuntimeError):
    """A structured failure that must not become a sidecar selection."""

    def __init__(
        self,
        code: str,
        detail: str,
        request_identity: str | None = None,
    ) -> None:
        super().__init__(detail)
        self.code = code
        self.request_identity = request_identity


@dataclass(frozen=True)
class ProtocolResult:
    request_identity: str
    inner_response: dict[str, Any]
    raw_response_path: Path
    metadata_path: Path


def canonical_request_json(request: dict[str, Any]) -> bytes:
    return json.dumps(
        request,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def request_identity(request: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_request_json(request)).hexdigest()


def wrapper_request(request: dict[str, Any]) -> dict[str, Any]:
    return {
        "protocol_revision": PROTOCOL_REVISION,
        "request_identity": request_identity(request),
        "request": request,
    }


def _write_new(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with path.open("xb") as output:
            output.write(payload)
    except FileExistsError as error:
        raise ProtocolFailure(
            "duplicate_response",
            f"refusing to overwrite existing raw artifact: {path}",
        ) from error


def _metadata_path(artifact_dir: Path, identity: str) -> Path:
    return artifact_dir / "metadata" / f"{identity}.json"


def _raw_path(artifact_dir: Path, identity: str) -> Path:
    return artifact_dir / "raw-responses" / f"{identity}.stdout"


def _parse_exactly_one_json(raw: bytes) -> dict[str, Any]:
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ProtocolFailure("malformed_response", "response is not UTF-8") from error

    if not text.strip():
        raise ProtocolFailure("missing_response", "provider returned no response")

    decoder = json.JSONDecoder()
    try:
        value, end = decoder.raw_decode(text.lstrip())
    except json.JSONDecodeError as error:
        raise ProtocolFailure("malformed_response", "response is not JSON") from error

    remainder = text.lstrip()[end:].strip()
    if remainder:
        try:
            decoder.raw_decode(remainder)
        except json.JSONDecodeError as error:
            raise ProtocolFailure(
                "malformed_response",
                "response contains trailing non-JSON bytes",
            ) from error
        raise ProtocolFailure("duplicate_response", "response contains more than one JSON value")

    if not isinstance(value, dict):
        raise ProtocolFailure("malformed_response", "response must be a JSON object")
    return value


def validate_wrapper_response(
    request: dict[str, Any],
    response: dict[str, Any],
) -> dict[str, Any]:
    if not isinstance(request, dict):
        raise ProtocolFailure("malformed_request", "request must be a JSON object")
    identity = request_identity(request)
    candidates = request.get("candidates")
    if not isinstance(candidates, list):
        raise ProtocolFailure("malformed_request", "request candidates must be a list", identity)
    candidate_ids = set()
    for candidate in candidates:
        if not isinstance(candidate, dict) or not isinstance(candidate.get("candidate_id"), str):
            raise ProtocolFailure(
                "malformed_request",
                "every request candidate must have a string candidate_id",
                identity,
            )
        candidate_ids.add(candidate["candidate_id"])

    if not isinstance(response, dict):
        raise ProtocolFailure("malformed_response", "wrapper response must be an object", identity)
    if set(response) != WRAPPER_FIELDS:
        raise ProtocolFailure("malformed_response", "wrapper response fields are invalid", identity)
    if response["protocol_revision"] != PROTOCOL_REVISION:
        raise ProtocolFailure(
            "malformed_response",
            "wrapper protocol revision does not match",
            identity,
        )
    if response["request_identity"] != identity:
        raise ProtocolFailure("identity_mismatch", "response identity does not match request", identity)

    inner = response["response"]
    if not isinstance(inner, dict) or set(inner) != RESPONSE_FIELDS:
        raise ProtocolFailure("malformed_response", "inner response fields are invalid", identity)
    if inner["schema_revision"] != RANKING_SCHEMA_REVISION:
        raise ProtocolFailure("malformed_response", "inner schema revision does not match", identity)
    if inner["requires_review"] is not True:
        raise ProtocolFailure("invalid_response", "requires_review must be true", identity)

    assessment = inner["assessment"]
    selected = inner["selected_candidate_id"]
    reasons = inner["reason_codes"]
    explanation = inner["display_explanation"]
    if not isinstance(assessment, str) or assessment not in ASSESSMENTS:
        raise ProtocolFailure("invalid_response", "assessment is invalid", identity)
    if selected is not None and not isinstance(selected, str):
        raise ProtocolFailure("malformed_response", "selected candidate must be text or null", identity)
    if selected is not None and selected not in candidate_ids:
        raise ProtocolFailure(
            "invalid_candidate_membership",
            "selected candidate is not in request",
            identity,
        )
    if not isinstance(reasons, list) or not reasons or any(
        not isinstance(reason, str) or reason not in REASON_CODES for reason in reasons
    ):
        raise ProtocolFailure("invalid_response", "reason codes are invalid", identity)
    if explanation is not None and not isinstance(explanation, str):
        raise ProtocolFailure("malformed_response", "display explanation must be text or null", identity)
    if isinstance(explanation, str) and len(explanation) > 160:
        raise ProtocolFailure("invalid_response", "display explanation exceeds 160 characters", identity)
    if assessment in {"strong", "plausible"} and selected is None:
        raise ProtocolFailure("invalid_response", "selected assessment requires a candidate", identity)
    if assessment in {"strong", "plausible"} and "no_candidate_supported" in reasons:
        raise ProtocolFailure(
            "invalid_response",
            "selected assessment must not use no_candidate_supported",
            identity,
        )
    if assessment == "unsupported":
        if selected is not None or "no_candidate_supported" not in reasons:
            raise ProtocolFailure(
                "invalid_response",
                "unsupported requires null selection and no_candidate_supported",
                identity,
            )
    if assessment == "ambiguous":
        if selected is not None or "multiple_candidates" not in reasons or len(candidates) <= 1:
            raise ProtocolFailure(
                "invalid_response",
                "ambiguous requires multiple request candidates and multiple_candidates",
                identity,
            )

    return inner


def _write_metadata(
    artifact_dir: Path,
    identity: str,
    request: dict[str, Any],
    raw: bytes,
    outcome: str,
    failure: ProtocolFailure | None,
) -> Path:
    metadata = {
        "protocol_revision": PROTOCOL_REVISION,
        "request_identity": identity,
        "request_sha256": identity,
        "raw_response_sha256": hashlib.sha256(raw).hexdigest(),
        "outcome": outcome,
        "failure": None if failure is None else {"code": failure.code, "detail": str(failure)},
    }
    path = _metadata_path(artifact_dir, identity)
    _write_new(
        path,
        (json.dumps(metadata, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8"),
    )
    return path


def invoke_one(
    request: dict[str, Any],
    command: list[str],
    artifact_dir: Path,
    timeout_seconds: float,
) -> ProtocolResult:
    """Invoke exactly one external process and persist its raw stdout first."""

    identity = request_identity(request)
    raw_path = _raw_path(artifact_dir, identity)
    if raw_path.exists():
        raise ProtocolFailure(
            "duplicate_response",
            f"raw response already exists for request identity {identity}",
            identity,
        )
    payload = canonical_request_json(wrapper_request(request)) + b"\n"
    raw = b""
    try:
        completed = subprocess.run(
            command,
            input=payload,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
            timeout=timeout_seconds,
        )
        raw = completed.stdout
        _write_new(raw_path, raw)
        if completed.returncode != 0:
            raise ProtocolFailure("nonzero_exit", f"provider exited with {completed.returncode}")
        parsed = _parse_exactly_one_json(raw)
        inner = validate_wrapper_response(request, parsed)
    except subprocess.TimeoutExpired as error:
        raw = error.stdout or b""
        _write_new(raw_path, raw)
        failure = ProtocolFailure(
            "timeout",
            f"provider exceeded {timeout_seconds} seconds",
            identity,
        )
        _write_metadata(artifact_dir, identity, request, raw, "failed", failure)
        raise failure from error
    except ProtocolFailure as failure:
        failure.request_identity = failure.request_identity or identity
        if not raw_path.exists():
            _write_new(raw_path, raw)
        _write_metadata(artifact_dir, identity, request, raw, "failed", failure)
        raise
    except OSError as error:
        failure = ProtocolFailure("provider_spawn_failed", str(error), identity)
        _write_new(raw_path, raw)
        _write_metadata(artifact_dir, identity, request, raw, "failed", failure)
        raise failure from error
    except Exception as error:
        failure = ProtocolFailure("unexpected_subprocess_error", str(error), identity)
        if not raw_path.exists():
            _write_new(raw_path, raw)
        _write_metadata(artifact_dir, identity, request, raw, "failed", failure)
        raise failure from error

    metadata_path = _write_metadata(artifact_dir, identity, request, raw, "accepted", None)
    return ProtocolResult(identity, inner, raw_path, metadata_path)


def invoke_many(
    requests: Iterable[dict[str, Any]],
    command: list[str],
    artifact_dir: Path,
    timeout_seconds: float,
    max_workers: int,
) -> list[ProtocolResult | ProtocolFailure]:
    """Aggregate independent requests outside the model process by identity."""

    request_list = list(requests)
    if max_workers < 1:
        raise ValueError("max_workers must be positive")
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(invoke_one, request, command, artifact_dir, timeout_seconds)
            for request in request_list
        ]
        outcomes: list[ProtocolResult | ProtocolFailure] = []
        for future in futures:
            try:
                outcomes.append(future.result())
            except ProtocolFailure as failure:
                outcomes.append(failure)
    return outcomes
