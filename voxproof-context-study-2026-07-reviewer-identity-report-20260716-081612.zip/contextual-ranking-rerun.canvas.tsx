import { useHostTheme } from "cursor/canvas";

const retrievalComparison = [
  ["Retrieval windows", "148", "48"],
  ["Candidates", "149", "49"],
  ["Candidates / minute", "2.60", "0.856"],
  ["Frozen true retained", "13 / 13", "13 / 13"],
  ["Frozen non-exact retrieval recall", "52%", "52%"],
];

const identityRanking = [
  ["Retrieved true", "13"],
  ["Selected", "13"],
  ["Selected true (TP)", "12"],
  ["Selected false (FP)", "1"],
  ["Retrieved-true miss", "1"],
  ["Selected precision", "92.31%"],
  ["Retention of retrieved true", "12 / 13"],
  ["Non-exact recall", "48%"],
  ["Combined exact + selected recall", "70.45%"],
  ["Selected / minute", "0.227"],
  ["Assessments", "13 strong · 35 unsupported"],
  ["Wall time", "204 s"],
];

const identitySamples = [
  ["Technology", "15 / 14", "3", "3", "0"],
  ["Persona", "5 / 5", "0", "0", "1"],
  ["Sports", "18 / 18", "10", "9", "0"],
  ["Education control", "11 / 11", "0", "0", "0"],
];

const descriptiveComparison = [
  ["Selected true", "12", "12"],
  ["Selected false", "18", "1"],
  ["Non-exact recall", "48%", "48%"],
  ["Combined exact + selected recall", "70.45%", "70.45%"],
];

const invalidBatchDiagnostics = [
  ["Selected", "30", "4"],
  ["Selected true", "12", "3"],
  ["Selected false", "18", "1"],
  ["Selected precision", "40.0%", "75.0%"],
  ["Retained retrieved true", "12/13", "3/13"],
  ["Non-exact recall", "48.0%", "12.0%"],
  ["Exact + selected recall", "70.45%", "50.0%"],
  ["Selected / minute", "0.524", "0.070"],
];

const invalidSamples = [
  ["Technology", "15 / 14", "3", "3", "3", "0"],
  ["Persona", "5 / 5", "0", "1", "0", "1"],
  ["Sports", "18 / 18", "10", "0", "0", "0"],
  ["Education control", "11 / 11", "0", "0", "0", "0"],
];

const invalidMissed = [
  "so far → soccer",
  "ten days → tennis",
  "Bagminton → badminton (6 occurrences)",
  "brackminton → badminton",
  "Tracy Magrady → Tracy McGrady",
];

export default function ContextualRankingRerun() {
  const theme = useHostTheme();
  const cell = {
    padding: "8px 10px",
    borderBottom: `1px solid ${theme.stroke.secondary}`,
    textAlign: "left" as const,
  };

  return (
    <main
      style={{
        minHeight: "100vh",
        background: theme.bg.editor,
        color: theme.text.primary,
        padding: 24,
        fontFamily: "system-ui, sans-serif",
      }}
    >
      <header style={{ maxWidth: 1040, marginBottom: 24 }}>
        <div style={{ color: theme.text.tertiary, fontSize: 12, letterSpacing: 0.6 }}>
          RETRIEVAL 0.3 · SIDECAR V3 · IDENTITY-VALIDATED-SINGLE-REQUEST-V1 · HEAD 5286c16
        </div>
        <h1 style={{ margin: "6px 0 8px", fontSize: 24 }}>
          Valid identity-protocol ranking result
        </h1>
        <p style={{ margin: 0, color: theme.text.secondary, lineHeight: 1.55 }}>
          Accepted research evidence under 48 isolated Codex requests. Deterministic retrieval passed
          all gates; external ranking passed identity, schema, and membership validation with no
          shifted or repaired responses.
        </p>
      </header>

      <section
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, minmax(130px, 1fr))",
          gap: 12,
          maxWidth: 1040,
          marginBottom: 28,
        }}
      >
        {[
          ["Selected true", "12", "true positives"],
          ["Selected false", "1", "false positive"],
          ["Retrieved-true miss", "1", "so far → soccer"],
          ["Identity verified", "48 / 48", "no shift · no retry"],
        ].map(([label, value, note]) => (
          <div
            key={label}
            style={{
              background: theme.fill.tertiary,
              border: `1px solid ${theme.stroke.secondary}`,
              padding: 14,
            }}
          >
            <div style={{ color: theme.text.tertiary, fontSize: 12 }}>{label}</div>
            <div style={{ fontSize: 22, fontWeight: 650, margin: "4px 0" }}>{value}</div>
            <div style={{ color: theme.text.secondary, fontSize: 12 }}>{note}</div>
          </div>
        ))}
      </section>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "minmax(0, 1.4fr) minmax(300px, 1fr)",
          gap: 22,
          maxWidth: 1040,
          alignItems: "start",
        }}
      >
        <section>
          <h2 style={{ fontSize: 17, margin: "0 0 10px" }}>Valid deterministic retrieval</h2>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ background: theme.fill.secondary }}>
                <th style={cell}>Metric</th>
                <th style={cell}>Original corpus</th>
                <th style={cell}>Retrieval 0.3</th>
              </tr>
            </thead>
            <tbody>
              {retrievalComparison.map(([metric, original, current]) => (
                <tr key={metric}>
                  <td style={cell}>{metric}</td>
                  <td style={cell}>{original}</td>
                  <td style={cell}>{current}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div style={{ color: theme.text.tertiary, fontSize: 11, marginTop: 8 }}>
            Source: frozen VoxProof contextual study · 57:14.086 of speech · 2026-07-15. Valid
            before external ranking.
          </div>
        </section>

        <aside
          style={{
            borderLeft: `3px solid ${theme.accent.primary}`,
            padding: "4px 0 4px 16px",
          }}
        >
          <h2 style={{ fontSize: 17, margin: "0 0 10px" }}>Identity protocol execution</h2>
          <ul style={{ margin: 0, paddingLeft: 18, lineHeight: 1.55, color: theme.text.secondary }}>
            <li>Codex CLI 0.144.3 · gpt-5.6-sol · low reasoning</li>
            <li>48 independent invocations · max concurrency 2</li>
            <li>Wall time 204 seconds · complete_identity_verified</li>
            <li>No automatic retry · no arbitrary replacement text</li>
          </ul>
        </aside>
      </div>

      <section style={{ maxWidth: 1040, marginTop: 30 }}>
        <h2 style={{ fontSize: 17, margin: "0 0 8px" }}>Valid identity-protocol ranking</h2>
        <p style={{ margin: "0 0 10px", color: theme.text.secondary, lineHeight: 1.5 }}>
          Primary accepted result. 92.31% selected precision applies only to this protocol and
          corpus; it is not general VoxProof product precision.
        </p>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ background: theme.fill.secondary }}>
              <th style={cell}>Metric</th>
              <th style={cell}>Identity-validated run</th>
            </tr>
          </thead>
          <tbody>
            {identityRanking.map(([metric, value]) => (
              <tr key={metric}>
                <td style={cell}>{metric}</td>
                <td style={cell}>{value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section style={{ maxWidth: 1040, marginTop: 30 }}>
        <h2 style={{ fontSize: 17, margin: "0 0 10px" }}>Per-sample identity ranking</h2>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ background: theme.fill.secondary }}>
              {["Sample", "Candidates / windows", "Retrieved true", "Selected true", "Selected false"].map(
                (heading) => (
                  <th key={heading} style={cell}>{heading}</th>
                ),
              )}
            </tr>
          </thead>
          <tbody>
            {identitySamples.map((row) => (
              <tr key={row[0]}>
                {row.map((value, index) => (
                  <td key={`${row[0]}-${index}`} style={cell}>{value}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 24,
          maxWidth: 1040,
          marginTop: 28,
        }}
      >
        <div>
          <h2 style={{ fontSize: 17, margin: "0 0 8px" }}>False positive</h2>
          <p style={{ margin: 0, color: theme.text.secondary, lineHeight: 1.55 }}>
            Persona · <b>information system management</b> → <b>information systems management</b>
          </p>
        </div>
        <div>
          <h2 style={{ fontSize: 17, margin: "0 0 8px" }}>Retrieved-true miss</h2>
          <p style={{ margin: 0, color: theme.text.secondary, lineHeight: 1.55 }}>
            Sports · <b>so far</b> → <b>soccer</b> · unsupported
          </p>
        </div>
        <div>
          <h2 style={{ fontSize: 17, margin: "0 0 8px" }}>Pinyin negative</h2>
          <p style={{ margin: 0, color: theme.text.secondary, lineHeight: 1.55 }}>
            Education · <b>所以嗯</b> → <b>Duolingo</b> · unsupported
          </p>
        </div>
        <div>
          <h2 style={{ fontSize: 17, margin: "0 0 8px" }}>Multi-candidate negative window</h2>
          <p style={{ margin: 0, color: theme.text.secondary, lineHeight: 1.55 }}>
            Technology · <b>phone</b> → <b>iPhone</b> or <b>Python</b> · unsupported · null selection
          </p>
        </div>
      </section>

      <section style={{ maxWidth: 1040, marginTop: 34 }}>
        <h2 style={{ fontSize: 17, margin: "0 0 8px" }}>Descriptive protocol-confounded comparison</h2>
        <p style={{ margin: "0 0 10px", color: theme.text.secondary, lineHeight: 1.5 }}>
          Not a controlled equivalence. Corpus size, batching shape, prompt protocol, and request
          isolation differ; this does not isolate model-quality change.
        </p>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ background: theme.fill.secondary }}>
              <th style={cell}>Metric</th>
              <th style={cell}>Original positional batch (148 windows)</th>
              <th style={cell}>Identity protocol (48 windows)</th>
            </tr>
          </thead>
          <tbody>
            {descriptiveComparison.map(([metric, original, current]) => (
              <tr key={metric}>
                <td style={cell}>{metric}</td>
                <td style={cell}>{original}</td>
                <td style={cell}>{current}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section
        style={{
          maxWidth: 1040,
          marginTop: 34,
          paddingTop: 20,
          borderTop: `2px solid ${theme.stroke.primary}`,
        }}
      >
        <div style={{ color: theme.text.tertiary, fontSize: 11, letterSpacing: 0.5, marginBottom: 8 }}>
          HISTORICAL · INVALID POSITIONAL BATCH · FORENSIC ONLY
        </div>
        <h2 style={{ fontSize: 17, margin: "0 0 8px" }}>Invalid shifted batch record</h2>
        <p style={{ margin: "0 0 10px", color: theme.text.secondary, lineHeight: 1.5 }}>
          Attempts 1–3 under positional batching. The only completed batch shifted response content
          from request index 18. Safe-replay diagnostics below are not model performance and must
          not be used as a baseline.
        </p>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ background: theme.fill.secondary }}>
              <th style={cell}>Metric</th>
              <th style={cell}>Original external result</th>
              <th style={cell}>Invalid safe replay</th>
            </tr>
          </thead>
          <tbody>
            {invalidBatchDiagnostics.map(([metric, original, current]) => (
              <tr key={metric}>
                <td style={cell}>{metric}</td>
                <td style={cell}>{original}</td>
                <td style={cell}>{current}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section style={{ maxWidth: 1040, marginTop: 24 }}>
        <h2 style={{ fontSize: 17, margin: "0 0 10px" }}>Invalid-batch per-sample safe replay</h2>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ background: theme.fill.secondary }}>
              {["Sample", "Candidates / windows", "Retrieved true", "Selected", "TP", "FP"].map(
                (heading) => (
                  <th key={heading} style={cell}>{heading}</th>
                ),
              )}
            </tr>
          </thead>
          <tbody>
            {invalidSamples.map((row) => (
              <tr key={row[0]}>
                {row.map((value, index) => (
                  <td key={`${row[0]}-${index}`} style={cell}>{value}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section style={{ maxWidth: 1040, marginTop: 20 }}>
        <h2 style={{ fontSize: 17, margin: "0 0 8px" }}>Uninterpretable invalid-batch non-selections</h2>
        <ul style={{ margin: 0, paddingLeft: 18, color: theme.text.secondary, lineHeight: 1.55 }}>
          {invalidMissed.map((item) => <li key={item}>{item}</li>)}
        </ul>
        <p style={{ color: theme.text.tertiary, fontSize: 12, lineHeight: 1.5 }}>
          All occurred in the misaligned response region; none is a valid model rejection. Pinyin
          所以嗯 → Duolingo was also in the shifted region.
        </p>
      </section>

      <footer
        style={{
          maxWidth: 1040,
          marginTop: 28,
          paddingTop: 14,
          borderTop: `1px solid ${theme.stroke.primary}`,
          color: theme.text.tertiary,
          fontSize: 12,
          lineHeight: 1.5,
        }}
      >
        Provenance: root manifest HEAD 30e06061 identifies the original frozen corpus; rerun HEAD
        5286c16 identifies this execution. Invalid-batch report SHA 8380c3a4 preserved unchanged.
        Safety: no experimental selection entered decision logs or reviewed transcript; no repository
        source change, commit, or push. Accepted research evidence only — not a Material Decision.
      </footer>
    </main>
  );
}
