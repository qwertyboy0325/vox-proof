# Provisional Scoring Report — identity-validated-single-request-v1

Status: provisional pending ChatGPT review of scorer, label mapping, and results.

## Aggregate
- windows: 48
- candidates: 49
- retrieved true candidates: 13
- selected: 13
- selected true: 12
- selected false: 1
- selected precision: 0.9230769230769231
- retention of retrieved true: 0.9230769230769231
- non-exact recall (25 frozen corrections): 0.48
- combined exact + selected recall: 0.7045454545454546
- candidates per minute: 0.8561229975021009
- selected per minute: 0.22713467280667984

## Per sample
- technology: windows=14 candidates=15 retrieved_true=3 selected=3 selected_true=3 selected_false=0 precision=1.0 retention=1.0
- persona: windows=5 candidates=5 retrieved_true=0 selected=1 selected_true=0 selected_false=1 precision=0.0 retention=None
- sports: windows=18 candidates=18 retrieved_true=10 selected=9 selected_true=9 selected_false=0 precision=1.0 retention=0.9
- education: windows=11 candidates=11 retrieved_true=0 selected=0 selected_true=0 selected_false=0 precision=None retention=None

## Special outcomes
- remaining pinyin candidate selected: False
- multi-candidate window assessment: unsupported
- multi-candidate window selected: None

## Descriptive comparison
Differences confound protocol, corpus size, and execution shape; not an isolated model-quality estimate.
