# VoxProof retrieval 0.3 / sidecar v3 — identity-validated single-request ranking

Date: 2026-07-15  
Repository HEAD: `5286c1627e54852fc08f4766240ce7545269e982`  
Status: **accepted research evidence** — valid external ranking under `identity-validated-single-request-v1`

This report records a valid result for:

- retrieval **0.3**
- sidecar v3 candidate corpus
- protocol **`identity-validated-single-request-v1`**
- Codex CLI **0.144.3**
- model **`gpt-5.6-sol`**
- reasoning effort **low**
- **48** independent model invocations
- maximum concurrency **2**
- execution wall time **204 seconds**

Classification: accepted research evidence. This is not a product semantic rule, Material Decision, or general VoxProof precision claim.

## Provenance

- Frozen ranking requests and expectation were unchanged from the retrieval 0.3 sidecar v3 corpus.
- Root `manifest.json` records `30e06061a88cf548d663f7e5a09c047d74bec118` as the repository HEAD when the original frozen corpus and study were created.
- This run and its output manifest record `5286c1627e54852fc08f4766240ce7545269e982`.
- The invalid positional-batch forensic record remains separate and immutable:
  - `retrieval-0.3-sidecar-v3-external/study-report-retrieval-0.3-sidecar-v3.md`
  - SHA-256: `8380c3a4d8a4a10765c75c632a1438233217c46b2b6b3c08ade637b4509f0d24`
- Portable scoring reviewer package SHA-256: `be83607e7059ae7e3e24ffe20bffab25a849f1895c04b715c1f899b899938e67`

## Valid deterministic retrieval result

Retrieval 0.3 passed every pre-ranking gate before external ranking. These values are valid independent of ranking protocol:

| Metric | Value |
|---|---:|
| Windows | 48 |
| Candidates | 49 |
| Candidates per source-audio minute | 0.856 |
| Frozen true candidates retained | 13 / 13 |
| Frozen non-exact retrieval recall | 52% |

## Accepted identity-protocol ranking metrics

All 48 responses passed identity, schema, and membership validation. No response was shifted or repaired. No automatic retry occurred.

| Metric | Value |
|---|---:|
| Windows | 48 |
| Candidates | 49 |
| Retrieved true | 13 |
| Selected | 13 |
| Selected true | 12 |
| Selected false | 1 |
| Selected precision | 92.3077% |
| Retention of retrieved true | 12 / 13 = 92.3077% |
| Non-exact recall | 12 / 25 = 48% |
| Combined exact + selected recall | 31 / 44 = 70.4545% |
| Candidates per source-audio minute | 0.856 |
| Selected per source-audio minute | 0.227 |
| Assessments | 13 strong, 35 unsupported |
| Execution wall time | 204 seconds |

### Per-sample breakdown

| Sample | Candidates / windows | Retrieved true | Selected true | Selected false |
|---|---:|---:|---:|---:|
| technology | 15 / 14 | 3 | 3 | 0 |
| persona | 5 / 5 | 0 | 0 | 1 |
| sports | 18 / 18 | 10 | 9 | 0 |
| education | 11 / 11 | 0 | 0 | 0 |

### Documented outcomes

**False positive**

- Persona: `information system management` → `information systems management`

**True candidate rejected**

- Sports: `so far` → `soccer` (unsupported; retrieved true not selected)

**Pinyin negative**

- Education: `所以嗯` → `Duolingo` (unsupported)

**Multi-candidate negative window**

- Technology: `phone` → `iPhone` or `Python` (unsupported; null selection)

## Descriptive protocol-confounded comparison

The original positional batch and this identity-validated run may be shown side by side only as a descriptive comparison. The comparison does **not** isolate a change in model quality because retrieval corpus size, batching shape, prompt protocol, and request isolation differ.

| Observation | Original positional batch (148 windows) | Identity protocol (48 windows) |
|---|---:|---:|
| Selected true | 12 | 12 |
| Selected false | 18 | 1 |
| Non-exact recall | 48% | 48% |
| Combined exact + selected recall | 70.45% | 70.45% |

Do not use the invalid attempt-2 safe-replay diagnostic as a performance baseline. Do not claim 92.3% as general VoxProof product precision.

## Safety and governance

- All 48 responses passed identity, schema, and membership validation.
- No response was shifted or repaired.
- No automatic retry occurred.
- No arbitrary replacement text was accepted.
- No selection entered decision logs or reviewed SRT output.
- Repository HEAD remained `5286c1627e54852fc08f4766240ce7545269e982`.
- No repository source change, commit, or push occurred.
