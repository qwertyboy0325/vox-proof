#!/usr/bin/env python3
"""Study-only Codex single-request provider.

Reads exactly one identity-wrapper request from stdin, launches exactly one
Codex process, and writes the model output bytes to stdout unchanged.
Diagnostics go to stderr only.
"""

from __future__ import annotations

import os
import shlex
import subprocess
import sys
import tempfile
from pathlib import Path


HARNESS_DIR = Path(__file__).parent
PROMPT_FILE = HARNESS_DIR / "single-request-ranking-prompt.txt"
SCHEMA_FILE = HARNESS_DIR / "single-request-wrapper-schema.json"
DEFAULT_CODEX = "/opt/homebrew/bin/codex"


def main() -> None:
    wrapper_bytes = sys.stdin.buffer.read()
    if not wrapper_bytes.strip():
        print("provider stdin is empty", file=sys.stderr)
        raise SystemExit(1)

    prompt = PROMPT_FILE.read_text(encoding="utf-8").strip()
    codex_command = shlex.split(os.environ.get("VOXPROOF_CODEX_PATH", DEFAULT_CODEX))
    timeout_seconds = float(os.environ.get("VOXPROOF_PROVIDER_TIMEOUT_SECONDS", "120"))
    study_root = os.environ.get("VOXPROOF_STUDY_ROOT", str(HARNESS_DIR.parent))

    with tempfile.NamedTemporaryFile(delete=False, suffix=".json") as handle:
        output_path = Path(handle.name)

    try:
        command = [
            *codex_command,
            "exec",
            "--ephemeral",
            "--skip-git-repo-check",
            "--sandbox",
            "read-only",
            "--ignore-rules",
            "--model",
            "gpt-5.6-sol",
            "--config",
            'model_reasoning_effort="low"',
            "--output-schema",
            str(SCHEMA_FILE),
            "--output-last-message",
            str(output_path),
            prompt,
        ]
        completed = subprocess.run(
            command,
            input=wrapper_bytes,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=study_root,
            timeout=timeout_seconds,
            check=False,
        )
        if completed.stderr:
            sys.stderr.buffer.write(completed.stderr)
        if completed.returncode != 0:
            raise SystemExit(completed.returncode)
        if not output_path.exists() or output_path.stat().st_size == 0:
            print("provider received no model output artifact", file=sys.stderr)
            raise SystemExit(1)
        sys.stdout.buffer.write(output_path.read_bytes())
    finally:
        output_path.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
