# V3 Phase A Executable-Envelope Memo

## 1. Problem framing

The first V3 Phase A package freezes target selection but not an executable Phase B envelope. Phase B must remain repo-source-preserving while binding every product-derived candidate and reviewed output to one isolated, hash-attested `vox-proof` binary. ES2004b content remains behind the access gate.

Confirmed constants:

- repository HEAD: `5286c1627e54852fc08f4766240ce7545269e982`
- target: `ES2004b`
- window: `[300.000, 900.000)`
- terms: the four previously frozen entries, unchanged
- no fallback, reselection, retry, target-content access, scoring, or Phase B execution in Phase A

## 2. Current executable semantics

Repository product flow:

1. `src/main.rs::run_review_from_args` accepts exactly five paths after `review`.
2. `run_review_command` parses SRT and terms, calls `pipeline::run_term_review`, and receives the complete ordered `Vec<ReviewCase>`.
3. `review_cases_interactively` prints each case and accepts `a <index>`, `r`, `d`, or `m`.
4. `ReviewLedger::record_decision` binds each decision to `TranscriptRevisionId`.
5. `derive_reviewed_srt` materializes accepted alternatives only.
6. `render_decision_log` and `render_session_summary` emit review evidence. The summary contains transcript revision, case count, detector/version counts, and decision counts.

Relevant symbols:

- `src/main.rs::run_review_command`
- `src/main.rs::review_cases_interactively`
- `src/main.rs::parse_decision_input`
- `src/main.rs::print_review_case`
- `src/pipeline.rs::run_term_review`
- `src/session_summary.rs::collect_session_summary`
- `src/session_summary.rs::render_session_summary`
- `src/reviewed_output.rs::derive_reviewed_srt`
- `src/session_log.rs::render_decision_log`
- `src/transcript.rs::Transcript::revision_id`

CLI limitations:

- There is no candidate-inventory subcommand or machine-readable candidate export.
- Candidate details are printed to stdout only during `review`.
- `session-summary.txt` is explicitly human-readable and not a machine re-import format.
- A Python reimplementation of the detector cannot establish that the exact binary produced the same candidates.

Therefore, without repository edits, candidate freezing must use the exact binary's `review` command itself.

## 3. Chosen executable envelope

### 3.1 Exact-binary candidate probe

After hypothesis SRT creation and before manual/reference access:

1. Verify the isolated binary SHA-256 against `binary-attestation.json`.
2. Invoke the exact absolute binary with `review`, the exact SRT, and exact terms.
3. Feed a bounded all-`d` stream (maximum case bound frozen in config) so every candidate is printed and the command completes. These defer decisions are probe-only and non-authoritative.
4. Parse stdout case blocks plus the generated session summary.
5. Freeze:
   - binary SHA-256;
   - input SRT SHA-256;
   - terms SHA-256;
   - transcript revision;
   - ordered candidate records as printed by the binary;
   - candidate count;
   - canonical JSON multiset/sequence SHA-256;
   - raw stdout, decision log, summary, and probe output hashes.
6. If the command exhausts input, stdout is malformed, counts disagree, or any hash changes, fail closed.

The probe is the product candidate-generation invocation. The all-defer ledger is not a research decision record and cannot be reused as authoritative review.

### 3.2 Authoritative review binding

After reference access and human labeling:

1. A designated human study reviewer creates `ground-truth.json` and `decision-inputs.json` under the frozen schemas and metric definitions.
2. Validate one decision per frozen candidate, candidate fingerprints, transcript revision, allowed decision syntax, and accept-alternative index.
3. Verify binary hash immediately before invocation.
4. Run `review` into a temporary output directory.
5. Parse its stdout into the same candidate representation.
6. Require exact ordered equality and multiset hash equality with the frozen candidate inventory, plus identical transcript revision and case count.
7. Only after equality passes, promote reviewed SRT, decision log, session summary, and CLI capture to canonical output paths.
8. On mismatch or command failure, preserve failure artifacts and stop; do not repair or rerun.

### 3.3 Chronology

Single authoritative order:

1. verify repository, archive, script, and config hashes; build isolated binary;
2. cross the target-content gate once by opening target ASR words/segments;
3. materialize hypothesis SRT and cue/token ledger;
4. invoke exact binary candidate probe and seal candidate inventory;
5. only then open manual/reference words content;
6. materialize reference/scoring layers; human reviewer creates ground truth and decision inputs under frozen definitions;
7. validate decision binding; invoke authoritative review; verify candidate reproduction before promoting outputs;
8. score with corrected operation-aware scorer; independently verify; package once; detached seal afterward.

## 4. Evaluation definitions

- **Ground-truth glossary correction opportunity:** a localized hypothesis span in the frozen window where the manual reference supports one frozen canonical term as the correction for a source rendering, under the frozen normalization and overlap policy. Acceptable variants are not opportunities.
- **Selected/detected true candidate:** a frozen binary candidate that maps to one ground-truth opportunity and proposes the supported canonical term.
- **Selected/detected false candidate:** a frozen binary candidate with no matching opportunity, or whose proposed canonical term is unsupported.
- **Detector miss:** a ground-truth opportunity with no selected/detected true candidate.
- **Candidate precision:** true candidates / all frozen candidates; null if candidate count is zero.
- **Candidate recall:** matched opportunities / all ground-truth opportunities; null if opportunity count is zero.
- **Correction recall:** opportunities correctly materialized in reviewed output / all opportunities; null if opportunity count is zero.
- **False-positive burden:** count of false candidates presented for review. Zero candidates yields zero burden but is not detector-quality evidence.
- **Unsafe edit:** an accepted/materialized edit unsupported by ground truth, mapped to the wrong opportunity, with wrong replacement/boundary, or worsening the candidate-local reference agreement under frozen tokenization.
- **Unsafe edit rate:** unsafe materialized edits / accepted materialized edits; null if none accepted.
- **Raw-to-reviewed WER delta:** reviewed WER minus raw WER. Negative is improvement. Both WERs use the same frozen reference stream and scorer.
- **Zero denominator:** ratio is JSON `null`; numerator and denominator remain explicit integers.

Ground truth is produced only after candidate freeze. Terms, definitions, matching rules, target, window, scorer, and schemas cannot change after the target-content gate.

## 5. Frozen script set and responsibilities

Package exact sources under `phase-b/scripts/`:

- `study_config.py`: constants, absolute study paths, hashes, target/window, archive members, limits.
- `common.py`: canonical JSON, hashing, path safety, subprocess capture, invariant helpers.
- `ami_transform.py`: hypothesis/reference/scoring transforms, parameterized only by frozen config.
- `binary_gate.py`: isolated build, attestation, immediate pre-invocation hash checks.
- `candidate_capture.py`: exact-binary probe, stdout parser, candidate inventory, review reproduction check.
- `decision_workflow.py`: ground-truth/decision schema validation and stdin rendering.
- `alignment_scorer.py`: corrected scorer plus real CLI (`score` and `verify-metrics`).
- `independent_verifier.py`: independent edit-distance/count/invariant verification; no primary backtrace import.
- `metrics.py`: frozen semantic labels and metric computation.
- `package_builder.py`: allowlist staging, manifest excluding itself, single ZIP build, detached seal.
- `package_verifier.py`: duplicate/unsafe path, exact closure, bytes/hashes, manifest count/hash, seal, joins, metrics.
- `phase_b_runner.py`: explicit subcommands and stage-state gates.

Every script is listed in `script-lock.json` with exact SHA-256 and byte length. Phase B preflight recomputes all rows before any target access.

## 6. Required schemas

Freeze schemas for:

- binary attestation;
- hypothesis layer manifest;
- candidate inventory and candidate record;
- ground-truth opportunities and candidate labels;
- decision inputs;
- authoritative review capture/binding;
- scoring tokens;
- metrics;
- invariant report;
- package manifest and detached seal;
- failure record and stage-state.

Candidate identity in the study envelope is a deterministic fingerprint over the exact ordered stdout-derived candidate record and transcript revision. It is study evidence, not a replacement for repository `CandidateKey`.

## 7. Exact patch plan

1. Create a new correction root; preserve the first V3 ZIP/seal unchanged.
2. Copy only safe Phase A metadata, attribution snapshots, archive inventory, terms, and disclosed v2 fixture.
3. Implement the frozen script set above; do not copy c1 scripts unchanged.
4. Add fixture-only tests:
   - zero candidate;
   - nonzero accept/reject;
   - candidate/review mismatch rejection;
   - binary hash mismatch rejection;
   - v2 scoring regression;
   - malformed WER decomposition rejection;
   - package manifest/hash corruption rejection;
   - exact command dry-run.
5. Build the repository in an isolated temporary target only for fixture rehearsals. No repository files change.
6. Run synthetic end-to-end dry-run with generated fixture SRT/terms/reference tokens and the isolated binary.
7. Generate corrected Phase A documents, source/config/script locks, exact commands, schemas, tests, captured output, access statement, and implementation diff.
8. Build one final reviewer ZIP. Manifest lists every ordinary ZIP entry except itself. Detached seal lists every entry including manifest.
9. Verify duplicate/unsafe paths, exact set closure, bytes, hashes, manifest entry count, embedded manifest hash, ZIP hash, and post-seal immutability.

## 8. Risks and fail-closed behavior

- CLI stdout is a human format. The parser must be strict and locked by fixture tests; any format drift aborts.
- Probe all-defer input has a frozen maximum candidate bound. Exceeding it aborts rather than truncating.
- Product outputs may exist before a reproduction mismatch is detected. They stay in a temporary failure directory and are never promoted.
- Reference timing is forced-aligned metadata and may be ambiguous. Human reviewer may choose defer/manual correction; no automatic arbitrary replacement.
- Package verifier must never trust scalar WER, manifest self-hash, or seal entry metadata without recomputation.
- No automatic retry after target access. Failure artifacts are preserved and execution stops.

## 9. Validation checklist

- all scripts present, byte-locked, and importable from the packaged tree;
- exact absolute isolated binary used for probe and authoritative review;
- binary hash checked immediately before every product invocation;
- target ASR opens before candidate freeze; manual reference opens only after;
- candidate probe and authoritative candidate sequence exactly equal;
- nonzero decisions are human-authored and schema-bound;
- scorer and independent verifier agree on distance; each decomposition satisfies length invariants;
- every metric definition and zero-denominator rule is executable;
- synthetic zero/nonzero paths pass;
- required negative tests fail closed;
- Phase A package closure and detached seal pass;
- ES2004b words/segments content remains unopened in Phase A.
