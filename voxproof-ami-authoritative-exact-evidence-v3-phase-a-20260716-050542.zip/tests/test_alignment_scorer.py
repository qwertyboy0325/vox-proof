#!/usr/bin/env python3
"""Tests for exploratory v2 alignment scorer."""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "phase-b/scripts"))

from alignment_scorer import (  # noqa: E402
    AlignmentOperation,
    AlignmentResult,
    align_tokens,
    backtrace_alignment,
    load_frozen_streams,
)


class AlignmentScorerTests(unittest.TestCase):
    def test_exact_match(self) -> None:
        result = align_tokens(["a", "b", "c"], ["a", "b", "c"])
        self.assertEqual(result.edit_distance, 0)
        self.assertEqual(result.validate_invariants(), [])

    def test_frozen_v2_regression(self) -> None:
        fixture = ROOT / "tests/fixture-exploratory-v2-scoring_tokens.json"
        reference, hypothesis, _ = load_frozen_streams(fixture)
        result = align_tokens(reference, hypothesis)
        self.assertEqual(result.edit_distance, 374)
        self.assertEqual(len(reference), 705)
        self.assertEqual(len(hypothesis), 699)

    def test_malformed_transition_rejected(self) -> None:
        with self.assertRaises(ValueError):
            backtrace_alignment(["a"], ["b"], [[0, 99]])

    def test_inconsistent_counts_rejected(self) -> None:
        result = AlignmentResult(
            reference_tokens=("a", "b"),
            hypothesis_tokens=("a", "b"),
            operations=(),
            matches=1,
            substitutions=0,
            deletions=0,
            insertions=0,
            edit_distance=0,
        )
        self.assertTrue(any("M+S+D != N" in err for err in result.validate_invariants()))

    def test_cli_scores_raw_and_reviewed_streams(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            scoring = root / "scoring.json"
            scoring.write_text(
                json.dumps(
                    {
                        "reference_tokens": ["project", "manager"],
                        "hypothesis_tokens": ["pm"],
                        "ordering_policy": {"policy_id": "meeting-time-midpoint-v1"},
                    }
                )
            )
            reviewed = root / "reviewed.srt"
            reviewed.write_text(
                "1\n00:00:00,000 --> 00:00:01,000\nProject Manager\n"
            )
            metrics = root / "audit.json"
            result = subprocess.run(
                [
                    sys.executable,
                    str(ROOT / "phase-b/scripts/alignment_scorer.py"),
                    "score",
                    "--scoring-tokens",
                    str(scoring),
                    "--reviewed-srt",
                    str(reviewed),
                    "--output-metrics",
                    str(metrics),
                    "--output-operations",
                    str(root / "raw.tsv"),
                    "--output-reviewed-operations",
                    str(root / "reviewed.tsv"),
                ],
                text=True,
                capture_output=True,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            audit = json.loads(metrics.read_text())
            self.assertGreater(audit["raw"]["wer"], audit["reviewed"]["wer"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
