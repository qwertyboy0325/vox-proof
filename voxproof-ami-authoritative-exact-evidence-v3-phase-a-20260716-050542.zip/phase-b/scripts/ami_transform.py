#!/usr/bin/env python3
"""Deterministic AMI XML-to-SRT/reference/scoring transforms."""

from __future__ import annotations

import json
import sys
import zipfile
from decimal import Decimal
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from ami_common import (  # noqa: E402
    ALLOWED_ASR_TAGS,
    ALLOWED_MANUAL_TAGS,
    HREF_RE,
    MANUAL_EVENT_TAGS,
    NITE_NS,
    ORDERING_POLICY,
    Token,
    build_ordered_stream,
    ceil_ms,
    compute_revision,
    floor_ms,
    format_timestamp,
    in_window,
    load_xml_member,
    local_name,
    parse_tokens,
    write_json,
)
from common import sha256_file  # noqa: E402
from study_config import (  # noqa: E402
    AUTO_PREFIX,
    AUTO_ZIP,
    MANUAL_ZIP,
    MEETING_ID,
    SPEAKERS,
    REVIEWED_PROJECTION_POLICY_ID,
    WINDOW_END,
    WINDOW_START,
)


def required_auto_members() -> list[str]:
    return [
        f"{AUTO_PREFIX}{MEETING_ID}.{speaker}.words.xml" for speaker in SPEAKERS
    ] + [f"{AUTO_PREFIX}{MEETING_ID}.{speaker}.segments.xml" for speaker in SPEAKERS]


def required_manual_members() -> list[str]:
    return [f"words/{MEETING_ID}.{speaker}.words.xml" for speaker in SPEAKERS]


def token_dict(token: Token, segment_id: str | None = None) -> dict[str, Any]:
    record = {
        "speaker": token.speaker,
        "archive_member": token.member,
        "element_id": token.element_id,
        "tag": token.tag,
        "start": format(token.start, "f"),
        "end": format(token.end, "f"),
        "text": token.text,
        "in_window": in_window(token),
    }
    if segment_id is not None:
        record["segment_id"] = segment_id
    return record


def resolve_segment_tokens(
    words: list[Token], segment: Any, speaker: str, member: str
) -> list[Token]:
    ids = [token.element_id for token in words]
    by_id = {token.element_id: token for token in words}
    selected: list[Token] = []
    children = list(segment)
    if not children:
        raise ValueError(f"segment without child href in {member}")
    for child in children:
        if local_name(child.tag) != "child":
            raise ValueError(f"unexpected segment child {local_name(child.tag)!r} in {member}")
        match = HREF_RE.match(child.attrib.get("href", ""))
        if not match:
            raise ValueError(f"malformed child href in {member}: {child.attrib.get('href')!r}")
        first, last = match.groups()
        if first not in by_id or last not in by_id:
            raise ValueError(f"href endpoint missing in words layer: {first}..{last}")
        start = ids.index(first)
        end = ids.index(last)
        if end < start:
            raise ValueError(f"reverse href range: {first}..{last}")
        selected.extend(by_id[element_id] for element_id in ids[start : end + 1])
    return selected


def build_hypothesis_layers(
    auto_zip: Path, build_root: Path
) -> dict[str, Any]:
    """Open target ASR XML and materialize SRT plus cue/token ledgers."""
    parsed = build_root / "parsed"
    parsed.mkdir(parents=True, exist_ok=True)
    token_records: list[dict[str, Any]] = []
    cues: list[dict[str, Any]] = []
    with zipfile.ZipFile(auto_zip) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("duplicate auto archive member path")
        missing = sorted(set(required_auto_members()) - set(names))
        if missing:
            raise ValueError(f"missing auto members: {missing}")
        for speaker in SPEAKERS:
            words_member = f"{AUTO_PREFIX}{MEETING_ID}.{speaker}.words.xml"
            segments_member = f"{AUTO_PREFIX}{MEETING_ID}.{speaker}.segments.xml"
            words = parse_tokens(
                load_xml_member(archive, words_member),
                speaker=speaker,
                member=words_member,
                allowed_tags=ALLOWED_ASR_TAGS,
            )
            segments_root = load_xml_member(archive, segments_member)
            for segment in segments_root:
                if local_name(segment.tag) != "segment":
                    raise ValueError(
                        f"unexpected tag {local_name(segment.tag)!r} in {segments_member}"
                    )
                segment_id = segment.attrib.get(f"{NITE_NS}id")
                if not segment_id:
                    raise ValueError(f"segment missing nite:id in {segments_member}")
                segment_tokens = resolve_segment_tokens(
                    words, segment, speaker, segments_member
                )
                token_records.extend(
                    token_dict(token, segment_id) for token in segment_tokens
                )
                selected = [
                    token
                    for token in segment_tokens
                    if token.tag == "w" and in_window(token)
                ]
                if not selected:
                    continue
                cues.append(
                    {
                        "speaker": speaker,
                        "segment_id": segment_id,
                        "start_ms": floor_ms(min(token.start for token in selected)),
                        "end_ms": ceil_ms(max(token.end for token in selected)),
                        "text": " ".join(token.text for token in selected),
                        "token_ids": [token.element_id for token in selected],
                    }
                )
    cues.sort(key=lambda cue: (cue["start_ms"], cue["speaker"], cue["segment_id"]))
    segments = [
        {
            "index": index,
            "start_ms": cue["start_ms"],
            "end_ms": cue["end_ms"],
            "text": cue["text"],
        }
        for index, cue in enumerate(cues, 1)
    ]
    srt = "\n\n".join(
        f"{segment['index']}\n"
        f"{format_timestamp(segment['start_ms'])} --> "
        f"{format_timestamp(segment['end_ms'])}\n{segment['text']}"
        for segment in segments
    )
    if srt:
        srt += "\n"
    srt_path = build_root / "input.srt"
    srt_path.write_text(srt, encoding="utf-8")
    tokens_path = parsed / "hypothesis_tokens.jsonl"
    tokens_path.write_text(
        "".join(json.dumps(record, sort_keys=True) + "\n" for record in token_records),
        encoding="utf-8",
    )
    cues_path = parsed / "asr_cues.json"
    write_json(cues_path, {"cues": cues, "segment_count": len(segments)})
    manifest = {
        "schema_revision": "voxproof-ami-hypothesis-layer-manifest-v1",
        "layer": "hypothesis",
        "meeting_id": MEETING_ID,
        "window": {
            "start_inclusive": str(WINDOW_START),
            "end_exclusive": str(WINDOW_END),
        },
        "archive": str(auto_zip),
        "required_members": required_auto_members(),
        "build_root": str(build_root),
        "transcript_revision": compute_revision(segments),
        "segment_count": len(segments),
        "reference_exposure": False,
        "files": {
            "input.srt": sha256_file(srt_path),
            "parsed/hypothesis_tokens.jsonl": sha256_file(tokens_path),
            "parsed/asr_cues.json": sha256_file(cues_path),
        },
    }
    write_json(build_root / "layer_manifest.json", manifest)
    return manifest


def build_reference_layers(
    manual_zip: Path, build_root: Path, candidate_inventory_sha256: str
) -> dict[str, Any]:
    """Open manual words only after the runner has sealed candidate inventory."""
    parsed = build_root / "parsed"
    hypothesis_path = parsed / "hypothesis_tokens.jsonl"
    if not hypothesis_path.exists():
        raise ValueError("hypothesis token ledger missing")
    records: list[dict[str, Any]] = []
    with zipfile.ZipFile(manual_zip) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("duplicate manual archive member path")
        missing = sorted(set(required_manual_members()) - set(names))
        if missing:
            raise ValueError(f"missing manual members: {missing}")
        for speaker in SPEAKERS:
            member = f"words/{MEETING_ID}.{speaker}.words.xml"
            records.extend(
                token_dict(token)
                for token in parse_tokens(
                    load_xml_member(archive, member),
                    speaker=speaker,
                    member=member,
                    allowed_tags=ALLOWED_MANUAL_TAGS,
                )
            )
    reference_path = parsed / "reference_tokens.jsonl"
    reference_path.write_text(
        "".join(json.dumps(record, sort_keys=True) + "\n" for record in records),
        encoding="utf-8",
    )
    hypothesis = [
        json.loads(line)
        for line in hypothesis_path.read_text(encoding="utf-8").splitlines()
        if line
    ]
    scoring = {
        "schema_revision": "voxproof-ami-scoring-tokens-v1",
        "ordering_policy": ORDERING_POLICY,
        "reviewed_projection_policy_id": REVIEWED_PROJECTION_POLICY_ID,
        "window": {
            "start_inclusive": str(WINDOW_START),
            "end_exclusive": str(WINDOW_END),
        },
        "hypothesis_tokens": build_ordered_stream(hypothesis),
        "reference_tokens": build_ordered_stream(records),
        "hypothesis_event_exclusions_window": sum(
            1 for record in hypothesis if record["tag"] != "w" and record["in_window"]
        ),
        "manual_typed_event_exclusions_window": sum(
            1
            for record in records
            if record["tag"] in MANUAL_EVENT_TAGS and record["in_window"]
        ),
        "boundary_token_count": sum(
            1
            for record in hypothesis
            if record["in_window"]
            and (
                Decimal(record["start"]) < WINDOW_START
                or Decimal(record["end"]) > WINDOW_END
            )
        ),
    }
    scoring["stream_validation"] = {
        "hypothesis_token_count": len(scoring["hypothesis_tokens"]),
        "reference_token_count": len(scoring["reference_tokens"]),
        "reference_N": len(scoring["reference_tokens"]),
    }
    scoring_path = build_root / "scoring_tokens.json"
    write_json(scoring_path, scoring)
    reference_manifest = {
        "schema_revision": "voxproof-ami-reference-layer-manifest-v1",
        "layer": "reference+scoring",
        "meeting_id": MEETING_ID,
        "archive": str(manual_zip),
        "required_members": required_manual_members(),
        "candidate_inventory_sha256_before_reference_access": candidate_inventory_sha256,
        "normalization_policy_id": "unicode-nfc-casefold-remove-punctuation-v1",
        "ordering_policy_id": ORDERING_POLICY["policy_id"],
        "files": {
            "parsed/reference_tokens.jsonl": sha256_file(reference_path),
            "scoring_tokens.json": sha256_file(scoring_path),
        },
    }
    write_json(build_root / "reference-layer-manifest.json", reference_manifest)
    return reference_manifest
