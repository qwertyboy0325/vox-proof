#!/usr/bin/env python3
"""Independent alignment verification without importing primary backtrace."""

from __future__ import annotations

import json
import sys
import csv
import hashlib
import re
import unicodedata
from decimal import Decimal
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from ami_common import (  # noqa: E402
    find_substring_byte_occurrences,
    is_utf8_byte_boundary,
    parse_srt_strict,
    replace_utf8_span,
    slice_utf8_bytes,
    verify_srt_structure,
)

REVIEWED_PROJECTION_POLICY_ID = "cue-local-edit-global-midpoint-merge-v1"
SPEAKERS = "ABCD"
ACCEPT_RE = re.compile(r"^a (\d+)$")


def independently_extract_inventory_span(
    candidate: dict[str, Any],
) -> tuple[int, int] | None:
    matched_span = candidate.get("matched_span")
    if isinstance(matched_span, dict):
        start = matched_span.get("start_byte")
        end = matched_span.get("end_byte")
        if isinstance(start, int) and isinstance(end, int):
            return start, end
    start = candidate.get("matched_span_start_byte")
    end = candidate.get("matched_span_end_byte")
    if isinstance(start, int) and isinstance(end, int):
        return start, end
    source_span = candidate.get("source_span")
    if isinstance(source_span, dict):
        start = source_span.get("start_byte")
        end = source_span.get("end_byte")
        if isinstance(start, int) and isinstance(end, int):
            return start, end
    return None


def independently_resolve_matched_span(
    *,
    cue_text: str,
    candidate: dict[str, Any],
) -> dict[str, Any]:
    matched_text = candidate["matched_text"]
    if candidate.get("cue_text") != cue_text:
        return {
            "pass": False,
            "matched_span": None,
            "detail": "inventory cue_text does not match source cue",
        }
    inventory_span = independently_extract_inventory_span(candidate)
    if inventory_span is not None:
        start_byte, end_byte = inventory_span
        if not (
            is_utf8_byte_boundary(cue_text, start_byte)
            and is_utf8_byte_boundary(cue_text, end_byte)
        ):
            return {
                "pass": False,
                "matched_span": None,
                "detail": "inventory span is not utf-8 boundary aligned",
            }
        try:
            span_text = slice_utf8_bytes(cue_text, start_byte, end_byte)
        except ValueError:
            return {
                "pass": False,
                "matched_span": None,
                "detail": "inventory span slice failed utf-8 boundary validation",
            }
        if span_text != matched_text:
            return {
                "pass": False,
                "matched_span": None,
                "detail": "inventory span text does not equal matched_text",
            }
        return {
            "pass": True,
            "matched_span": {"start_byte": start_byte, "end_byte": end_byte},
            "detail": "trustworthy inventory span validated against cue text",
        }
    occurrences = find_substring_byte_occurrences(cue_text, matched_text)
    if len(occurrences) == 1:
        start_byte, end_byte = occurrences[0]
        return {
            "pass": True,
            "matched_span": {"start_byte": start_byte, "end_byte": end_byte},
            "detail": "unique matched_text occurrence in cue",
        }
    if not occurrences:
        return {
            "pass": False,
            "matched_span": None,
            "detail": "matched_text not found in cue",
        }
    return {
        "pass": False,
        "matched_span": None,
        "detail": "ambiguous matched_text occurrence without trustworthy inventory span",
        "occurrence_count": len(occurrences),
    }


def independently_spans_overlap(left: tuple[int, int], right: tuple[int, int]) -> bool:
    return left[0] < right[1] and right[0] < left[1]


def independently_expected_cue(
    cue_text: str,
    replacements: list[tuple[int, int, str]],
) -> str:
    expected = cue_text
    for start_byte, end_byte, replacement in sorted(
        replacements, key=lambda item: item[0], reverse=True
    ):
        expected = replace_utf8_span(expected, start_byte, end_byte, replacement)
    return expected


def independently_verify_accepted_cue(
    *,
    segment_position: int,
    input_cue: str,
    reviewed_cue: str,
    accepted_items: list[dict[str, Any]],
) -> dict[str, Any]:
    resolved: list[dict[str, Any]] = []
    for item in accepted_items:
        span_check = independently_resolve_matched_span(
            cue_text=input_cue,
            candidate=item["candidate"],
        )
        resolved.append({**item, "span_check": span_check})
    if any(not row["span_check"]["pass"] for row in resolved):
        return {
            "pass": False,
            "segment_position": segment_position,
            "detail": "accepted candidate span resolution failed",
            "resolved_candidates": resolved,
        }
    spans: list[tuple[int, int]] = []
    replacements: list[tuple[int, int, str]] = []
    for row in resolved:
        span = row["span_check"]["matched_span"]
        assert span is not None
        current_span = (int(span["start_byte"]), int(span["end_byte"]))
        if any(
            independently_spans_overlap(current_span, prior) for prior in spans
        ):
            return {
                "pass": False,
                "segment_position": segment_position,
                "detail": "overlapping accepted candidate spans in cue",
                "resolved_candidates": resolved,
            }
        spans.append(current_span)
        replacements.append((*current_span, row["expected_replacement"]))
    expected_cue = independently_expected_cue(input_cue, replacements)
    if reviewed_cue != expected_cue:
        return {
            "pass": False,
            "segment_position": segment_position,
            "detail": "reviewed cue does not equal jointly expected accepted replacements",
            "expected_cue_text": expected_cue,
            "resolved_candidates": resolved,
        }
    return {
        "pass": True,
        "segment_position": segment_position,
        "detail": "joint accepted replacements verified",
        "expected_cue_text": expected_cue,
        "resolved_candidates": resolved,
    }


def independently_collect_unrelated_cue_edits(
    input_segments: list[dict[str, Any]],
    reviewed_segments: list[dict[str, Any]],
    accepted_segment_positions: set[int],
) -> list[dict[str, Any]]:
    unrelated: list[dict[str, Any]] = []
    for position, (source, reviewed) in enumerate(zip(input_segments, reviewed_segments)):
        if source["text"] == reviewed["text"]:
            continue
        if position not in accepted_segment_positions:
            unrelated.append(
                {
                    "segment_position": position,
                    "cue_index": position + 1,
                    "input_cue_text": source["text"],
                    "reviewed_cue_text": reviewed["text"],
                }
            )
    return unrelated


def independently_recompute_materialization_audit(
    *,
    input_srt: Path,
    reviewed_srt: Path,
    inventory: dict[str, Any],
    labels_payload: dict[str, Any],
    decisions_payload: dict[str, Any],
    ground_truth: dict[str, Any],
    input_srt_sha256: str,
    terms_sha256: str,
    reference_layer_sha256: str,
) -> dict[str, Any]:
    input_segments = parse_srt_strict(input_srt.read_text(encoding="utf-8"))
    reviewed_segments = parse_srt_strict(reviewed_srt.read_text(encoding="utf-8"))
    srt_structure = verify_srt_structure(input_segments, reviewed_segments)
    if not srt_structure["pass"]:
        raise ValueError(srt_structure["detail"])

    labels = labels_payload["labels"]
    decisions = decisions_payload["decisions"]
    candidates = inventory["candidates"]
    opportunity_by_id = {
        row["opportunity_id"]: row for row in ground_truth.get("opportunities", [])
    }
    accepted_by_segment: dict[int, list[dict[str, Any]]] = {}
    records: list[dict[str, Any]] = []
    accepted_segment_positions: set[int] = set()
    cue_verifications: list[dict[str, Any]] = []

    for index, (candidate, label, decision) in enumerate(
        zip(candidates, labels, decisions)
    ):
        base = {
            "candidate_index": index,
            "candidate_fingerprint": candidate["fingerprint"],
            "decision": decision,
            "classification": label.get("classification"),
            "pre_review_replacement_supported": label.get("replacement_supported"),
            "pre_review_boundary_supported": label.get("boundary_supported"),
            "matched_opportunity_id": label.get("matched_opportunity_id"),
        }
        accept = ACCEPT_RE.match(decision)
        if not accept:
            records.append(
                {
                    **base,
                    "status": "non_materialized",
                    "accepted_alternative_index": None,
                    "expected_replacement": None,
                    "materialized_correctly": False,
                    "unsafe_materialized_edit": False,
                }
            )
            continue
        alt_index = int(accept.group(1))
        expected_replacement = candidate["alternatives"][alt_index]["replacement_text"]
        segment_position = int(candidate["source_segment_position"])
        accepted_segment_positions.add(segment_position)
        accepted_by_segment.setdefault(segment_position, []).append(
            {
                "candidate_index": index,
                "candidate": candidate,
                "label": label,
                "expected_replacement": expected_replacement,
            }
        )
        records.append(
            {
                **base,
                "status": "materialized",
                "accepted_alternative_index": alt_index,
                "expected_replacement": expected_replacement,
                "materialized_correctly": False,
                "unsafe_materialized_edit": True,
            }
        )

    for segment_position, accepted_items in sorted(accepted_by_segment.items()):
        cue_verification = independently_verify_accepted_cue(
            segment_position=segment_position,
            input_cue=input_segments[segment_position]["text"],
            reviewed_cue=reviewed_segments[segment_position]["text"],
            accepted_items=accepted_items,
        )
        cue_verifications.append(cue_verification)
        for item in accepted_items:
            index = item["candidate_index"]
            record = records[index]
            label = item["label"]
            resolved = next(
                row
                for row in cue_verification.get("resolved_candidates", [])
                if row["candidate_index"] == index
            )
            span_check = resolved["span_check"]
            opportunity = (
                opportunity_by_id.get(label["matched_opportunity_id"])
                if label.get("matched_opportunity_id")
                else None
            )
            opportunity_term_match = (
                opportunity is not None
                and opportunity.get("canonical_term") == item["expected_replacement"]
            )
            materialized_correctly = (
                cue_verification["pass"]
                and span_check["pass"]
                and label.get("classification") == "selected_true"
                and label.get("replacement_supported") is True
                and label.get("boundary_supported") is True
                and opportunity_term_match
                and label.get("matched_opportunity_id") is not None
            )
            record["materialized_correctly"] = materialized_correctly
            record["unsafe_materialized_edit"] = not materialized_correctly

    unrelated = independently_collect_unrelated_cue_edits(
        input_segments, reviewed_segments, accepted_segment_positions
    )
    if unrelated:
        for record in records:
            if record["status"] == "materialized":
                record["materialized_correctly"] = False
                record["unsafe_materialized_edit"] = True

    fail_closed_reasons = [cue["detail"] for cue in cue_verifications if not cue["pass"]]
    if unrelated:
        fail_closed_reasons.append("unrelated cue edits detected")

    return {
        "srt_structure_verification": srt_structure,
        "cue_verifications": cue_verifications,
        "audit_pass": not fail_closed_reasons,
        "fail_closed_reasons": fail_closed_reasons,
        "records": records,
        "unrelated_cue_edits": unrelated,
        "materialized_record_count": sum(
            1 for record in records if record["status"] == "materialized"
        ),
        "correctly_materialized_opportunity_ids": sorted(
            {
                record["matched_opportunity_id"]
                for record in records
                if record["status"] == "materialized"
                and record["materialized_correctly"]
                and record.get("matched_opportunity_id")
            }
        ),
        "unsafe_materialized_accept_count": sum(
            1
            for record in records
            if record["status"] == "materialized"
            and record["unsafe_materialized_edit"]
        ),
        "bindings": {
            "input_srt_sha256": input_srt_sha256,
            "terms_sha256": terms_sha256,
            "reference_layer_sha256": reference_layer_sha256,
            "reviewed_output_sha256": file_sha256(reviewed_srt),
        },
    }


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalized_tokens(text: str) -> list[str]:
    output: list[str] = []
    for piece in text.split():
        token = unicodedata.normalize("NFC", piece).casefold()
        token = "".join(
            char for char in token if not unicodedata.category(char).startswith("P")
        )
        if token:
            output.append(token)
    return output


def parse_srt_independent(path: Path) -> list[dict[str, Any]]:
    blocks = re.split(r"\r?\n\r?\n", path.read_text(encoding="utf-8").strip())
    result = []
    for block in blocks:
        lines = block.splitlines()
        if len(lines) < 3 or not lines[0].isdigit():
            raise ValueError("independent SRT parse failed")
        result.append({"index": int(lines[0]), "text": "\n".join(lines[2:])})
    return result


def project_cue_independent(
    original: list[tuple[str, tuple[Any, ...]]], reviewed: list[str]
) -> list[tuple[tuple[Any, ...], str]]:
    source = [item[0] for item in original]
    n, m = len(source), len(reviewed)
    matrix = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        matrix[i][0] = i
    for j in range(m + 1):
        matrix[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            substitution = matrix[i - 1][j - 1] + (source[i - 1] != reviewed[j - 1])
            matrix[i][j] = min(substitution, matrix[i - 1][j] + 1, matrix[i][j - 1] + 1)
    reverse: list[tuple[str, int, int]] = []
    i, j = n, m
    while i or j:
        if i and j and matrix[i][j] == matrix[i - 1][j - 1] + (
            source[i - 1] != reviewed[j - 1]
        ):
            reverse.append(("map", i - 1, j - 1))
            i -= 1
            j -= 1
        elif i and matrix[i][j] == matrix[i - 1][j] + 1:
            reverse.append(("delete", i - 1, j))
            i -= 1
        elif j and matrix[i][j] == matrix[i][j - 1] + 1:
            reverse.append(("insert", i, j - 1))
            j -= 1
        else:
            raise ValueError("independent cue projection backtrace failed")
    counts: dict[tuple[int, str], int] = {}
    output = []
    for operation, source_index, reviewed_index in reversed(reverse):
        if operation == "delete":
            continue
        if operation == "map":
            key = (*original[source_index][1], 0, 0)
        elif source_index == 0:
            count_key = (source_index, "before")
            counts[count_key] = counts.get(count_key, 0) + 1
            key = (*original[0][1], -1, counts[count_key])
        else:
            count_key = (source_index, "after")
            counts[count_key] = counts.get(count_key, 0) + 1
            key = (*original[source_index - 1][1], 1, counts[count_key])
        output.append((key, reviewed[reviewed_index]))
    return output


def independently_project_reviewed(phase_b: Path, raw: list[str]) -> list[str]:
    cues = json.loads((phase_b / "build-primary/parsed/asr_cues.json").read_text())["cues"]
    records = [
        json.loads(line)
        for line in (
            phase_b / "build-primary/parsed/hypothesis_tokens.jsonl"
        ).read_text().splitlines()
        if line
    ]
    by_id = {row["element_id"]: row for row in records}
    source_srt = parse_srt_independent(phase_b / "build-primary/input.srt")
    reviewed_srt = parse_srt_independent(phase_b / "review/reviewed-output.srt")
    if len(cues) != len(source_srt) or len(cues) != len(reviewed_srt):
        raise ValueError("independent cue count mismatch")
    merged = []
    identity = True
    for position, (cue, source, reviewed) in enumerate(
        zip(cues, source_srt, reviewed_srt), 1
    ):
        if source["index"] != position or reviewed["index"] != position:
            raise ValueError("independent cue index mismatch")
        if source["text"] != cue["text"]:
            raise ValueError("independent source cue text mismatch")
        original = []
        for token_id in cue["token_ids"]:
            row = by_id[token_id]
            if row["segment_id"] != cue["segment_id"]:
                raise ValueError("independent token/segment mismatch")
            base = (
                (Decimal(row["start"]) + Decimal(row["end"])) / 2,
                SPEAKERS.index(row["speaker"]),
                row["element_id"],
            )
            original.extend(
                (token, (*base, subindex))
                for subindex, token in enumerate(normalized_tokens(row["text"]))
            )
        source_tokens = [item[0] for item in original]
        if source_tokens != normalized_tokens(source["text"]):
            raise ValueError("independent source token reconstruction mismatch")
        reviewed_tokens = normalized_tokens(reviewed["text"])
        identity = identity and source_tokens == reviewed_tokens
        merged.extend(project_cue_independent(original, reviewed_tokens))
    merged.sort(key=lambda item: item[0])
    projected = [item[1] for item in merged]
    if identity and projected != raw:
        raise ValueError("independent identity projection differs from raw")
    return projected


def recompute_metrics(
    inventory: dict[str, Any],
    ground: dict[str, Any],
    labels: list[dict[str, Any]],
    decisions: list[str],
    alignment: dict[str, Any],
    materialization_audit: dict[str, Any],
) -> dict[str, Any]:
    opportunities = ground.get("opportunities", [])
    candidates = inventory.get("candidates", [])
    true_labels = [row for row in labels if row.get("classification") == "selected_true"]
    false_labels = [row for row in labels if row.get("classification") == "selected_false"]
    matched = {row["matched_opportunity_id"] for row in true_labels}
    accepted = {i for i, value in enumerate(decisions) if value.startswith("a ")}
    materialized_records = {
        record["candidate_index"]: record
        for record in materialization_audit.get("records", [])
        if record.get("status") == "materialized"
    }
    corrected = {
        record["matched_opportunity_id"]
        for index in accepted
        if (record := materialized_records.get(index))
        and record.get("materialized_correctly")
        and record.get("matched_opportunity_id")
    }
    unsafe = {
        index
        for index in accepted
        if (record := materialized_records.get(index))
        and record.get("unsafe_materialized_edit")
    }

    def ratio(numerator: int, denominator: int) -> float | None:
        return None if denominator == 0 else numerator / denominator

    raw_wer = alignment["raw"]["wer"]
    reviewed_wer = alignment["reviewed"]["wer"]
    return {
        "schema_revision": "voxproof-ami-study-metrics-v1",
        "definitions_revision": "v3-phase-a-materialization-audit-v1",
        "candidate_precision": {
            "numerator": len(true_labels),
            "denominator": len(candidates),
            "ratio": ratio(len(true_labels), len(candidates)),
        },
        "candidate_recall": {
            "numerator": len(matched),
            "denominator": len(opportunities),
            "ratio": ratio(len(matched), len(opportunities)),
        },
        "correction_recall": {
            "numerator": len(corrected),
            "denominator": len(opportunities),
            "ratio": ratio(len(corrected), len(opportunities)),
        },
        "false_positive_burden": len(false_labels),
        "unsafe_edit_rate": {
            "numerator": len(unsafe),
            "denominator": len(accepted),
            "ratio": ratio(len(unsafe), len(accepted)),
        },
        "raw_wer": raw_wer,
        "reviewed_wer": reviewed_wer,
        "raw_to_reviewed_wer_delta": (
            None if raw_wer is None or reviewed_wer is None else reviewed_wer - raw_wer
        ),
        "zero_denominator_rule": "ratio fields are JSON null when denominator is zero",
        "detector_miss_count": len(opportunities) - len(matched),
        "selected_true_candidate_count": len(true_labels),
        "selected_false_candidate_count": len(false_labels),
        "alignment": {
            key: alignment[key]
            for key in ("raw", "reviewed", "raw_to_reviewed_wer_delta")
        },
        "accepted_candidate_count": len(accepted),
        "materialization_audit_sha256": materialization_audit.get("_sha256"),
    }


def independent_edit_distance(reference: list[str], hypothesis: list[str]) -> int:
    n = len(reference)
    m = len(hypothesis)
    previous = list(range(m + 1))
    for i in range(1, n + 1):
        current = [i]
        ref_token = reference[i - 1]
        for j in range(1, m + 1):
            cost_substitution = 0 if ref_token == hypothesis[j - 1] else 1
            current.append(
                min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost_substitution)
            )
        previous = current
    return previous[m]


def independent_backtrace_alternate_tie(
    reference: list[str], hypothesis: list[str]
) -> dict[str, int]:
    n = len(reference)
    m = len(hypothesis)
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        dp[i][0] = i
    for j in range(1, m + 1):
        dp[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if reference[i - 1] == hypothesis[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = 1 + min(dp[i - 1][j - 1], dp[i][j - 1], dp[i - 1][j])
    counts = {"match": 0, "substitution": 0, "deletion": 0, "insertion": 0}
    i = n
    j = m
    while i > 0 or j > 0:
        current = dp[i][j]
        if i > 0 and j > 0 and reference[i - 1] == hypothesis[j - 1] and current == dp[i - 1][j - 1]:
            counts["match"] += 1
            i -= 1
            j -= 1
            continue
        candidates: list[tuple[str, int, int]] = []
        if i > 0 and j > 0 and current == dp[i - 1][j - 1] + 1:
            candidates.append(("substitution", i - 1, j - 1))
        if j > 0 and current == dp[i][j - 1] + 1:
            candidates.append(("insertion", i, j - 1))
        if i > 0 and current == dp[i - 1][j] + 1:
            candidates.append(("deletion", i - 1, j))
        if not candidates:
            raise ValueError(f"alternate backtrace failed at ({i},{j})")
        op, ni, nj = candidates[0]
        counts[op] += 1
        i, j = ni, nj
    n_ref = len(reference)
    h_hyp = len(hypothesis)
    m_count = counts["match"]
    s_count = counts["substitution"]
    d_count = counts["deletion"]
    ins_count = counts["insertion"]
    if m_count + s_count + d_count != n_ref:
        raise ValueError("alternate decomposition failed M+S+D=N")
    if m_count + s_count + ins_count != h_hyp:
        raise ValueError("alternate decomposition failed M+S+I=H")
    if h_hyp != n_ref - d_count + ins_count:
        raise ValueError("alternate decomposition failed H=N-D+I")
    if dp[n][m] != s_count + d_count + ins_count:
        raise ValueError("alternate decomposition failed edit distance")
    counts["edit_distance"] = dp[n][m]
    counts["N_reference"] = n_ref
    counts["H_hypothesis"] = h_hyp
    counts["matches"] = counts.pop("match")
    counts["substitutions"] = counts.pop("substitution")
    counts["deletions"] = counts.pop("deletion")
    counts["insertions"] = counts.pop("insertion")
    return counts


def verify_operations(
    path: Path,
    reference: list[str],
    hypothesis: list[str],
    expected: dict[str, int],
) -> list[str]:
    errors: list[str] = []
    rows = list(csv.DictReader(path.open(encoding="utf-8"), delimiter="\t"))
    reconstructed_reference: list[str] = []
    reconstructed_hypothesis: list[str] = []
    counts = {"match": 0, "substitution": 0, "deletion": 0, "insertion": 0}
    ref_pos = hyp_pos = 0
    for ordinal, row in enumerate(rows):
        operation = row["operation"]
        if int(row["ordinal"]) != ordinal or operation not in counts:
            errors.append(f"{path.name}: invalid ordinal/operation at {ordinal}")
            continue
        if int(row["reference_coord_before"]) != ref_pos:
            errors.append(f"{path.name}: reference coordinate discontinuity at {ordinal}")
        if int(row["hypothesis_coord_before"]) != hyp_pos:
            errors.append(f"{path.name}: hypothesis coordinate discontinuity at {ordinal}")
        reference_token = row["reference_token"] or None
        hypothesis_token = row["hypothesis_token"] or None
        if operation in {"match", "substitution", "deletion"}:
            reconstructed_reference.append(reference_token or "")
            ref_pos += 1
        if operation in {"match", "substitution", "insertion"}:
            reconstructed_hypothesis.append(hypothesis_token or "")
            hyp_pos += 1
        if operation == "match" and reference_token != hypothesis_token:
            errors.append(f"{path.name}: unequal match at {ordinal}")
        if operation == "substitution" and reference_token == hypothesis_token:
            errors.append(f"{path.name}: equal substitution at {ordinal}")
        counts[operation] += 1
    if reconstructed_reference != reference:
        errors.append(f"{path.name}: reconstructed reference mismatch")
    if reconstructed_hypothesis != hypothesis:
        errors.append(f"{path.name}: reconstructed hypothesis mismatch")
    derived = {
        "N_reference": len(reference),
        "H_hypothesis": len(hypothesis),
        "matches": counts["match"],
        "substitutions": counts["substitution"],
        "deletions": counts["deletion"],
        "insertions": counts["insertion"],
        "edit_distance": counts["substitution"] + counts["deletion"] + counts["insertion"],
    }
    if derived != expected:
        errors.append(f"{path.name}: operation counts mismatch")
    if derived["matches"] + derived["substitutions"] + derived["deletions"] != len(reference):
        errors.append(f"{path.name}: M+S+D != N")
    if derived["matches"] + derived["substitutions"] + derived["insertions"] != len(hypothesis):
        errors.append(f"{path.name}: M+S+I != H")
    return errors


def comparable_materialization_records(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    keys = (
        "candidate_index",
        "candidate_fingerprint",
        "decision",
        "classification",
        "status",
        "accepted_alternative_index",
        "expected_replacement",
        "matched_opportunity_id",
        "materialized_correctly",
        "unsafe_materialized_edit",
    )
    return [{key: record.get(key) for key in keys} for record in records]


def verify_study_root(study_root: Path) -> dict[str, Any]:
    phase_b = study_root / "phase-b"
    scoring_path = phase_b / "build-primary/scoring_tokens.json"
    alignment_path = phase_b / "alignment-audit.json"
    metrics_path = phase_b / "metrics.json"
    errors: list[str] = []
    scoring = json.loads(scoring_path.read_text(encoding="utf-8"))
    alignment = json.loads(alignment_path.read_text(encoding="utf-8"))
    metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
    state = json.loads((phase_b / "stage-state.json").read_text(encoding="utf-8"))
    details = state.get("stage_details", {})
    disclosures: list[str] = []
    reference = list(scoring["reference_tokens"])
    streams = {
        "raw": list(scoring["hypothesis_tokens"]),
        "reviewed": list(alignment["reviewed_tokens"]),
    }
    for name, hypothesis in streams.items():
        audit = alignment[name]
        counts = audit["counts"]
        independent = independent_backtrace_alternate_tie(reference, hypothesis)
        distance = independent_edit_distance(reference, hypothesis)
        if distance != counts["edit_distance"]:
            errors.append(f"{name}: independent edit distance mismatch")
        if counts["matches"] + counts["substitutions"] + counts["deletions"] != len(reference):
            errors.append(f"{name}: primary M+S+D invariant mismatch")
        if counts["matches"] + counts["substitutions"] + counts["insertions"] != len(hypothesis):
            errors.append(f"{name}: primary M+S+I invariant mismatch")
        if counts["substitutions"] + counts["deletions"] + counts["insertions"] != distance:
            errors.append(f"{name}: primary decomposition is not optimal")
        if independent != counts:
            disclosures.append(
                f"{name}: alternate deterministic tie policy produced a different "
                "optimal S/D/I decomposition; primary operations remain authoritative"
            )
        expected_wer = None if not reference else counts["edit_distance"] / len(reference)
        if audit["wer"] != expected_wer:
            errors.append(f"{name}: scalar WER mismatch")
        errors.extend(
            verify_operations(
                phase_b / f"{name}-alignment-operations.tsv",
                reference,
                hypothesis,
                counts,
            )
        )
    if metrics.get("alignment") != {
        key: alignment[key] for key in ("raw", "reviewed", "raw_to_reviewed_wer_delta")
    }:
        errors.append("metrics alignment audit disagreement")
    inventory = json.loads((phase_b / "probe/candidate-inventory.json").read_text())
    ground_path = phase_b / "review/ground-truth.json"
    labels_path = phase_b / "review/candidate-labels.json"
    decisions_path = phase_b / "review/decision-inputs.json"
    materialization_path = phase_b / "review/materialization-audit.json"
    ground = json.loads(ground_path.read_text())
    labels_payload = json.loads(labels_path.read_text())
    decisions_payload = json.loads(decisions_path.read_text())
    materialization_audit = json.loads(materialization_path.read_text())
    materialization_audit["_sha256"] = file_sha256(materialization_path)
    binding = json.loads(
        (phase_b / "review/authoritative-review-binding.json").read_text()
    )
    if not binding.get("reproduction_verified"):
        errors.append("review reproduction not verified")
    for field in ("binary_sha256", "transcript_revision", "candidate_count"):
        if binding.get(field) != inventory.get(field):
            errors.append(f"inventory/review binding mismatch: {field}")
    if binding.get("candidate_sequence_sha256") != inventory.get(
        "candidate_sequence_sha256"
    ):
        errors.append("inventory/review candidate sequence mismatch")
    if binding.get("decisions") != decisions_payload.get("decisions"):
        errors.append("authoritative binding decisions mismatch")
    independently_reviewed = independently_project_reviewed(
        phase_b, list(scoring["hypothesis_tokens"])
    )
    if alignment.get("reviewed_projection_policy_id") != REVIEWED_PROJECTION_POLICY_ID:
        errors.append("reviewed projection policy mismatch")
    if scoring.get("reviewed_projection_policy_id") != REVIEWED_PROJECTION_POLICY_ID:
        errors.append("scoring projection policy mismatch")
    if independently_reviewed != alignment.get("reviewed_tokens"):
        errors.append("independent reviewed-stream projection mismatch")

    recomputed_audit = independently_recompute_materialization_audit(
        input_srt=phase_b / "build-primary/input.srt",
        reviewed_srt=phase_b / "review/reviewed-output.srt",
        inventory=inventory,
        labels_payload=labels_payload,
        decisions_payload=decisions_payload,
        ground_truth=ground,
        input_srt_sha256=file_sha256(phase_b / "build-primary/input.srt"),
        terms_sha256=file_sha256(study_root / "session-terms/session-terms.txt"),
        reference_layer_sha256=file_sha256(
            phase_b / "build-primary/reference-layer-manifest.json"
        ),
    )
    if comparable_materialization_records(
        materialization_audit.get("records", [])
    ) != comparable_materialization_records(recomputed_audit.get("records", [])):
        errors.append("materialization audit mismatch: records")
    for key in (
        "unrelated_cue_edits",
        "correctly_materialized_opportunity_ids",
        "unsafe_materialized_accept_count",
        "materialized_record_count",
        "audit_pass",
        "fail_closed_reasons",
    ):
        if materialization_audit.get(key) != recomputed_audit.get(key):
            errors.append(f"materialization audit mismatch: {key}")
    if materialization_audit.get("bindings", {}).get(
        "reviewed_output_sha256"
    ) != file_sha256(phase_b / "review/reviewed-output.srt"):
        errors.append("materialization audit reviewed-output hash mismatch")
    if not recomputed_audit.get("audit_pass"):
        errors.append("independently recomputed materialization audit failed closed")
    for index, (label, record) in enumerate(
        zip(labels_payload["labels"], recomputed_audit["records"])
    ):
        if not decisions_payload["decisions"][index].startswith("a "):
            continue
        if (
            label.get("classification") == "selected_true"
            and label.get("replacement_supported") is True
            and label.get("boundary_supported") is True
            and not record.get("materialized_correctly")
        ):
            errors.append(
                f"pre-review supported true label failed materialization audit at {index}"
            )

    recomputed_audit["_sha256"] = file_sha256(materialization_path)
    expected_metrics = recompute_metrics(
        inventory,
        ground,
        labels_payload["labels"],
        decisions_payload["decisions"],
        alignment,
        recomputed_audit,
    )
    if metrics != expected_metrics:
        errors.append("independently recomputed study metrics mismatch")

    hash_checks = (
        (
            phase_b / "build-primary/input.srt",
            details.get("hypothesis", {}).get("input_srt_sha256"),
            "input SRT",
        ),
        (
            phase_b / "build-primary/parsed/hypothesis_tokens.jsonl",
            details.get("hypothesis", {}).get("hypothesis_tokens_sha256"),
            "hypothesis token ledger",
        ),
        (
            phase_b / "build-primary/parsed/asr_cues.json",
            details.get("hypothesis", {}).get("asr_cues_sha256"),
            "ASR cue ledger",
        ),
        (
            phase_b / "probe/candidate-inventory.json",
            details.get("probe-candidates", {}).get("candidate_inventory_sha256"),
            "probe inventory",
        ),
        (
            phase_b / "build-primary/reference-layer-manifest.json",
            details.get("reference", {}).get("reference_layer_sha256"),
            "reference layer",
        ),
        (
            phase_b / "build-primary/scoring_tokens.json",
            details.get("reference", {}).get("scoring_tokens_sha256"),
            "scoring tokens",
        ),
        (
            ground_path,
            details.get("validate-review-inputs", {}).get("ground_truth_sha256"),
            "ground truth",
        ),
        (
            labels_path,
            details.get("validate-review-inputs", {}).get("candidate_labels_sha256"),
            "candidate labels",
        ),
        (
            decisions_path,
            details.get("validate-review-inputs", {}).get("decision_inputs_sha256"),
            "decision inputs",
        ),
        (
            phase_b / "review/authoritative-review-binding.json",
            details.get("authoritative-review", {}).get(
                "authoritative_review_binding_sha256"
            ),
            "authoritative binding",
        ),
        (
            phase_b / "review/reviewed-output.srt",
            details.get("authoritative-review", {}).get("reviewed_output_sha256"),
            "reviewed output",
        ),
        (
            materialization_path,
            details.get("audit-materialization", {}).get("materialization_audit_sha256"),
            "materialization audit",
        ),
        (
            alignment_path,
            details.get("score", {}).get("alignment_audit_sha256"),
            "alignment audit",
        ),
        (
            metrics_path,
            details.get("score", {}).get("metrics_sha256"),
            "metrics",
        ),
    )
    for path, expected_hash, label in hash_checks:
        if not expected_hash or file_sha256(path) != expected_hash:
            errors.append(f"stage-detail hash mismatch: {label}")
    authoritative = details.get("authoritative-review", {})
    materialization = details.get("audit-materialization", {})
    validated = details.get("validate-review-inputs", {})
    for field in (
        "candidate_inventory_sha256",
        "reference_layer_sha256",
        "scoring_tokens_sha256",
        "ground_truth_sha256",
        "candidate_labels_sha256",
        "decision_inputs_sha256",
    ):
        expected = (
            details.get("probe-candidates", {}).get(field)
            or details.get("reference", {}).get(field)
            or validated.get(field)
        )
        if authoritative.get(field) != expected:
            errors.append(f"authoritative immutable join mismatch: {field}")
    for field in (
        "authoritative_review_binding_sha256",
        "reviewed_output_sha256",
    ):
        if materialization.get(field) != authoritative.get(field):
            errors.append(f"materialization immutable join mismatch: {field}")
    return {
        "status": "pass" if not errors else "fail",
        "errors": errors,
        "raw_independent_distance": independent_edit_distance(reference, streams["raw"]),
        "reviewed_independent_distance": independent_edit_distance(
            reference, streams["reviewed"]
        ),
        "ordering_policy": scoring.get("ordering_policy"),
        "reviewed_projection_policy_id": REVIEWED_PROJECTION_POLICY_ID,
        "tie_policy_disclosures": disclosures,
        "study_root": str(study_root),
    }


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: independent_verifier.py <study_root>", file=sys.stderr)
        return 2
    study_root = Path(sys.argv[1]).resolve()
    out = verify_study_root(study_root)
    output_path = study_root / "phase-b/reports/independent-verifier-output.json"
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(out, indent=2))
    return 0 if out["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
