#!/usr/bin/env python3
"""Post-authoritative-review deterministic materialization audit."""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from ami_common import (  # noqa: E402
    find_substring_byte_occurrences,
    is_utf8_byte_boundary,
    parse_srt_strict,
    replace_utf8_span,
    slice_utf8_bytes,
    verify_srt_structure,
)
from common import read_json, sha256_file, utc_now, write_json  # noqa: E402
from study_config import UNSAFE_DEFINITION_ID  # noqa: E402

ACCEPT_RE = re.compile(r"^a (\d+)$")


def extract_trustworthy_inventory_span(
    candidate: dict[str, Any],
) -> tuple[int, int] | None:
    matched_span = candidate.get("matched_span")
    if isinstance(matched_span, dict):
        start = matched_span.get("start_byte")
        end = matched_span.get("end_byte")
        if isinstance(start, int) and isinstance(end, int):
            return start, end
    start = candidate.get("matched_span_start_byte")
    end = candidate.get("matched_span_end_byte")
    if isinstance(start, int) and isinstance(end, int):
        return start, end
    source_span = candidate.get("source_span")
    if isinstance(source_span, dict):
        start = source_span.get("start_byte")
        end = source_span.get("end_byte")
        if isinstance(start, int) and isinstance(end, int):
            return start, end
    return None


def resolve_matched_span(
    *,
    cue_text: str,
    candidate: dict[str, Any],
) -> dict[str, Any]:
    matched_text = candidate["matched_text"]
    if candidate.get("cue_text") != cue_text:
        return {
            "pass": False,
            "matched_span": None,
            "detail": "inventory cue_text does not match source cue",
        }
    inventory_span = extract_trustworthy_inventory_span(candidate)
    if inventory_span is not None:
        start_byte, end_byte = inventory_span
        if not (
            is_utf8_byte_boundary(cue_text, start_byte)
            and is_utf8_byte_boundary(cue_text, end_byte)
        ):
            return {
                "pass": False,
                "matched_span": None,
                "detail": "inventory span is not utf-8 boundary aligned",
            }
        try:
            span_text = slice_utf8_bytes(cue_text, start_byte, end_byte)
        except ValueError:
            return {
                "pass": False,
                "matched_span": None,
                "detail": "inventory span slice failed utf-8 boundary validation",
            }
        if span_text != matched_text:
            return {
                "pass": False,
                "matched_span": None,
                "detail": "inventory span text does not equal matched_text",
            }
        return {
            "pass": True,
            "matched_span": {"start_byte": start_byte, "end_byte": end_byte},
            "detail": "trustworthy inventory span validated against cue text",
        }

    occurrences = find_substring_byte_occurrences(cue_text, matched_text)
    if len(occurrences) == 1:
        start_byte, end_byte = occurrences[0]
        return {
            "pass": True,
            "matched_span": {"start_byte": start_byte, "end_byte": end_byte},
            "detail": "unique matched_text occurrence in cue",
        }
    if not occurrences:
        return {
            "pass": False,
            "matched_span": None,
            "detail": "matched_text not found in cue",
        }
    return {
        "pass": False,
        "matched_span": None,
        "detail": "ambiguous matched_text occurrence without trustworthy inventory span",
        "occurrence_count": len(occurrences),
    }


def spans_overlap(
    left: tuple[int, int], right: tuple[int, int]
) -> bool:
    return left[0] < right[1] and right[0] < left[1]


def expected_cue_after_joint_replacements(
    cue_text: str,
    replacements: list[tuple[int, int, str]],
) -> str:
    expected = cue_text
    for start_byte, end_byte, replacement in sorted(
        replacements, key=lambda item: item[0], reverse=True
    ):
        expected = replace_utf8_span(expected, start_byte, end_byte, replacement)
    return expected


def verify_accepted_cue_materialization(
    *,
    segment_position: int,
    input_cue: str,
    reviewed_cue: str,
    accepted_items: list[dict[str, Any]],
) -> dict[str, Any]:
    resolved: list[dict[str, Any]] = []
    for item in accepted_items:
        span_check = resolve_matched_span(
            cue_text=input_cue,
            candidate=item["candidate"],
        )
        resolved.append({**item, "span_check": span_check})

    if any(not row["span_check"]["pass"] for row in resolved):
        return {
            "pass": False,
            "segment_position": segment_position,
            "detail": "accepted candidate span resolution failed",
            "resolved_candidates": resolved,
        }

    spans: list[tuple[int, int]] = []
    replacements: list[tuple[int, int, str]] = []
    for row in resolved:
        span = row["span_check"]["matched_span"]
        assert span is not None
        start_byte = int(span["start_byte"])
        end_byte = int(span["end_byte"])
        current_span = (start_byte, end_byte)
        if any(spans_overlap(current_span, prior) for prior in spans):
            return {
                "pass": False,
                "segment_position": segment_position,
                "detail": "overlapping accepted candidate spans in cue",
                "resolved_candidates": resolved,
            }
        spans.append(current_span)
        replacements.append((start_byte, end_byte, row["expected_replacement"]))

    expected_cue = expected_cue_after_joint_replacements(input_cue, replacements)
    if reviewed_cue != expected_cue:
        return {
            "pass": False,
            "segment_position": segment_position,
            "detail": "reviewed cue does not equal jointly expected accepted replacements",
            "expected_cue_text": expected_cue,
            "resolved_candidates": resolved,
        }
    return {
        "pass": True,
        "segment_position": segment_position,
        "detail": "joint accepted replacements verified",
        "expected_cue_text": expected_cue,
        "resolved_candidates": resolved,
    }


def collect_unrelated_cue_edits(
    input_segments: list[dict[str, Any]],
    reviewed_segments: list[dict[str, Any]],
    accepted_segment_positions: set[int],
) -> list[dict[str, Any]]:
    unrelated: list[dict[str, Any]] = []
    for position, (source, reviewed) in enumerate(zip(input_segments, reviewed_segments)):
        if source["text"] == reviewed["text"]:
            continue
        if position not in accepted_segment_positions:
            unrelated.append(
                {
                    "segment_position": position,
                    "cue_index": position + 1,
                    "input_cue_text": source["text"],
                    "reviewed_cue_text": reviewed["text"],
                }
            )
    return unrelated


def audit_materialization(
    *,
    input_srt: Path,
    reviewed_srt: Path,
    inventory: dict[str, Any],
    labels_payload: dict[str, Any],
    decisions_payload: dict[str, Any],
    ground_truth: dict[str, Any],
    binding: dict[str, Any],
    input_srt_sha256: str,
    terms_sha256: str,
    reference_layer_sha256: str,
) -> dict[str, Any]:
    input_segments = parse_srt_strict(input_srt.read_text(encoding="utf-8"))
    reviewed_segments = parse_srt_strict(reviewed_srt.read_text(encoding="utf-8"))
    srt_structure = verify_srt_structure(input_segments, reviewed_segments)
    if not srt_structure["pass"]:
        raise ValueError(srt_structure["detail"])

    labels = labels_payload["labels"]
    decisions = decisions_payload["decisions"]
    candidates = inventory["candidates"]
    if len(labels) != len(candidates) or len(decisions) != len(candidates):
        raise ValueError("inventory/labels/decisions length mismatch")

    opportunity_by_id = {
        row["opportunity_id"]: row for row in ground_truth.get("opportunities", [])
    }
    accepted_by_segment: dict[int, list[dict[str, Any]]] = {}
    records: list[dict[str, Any]] = []
    accepted_segment_positions: set[int] = set()
    cue_verifications: list[dict[str, Any]] = []

    for index, (candidate, label, decision) in enumerate(
        zip(candidates, labels, decisions)
    ):
        base = {
            "candidate_index": index,
            "candidate_fingerprint": candidate["fingerprint"],
            "decision": decision,
            "classification": label.get("classification"),
            "pre_review_replacement_supported": label.get("replacement_supported"),
            "pre_review_boundary_supported": label.get("boundary_supported"),
            "matched_opportunity_id": label.get("matched_opportunity_id"),
        }
        accept = ACCEPT_RE.match(decision)
        if not accept:
            records.append(
                {
                    **base,
                    "status": "non_materialized",
                    "accepted_alternative_index": None,
                    "expected_replacement": None,
                    "actual_reviewed_cue_text": None,
                    "actual_reviewed_span_text": None,
                    "actual_boundary_verification": None,
                    "actual_replacement_verification": None,
                    "materialized_correctly": False,
                    "unsafe_materialized_edit": False,
                    "rationale": "reject/defer/manual decisions do not materialize edits",
                }
            )
            continue

        alt_index = int(accept.group(1))
        alternatives = candidate.get("alternatives", [])
        if alt_index >= len(alternatives):
            raise ValueError(f"accepted alternative out of range at candidate {index}")
        expected_replacement = alternatives[alt_index]["replacement_text"]
        segment_position = int(candidate["source_segment_position"])
        cue_index = int(candidate["cue_index"])
        if segment_position != cue_index - 1:
            raise ValueError(
                f"candidate {index} cue_index/source_segment_position inconsistent"
            )
        if segment_position >= len(input_segments):
            raise ValueError(f"candidate {index} segment position out of range")
        accepted_segment_positions.add(segment_position)
        accepted_by_segment.setdefault(segment_position, []).append(
            {
                "candidate_index": index,
                "candidate": candidate,
                "label": label,
                "expected_replacement": expected_replacement,
                "accepted_alternative_index": alt_index,
            }
        )
        records.append(
            {
                **base,
                "status": "materialized",
                "accepted_alternative_index": alt_index,
                "expected_replacement": expected_replacement,
                "actual_reviewed_cue_text": reviewed_segments[segment_position]["text"],
                "actual_reviewed_span_text": None,
                "actual_boundary_verification": None,
                "actual_replacement_verification": None,
                "materialized_correctly": False,
                "unsafe_materialized_edit": True,
                "rationale": "pending cue-level joint materialization verification",
                "human_attestation": None,
            }
        )

    for segment_position, accepted_items in sorted(accepted_by_segment.items()):
        cue_verification = verify_accepted_cue_materialization(
            segment_position=segment_position,
            input_cue=input_segments[segment_position]["text"],
            reviewed_cue=reviewed_segments[segment_position]["text"],
            accepted_items=accepted_items,
        )
        cue_verifications.append(cue_verification)
        for item in accepted_items:
            index = item["candidate_index"]
            record = records[index]
            label = item["label"]
            candidate = item["candidate"]
            resolved = next(
                row
                for row in cue_verification.get("resolved_candidates", [])
                if row["candidate_index"] == index
            )
            span_check = resolved["span_check"]
            matched_span = span_check.get("matched_span")
            replacement_check = {
                "pass": cue_verification["pass"] and span_check["pass"],
                "matched_span": matched_span,
                "actual_reviewed_span_text": (
                    item["expected_replacement"]
                    if cue_verification["pass"] and span_check["pass"]
                    else None
                ),
                "detail": span_check["detail"],
            }
            opportunity = (
                opportunity_by_id.get(label["matched_opportunity_id"])
                if label.get("matched_opportunity_id")
                else None
            )
            opportunity_term_match = (
                opportunity is not None
                and opportunity.get("canonical_term") == item["expected_replacement"]
            )
            materialized_correctly = (
                cue_verification["pass"]
                and label.get("classification") == "selected_true"
                and label.get("replacement_supported") is True
                and label.get("boundary_supported") is True
                and span_check["pass"]
                and opportunity_term_match
                and label.get("matched_opportunity_id") is not None
            )
            unsafe_materialized_edit = not materialized_correctly
            record.update(
                {
                    "actual_replacement_verification": replacement_check,
                    "actual_boundary_verification": {
                        "pass": cue_verification["pass"],
                        "detail": cue_verification["detail"],
                    },
                    "materialized_correctly": materialized_correctly,
                    "unsafe_materialized_edit": unsafe_materialized_edit,
                    "rationale": (
                        "deterministic post-review materialization verification"
                        if materialized_correctly
                        else cue_verification["detail"]
                    ),
                }
            )
            if candidate.get("cue_text") != input_segments[segment_position]["text"]:
                record["materialized_correctly"] = False
                record["unsafe_materialized_edit"] = True
                record["rationale"] = "candidate cue_text does not match source cue"

    unrelated = collect_unrelated_cue_edits(
        input_segments, reviewed_segments, accepted_segment_positions
    )
    if unrelated:
        for record in records:
            if record["status"] == "materialized":
                record["materialized_correctly"] = False
                record["unsafe_materialized_edit"] = True
                record["rationale"] = (
                    "unrelated cue edits detected outside accepted candidate targets"
                )

    fail_closed_reasons = [
        cue["detail"]
        for cue in cue_verifications
        if not cue["pass"]
    ]
    if unrelated:
        fail_closed_reasons.append("unrelated cue edits detected")

    return {
        "schema_revision": "voxproof-ami-materialization-audit-v1",
        "unsafe_definition_id": UNSAFE_DEFINITION_ID,
        "recorded_at_utc": utc_now(),
        "srt_structure_verification": srt_structure,
        "cue_verifications": cue_verifications,
        "audit_pass": not fail_closed_reasons,
        "fail_closed_reasons": fail_closed_reasons,
        "bindings": {
            "reviewed_output_sha256": sha256_file(reviewed_srt),
            "decision_log_sha256": binding["artifact_hashes"]["decision_log_sha256"],
            "authoritative_review_binding_sha256": sha256_file(
                Path(str(binding["_binding_path"]))
            ),
            "candidate_inventory_sha256": sha256_file(Path(str(binding["_inventory_path"]))),
            "ground_truth_sha256": sha256_file(Path(str(binding["_ground_truth_path"]))),
            "candidate_labels_sha256": sha256_file(Path(str(binding["_labels_path"]))),
            "decision_inputs_sha256": sha256_file(Path(str(binding["_decisions_path"]))),
            "input_srt_sha256": input_srt_sha256,
            "terms_sha256": terms_sha256,
            "reference_layer_sha256": reference_layer_sha256,
        },
        "records": records,
        "unrelated_cue_edits": unrelated,
        "accepted_candidate_count": sum(
            1 for decision in decisions if decision.startswith("a ")
        ),
        "materialized_record_count": sum(
            1 for record in records if record["status"] == "materialized"
        ),
        "correctly_materialized_opportunity_ids": sorted(
            {
                record["matched_opportunity_id"]
                for record in records
                if record["status"] == "materialized"
                and record["materialized_correctly"]
                and record.get("matched_opportunity_id")
            }
        ),
        "unsafe_materialized_accept_count": sum(
            1
            for record in records
            if record["status"] == "materialized"
            and record["unsafe_materialized_edit"]
        ),
    }


def run_materialization_audit(
    *,
    input_srt: Path,
    reviewed_srt: Path,
    decision_log: Path,
    binding_path: Path,
    inventory_path: Path,
    ground_truth_path: Path,
    labels_path: Path,
    decisions_path: Path,
    reference_layer_path: Path,
    terms_path: Path,
    output_path: Path,
) -> dict[str, Any]:
    binding = read_json(binding_path)
    binding["_binding_path"] = str(binding_path)
    binding["_inventory_path"] = str(inventory_path)
    binding["_ground_truth_path"] = str(ground_truth_path)
    binding["_labels_path"] = str(labels_path)
    binding["_decisions_path"] = str(decisions_path)
    if sha256_file(reviewed_srt) != binding["artifact_hashes"]["reviewed_output_sha256"]:
        raise RuntimeError("reviewed output hash mismatch with authoritative binding")
    if sha256_file(decision_log) != binding["artifact_hashes"]["decision_log_sha256"]:
        raise RuntimeError("decision log hash mismatch with authoritative binding")

    payload = audit_materialization(
        input_srt=input_srt,
        reviewed_srt=reviewed_srt,
        inventory=read_json(inventory_path),
        labels_payload=read_json(labels_path),
        decisions_payload=read_json(decisions_path),
        ground_truth=read_json(ground_truth_path),
        binding=binding,
        input_srt_sha256=sha256_file(input_srt),
        terms_sha256=sha256_file(terms_path),
        reference_layer_sha256=sha256_file(reference_layer_path),
    )
    write_json(output_path, payload)
    return payload


def main() -> int:
    import argparse
    import json

    parser = argparse.ArgumentParser(description="Audit post-review materialization")
    parser.add_argument("--input-srt", required=True)
    parser.add_argument("--reviewed-srt", required=True)
    parser.add_argument("--decision-log", required=True)
    parser.add_argument("--binding", required=True)
    parser.add_argument("--inventory", required=True)
    parser.add_argument("--ground-truth", required=True)
    parser.add_argument("--labels", required=True)
    parser.add_argument("--decision-inputs", required=True)
    parser.add_argument("--reference-layer", required=True)
    parser.add_argument("--terms", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    payload = run_materialization_audit(
        input_srt=Path(args.input_srt),
        reviewed_srt=Path(args.reviewed_srt),
        decision_log=Path(args.decision_log),
        binding_path=Path(args.binding),
        inventory_path=Path(args.inventory),
        ground_truth_path=Path(args.ground_truth),
        labels_path=Path(args.labels),
        decisions_path=Path(args.decision_inputs),
        reference_layer_path=Path(args.reference_layer),
        terms_path=Path(args.terms),
        output_path=Path(args.output),
    )
    print(
        json.dumps(
            {
                "status": "ok",
                "audit_pass": payload["audit_pass"],
                "materialized_record_count": payload["materialized_record_count"],
                "unsafe_materialized_accept_count": payload[
                    "unsafe_materialized_accept_count"
                ],
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
