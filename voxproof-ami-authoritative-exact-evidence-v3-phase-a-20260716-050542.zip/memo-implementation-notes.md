# Executable-envelope implementation notes

The strong-model rejection was treated as a blocking audit, not as a request to
relax verification.

- One study root now controls every Phase B path through
  `VOXPROOF_V3_STUDY_ROOT`; its frozen default is the extracted correction tree.
- `phase_b_runner.py` owns the complete stage chronology. Target access is
  durably recorded before ASR XML opens. Any failure after access is terminal,
  persistent, and non-retryable.
- `ami_transform.py` and `ami_common.py` strictly parse AMI-shaped words and
  segments XML, resolve href ranges, validate tags/IDs/timestamps, and write the
  hypothesis, reference, and scoring layers.
- Candidate probe and review use the attested environment and immediate binary
  hash checks. Review rechecks the inventory's binary/SRT/terms bindings and
  promotes outputs only after exact candidate reproduction.
- Human ground truth, labels, and decisions are jointly validated. Detector
  misses derive from unmatched opportunities; accepted and unsafe counts derive
  from decisions plus validated label semantics.
- Raw and reviewed transcript streams are aligned independently. The independent
  verifier reads operation files and audits directly and imports no primary
  scorer implementation.
- Script-lock generation is Phase A build behavior. Phase B preflight only reads
  and verifies exact set/hash/byte closure.
- Synthetic auto/manual ZIPs exercise every runner stage for zero and nonzero
  paths. ES2004b content is never opened by Phase A rehearsals.
- Phase A and Phase B package modes are explicit. Manifest/seal closure is
  recomputed after final ZIP creation.
