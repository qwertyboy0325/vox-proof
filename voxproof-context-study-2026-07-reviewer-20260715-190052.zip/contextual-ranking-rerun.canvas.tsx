import { useHostTheme } from "cursor/canvas";

const retrievalComparison = [
  ["Retrieval windows", "148", "48"],
  ["Candidates", "149", "49"],
  ["Candidates / minute", "2.60", "0.856"],
  ["Frozen true retained", "13 / 13", "13 / 13"],
  ["Frozen non-exact retrieval recall", "52%", "52%"],
];

const invalidBatchDiagnostics = [
  ["Selected", "30", "4"],
  ["Selected true", "12", "3"],
  ["Selected false", "18", "1"],
  ["Selected precision", "40.0%", "75.0%"],
  ["Retained retrieved true", "12/13", "3/13"],
  ["Non-exact recall", "48.0%", "12.0%"],
  ["Exact + selected recall", "70.45%", "50.0%"],
  ["Selected / minute", "0.524", "0.070"],
];

const samples = [
  ["Technology", "15 / 14", "3", "3", "3", "0"],
  ["Persona", "5 / 5", "0", "1", "0", "1"],
  ["Sports", "18 / 18", "10", "0", "0", "0"],
  ["Education control", "11 / 11", "0", "0", "0", "0"],
];

const missed = [
  "so far → soccer",
  "ten days → tennis",
  "Bagminton → badminton (6 occurrences)",
  "brackminton → badminton",
  "Tracy Magrady → Tracy McGrady",
];

export default function ContextualRankingRerun() {
  const theme = useHostTheme();
  const cell = {
    padding: "8px 10px",
    borderBottom: `1px solid ${theme.stroke.secondary}`,
    textAlign: "left" as const,
  };

  return (
    <main
      style={{
        minHeight: "100vh",
        background: theme.bg.editor,
        color: theme.text.primary,
        padding: 24,
        fontFamily: "system-ui, sans-serif",
      }}
    >
      <header style={{ maxWidth: 1000, marginBottom: 24 }}>
        <div style={{ color: theme.text.tertiary, fontSize: 12, letterSpacing: 0.6 }}>
          RETRIEVAL 0.3 · SIDECAR V3 · RERUN HEAD 5286c16
        </div>
        <h1 style={{ margin: "6px 0 8px", fontSize: 24 }}>
          External ranking rerun: comparison invalid
        </h1>
        <p style={{ margin: 0, color: theme.text.secondary, lineHeight: 1.55 }}>
          Retrieval passed all frozen gates, but the only completed Codex batch shifted response
          content from request 18. Ten selected IDs pointed into the next window and were safely
          suppressed. Deterministic retrieval is valid; ranking diagnostics are not model-quality
          results.
        </p>
      </header>

      <section
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, minmax(130px, 1fr))",
          gap: 12,
          maxWidth: 1000,
          marginBottom: 28,
        }}
      >
        {[
          ["Candidates", "49", "expected 49"],
          ["Windows", "48", "one multi-candidate"],
          ["True retained", "13 / 13", "retrieval gate passed"],
          ["Invalid raw selections", "10", "forensic signal only"],
        ].map(([label, value, note]) => (
          <div
            key={label}
            style={{
              background: theme.fill.tertiary,
              border: `1px solid ${theme.stroke.secondary}`,
              padding: 14,
            }}
          >
            <div style={{ color: theme.text.tertiary, fontSize: 12 }}>{label}</div>
            <div style={{ fontSize: 22, fontWeight: 650, margin: "4px 0" }}>{value}</div>
            <div style={{ color: theme.text.secondary, fontSize: 12 }}>{note}</div>
          </div>
        ))}
      </section>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "minmax(0, 1.5fr) minmax(280px, 1fr)",
          gap: 22,
          maxWidth: 1000,
          alignItems: "start",
        }}
      >
        <section>
          <h2 style={{ fontSize: 17, margin: "0 0 10px" }}>Valid deterministic retrieval</h2>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ background: theme.fill.secondary }}>
                <th style={cell}>Metric</th>
                <th style={cell}>Original</th>
                <th style={cell}>Retrieval 0.3</th>
              </tr>
            </thead>
            <tbody>
              {retrievalComparison.map(([metric, original, current]) => (
                <tr key={metric}>
                  <td style={cell}>{metric}</td>
                  <td style={cell}>{original}</td>
                  <td style={cell}>{current}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div style={{ color: theme.text.tertiary, fontSize: 11, marginTop: 8 }}>
            Source: frozen VoxProof contextual study · 57:14.086 of speech · 2026-07-15.
            These values are valid before external ranking.
          </div>
        </section>

        <aside
          style={{
            borderLeft: `3px solid ${theme.accent.primary}`,
            padding: "4px 0 4px 16px",
          }}
        >
          <h2 style={{ fontSize: 17, margin: "0 0 10px" }}>External attempts</h2>
          <ol style={{ margin: 0, paddingLeft: 18, lineHeight: 1.55, color: theme.text.secondary }}>
            <li>Timed out at 120 seconds; model-catalog refresh also timed out.</li>
            <li>Completed in 65.351 seconds; response alignment failed from index 18.</li>
            <li>Timed out at 120 seconds; no replacement response artifact.</li>
          </ol>
          <h3 style={{ fontSize: 14, margin: "18px 0 6px" }}>Disposition sidecar</h3>
          <p style={{ margin: 0, color: theme.text.secondary, lineHeight: 1.5 }}>
            48 succeeded · 0 fallback · 0 not run. “Succeeded” means the replay adapter returned
            schema-valid safe suppressions; it does not validate upstream semantic alignment.
          </p>
        </aside>
      </div>

      <section style={{ maxWidth: 1000, marginTop: 30 }}>
        <h2 style={{ fontSize: 17, margin: "0 0 8px" }}>Invalid-batch forensic diagnostics</h2>
        <p style={{ margin: "0 0 10px", color: theme.text.secondary, lineHeight: 1.5 }}>
          The completed batch lost semantic request alignment. These safe-replay values are retained
          for forensic analysis only; they are not model performance.
        </p>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ background: theme.fill.secondary }}>
              <th style={cell}>Metric</th>
              <th style={cell}>Original external result</th>
              <th style={cell}>Invalid safe replay</th>
            </tr>
          </thead>
          <tbody>
            {invalidBatchDiagnostics.map(([metric, original, current]) => (
              <tr key={metric}>
                <td style={cell}>{metric}</td>
                <td style={cell}>{original}</td>
                <td style={cell}>{current}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section style={{ maxWidth: 1000, marginTop: 30 }}>
        <h2 style={{ fontSize: 17, margin: "0 0 10px" }}>Per-sample safe-replay diagnostic</h2>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ background: theme.fill.secondary }}>
              {["Sample", "Candidates / windows", "Retrieved true", "Selected", "TP", "FP"].map(
                (heading) => (
                  <th key={heading} style={cell}>{heading}</th>
                ),
              )}
            </tr>
          </thead>
          <tbody>
            {samples.map((row) => (
              <tr key={row[0]}>
                {row.map((value, index) => (
                  <td key={`${row[0]}-${index}`} style={cell}>{value}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 24,
          maxWidth: 1000,
          marginTop: 28,
        }}
      >
        <div>
          <h2 style={{ fontSize: 17, margin: "0 0 8px" }}>Selected false positive</h2>
          <p style={{ margin: 0, color: theme.text.secondary, lineHeight: 1.55 }}>
            Persona · segment 26 bytes 22–51 · <b>information system management</b> →{" "}
            <b>information systems management</b> · Latin token-boundary · strong.
          </p>
          <p style={{ color: theme.text.tertiary, fontSize: 12, lineHeight: 1.5 }}>
            “Information systems management is the standard major name and a one-character
            correction.” Frozen taxonomy: ground-truth-negative domain-term morphology/context
            overlap.
          </p>
        </div>
        <div>
          <h2 style={{ fontSize: 17, margin: "0 0 8px" }}>Uninterpretable non-selections</h2>
          <ul style={{ margin: 0, paddingLeft: 18, color: theme.text.secondary, lineHeight: 1.55 }}>
            {missed.map((item) => <li key={item}>{item}</li>)}
          </ul>
          <p style={{ color: theme.text.tertiary, fontSize: 12, lineHeight: 1.5 }}>
            All ten sports outcomes and the remaining pinyin outcome occurred in the misaligned
            region; none is a model rejection.
          </p>
        </div>
      </section>

      <footer
        style={{
          maxWidth: 1000,
          marginTop: 28,
          paddingTop: 14,
          borderTop: `1px solid ${theme.stroke.primary}`,
          color: theme.text.tertiary,
          fontSize: 12,
          lineHeight: 1.5,
        }}
      >
        Provenance: root manifest HEAD 30e06061 identifies the original frozen corpus; rerun HEAD
        5286c16 identifies this retrieval 0.3 execution. Safety: all frozen manifest hashes matched;
        cue indices/timing/text were unchanged; no
        experimental selection entered the decision log or reviewed transcript; no arbitrary
        replacement text materialized. The remaining pinyin candidate 所以嗯 → Duolingo was not
        selected, but its shifted response is not a valid contextual judgment.
      </footer>
    </main>
  );
}
