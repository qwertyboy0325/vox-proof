# VoxProof real-material contextual-resolution calibration

Study ID: `voxproof-context-study-2026-07`  
Date: 2026-07-15  
Workspace: `/tmp/voxproof-context-study-2026-07/`  
Study-authored repository source/docs modifications: no  
Commit or push performed: no

## Executive result

The current retrieval thresholds create unacceptable review burden. Across 57:14 of authorized real bilingual speech, rules-only produced 149 candidates in 148 source windows for 25 relevant non-exact correction opportunities: 8.72% candidate precision, 52.0% recall, 2.60 candidates/minute, and 5.96 candidates per relevant correction. The existing CLI still prompted for all 148 windows in every experimental mode.

The strong external model materially filtered candidates, selecting 30 with 40.0% precision and retaining 12/13 retrieved true corrections. That is useful suppression evidence, but it did not demonstrate candidate-ordering uplift: all 13 true retrieved windows had only one candidate, while the corpus's sole multi-candidate window was a false positive. Deterministic hit@1/hit@3/MRR on retrieved true windows were already 1.0; the model rejected one true `so far` -> `soccer` correction. In the present interaction, model filtering also did not reduce prompts.

The dominant defect in study quality is retrieval noise, not model plumbing: `han_pinyin_auxiliary` emitted 85/149 candidates and 0 true positives, mainly ordinary one-character Mandarin discourse words compared with `AI`.

## 1. Repository re-entry facts

- Branch: `main`
- Initial HEAD before synchronization: `af8e32b4074e37c53610c823cff57b4672a8f432`
- Synchronized study HEAD: `30e06061a88cf548d663f7e5a09c047d74bec118`
- Worktree: clean; `main...origin/main`, no divergence
- Latest commit: `30e0606 docs: update README for contextual resolution experiment`
- Pushed contextual-resolution commit present: yes; `af8e32b` is the immediate parent of current HEAD
- Synchronization detail: the checkout fast-forwarded from `af8e32b` to the remote-authored, README-only `30e0606`; no runtime source changed and no study changes were authored in the repository.
- Untracked review patch files: none
- No files were cleaned or deleted.
- Exact documented invocation:

```sh
cargo run -- review-experiment \
  tests/fixtures/contextual-resolution-synthetic/input.srt \
  tests/fixtures/contextual-resolution-synthetic/session-terms.txt \
  tests/fixtures/contextual-resolution-synthetic/session-description.txt \
  rules-only \
  /tmp/experimental-report.json \
  /tmp/reviewed.srt \
  /tmp/decisions.txt \
  /tmp/session-summary.txt
```

General CLI shape:

```text
vox-proof review-experiment <input.srt> <session-terms.txt> <session-description.txt> <rules-only|fake|external-command> <experimental-report.json> <reviewed-output.srt> <decision-log.txt> <session-summary.txt>
```

Validation before the study: `cargo test` passed 145 library tests and 15 CLI tests, 0 failures.

## 2. Material shortlist and permission basis

| Candidate | Duration | Language/domain | Permission | Expected terminology | Decision |
|---|---:|---|---|---|---|
| ASCEND test split | 57:14 selected from 10.62h corpus | Mandarin/English code-switching; technology, persona, sports, education | CC BY-SA 4.0; expert-generated transcripts | AI, devices, locations, disciplines, athletes, sports/products | Selected; cue-aligned audio and trusted transcript |
| [*Relativity*, section 1](https://librivox.org/relativity-by-albert-einstein/) | 14:55 | English technical/science | Public-domain LibriVox text/audio | relativity, coordinates, mechanics | Excluded: book text was not cue-aligned trusted subtitle; would require a new human transcription |
| [*Great Astronomers*, introduction](https://librivox.org/great-astronomers-by-robert-stawell-ball/) | 11:49 | English technical/history of science | Public-domain LibriVox text/audio | astronomer and proper names | Excluded for the same alignment reason |
| [*The Elements of Style*, section 8](https://librivox.org/the-elements-of-style-by-william-strunk-jr/) | 13:04 | English instructional prose | Public-domain LibriVox text/audio | grammar/style terms | Excluded for the same alignment reason |
| [BSTC](https://aclanthology.org/2021.autosimtrans-1.5/) | potential 30-60 min subset | Mandarin/English speech translation | Reuse license not clear enough from the paper/artifact material | bilingual technical terms | Excluded before use because permission status was unclear |

Selected source: <https://huggingface.co/datasets/CAiRE/ASCEND>. The public dataset card describes expert-generated transcripts and a CC BY-SA 4.0 license.

## 3. Selected samples

| ID | Duration | Utterances | Language/script profile | Role |
|---|---:|---:|---|---|
| technology | 17:00.335 | 345 | 180 zh, 129 mixed, 36 en | Technical code-switching; devices, AI, payments |
| persona | 18:59.751 | 443 | 216 zh, 136 mixed, 91 en | Proper names, locations, disciplines |
| sports | 11:12.835 | 283 | 130 zh, 62 mixed, 91 en | Name/term-heavy positive sample |
| education | 10:01.165 | 244 | 159 zh, 46 mixed, 39 en | Negative control; plausible platform terms absent |
| **Total** | **57:14.086** | **1,315** | 685 zh, 373 mixed, 257 en | Four real samples |

The education term list intentionally contains Canvas, Moodle, Blackboard, Coursera, Pearson, Turnitin, Khan Academy, Quizlet, Duolingo, and Google Classroom while its description says no learning platform is expected. Terms for the other samples were plausible session knowledge, not copied exhaustively from reference errors.

## 4. Local workspace structure

```text
/tmp/voxproof-context-study-2026-07/
├── manifest.json
├── metrics.json
├── ground-truth-labels.json
├── study-report.md
├── sources/                  # downloaded source artifacts and excluded shortlist material
├── samples/<topic>/
│   ├── audio.wav
│   ├── clips/*.wav
│   ├── raw-asr.srt
│   ├── reference.srt
│   ├── session-terms.txt
│   ├── session-description.txt
│   ├── provenance.txt
│   └── source-rows.jsonl
├── runs/<topic>/<mode>/      # baseline, rules-only, fake, external-command
├── runs/education/external-failure/
└── tools/                    # preparation, temporary adapters, scoring scripts, local models
```

All corpus and derived material remained outside tracked repository paths.

## 5. Exact commands used

Repository checks and validation:

```sh
git branch --show-current
git rev-parse HEAD
git status --short --branch
git log -1 --oneline --decorate
git rev-parse origin/main
rg --files -g '*patch*' -g '*diff*'
cargo test
```

Corpus preparation:

```sh
PYTHONPATH=/tmp/voxproof-context-study-2026-07/tools/python-packages \
  python3 /tmp/voxproof-context-study-2026-07/tools/prepare_ascend.py
```

Raw ASR, once per topic:

```sh
whisper-cli -ng \
  -m /tmp/voxproof-context-study-2026-07/tools/ggml-small.bin \
  -l auto -t 12 \
  --vad -vm /tmp/voxproof-context-study-2026-07/tools/ggml-silero-v6.2.0.bin \
  -vspd 100 -vsd 80 -vmsd 30 -vp 30 \
  -osrt -np \
  -of /tmp/voxproof-context-study-2026-07/samples/<topic>/raw-asr \
  /tmp/voxproof-context-study-2026-07/samples/<topic>/audio.wav
```

The initial Metal attempt failed to allocate a 4.41 MiB buffer; CPU mode (`-ng`) succeeded. This was an ASR environment issue, not a VoxProof defect.

Per-topic baseline and built-in modes:

```sh
python3 /tmp/voxproof-context-study-2026-07/tools/drive_review.py <topic> baseline
python3 /tmp/voxproof-context-study-2026-07/tools/drive_review.py <topic> rules-only
python3 /tmp/voxproof-context-study-2026-07/tools/drive_review.py <topic> fake
```

The driver resolved these to the existing binary's `review` or `review-experiment` invocation and answered `r` for every exact case and `n` for every experimental suggestion so output fidelity could be measured separately without accepting changes.

External request capture, one pass per topic:

```sh
python3 /tmp/voxproof-context-study-2026-07/tools/drive_review.py <topic> external-command \
  --experiment-command /tmp/voxproof-context-study-2026-07/tools/capture_adapter.py
```

Strong-model batch invocation inside `run_batch_ranker.py`:

```sh
codex exec --ephemeral --skip-git-repo-check --sandbox read-only --ignore-rules \
  --model gpt-5.6-sol --config 'model_reasoning_effort="low"' \
  --output-schema /tmp/voxproof-context-study-2026-07/tools/batch-ranking-schema.json \
  --output-last-message /tmp/voxproof-context-study-2026-07/tools/batch-ranking-responses.json \
  '<bounded ranking prompt plus the 148 captured JSONL requests on stdin>'
```

The non-interactive flags and schema workflow were checked against the official Codex manual: <https://developers.openai.com/codex/codex-manual.md>.

Strict cached replay through the real external-command boundary:

```sh
python3 /tmp/voxproof-context-study-2026-07/tools/drive_review.py <topic> external-command \
  --experiment-command /tmp/voxproof-context-study-2026-07/tools/replay_adapter.py \
  --timeout-ms 5000
```

Failure fallback:

```sh
python3 /tmp/voxproof-context-study-2026-07/tools/drive_review.py education external-command \
  --output-label external-failure \
  --experiment-command /tmp/voxproof-context-study-2026-07/tools/fail_adapter.py \
  --timeout-ms 5000
```

## 6. Manifest summary

- Dataset artifact SHA-256, all audio/reference/raw/terms/description/provenance paths and hashes, durations, HEAD, ASR model hashes, and external response hash are in `manifest.json`.
- ASR: whisper.cpp `whisper-cli` 1.9.1, `ggml-small.bin`, auto language, CPU, Silero VAD 6.2.0.
- External: Codex CLI 0.144.3, `gpt-5.6-sol`, low reasoning, ephemeral/read-only execution.
- Captured external requests: 148; request JSONL SHA-256 `387c06b37a287a85bd629b3672ceac678a1fabeecc911920c9c405b1d7e9b188`.
- Model response SHA-256 `bf8e3792f2ce2896a3b3b3c4264d1972d4e0cd69f4ea8a535b85d29d797e442a`.

## 7. Per-sample metrics

The denominator “actual non-exact” counts configured-vocabulary corrections with a recoverable contiguous source span. Whole-clause ASR omissions are recorded qualitatively but excluded. Ground-truth decisions and edge-case notes are in `ground-truth-labels.json`.

| Sample | Actual non-exact | Candidates/windows | True retrieved | Precision | Recall | Cand/min | External selected (TP/FP) | External precision | Exact relevant/raised |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| technology | 6 | 101/100 | 3 | 2.97% | 50.0% | 5.94 | 5 (3/2) | 60.0% | 9/14 |
| persona | 1 | 16/16 | 0 | 0.0% | 0.0% | 0.84 | 12 (0/12) | 0.0% | 1/2 |
| sports | 18 | 21/21 | 10 | 47.62% | 55.56% | 1.87 | 13 (9/4) | 69.23% | 9/13 |
| education negative | 0 | 11/11 | 0 | 0.0% | n/a | 1.10 | 0 (0/0) | n/a | 0/0 |

## 8. Aggregate metrics

| Metric | Result |
|---|---:|
| Actual relevant exact corrections | 19 |
| Actual relevant non-exact corrections | 25 |
| Exact candidates raised / relevant | 29 / 19 |
| Exact candidate precision | 65.52% |
| Experimental candidates / source windows | 149 / 148 |
| Non-exact true candidates retrieved | 13 |
| Non-exact retrieval recall | 52.0% |
| Candidate precision | 8.72% |
| Candidate-window precision | 8.78% |
| Candidates per transcript minute | 2.60 |
| Candidates per non-exact relevant correction | 5.96 |
| False-positive candidates | 136 (2.38/min) |
| Deterministic hit@1 / hit@3 / MRR on retrieved true windows | 1.0 / 1.0 / 1.0 |
| Strong model selected / TP / FP | 30 / 12 / 18 |
| Strong-model selection precision | 40.0% |
| Strong-model recall of retrieved true candidates | 92.31% |
| Strong-model recall of all non-exact corrections | 48.0% |
| Exact + rules retrieval recall over all 44 relevant corrections | 72.73% |
| Exact + external-selected recall over all 44 relevant corrections | 70.45% |
| Selected manual-correction markers | 0 |
| External-selected true alias suggestions / distinct pairs | 12 / 7 |
| Multi-candidate windows / overlapping-window pairs | 1 / 7 |

Producer breakdown: 85 Han-pinyin auxiliary, 36 Latin normalized distance, 28 Latin token-boundary. All 13 true candidates came from Latin producers; Han-pinyin precision was 0/85. Fourteen Han-pinyin reports used alternate readings, none were correct; no pinyin expansion was truncated. No source window reached the configured cap of three candidates, so there was no observed candidate-cap loss.

## 9. Exact baseline versus model-ranked comparison

| Path | Relevant signal | False burden | What the run establishes |
|---|---:|---:|---|
| Existing exact path | 19/29 candidates relevant | 10 false exact candidates | Useful but can overgenerate on substring aliases (`Jordan` inside `Michael Jordan`) and style aliases contradicted by reference |
| Rules-only experimental | 13/149 candidates relevant; 52% non-exact recall | 136 false candidates | Retrieval finds useful misspellings but burden is unacceptable |
| Fake ranker | 148 successful ranking responses; 28 strong, 119 plausible, 1 ambiguous | Not a quality measure | Plumbing only; schema, prompt, and sidecar paths work |
| External strong model | 12/30 selected relevant; 40% precision | 18 selected false; one true rejected | Good suppression versus raw candidates, but no ordering uplift demonstrated and prompts remained 148 |

“Model ranking uplift over deterministic ordering” is not established. There was only one multi-candidate window (`phone` -> `iPhone` or `Python`), and neither candidate was correct. Every retrieved true window was single-candidate, so deterministic ordering already had hit@1=1.0. The model reduced false selections from 136 candidates to 18 but reduced true retrieved selection from 13 to 12.

## 10. Representative true positives

- `passanger` -> `passenger` (technology): distance producer retrieved it; external assessment strong.
- `neuro network` -> `neural network` (technology): external assessment strong.
- `deplanning` -> `deep learning` (technology): external assessment plausible.
- `ten days` -> `tennis` (sports): context and trusted reference support the full-span correction.
- `Bagminton` -> `badminton` (sports): six repeated real occurrences, all retrieved and externally selected strong.
- `brackminton` -> `badminton` (sports): retrieved and externally selected plausible.
- `Tracy Magrady` -> `Tracy McGrady` (sports): retrieved and externally selected strong.
- `so far` -> `soccer` (sports): retrieval true positive, but external model incorrectly marked unsupported; representative ranking failure.

## 11. Representative false positives and classes

- Short-token/pinyin collisions: ordinary `对`, `嗯`, `的`, `去`, `会`, `啊` -> `AI`. This is the largest class and is retrieval failure.
- Ordinary/domain collisions: negative control produced `doing` -> `Duolingo`, `more` -> `Moodle`, `reason/period/years` -> `Pearson`, and `can/cannot` -> `Canvas`. The model suppressed all 11, but rules-only still prompted all 11.
- Token-window overgeneration: `use iPhone` -> `iPhone`, `for iPhone` -> `iPhone`, `to Guangdong` -> `Guangdong`, `the integrated circuit` -> `integrated circuit`. The canonical term is already embedded; replacement would delete valid neighboring words. The model selected many of these, especially all 12 persona selections being false.
- Overlap: `ten` and `ten days` both targeted the same span; only the full `ten days` window is safe. Similar overlaps occurred for `years`/`years old`, `My Cantonese`/`Cantonese is`, Shenzhen/Shanghai windows, and `new one`/`one`.
- Candidate mention/session-description leakage: the strong model overpreferred embedded candidates in the persona sample even when replacement semantics were wrong. The description supplied domain plausibility, not proof of a span replacement.
- Pinyin heteronyms: 14 alternate-reading reports were emitted, 0 correct. The more basic short-span eligibility problem dominated; no bounded expansion was truncated.
- Acronym/symbol/explicit alias: correct `Ai` -> `AI` cases stayed in the exact path. This supports explicit aliases rather than fuzzy pinyin for short acronyms.

## 12. Missed corrections

Twelve of 25 relevant non-exact corrections were not retrieved:

- Technology: `阿里佩` -> `Alipay` twice; `vary fission code` -> `verification code` once.
- Persona: a `(speaking in foreign language)` span corresponding to `Shenzhen` once. A complete early utterance omission containing `information systems management` was recorded as ASR/reference uncertainty and excluded from the recoverable-span denominator.
- Sports: three unretrieved soccer/code-switch spans; four additional `Magrady`/`McGrady` surfaces; `Hillstone Rocket` -> `Houston Rockets` once.

Misses separate into transliteration gaps (Alipay), multi-token phonetic gaps (verification code, Houston Rockets), ASR placeholder/omission (Shenzhen), and insufficient alias coverage (repeated Magrady).

## 13. Candidate-overload observations

- All modes prompted exactly 148 experimental windows, including unsupported external rankings. Therefore model filtering did not reduce current product interaction burden.
- Technology alone produced 101 candidates in 17 minutes (5.94/minute), 98 false.
- The 85 Han-pinyin candidates are 57.0% of all candidates and contributed no true positives.
- Seven pairs of source windows overlapped; one window had two candidates. Overlaps can present mutually unsafe partial/full replacements.
- No candidate-cap loss occurred: the maximum observed candidates per window was two, below the cap of three.
- The fake ranker validates mechanics only and must not be interpreted as confidence or quality.

## 14. Alias-promotion opportunities

The external model selected 12 true suggestions representing seven distinct potential alias pairs: `passanger`/passenger, `neuro network`/neural network, `deplanning`/deep learning, `ten days`/tennis, `Bagminton`/badminton, `brackminton`/badminton, and `Tracy Magrady`/Tracy McGrady. Rules-only also retrieved `so far`/soccer, but the external model rejected it, making eight distinct true retrieved pairs overall.

Only `Bagminton` has strong within-session recurrence (six occurrences) and is the clearest explicit-alias promotion opportunity. Other potential aliases from misses include `Magrady`, `阿里佩`, `vary fission code`, and `Hillstone Rocket`, but single-study evidence should not silently promote them. All would remain human-approved/session-scoped.

## 15. Experiment-blocking defect

No VoxProof experiment-blocking defect was found. Baseline, rules-only, fake, strict external replay, and failure fallback all completed through the existing interfaces. The inability to establish ranking-order uplift is a corpus/result limitation (only one multi-candidate window, and it was false), not a runtime defect.

LM Studio 0.4.19+2 was discovered locally, but probing its `lms` CLI launched the GUI and macOS aborted AppKit registration under the Codex process context. It was stopped and not used for study results. The already-installed headless Codex CLI was used instead, without changing VoxProof provider architecture.

## 16. Single highest-value next implementation change

Add a deterministic pre-ranking source-span eligibility gate for `han_pinyin_auxiliary`: do not emit fuzzy pinyin candidates for one- or two-character ordinary Han spans against very short Latin acronyms such as `AI` unless the surface is an explicit alias (or meets a much stronger, independently justified boundary/evidence rule).

This one bounded change targets 85/149 candidates and 0/13 true positives, so it should remove the largest measured burden before any model cost or interaction. Re-run the same frozen manifest afterward; do not first invest in richer ranking architecture. A follow-on study can then address embedded-term window viability and transliteration recall.

## Safety and authority checks

- Experimental suggestions became ReviewCases: no.
- Sidecar markers entered ReviewLedger: no; manual marker count was 0.
- Reviewed SRT changed: no; parsed timing/text matched raw ASR in all 16 primary runs because every exact case was rejected and every experimental suggestion was declined.
- Rules-only disposition: 148/148 `not_run`, no provider failure.
- External replay: 148/148 `succeeded`, strict response validation failures 0.
- Forced adapter exit 7: VoxProof exited 0 and 11/11 education rankings recorded `fell_back_after_failure` with `non_zero_exit`.
- Arbitrary model replacement in rankings/output: none; all selected IDs were members of the request and `requires_review=true`.
- Repository source/docs modified, committed, or pushed: no.
