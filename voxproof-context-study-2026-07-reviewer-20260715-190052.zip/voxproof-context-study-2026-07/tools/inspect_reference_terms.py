#!/usr/bin/env python3
import re
from pathlib import Path

ROOT = Path("/tmp/voxproof-context-study-2026-07")


def timestamp(value: str) -> int:
    h, m, tail = value.replace(".", ",").split(":")
    s, ms = tail.split(",")
    return ((int(h) * 60 + int(m)) * 60 + int(s)) * 1000 + int(ms)


def srt(path: Path) -> list[dict]:
    out = []
    for block in re.split(r"\n\s*\n", path.read_text().strip()):
        lines = block.splitlines()
        start, end = lines[1].split(" --> ")
        out.append({"index": int(lines[0]), "start": timestamp(start), "end": timestamp(end), "text": " ".join(lines[2:])})
    return out


def terms(path: Path) -> list[tuple[str, list[str]]]:
    out = []
    for line in path.read_text().splitlines():
        if not line or line.startswith("#"):
            continue
        bits = [x.strip() for x in line.split("|")]
        canonical = bits[0]
        aliases = [x.split(":", 1)[1] for x in bits[1:] if x.startswith("alias:")]
        out.append((canonical, [canonical] + aliases))
    return out


def compact(text: str) -> str:
    return "".join(c.casefold() for c in text if c.isalnum())


for topic in ["technology", "persona", "sports", "education"]:
    raw = srt(ROOT / "samples" / topic / "raw-asr.srt")
    ref = srt(ROOT / "samples" / topic / "reference.srt")
    vocab = terms(ROOT / "samples" / topic / "session-terms.txt")
    print("\n###", topic)
    for cue in ref:
        hits = [canonical for canonical, forms in vocab if any(compact(form) in compact(cue["text"]) for form in forms)]
        if not hits:
            continue
        overlap = " / ".join(r["text"] for r in raw if r["end"] >= cue["start"] and r["start"] <= cue["end"])
        print(f"{cue['index']}\t{','.join(hits)}\tREF={cue['text']}\tRAW={overlap}")
