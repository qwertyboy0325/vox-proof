#!/usr/bin/env python3
import subprocess
from pathlib import Path


ROOT = Path("/tmp/voxproof-context-study-2026-07/tools")
REQUESTS = ROOT / "ranking-requests.jsonl"
SCHEMA = ROOT / "batch-ranking-schema.json"
OUTPUT = ROOT / "batch-ranking-responses.json"

PROMPT = """Rank the 148 independent VoxProof experimental requests supplied as JSONL on stdin.

Return exactly one response per input line, in the same order, with request_index equal to the zero-based line index. Treat every request independently. Select only a candidate_id present in that request, or null. This is ranking and support assessment only: never produce replacement text.

Use the source surface, nearby context, session description, candidate canonical term, retrieval producer, representations, and distance. A term merely appearing or being suggested by the session description is not enough when nearby context does not support it. Suppress ordinary-word/domain-term collisions. Use strong or plausible only with a selected candidate. Use unsupported with null and no_candidate_supported when no candidate fits. Use ambiguous with null and multiple_candidates only when multiple candidates remain genuinely tied. Always requires_review=true. Keep display explanations short and do not include hidden reasoning."""


def main() -> None:
    request_text = REQUESTS.read_text(encoding="utf-8")
    command = [
        "/opt/homebrew/bin/codex",
        "exec",
        "--ephemeral",
        "--skip-git-repo-check",
        "--sandbox",
        "read-only",
        "--ignore-rules",
        "--model",
        "gpt-5.6-sol",
        "--config",
        'model_reasoning_effort="low"',
        "--output-schema",
        str(SCHEMA),
        "--output-last-message",
        str(OUTPUT),
        PROMPT,
    ]
    completed = subprocess.run(
        command,
        input=request_text,
        text=True,
        cwd="/tmp/voxproof-context-study-2026-07",
        check=False,
    )
    raise SystemExit(completed.returncode)


if __name__ == "__main__":
    main()
