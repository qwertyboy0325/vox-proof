#!/usr/bin/env python3
import io
import json
import sys
import wave
from collections import defaultdict
from pathlib import Path

import pyarrow.parquet as pq


ROOT = Path("/tmp/voxproof-context-study-2026-07")
PARQUET = ROOT / "sources" / "ascend-test.parquet"
SAMPLES = ROOT / "samples"
TOPICS = ("technology", "persona", "sports", "education")
SILENCE_MS = 100


def srt_time(milliseconds: int) -> str:
    hours, remainder = divmod(milliseconds, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    seconds, millis = divmod(remainder, 1_000)
    return f"{hours:02}:{minutes:02}:{seconds:02},{millis:03}"


def main() -> None:
    rows = pq.read_table(PARQUET).to_pylist()
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["topic"]].append(row)

    for topic in TOPICS:
        sample_dir = SAMPLES / topic
        sample_dir.mkdir(parents=True, exist_ok=True)
        clips_dir = sample_dir / "clips"
        clips_dir.mkdir(parents=True, exist_ok=True)
        topic_rows = grouped[topic]
        params = None
        frames = []
        reference_blocks = []
        metadata_lines = []
        cursor_frames = 0

        for cue_index, row in enumerate(topic_rows, start=1):
            with wave.open(io.BytesIO(row["audio"]["bytes"]), "rb") as source:
                current = (
                    source.getnchannels(),
                    source.getsampwidth(),
                    source.getframerate(),
                    source.getcomptype(),
                    source.getcompname(),
                )
                if params is None:
                    params = current
                elif current != params:
                    raise RuntimeError(f"audio parameters differ for {row['id']}: {current} != {params}")
                clip_frames = source.readframes(source.getnframes())
                clip_count = len(clip_frames) // (params[0] * params[1])

            clip_path = clips_dir / f"{cue_index:05}.wav"
            clip_path.write_bytes(row["audio"]["bytes"])

            start_ms = round(cursor_frames * 1000 / params[2])
            frames.append(clip_frames)
            cursor_frames += clip_count
            end_ms = round(cursor_frames * 1000 / params[2])
            reference_blocks.append(
                f"{cue_index}\n{srt_time(start_ms)} --> {srt_time(end_ms)}\n{row['transcription']}\n"
            )

            metadata_lines.append(
                json.dumps(
                    {
                        "cue_index": cue_index,
                        "ascend_id": row["id"],
                        "source_path": row["audio"]["path"],
                        "local_clip_path": str(clip_path),
                        "source_duration_seconds": row["duration"],
                        "language": row["language"],
                        "speaker_id": row["original_speaker_id"],
                        "session_id": row["session_id"],
                        "topic": row["topic"],
                        "reference": row["transcription"],
                    },
                    ensure_ascii=False,
                )
            )

            if cue_index != len(topic_rows):
                silence_frames = round(params[2] * SILENCE_MS / 1000)
                frames.append(b"\x00" * silence_frames * params[0] * params[1])
                cursor_frames += silence_frames

        with wave.open(str(sample_dir / "audio.wav"), "wb") as target:
            target.setnchannels(params[0])
            target.setsampwidth(params[1])
            target.setframerate(params[2])
            target.setcomptype(params[3], params[4])
            target.writeframes(b"".join(frames))

        (sample_dir / "reference.srt").write_text("\n".join(reference_blocks), encoding="utf-8")
        (sample_dir / "source-rows.jsonl").write_text("\n".join(metadata_lines) + "\n", encoding="utf-8")
        duration_ms = round(cursor_frames * 1000 / params[2])
        print(
            json.dumps(
                {
                    "topic": topic,
                    "utterances": len(topic_rows),
                    "duration_seconds_with_interclip_silence": duration_ms / 1000,
                    "language_counts": {
                        language: sum(row["language"] == language for row in topic_rows)
                        for language in ("zh", "mixed", "en")
                    },
                },
                ensure_ascii=False,
            )
        )


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"prepare_ascend.py: {error}", file=sys.stderr)
        raise
