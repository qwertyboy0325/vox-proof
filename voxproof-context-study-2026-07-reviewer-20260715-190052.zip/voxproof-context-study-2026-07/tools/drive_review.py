#!/usr/bin/env python3
import argparse
import os
import subprocess
import sys
from pathlib import Path


EXPERIMENT_PROMPT = b"Experimental selection [s <candidate-id>/n]: "
EXACT_PROMPT = b"Decision [a <index>/r/d/m]: "


def run(command: list[str], log_path: Path, environment: dict[str, str]) -> tuple[int, int, int]:
    process = subprocess.Popen(
        command,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=environment,
        bufsize=0,
    )
    pending = bytearray()
    experimental_prompts = 0
    exact_prompts = 0
    with log_path.open("wb") as log:
        while True:
            chunk = process.stdout.read(1)
            if not chunk:
                break
            log.write(chunk)
            pending.extend(chunk)
            if pending.endswith(EXPERIMENT_PROMPT):
                process.stdin.write(b"n\n")
                process.stdin.flush()
                log.write(b"n\n")
                experimental_prompts += 1
                pending.clear()
            elif pending.endswith(EXACT_PROMPT):
                process.stdin.write(b"r\n")
                process.stdin.flush()
                log.write(b"r\n")
                exact_prompts += 1
                pending.clear()
            elif len(pending) > max(len(EXPERIMENT_PROMPT), len(EXACT_PROMPT)):
                del pending[:-max(len(EXPERIMENT_PROMPT), len(EXACT_PROMPT))]
    return_code = process.wait()
    return return_code, experimental_prompts, exact_prompts


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("topic")
    parser.add_argument("mode", choices=("baseline", "rules-only", "fake", "external-command"))
    parser.add_argument("--experiment-command")
    parser.add_argument("--timeout-ms", default="120000")
    parser.add_argument("--output-label")
    args = parser.parse_args()

    root = Path("/tmp/voxproof-context-study-2026-07")
    sample = root / "samples" / args.topic
    output = root / "runs" / args.topic / (args.output_label or args.mode)
    output.mkdir(parents=True, exist_ok=True)
    binary = Path("/Users/Ezra4/Coding/Repo/vox-proof/target/debug/vox-proof")

    if args.mode == "baseline":
        command = [
            str(binary),
            "review",
            str(sample / "raw-asr.srt"),
            str(sample / "session-terms.txt"),
            str(output / "reviewed.srt"),
            str(output / "decision-log.txt"),
            str(output / "session-summary.txt"),
        ]
    else:
        command = [
            str(binary),
            "review-experiment",
            str(sample / "raw-asr.srt"),
            str(sample / "session-terms.txt"),
            str(sample / "session-description.txt"),
            args.mode,
            str(output / "experimental-report.json"),
            str(output / "reviewed.srt"),
            str(output / "decision-log.txt"),
            str(output / "session-summary.txt"),
        ]

    environment = os.environ.copy()
    if args.mode == "external-command":
        if not args.experiment_command:
            parser.error("--experiment-command is required for external-command")
        environment["VOX_PROOF_EXPERIMENT_COMMAND"] = args.experiment_command
        environment["VOX_PROOF_EXPERIMENT_TIMEOUT_MS"] = args.timeout_ms

    return_code, experimental_prompts, exact_prompts = run(
        command, output / "console.log", environment
    )
    print(
        f"topic={args.topic} mode={args.mode} exit={return_code} "
        f"experimental_prompts={experimental_prompts} exact_prompts={exact_prompts}"
    )
    if return_code != 0:
        sys.exit(return_code)


if __name__ == "__main__":
    main()
