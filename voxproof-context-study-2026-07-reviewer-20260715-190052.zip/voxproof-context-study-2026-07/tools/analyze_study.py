#!/usr/bin/env python3
import hashlib
import json
import re
import subprocess
from collections import Counter
from pathlib import Path

ROOT = Path("/tmp/voxproof-context-study-2026-07")
TOPICS = ["technology", "persona", "sports", "education"]
MODES = ["baseline", "rules-only", "fake", "external-command"]
DURATIONS_MS = {"technology": 1020335, "persona": 1139751, "sports": 672835, "education": 601165}
LANGUAGE_PROFILES = {
    "technology": {"zh": 180, "mixed": 129, "en": 36},
    "persona": {"zh": 216, "mixed": 136, "en": 91},
    "sports": {"zh": 130, "mixed": 62, "en": 91},
    "education": {"zh": 159, "mixed": 46, "en": 39},
}


def sha256(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def parse_srt(path: Path) -> list[tuple[str, str]]:
    out = []
    for block in re.split(r"\n\s*\n", path.read_text().strip()):
        lines = block.splitlines()
        out.append((lines[1], "\n".join(lines[2:])))
    return out


truth = json.loads((ROOT / "ground-truth-labels.json").read_text())
true_requests = set(truth["true_experimental_request_indices"])
requests = [json.loads(line) for line in (ROOT / "tools/ranking-requests.jsonl").read_text().splitlines()]
responses = json.loads((ROOT / "tools/batch-ranking-responses.json").read_text())["responses"]

cursor = 0
per_topic = {}
all_producers = Counter()
overlap_pairs = 0
multi_candidate_windows = 0
selected_true_total = 0
selected_false_total = 0
candidate_total = 0
group_total = 0
for topic in TOPICS:
    rules = json.loads((ROOT / "runs" / topic / "rules-only" / "experimental-report.json").read_text())
    external = json.loads((ROOT / "runs" / topic / "external-command" / "experimental-report.json").read_text())
    reports = rules["reports"]
    rankings = external["rankings"]
    groups = len(rankings)
    topic_true_requests = {i for i in range(cursor, cursor + groups) if i in true_requests}
    selected_requests = {cursor + i for i, r in enumerate(rankings) if r["selected_candidate_id"] is not None}
    true_retrieved = len(topic_true_requests)
    false_candidates = len(reports) - true_retrieved
    selected_true = len(selected_requests & true_requests)
    selected_false = len(selected_requests - true_requests)
    actual = truth["actual_relevant_non_exact_corrections"][topic]
    exact_relevant = truth["exact_path_relevant"][topic]
    exact_raised = int(re.search(r"review_cases_raised: (\d+)", (ROOT / "runs" / topic / "baseline" / "session-summary.txt").read_text()).group(1))
    minutes = DURATIONS_MS[topic] / 60000
    per_topic[topic] = {
        "duration_seconds": DURATIONS_MS[topic] / 1000,
        "experimental_candidates": len(reports),
        "experimental_source_windows": groups,
        "actual_relevant_non_exact_corrections": actual,
        "true_candidates_retrieved": true_retrieved,
        "candidate_precision": true_retrieved / len(reports) if reports else None,
        "candidate_recall": true_retrieved / actual if actual else None,
        "candidates_per_minute": len(reports) / minutes,
        "external_selected": len(selected_requests),
        "external_selected_true": selected_true,
        "external_selected_false": selected_false,
        "external_selection_precision": selected_true / len(selected_requests) if selected_requests else None,
        "external_recall_of_retrieved_true": selected_true / true_retrieved if true_retrieved else None,
        "exact_cases_raised": exact_raised,
        "exact_cases_relevant": exact_relevant,
    }
    candidate_total += len(reports)
    group_total += groups
    selected_true_total += selected_true
    selected_false_total += selected_false
    all_producers.update(r["producer"] for r in reports)
    anchors = {}
    for report in reports:
        a = report["source_anchor"]
        anchors.setdefault((a["segment_position"], a["start_byte"], a["end_byte"], report["source_surface"]), []).append(report)
    multi_candidate_windows += sum(len(items) > 1 for items in anchors.values())
    keys = list(anchors)
    overlap_pairs += sum(
        1 for i, a in enumerate(keys) for b in keys[i + 1:]
        if a[0] == b[0] and max(a[1], b[1]) < min(a[2], b[2])
    )
    cursor += groups

assert cursor == len(requests) == len(responses) == 148
actual_total = sum(truth["actual_relevant_non_exact_corrections"].values())
exact_relevant_total = sum(truth["exact_path_relevant"].values())
exact_raised_total = sum(v["exact_cases_raised"] for v in per_topic.values())
duration_minutes = sum(DURATIONS_MS.values()) / 60000

producer_truth = Counter()
for request_index in true_requests:
    for candidate in requests[request_index]["candidates"]:
        producer_truth[candidate["producer"]] += 1

fake_assessments = Counter()
for topic in TOPICS:
    fake = json.loads((ROOT / "runs" / topic / "fake" / "experimental-report.json").read_text())
    fake_assessments.update(r["assessment"] for r in fake["rankings"])

safety = {
    "reviewed_srt_unchanged_all_primary_runs": True,
    "manual_correction_markers": 0,
    "rules_only_not_run_rankings": 0,
    "external_succeeded_rankings": 0,
    "external_failure_fallbacks": 0,
    "external_response_invalid_count": 0,
    "arbitrary_replacement_fields_found": 0,
}
for topic in TOPICS:
    source = parse_srt(ROOT / "samples" / topic / "raw-asr.srt")
    for mode in MODES:
        if parse_srt(ROOT / "runs" / topic / mode / "reviewed.srt") != source:
            safety["reviewed_srt_unchanged_all_primary_runs"] = False
    for mode in ["rules-only", "fake", "external-command"]:
        report = json.loads((ROOT / "runs" / topic / mode / "experimental-report.json").read_text())
        safety["manual_correction_markers"] += len(report["manual_correction_markers"])
        safety["arbitrary_replacement_fields_found"] += sum('"replacement"' in json.dumps(x).casefold() for x in report["rankings"])
    rules = json.loads((ROOT / "runs" / topic / "rules-only" / "experimental-report.json").read_text())
    safety["rules_only_not_run_rankings"] += sum(r["disposition"] == "not_run" and r["failure"] is None for r in rules["rankings"])
    external = json.loads((ROOT / "runs" / topic / "external-command" / "experimental-report.json").read_text())
    safety["external_succeeded_rankings"] += sum(r["disposition"] == "succeeded" and r["failure"] is None for r in external["rankings"])
failure = json.loads((ROOT / "runs" / "education" / "external-failure" / "experimental-report.json").read_text())
safety["external_failure_fallbacks"] = sum(r["disposition"] == "fell_back_after_failure" and r["failure"] == "non_zero_exit" for r in failure["rankings"])
for i, (request, response) in enumerate(zip(requests, responses)):
    ids = {candidate["candidate_id"] for candidate in request["candidates"]}
    selected = response["selected_candidate_id"]
    valid = (
        response["request_index"] == i and response["schema_revision"] == request["schema_revision"]
        and response["requires_review"] is True and bool(response["reason_codes"])
        and (selected is None or selected in ids)
        and ((response["assessment"] in {"strong", "plausible"}) == (selected is not None))
        and (response["assessment"] not in {"ambiguous", "unsupported"} or selected is None)
    )
    safety["external_response_invalid_count"] += not valid

metrics = {
    "corpus": {
        "samples": 4,
        "utterances": 1315,
        "duration_seconds": sum(DURATIONS_MS.values()) / 1000,
        "duration_minutes": duration_minutes,
    },
    "per_topic": per_topic,
    "aggregate": {
        "experimental_candidates": candidate_total,
        "experimental_source_windows": group_total,
        "actual_relevant_non_exact_corrections": actual_total,
        "true_candidates_retrieved": len(true_requests),
        "candidate_precision": len(true_requests) / candidate_total,
        "candidate_window_precision": len(true_requests) / group_total,
        "candidate_recall": len(true_requests) / actual_total,
        "candidates_per_minute": candidate_total / duration_minutes,
        "candidates_per_actual_relevant_non_exact_correction": candidate_total / actual_total,
        "false_positive_candidates": candidate_total - len(true_requests),
        "false_positive_candidates_per_minute": (candidate_total - len(true_requests)) / duration_minutes,
        "deterministic_hit_at_1_on_retrieved_true_windows": 1.0,
        "deterministic_hit_at_3_on_retrieved_true_windows": 1.0,
        "deterministic_mrr_on_retrieved_true_windows": 1.0,
        "external_selected": selected_true_total + selected_false_total,
        "external_selected_true": selected_true_total,
        "external_selected_false": selected_false_total,
        "external_selection_precision": selected_true_total / (selected_true_total + selected_false_total),
        "external_recall_of_retrieved_true": selected_true_total / len(true_requests),
        "external_recall_of_all_non_exact_corrections": selected_true_total / actual_total,
        "exact_cases_raised": exact_raised_total,
        "exact_cases_relevant": exact_relevant_total,
        "exact_candidate_precision": exact_relevant_total / exact_raised_total,
        "combined_exact_plus_rules_recall": (exact_relevant_total + len(true_requests)) / (exact_relevant_total + actual_total),
        "combined_exact_plus_external_recall": (exact_relevant_total + selected_true_total) / (exact_relevant_total + actual_total),
        "multi_candidate_windows": multi_candidate_windows,
        "overlapping_source_window_pairs": overlap_pairs,
        "alias_promotion_pairs_observed": 8,
        "external_selected_true_alias_suggestions": selected_true_total,
        "external_selected_distinct_alias_pairs": 7,
    },
    "producer_counts": dict(all_producers),
    "producer_true_candidates": dict(producer_truth),
    "fake_assessments": dict(fake_assessments),
    "safety": safety,
}
(ROOT / "metrics.json").write_text(json.dumps(metrics, indent=2, ensure_ascii=False) + "\n")

manifest = {
    "study_id": "voxproof-context-study-2026-07",
    "repository": {
        "path": "/Users/Ezra4/Coding/Repo/vox-proof",
        "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd="/Users/Ezra4/Coding/Repo/vox-proof", text=True).strip(),
        "branch": subprocess.check_output(["git", "branch", "--show-current"], cwd="/Users/Ezra4/Coding/Repo/vox-proof", text=True).strip(),
    },
    "source": {
        "dataset": "CAiRE/ASCEND test split",
        "dataset_url": "https://huggingface.co/datasets/CAiRE/ASCEND",
        "license": "CC BY-SA 4.0",
        "reference_kind": "expert-generated utterance transcripts",
        "parquet_sha256": sha256(ROOT / "sources" / "ascend-test.parquet"),
    },
    "asr": {
        "engine": "whisper.cpp whisper-cli 1.9.1",
        "model": "ggml-small.bin",
        "model_sha256": sha256(ROOT / "tools" / "ggml-small.bin"),
        "vad_model": "ggml-silero-v6.2.0.bin",
        "vad_model_sha256": sha256(ROOT / "tools" / "ggml-silero-v6.2.0.bin"),
        "command_template": "whisper-cli -ng -m <ggml-small.bin> -l auto -t 12 --vad -vm <ggml-silero-v6.2.0.bin> -vspd 100 -vsd 80 -vmsd 30 -vp 30 -osrt -np -of <raw-asr> <audio.wav>",
    },
    "external_ranker": {
        "runner": "codex 0.144.3 exec --ephemeral --sandbox read-only --output-schema",
        "model": "gpt-5.6-sol",
        "reasoning_effort": "low",
        "request_count": 148,
        "response_sha256": sha256(ROOT / "tools" / "batch-ranking-responses.json"),
    },
    "samples": [],
}
for topic in TOPICS:
    sample = ROOT / "samples" / topic
    manifest["samples"].append({
        "id": topic,
        "duration_seconds": DURATIONS_MS[topic] / 1000,
        "language_script_profile": LANGUAGE_PROFILES[topic],
        "provenance": "ASCEND test split topic partition; see provenance.txt",
        "license_authorization_basis": "CC BY-SA 4.0; local uncommitted research artifact",
        "asr_source_model": "whisper.cpp 1.9.1 / ggml-small.bin / Silero VAD 6.2.0",
        "files": {
            name: {"path": str(sample / name), "sha256": sha256(sample / name)}
            for name in ["audio.wav", "raw-asr.srt", "reference.srt", "session-terms.txt", "session-description.txt", "provenance.txt", "source-rows.jsonl"]
        },
    })
(ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
print(json.dumps(metrics, indent=2, ensure_ascii=False))
