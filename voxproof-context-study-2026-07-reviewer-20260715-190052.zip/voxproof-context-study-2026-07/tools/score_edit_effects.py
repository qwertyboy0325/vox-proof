#!/usr/bin/env python3
import json
import re
from pathlib import Path

ROOT = Path("/tmp/voxproof-context-study-2026-07")


def timestamp(value: str) -> int:
    h, m, tail = value.replace(".", ",").split(":")
    s, ms = tail.split(",")
    return ((int(h) * 60 + int(m)) * 60 + int(s)) * 1000 + int(ms)


def srt(path: Path) -> list[dict]:
    out = []
    for block in re.split(r"\n\s*\n", path.read_text().strip()):
        lines = block.splitlines()
        start, end = lines[1].split(" --> ")
        out.append({"start": timestamp(start), "end": timestamp(end), "text": " ".join(lines[2:])})
    return out


def norm(text: str) -> str:
    return "".join(c.casefold() for c in text if c.isalnum())


def lev(a: str, b: str) -> int:
    if len(a) > len(b):
        a, b = b, a
    row = list(range(len(a) + 1))
    for i, cb in enumerate(b, 1):
        next_row = [i]
        for j, ca in enumerate(a, 1):
            next_row.append(min(next_row[-1] + 1, row[j] + 1, row[j - 1] + (ca != cb)))
        row = next_row
    return row[-1]


for topic in ["technology", "persona", "sports", "education"]:
    raw = srt(ROOT / "samples" / topic / "raw-asr.srt")
    ref = srt(ROOT / "samples" / topic / "reference.srt")
    report = json.loads((ROOT / "runs" / topic / "rules-only" / "experimental-report.json").read_text())
    print("\n" + topic)
    for c in report["reports"]:
        a = c["source_anchor"]
        seg = raw[a["segment_position"]]
        reference = " ".join(r["text"] for r in ref if r["end"] >= seg["start"] and r["start"] <= seg["end"])
        data = seg["text"].encode()
        changed = (data[:a["start_byte"]] + c["canonical_term"].encode() + data[a["end_byte"]:]).decode()
        before = lev(norm(seg["text"]), norm(reference))
        after = lev(norm(changed), norm(reference))
        delta = after - before
        if delta < 0:
            print(f"{c['candidate_id']}\t{delta}\t{c['source_surface']} => {c['canonical_term']}\tREF={reference}")
