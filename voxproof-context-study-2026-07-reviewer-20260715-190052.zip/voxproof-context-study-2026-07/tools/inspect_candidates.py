#!/usr/bin/env python3
import json
import re
from pathlib import Path

ROOT = Path("/tmp/voxproof-context-study-2026-07")
TOPICS = ["technology", "persona", "sports", "education"]


def timestamp(value: str) -> int:
    h, m, tail = value.replace(".", ",").split(":")
    s, ms = tail.split(",")
    return ((int(h) * 60 + int(m)) * 60 + int(s)) * 1000 + int(ms)


def srt(path: Path) -> list[dict]:
    out = []
    for block in re.split(r"\n\s*\n", path.read_text().strip()):
        lines = block.splitlines()
        start, end = lines[1].split(" --> ")
        out.append({"start": timestamp(start), "end": timestamp(end), "text": " ".join(lines[2:])})
    return out


def byte_to_char(text: str, offset: int) -> int:
    return len(text.encode()[:offset].decode(errors="ignore"))


rows = []
request_cursor = 0
responses = json.loads((ROOT / "tools/batch-ranking-responses.json").read_text())["responses"]
for topic in TOPICS:
    raw = srt(ROOT / "samples" / topic / "raw-asr.srt")
    ref = srt(ROOT / "samples" / topic / "reference.srt")
    report = json.loads((ROOT / "runs" / topic / "rules-only" / "experimental-report.json").read_text())
    by_source = {}
    for candidate in report["reports"]:
        anchor = candidate["source_anchor"]
        key = (anchor["segment_position"], anchor["start_byte"], anchor["end_byte"], candidate["source_surface"])
        by_source.setdefault(key, []).append(candidate)
    for key, candidates in by_source.items():
        segment = raw[key[0]]
        text = segment["text"]
        lo = byte_to_char(text, key[1]) / max(1, len(text))
        hi = byte_to_char(text, key[2]) / max(1, len(text))
        duration = segment["end"] - segment["start"]
        anchor_start = segment["start"] + round(duration * lo)
        anchor_end = segment["start"] + round(duration * hi)
        local = [r["text"] for r in ref if r["end"] >= anchor_start - 750 and r["start"] <= anchor_end + 750]
        full = [r["text"] for r in ref if r["end"] >= segment["start"] and r["start"] <= segment["end"]]
        response = responses[request_cursor]
        rows.append({
            "request": request_cursor,
            "topic": topic,
            "source": key[3],
            "candidates": ";".join(c["canonical_term"] for c in candidates),
            "selected": response["selected_candidate_id"] or "",
            "assessment": response["assessment"],
            "local_ref": " / ".join(local),
            "raw_context": text,
            "full_ref": " / ".join(full),
        })
        request_cursor += 1

assert request_cursor == 148
path = ROOT / "candidate-inspection.tsv"
with path.open("w") as f:
    f.write("request\ttopic\tsource\tcandidates\tselected\tassessment\tlocal_ref\traw_context\tfull_ref\n")
    for row in rows:
        f.write("\t".join(str(row[k]).replace("\t", " ").replace("\n", " ") for k in row) + "\n")
print(path)
