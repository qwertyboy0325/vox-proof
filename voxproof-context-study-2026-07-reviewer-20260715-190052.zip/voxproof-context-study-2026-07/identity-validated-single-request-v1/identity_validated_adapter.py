#!/usr/bin/env python3
"""Rust subprocess adapter for the study-only single-request protocol.

Input and successful output remain the product's existing ranking request and
response shapes. The external provider sees only the identity wrapper.
"""

from __future__ import annotations

import json
import os
import shlex
import sys
from pathlib import Path

from single_request_protocol import ProtocolFailure, invoke_one


def main() -> None:
    command_text = os.environ.get("VOX_PROOF_SINGLE_REQUEST_COMMAND")
    if not command_text:
        raise SystemExit("VOX_PROOF_SINGLE_REQUEST_COMMAND is required")
    timeout_seconds = float(os.environ.get("VOX_PROOF_SINGLE_REQUEST_TIMEOUT_SECONDS", "30"))
    artifact_dir = Path(
        os.environ.get(
            "VOX_PROOF_SINGLE_REQUEST_ARTIFACT_DIR",
            str(Path(__file__).with_name("artifacts")),
        )
    )
    request = json.load(sys.stdin)

    try:
        result = invoke_one(
            request=request,
            command=shlex.split(command_text),
            artifact_dir=artifact_dir,
            timeout_seconds=timeout_seconds,
        )
    except ProtocolFailure as failure:
        print(f"single-request protocol failure [{failure.code}]: {failure}", file=sys.stderr)
        raise SystemExit(1) from failure

    json.dump(result.inner_response, sys.stdout, ensure_ascii=False, separators=(",", ":"))


if __name__ == "__main__":
    main()
