# Identity-validated single-request ranking protocol

This is a new experiment harness protocol, not attempt 4 of the frozen
positional batch. It does not modify the product request contract:
`experimental-context-rank-request-v1` remains the inner request and response.

For each inner request, the harness:

1. serializes canonical JSON with sorted keys and compact separators;
2. derives `request_identity` as its SHA-256;
3. invokes one external model subprocess with one wrapper request;
4. persists raw stdout bytes under `raw-responses/<request_identity>.stdout`
   before parsing;
5. accepts only one JSON wrapper response that echoes the same identity; and
6. returns the inner response to the Rust adapter only after schema, candidate,
   assessment, reason-code, review, and replacement-field validation.

Timeout, malformed output, duplicate response, identity mismatch, and invalid
candidate membership are recorded in per-request metadata and cause the adapter
to exit nonzero. They cannot become sidecar selections or reviewed-output edits.

`run_single_request_harness.py` is the future bounded-concurrency aggregation
entry point. Its `run-summary.json` reports `eligible` only when every required
request completed with verified identity; otherwise it reports
`diagnostic_only_partial_protocol_run`.

No provider was invoked while creating this harness. The frozen retrieval 0.3
requests and attempt-2 response remain outside this directory and unchanged.
