from __future__ import annotations

import json
import shlex
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HARNESS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HARNESS))

from single_request_protocol import (  # noqa: E402
    ProtocolFailure,
    invoke_one,
    request_identity,
)


REQUEST = {
    "schema_revision": "experimental-context-rank-request-v1",
    "session_description": "Sports commentary",
    "nearby_context": "The team played tennis.",
    "source_surface": "ten days",
    "candidates": [
        {
            "candidate_id": "experimental-1",
            "canonical_term": "tennis",
            "producer": "LatinNormalizedDistance",
            "source_representation": "ten days",
            "target_representation": "tennis",
            "distance": 1,
            "ratio_numerator": 8,
            "ratio_denominator": 9,
        }
    ],
}


def provider(script: str) -> list[str]:
    return [sys.executable, "-c", script]


def response_program(response_expression: str) -> str:
    return (
        "import json,sys; wrapper=json.load(sys.stdin); "
        f"response={response_expression}; "
        "sys.stdout.write(json.dumps(response,separators=(',',':')))"
    )


def valid_wrapper(identity_expression: str = "wrapper['request_identity']") -> str:
    return (
        "{'protocol_revision':'voxproof-single-request-identity-v1',"
        f"'request_identity':{identity_expression},"
        "'response':{'schema_revision':'experimental-context-rank-request-v1',"
        "'selected_candidate_id':'experimental-1','assessment':'strong',"
        "'reason_codes':['nearby_context_term_overlap'],'requires_review':True}}"
    )


class SingleRequestProtocolTests(unittest.TestCase):
    def invoke(self, command: list[str], request: dict = REQUEST):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        return invoke_one(request, command, Path(temporary.name), timeout_seconds=0.1)

    def assert_failure(self, code: str, command: list[str]) -> None:
        with self.assertRaises(ProtocolFailure) as raised:
            self.invoke(command)
        self.assertEqual(code, raised.exception.code)

    def test_accepts_valid_correlated_response_and_preserves_raw_bytes(self) -> None:
        result = self.invoke(
            provider(response_program(valid_wrapper())),
        )
        self.assertEqual(request_identity(REQUEST), result.request_identity)
        self.assertEqual("experimental-1", result.inner_response["selected_candidate_id"])
        raw = result.raw_response_path.read_bytes()
        self.assertEqual(
            raw,
            json.dumps(
                {
                    "protocol_revision": "voxproof-single-request-identity-v1",
                    "request_identity": result.request_identity,
                    "response": result.inner_response,
                },
                separators=(",", ":"),
            ).encode("utf-8"),
        )

    def test_rejects_wrong_request_identity(self) -> None:
        self.assert_failure(
            "identity_mismatch",
            provider(response_program(valid_wrapper("'wrong-identity'"))),
        )

    def test_rejects_next_window_candidate_id(self) -> None:
        expression = valid_wrapper().replace("'experimental-1'", "'next-window-candidate'")
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(ProtocolFailure) as raised:
                invoke_one(
                    REQUEST,
                    provider(response_program(expression)),
                    Path(temporary),
                    timeout_seconds=0.1,
                )
            self.assertEqual("invalid_candidate_membership", raised.exception.code)
            metadata = json.loads(
                (Path(temporary) / "metadata" / f"{request_identity(REQUEST)}.json").read_text()
            )
            self.assertEqual("invalid_candidate_membership", metadata["failure"]["code"])

    def test_records_missing_response(self) -> None:
        self.assert_failure("missing_response", provider("import sys; sys.stdin.read()"))

    def test_records_duplicate_response(self) -> None:
        script = (
            "import json,sys; wrapper=json.load(sys.stdin); "
            f"response={valid_wrapper()}; "
            "encoded=json.dumps(response,separators=(',',':')); "
            "sys.stdout.write(encoded + encoded)"
        )
        self.assert_failure("duplicate_response", provider(script))

    def test_records_malformed_response(self) -> None:
        self.assert_failure(
            "malformed_response",
            provider("import sys; sys.stdin.read(); sys.stdout.write('{')"),
        )

    def test_records_timeout(self) -> None:
        self.assert_failure(
            "timeout",
            provider("import sys,time; sys.stdin.read(); time.sleep(1)"),
        )

    def test_accepts_null_selection_with_valid_correlation(self) -> None:
        expression = (
            "{'protocol_revision':'voxproof-single-request-identity-v1',"
            "'request_identity':wrapper['request_identity'],"
            "'response':{'schema_revision':'experimental-context-rank-request-v1',"
            "'selected_candidate_id':None,'assessment':'unsupported',"
            "'reason_codes':['no_candidate_supported'],'requires_review':True}}"
        )
        result = self.invoke(provider(response_program(expression)))
        self.assertIsNone(result.inner_response["selected_candidate_id"])

    def test_invalid_response_cannot_become_adapter_output(self) -> None:
        script = response_program(valid_wrapper().replace("'experimental-1'", "'next-window-candidate'"))
        with tempfile.TemporaryDirectory() as temporary:
            command = [
                sys.executable,
                str(HARNESS / "identity_validated_adapter.py"),
            ]
            completed = subprocess.run(
                command,
                input=json.dumps(REQUEST).encode("utf-8"),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env={
                    "PATH": "/usr/bin:/bin",
                    "VOX_PROOF_SINGLE_REQUEST_COMMAND": (
                        f"{shlex.quote(sys.executable)} -c {shlex.quote(script)}"
                    ),
                    "VOX_PROOF_SINGLE_REQUEST_ARTIFACT_DIR": temporary,
                },
                check=False,
            )
            self.assertNotEqual(0, completed.returncode)
            self.assertEqual(b"", completed.stdout)
            self.assertIn(b"invalid_candidate_membership", completed.stderr)

    def test_partial_run_is_diagnostic_only(self) -> None:
        second_request = {**REQUEST, "source_surface": "next window"}
        provider_script = (
            "import json,sys; wrapper=json.load(sys.stdin); "
            "selected='experimental-1' if wrapper['request']['source_surface'] == 'ten days' "
            "else 'next-window-candidate'; "
            "response={'protocol_revision':'voxproof-single-request-identity-v1',"
            "'request_identity':wrapper['request_identity'],'response':"
            "{'schema_revision':'experimental-context-rank-request-v1',"
            "'selected_candidate_id':selected,'assessment':'strong',"
            "'reason_codes':['nearby_context_term_overlap'],'requires_review':True}}; "
            "sys.stdout.write(json.dumps(response,separators=(',',':')))"
        )
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            request_file = root / "requests.jsonl"
            request_file.write_text(
                "\n".join(json.dumps(request) for request in (REQUEST, second_request)) + "\n"
            )
            completed = subprocess.run(
                [
                    sys.executable,
                    str(HARNESS / "run_single_request_harness.py"),
                    "--requests",
                    str(request_file),
                    "--command",
                    f"{shlex.quote(sys.executable)} -c {shlex.quote(provider_script)}",
                    "--artifact-dir",
                    str(root / "artifacts"),
                    "--timeout-seconds",
                    "0.1",
                    "--max-workers",
                    "2",
                ],
                check=False,
            )
            self.assertEqual(1, completed.returncode)
            summary = json.loads((root / "artifacts" / "run-summary.json").read_text())
            self.assertEqual("diagnostic_only_partial_protocol_run", summary["quality_comparison_status"])


if __name__ == "__main__":
    unittest.main()
