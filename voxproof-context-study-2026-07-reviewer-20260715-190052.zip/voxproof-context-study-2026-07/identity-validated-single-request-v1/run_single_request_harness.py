#!/usr/bin/env python3
"""Run an identity-validated study harness without positional aggregation."""

from __future__ import annotations

import argparse
import json
import shlex
from pathlib import Path

from single_request_protocol import ProtocolFailure, ProtocolResult, invoke_many


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--requests", required=True, type=Path)
    parser.add_argument("--command", required=True)
    parser.add_argument("--artifact-dir", required=True, type=Path)
    parser.add_argument("--timeout-seconds", required=True, type=float)
    parser.add_argument("--max-workers", required=True, type=int)
    arguments = parser.parse_args()

    requests = [
        json.loads(line)
        for line in arguments.requests.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    outcomes = invoke_many(
        requests=requests,
        command=shlex.split(arguments.command),
        artifact_dir=arguments.artifact_dir,
        timeout_seconds=arguments.timeout_seconds,
        max_workers=arguments.max_workers,
    )
    failures = [outcome for outcome in outcomes if isinstance(outcome, ProtocolFailure)]
    summary = {
        "protocol_revision": "voxproof-single-request-identity-v1",
        "request_count": len(requests),
        "accepted_count": len(outcomes) - len(failures),
        "failure_count": len(failures),
        "complete_identity_verified": not failures and len(outcomes) == len(requests),
        "quality_comparison_status": (
            "eligible"
            if not failures and len(outcomes) == len(requests)
            else "diagnostic_only_partial_protocol_run"
        ),
        "outcomes": [
            (
                {
                    "request_identity": outcome.request_identity,
                    "outcome": "accepted",
                    "raw_response_path": str(outcome.raw_response_path),
                }
                if isinstance(outcome, ProtocolResult)
                else {"outcome": "failed", "failure_code": outcome.code, "detail": str(outcome)}
            )
            for outcome in outcomes
        ],
    }
    arguments.artifact_dir.mkdir(parents=True, exist_ok=True)
    (arguments.artifact_dir / "run-summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
