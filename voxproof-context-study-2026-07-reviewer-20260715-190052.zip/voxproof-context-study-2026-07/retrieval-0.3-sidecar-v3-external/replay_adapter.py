#!/usr/bin/env python3
import json
import sys
from pathlib import Path


ROOT = Path(__file__).parent
REQUESTS = ROOT / "ranking-requests-retrieval-0.3-sidecar-v3.jsonl"
RESPONSES = ROOT / "batch-ranking-responses-retrieval-0.3-sidecar-v3.json"


def canonical(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def safe_response(request: dict, response: dict) -> dict:
    candidates = {candidate["candidate_id"] for candidate in request["candidates"]}
    selected = response.get("selected_candidate_id")
    assessment = response.get("assessment")
    reasons = response.get("reason_codes")
    valid = (
        response.get("schema_revision") == request.get("schema_revision")
        and assessment in {"strong", "plausible", "ambiguous", "unsupported"}
        and isinstance(reasons, list)
        and bool(reasons)
        and response.get("requires_review") is True
        and (selected is None or selected in candidates)
        and ((assessment in {"strong", "plausible"}) == (selected is not None))
        and (assessment != "ambiguous" or selected is None)
        and (assessment != "unsupported" or selected is None)
    )
    if not valid:
        return {
            "schema_revision": request["schema_revision"],
            "selected_candidate_id": None,
            "assessment": "unsupported",
            "reason_codes": ["no_candidate_supported"],
            "requires_review": True,
            "display_explanation": "Invalid cached response suppressed safely.",
        }
    return {
        "schema_revision": response["schema_revision"],
        "selected_candidate_id": selected,
        "assessment": assessment,
        "reason_codes": reasons,
        "requires_review": True,
        "display_explanation": response.get("display_explanation", ""),
    }


def main() -> None:
    requests = [json.loads(line) for line in REQUESTS.read_text().splitlines()]
    responses = json.loads(RESPONSES.read_text())["responses"]
    by_index = {response["request_index"]: response for response in responses}
    if set(by_index) != set(range(len(requests))):
        raise SystemExit("cached response indices do not match captured requests")
    cache = {
        canonical(request): safe_response(request, by_index[index])
        for index, request in enumerate(requests)
    }
    request = json.load(sys.stdin)
    response = cache.get(canonical(request))
    if response is None:
        raise SystemExit("request not found in captured corpus")
    json.dump(response, sys.stdout, ensure_ascii=False, separators=(",", ":"))


if __name__ == "__main__":
    main()
