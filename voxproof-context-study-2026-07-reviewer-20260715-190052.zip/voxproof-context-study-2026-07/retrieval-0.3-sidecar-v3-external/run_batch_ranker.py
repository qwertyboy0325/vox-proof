#!/usr/bin/env python3
import importlib.util
import json
import subprocess
from pathlib import Path


STUDY_ROOT = Path("/private/tmp/voxproof-context-study-2026-07")
OUTPUT_ROOT = Path(__file__).parent
REQUESTS = OUTPUT_ROOT / "ranking-requests-retrieval-0.3-sidecar-v3.jsonl"
SCHEMA = OUTPUT_ROOT / "batch-ranking-schema-48-retrieval-0.3-sidecar-v3.json"
PROMPT_FILE = OUTPUT_ROOT / "batch-ranking-prompt-48-retrieval-0.3-sidecar-v3.txt"
OUTPUT = OUTPUT_ROOT / "batch-ranking-responses-retrieval-0.3-sidecar-v3.json"


def load_frozen_prompt() -> str:
    path = STUDY_ROOT / "tools" / "run_batch_ranker.py"
    spec = importlib.util.spec_from_file_location("frozen_batch_ranker", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load frozen batch ranker")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.PROMPT


def main() -> None:
    request_text = REQUESTS.read_text(encoding="utf-8")
    request_count = len(request_text.splitlines())
    if request_count != 48:
        raise SystemExit(f"expected 48 captured requests, found {request_count}")

    frozen_prompt = load_frozen_prompt()
    prompt = frozen_prompt.replace("148 independent", "48 independent", 1)
    if prompt == frozen_prompt:
        raise SystemExit("frozen prompt cardinality literal not found")
    PROMPT_FILE.write_text(prompt + "\n", encoding="utf-8")

    schema = json.loads((STUDY_ROOT / "tools" / "batch-ranking-schema.json").read_text())
    responses = schema["properties"]["responses"]
    responses["minItems"] = 48
    responses["maxItems"] = 48
    responses["items"]["properties"]["request_index"]["maximum"] = 47
    SCHEMA.write_text(json.dumps(schema, indent=2) + "\n", encoding="utf-8")

    command = [
        "/opt/homebrew/bin/codex",
        "exec",
        "--ephemeral",
        "--skip-git-repo-check",
        "--sandbox",
        "read-only",
        "--ignore-rules",
        "--model",
        "gpt-5.6-sol",
        "--config",
        'model_reasoning_effort="low"',
        "--output-schema",
        str(SCHEMA),
        "--output-last-message",
        str(OUTPUT),
        prompt,
    ]
    completed = subprocess.run(
        command,
        input=request_text,
        text=True,
        cwd=STUDY_ROOT,
        check=False,
        timeout=120,
    )
    raise SystemExit(completed.returncode)


if __name__ == "__main__":
    main()
