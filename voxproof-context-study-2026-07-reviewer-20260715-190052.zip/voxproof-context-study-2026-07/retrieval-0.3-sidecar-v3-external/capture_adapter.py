#!/usr/bin/env python3
import json
import os
import sys
from pathlib import Path


REQUESTS = Path(__file__).with_name("ranking-requests-retrieval-0.3-sidecar-v3.jsonl")


def main() -> None:
    request = json.load(sys.stdin)
    payload = json.dumps(request, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    descriptor = os.open(REQUESTS, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    try:
        os.write(descriptor, payload.encode("utf-8") + b"\n")
    finally:
        os.close(descriptor)
    json.dump(
        {
            "schema_revision": request["schema_revision"],
            "selected_candidate_id": None,
            "assessment": "unsupported",
            "reason_codes": ["no_candidate_supported"],
            "requires_review": True,
            "display_explanation": "capture pass only",
        },
        sys.stdout,
        separators=(",", ":"),
    )


if __name__ == "__main__":
    main()
