# VoxProof retrieval 0.3 / sidecar v3 external-ranking rerun

Date: 2026-07-15  
Rerun repository HEAD: `5286c1627e54852fc08f4766240ce7545269e982`  
Status: **external model-quality comparison invalid because the only completed batch response lost request alignment**

## Provenance

- Root `manifest.json` records `30e06061a88cf548d663f7e5a09c047d74bec118` as the repository HEAD when the original frozen corpus and study were created.
- This rerun's preflight and output manifest record `5286c1627e54852fc08f4766240ce7545269e982`.
- These values have different authority: the first identifies the original corpus freeze, while the second identifies this rerun. They are not a conflict.

## Valid deterministic retrieval result

Retrieval 0.3 passed every pre-ranking gate. These are valid deterministic retrieval findings, independent of the invalid external-ranking batch:

| Metric | Original unfiltered retrieval | Retrieval 0.3 |
|---|---:|---:|
| Windows | 148 | 48 |
| Candidates | 149 | 49 |
| Candidates/minute | 2.60 | 0.856 |
| Frozen true candidates retained | 13/13 | 13/13 |
| Frozen non-exact retrieval recall | 52% | 52% |

- Producers: 36 Latin normalized, 12 Latin token-boundary, 1 Han pinyin.
- Candidate multiset matched the accepted calibrated retrieval result.
- Retrieval version, sidecar revision, and both active profiles matched the requested values.

## Invalid-batch forensic diagnostics

The external batch did not yield a valid ranking result. Attempt 1 timed out at 120 seconds. Attempt 2 completed in 65.351 seconds, but from request index 18 its response content shifted forward by one request. Ten selected IDs were therefore not members of their requests. The strict replay adapter suppressed those invalid selections. Attempt 3 timed out at 120 seconds. No prompt, model, reasoning, sandbox, frozen input, or repository file was changed between attempts.

The following values describe safe replay of the invalid completed batch. They are forensic diagnostics, not current model performance or a valid comparison:

| Metric | Original external result | Current safe-replay diagnostic |
|---|---:|---:|
| Selected | 30 | 4 |
| Selected true | 12 | 3 |
| Selected false | 18 | 1 |
| Selected precision | 40.0% | 75.0% |
| Retained retrieved true | 12/13 | 3/13 |
| Non-exact recall | 48.0% | 12.0% |
| Exact + selected recall | 70.45% | 50.0% |
| Persona selected false | 12 | 1 |
| Education selected | 0 | 0 |
| Selected/minute | 0.524 | 0.070 |

### Per-sample safe-replay diagnostic

| Sample | Candidates/windows | Retrieved true | Selected | TP | FP |
|---|---:|---:|---:|---:|---:|
| technology | 15/14 | 3 | 3 | 3 | 0 |
| persona | 5/5 | 0 | 1 | 0 | 1 |
| sports | 18/18 | 10 | 0 | 0 | 0 |
| education negative control | 11/11 | 0 | 0 | 0 | 0 |

Replay dispositions were 48 `succeeded`, 0 `fell_back_after_failure`, and 0 `not_run`. This reflects that the replay adapter returned schema-valid safe suppressions; it does not erase the upstream batch-alignment failure.

### Selected false positive

- `persona`, anchor segment 26 bytes 22..51: `information system management` -> `information systems management`; producer `latin_token_boundary`; assessment `strong`; explanation: “Information systems management is the standard major name and a one-character correction.”
- Taxonomy: frozen-ground-truth-negative domain-term morphology/context-overlap selection. This is a hard-negative observation only; it is not a canonical rule, alias, or pack change.

### Retrieved true candidates not selected after safe replay

- `so far` -> `soccer`
- `ten days` -> `tennis`
- `Bagminton` -> `badminton` (six occurrences)
- `brackminton` -> `badminton`
- `Tracy Magrady` -> `Tracy McGrady`

All ten occurred in the misaligned response region. Their non-selection outcomes are therefore uninterpretable. The remaining pinyin candidate `所以嗯` -> `Duolingo` was also in the shifted region; its non-selection is not a valid contextual judgment.

### Ordering

There was one multi-candidate window (`phone` -> `iPhone` or `Python`). Neither candidate is a frozen true candidate. Therefore no correctness-based model-ordering comparison was possible; the response-alignment failure independently invalidates ranking interpretation.

## Safety

- Frozen manifest file hashes: all matched.
- Reviewed SRT cue indices, timing, and text: unchanged for all four samples.
- Literal raw-to-reviewed bytes differ only because the existing serializer emits one final newline while the raw files contain two; this was accepted as semantic identity for this rerun.
- Decision logs contain no experimental selections.
- Manual-correction markers: 0 in every sample.
- Sidecar selections remained experiment-only.
- Final replay selected IDs were bounded candidate IDs.
- Raw model response contained 10 unbounded cross-window selected IDs; all were suppressed.
- No arbitrary replacement text was accepted or materialized.
- Replay calls used the original 5-second adapter timeout; batch attempts used the frozen strict output schema with the authorized 48-item cardinality and a 120-second direct-process timeout.
- Repository worktree remained clean; no commit or push occurred.

## Runtime anomalies

1. Attempt 1: timeout after 120 seconds; no response artifact; Codex logged two model-catalog refresh timeouts.
2. Attempt 2: completed in 65.351 seconds; response content shifted from request index 18; 10 invalid selected IDs.
3. Attempt 3: timeout after 120 seconds; no replacement response artifact.

The attempt-2 response is preserved for inspection. It must not be repaired by shifting rows after the fact because that would alter model output and undermine the frozen comparison.
