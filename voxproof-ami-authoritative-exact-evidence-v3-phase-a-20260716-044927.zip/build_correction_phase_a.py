#!/usr/bin/env python3
"""Build and verify one new V3 Phase A correction package."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
SCRIPTS = ROOT / "phase-b/scripts"
REPO = Path("/Users/Ezra4/Coding/Repo/vox-proof")
FIRST_V3 = Path(
    "/private/tmp/voxproof-ami-authoritative-study-2026-07/"
    "v3-exact-evidence-phase-a"
)
sys.path.insert(0, str(SCRIPTS))

from common import sha256_file, write_json  # noqa: E402
from package_builder import build_package  # noqa: E402
from package_verifier import verify_package  # noqa: E402
from study_config import SCRIPT_NAMES  # noqa: E402

REQUIRED_HEAD = "5286c1627e54852fc08f4766240ce7545269e982"


def run(command: list[str], *, cwd: Path = ROOT) -> dict[str, Any]:
    process = subprocess.run(
        command, cwd=cwd, text=True, capture_output=True, check=False
    )
    return {
        "command": command,
        "exit_code": process.returncode,
        "stdout": process.stdout,
        "stderr": process.stderr,
    }


def require(result: dict[str, Any], name: str) -> None:
    if result["exit_code"] != 0:
        raise RuntimeError(
            f"{name} failed\n{result['stdout']}\n{result['stderr']}"
        )


def generate_script_lock() -> dict[str, Any]:
    rows = []
    for name in SCRIPT_NAMES:
        path = SCRIPTS / name
        rows.append(
            {
                "path": f"phase-b/scripts/{name}",
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
        )
    payload = {
        "schema_revision": "voxproof-ami-script-lock-v2",
        "generation_scope": "phase-a-build-only",
        "scripts": rows,
    }
    write_json(ROOT / "phase-b/script-lock.json", payload)
    return payload


def reset_phase_b_state() -> None:
    write_json(
        ROOT / "phase-b/stage-state.json",
        {
            "schema_revision": "voxproof-ami-stage-state-v2",
            "completed": [],
            "access_gate_crossed": False,
            "terminal_failed": False,
            "failure_record": None,
            "stage_details": {},
        },
    )
    attestation = ROOT / "phase-b/binary-attestation.json"
    if attestation.exists():
        attestation.unlink()


def implementation_diff() -> dict[str, Any]:
    excluded = {"package", "cargo-target-isolated", "__pycache__", "test-out", "rehearsal"}

    def inventory(root: Path) -> dict[str, str]:
        return {
            path.relative_to(root).as_posix(): sha256_file(path)
            for path in root.rglob("*")
            if path.is_file()
            and path.suffix not in {".zip", ".pyc"}
            and not any(part in excluded for part in path.relative_to(root).parts)
        }

    before = inventory(FIRST_V3)
    after = inventory(ROOT)
    payload = {
        "schema_revision": "voxproof-ami-v3-phase-a-correction-diff-v2",
        "first_v3_root": str(FIRST_V3),
        "correction_root": str(ROOT),
        "added": sorted(set(after) - set(before)),
        "removed": sorted(set(before) - set(after)),
        "changed": sorted(
            path
            for path in set(before) & set(after)
            if before[path] != after[path]
        ),
    }
    write_json(ROOT / "implementation-diff-vs-first-v3.json", payload)
    return payload


def main() -> int:
    output_dir = ROOT / "outputs"
    output_dir.mkdir(exist_ok=True)
    script_lock = generate_script_lock()
    reset_phase_b_state()

    cycles: list[dict[str, Any]] = []
    compile_result = run(
        [
            sys.executable,
            "-m",
            "compileall",
            "-q",
            str(SCRIPTS),
            str(ROOT / "tests"),
        ]
    )
    require(compile_result, "Python compile")
    cycles.append({"cycle": 1, "name": "python-compile", **compile_result})

    tests = run(
        [
            sys.executable,
            "-m",
            "unittest",
            "discover",
            "-s",
            str(ROOT / "tests"),
            "-v",
        ]
    )
    require(tests, "Python tests")
    test_match = re.search(r"Ran (\d+) tests?", tests["stderr"])
    if not test_match:
        raise RuntimeError("could not determine Python test count")
    python_test_count = int(test_match.group(1))
    cycles.append({"cycle": 2, "name": "python-tests", **tests})
    (output_dir / "python-test-output.txt").write_text(
        tests["stdout"] + tests["stderr"], encoding="utf-8"
    )

    rehearsal = run(
        [sys.executable, str(ROOT / "tests/run_full_pipeline_rehearsal.py")]
    )
    require(rehearsal, "full fixture rehearsal")
    cycles.append({"cycle": 3, "name": "exact-fixture-runner-rehearsal", **rehearsal})

    cargo_commands = [
        ["cargo", "fmt", "--all", "--", "--check"],
        [
            "cargo",
            "clippy",
            "--all-targets",
            "--all-features",
            "--",
            "-D",
            "warnings",
        ],
        ["cargo", "test", "--locked", "--all-targets"],
    ]
    for command in cargo_commands:
        result = run(command, cwd=REPO)
        require(result, " ".join(command))
        cycles.append(
            {
                "cycle": len(cycles) + 1,
                "name": " ".join(command),
                **result,
            }
        )

    command_check = run(
        [sys.executable, str(SCRIPTS / "phase_b_runner.py"), "self-check-commands"]
    )
    require(command_check, "command self-check")
    parsed_check = json.loads(command_check["stdout"])
    if parsed_check["result"]["status"] != "pass":
        raise RuntimeError(f"command self-check failed: {parsed_check}")
    cycles.append(
        {
            "cycle": len(cycles) + 1,
            "name": "command-reference-self-check",
            **command_check,
        }
    )

    head = subprocess.check_output(
        ["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True
    ).strip()
    tracked_diff = subprocess.run(
        ["git", "-C", str(REPO), "diff", "--quiet"], check=False
    ).returncode
    staged_diff = subprocess.run(
        ["git", "-C", str(REPO), "diff", "--cached", "--quiet"], check=False
    ).returncode
    diff_check = run(["git", "diff", "--check"], cwd=REPO)
    if head != REQUIRED_HEAD or tracked_diff or staged_diff or diff_check["exit_code"]:
        raise RuntimeError("repository HEAD/clean tracked state/diff-check gate failed")
    write_json(
        ROOT / "repository-status-evidence.json",
        {
            "required_head": REQUIRED_HEAD,
            "actual_head": head,
            "head_matches": True,
            "tracked_diff": False,
            "staged_diff": False,
            "diff_check_pass": True,
        },
    )

    reset_phase_b_state()
    diff = implementation_diff()
    debug = {
        "schema_revision": "voxproof-ami-internal-debug-v2",
        "internal_cycle_count": len(cycles),
        "cycles": cycles,
        "strong_audit_failures_found": [
            "commands rooted in repository instead of study root",
            "split correction/phase-b roots",
            "stub AMI transform",
            "incomplete runner stages and unsafe rehearsal state",
            "mutable script lock and incomplete preflight",
            "attested environment omitted from product invocations",
            "ephemeral review failure artifacts",
            "reviewed WER copied from raw WER",
            "incomplete human evaluation bindings",
            "independent verifier imported primary scorer",
            "missing executable Phase B package mode",
            "non-full synthetic rehearsal",
            "stale package contents and documentation",
            "initial rewritten independent verifier used singular count keys",
            "production behavior-affecting environment overrides were accepted",
            "stage state retained only the latest detail without immutable joins",
            "reviewed cue-order scoring was invalid for overlapping speakers",
            "independent verification did not recompute every study metric",
            "human labels did not enforce frozen unsafe consistency",
            "ZIP path checks allowed backslashes and NUL",
            "independent verification required identical tie decompositions",
            "phase-a packaging could retain stale runtime artifacts",
            "human labels carried pre-review materialization predictions used by metrics",
            "correction_recall and unsafe_edit_rate were not tied to reviewed output",
        ],
        "fixes_applied": [
            "implemented one environment-derived study root and exact runner-only commands",
            "implemented strict AMI XML/SRT/reference/scoring transformations",
            "implemented terminal stage state, persistent failures, immutable script verification",
            "bound product invocations to attested environment and immediate hashes",
            "implemented joint human review validation and independent raw/reviewed scoring",
            "implemented independent operation reconstruction without primary imports",
            "implemented explicit Phase A/Phase B package build and verification",
            "ran exact synthetic zero/nonzero runner chronologies and negative gates",
            "froze production target, window, repository, and source archives",
            "added stage_details and re-hash joins at every downstream stage",
            "implemented and independently duplicated global reviewed-stream projection",
            "independently recomputed and compared the complete study metric payload",
            "hardened ZIP paths, tie-policy disclosure, and phase-a exclusions",
            "added overlapping-speaker full runner rehearsal and mutation tests",
            "split candidate truth from post-review materialization audit",
            "removed pre-review materialization fields from candidate-labels.json",
            "added audit-materialization runner stage and materialization-audit.json output",
            "rebased correction_recall and unsafe_edit_rate on materialization audit only",
            "strengthened ground-truth.json frozen coverage validation",
        ],
        "semantic_correction_cycle": {
            "cycle_id": "v3-phase-a-materialization-truth-v1",
            "preserved_zip": "voxproof-ami-authoritative-exact-evidence-v3-phase-a-20260716-042745.zip",
            "preserved_seal": "package-seal-v3-phase-a-20260716-042745.json",
            "es2004b_content_opened": False,
        },
        "validation_failures": [],
        "final_status": "pass",
    }
    write_json(ROOT / "internal-debugging-record.json", debug)

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    summary = build_package(
        root=ROOT,
        output_dir=ROOT / "package",
        mode="phase-a",
        name_suffix=stamp,
    )
    verification = verify_package(
        ROOT,
        Path(summary["zip_path"]),
        Path(summary["seal_path"]),
        "phase-a",
    )
    if verification["status"] != "pass":
        raise RuntimeError("; ".join(verification["errors"]))
    write_json(output_dir / "package-verification-output.json", verification)
    write_json(ROOT / "package/package-summary.json", summary)

    shutil.copy2(summary["zip_path"], REPO / summary["zip_filename"])
    shutil.copy2(summary["seal_path"], REPO / summary["seal_filename"])
    final = {
        **summary,
        "verification_status": "pass",
        "python_tests": python_test_count,
        "internal_cycles": len(cycles),
        "script_lock": script_lock,
        "implementation_diff_counts": {
            key: len(diff[key]) for key in ("added", "removed", "changed")
        },
        "es2004b_content_opened": False,
        "repository_head": head,
    }
    write_json(output_dir / "build-summary.json", final)
    print(json.dumps(final, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
