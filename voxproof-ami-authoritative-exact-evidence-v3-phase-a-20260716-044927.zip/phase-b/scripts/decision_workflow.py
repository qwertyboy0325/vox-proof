#!/usr/bin/env python3
"""Joint human-review input validation against frozen inventory/reference layers."""

from __future__ import annotations

import json
import re
import sys
from decimal import Decimal
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from common import read_json, sha256_file  # noqa: E402
from study_config import (  # noqa: E402
    MEETING_ID,
    SESSION_TERMS_LINES,
    WINDOW_END,
    WINDOW_START,
)

ALLOWED_DECISION_RE = re.compile(r"^(a \d+|r|d|m)$")
POLICIES = {
    "normalization_policy_id": "unicode-nfc-casefold-remove-punctuation-v1",
    "overlap_policy_id": "localized-time-and-cue-overlap-one-to-one-v1",
    "acceptable_variant_policy_id": "acceptable-variants-are-not-opportunities-v1",
}


def parse_session_terms() -> set[str]:
    terms: set[str] = set()
    for line in SESSION_TERMS_LINES:
        canonical = line.split("|", 1)[0].strip()
        if canonical:
            terms.add(canonical)
    return terms


def validate_reviewer(payload: dict[str, Any], prefix: str) -> list[str]:
    errors: list[str] = []
    reviewer = payload.get("reviewer")
    if not isinstance(reviewer, dict):
        return [f"{prefix}.reviewer missing"]
    for field in ("reviewer_id", "display_name", "attested_at_utc", "attestation"):
        if not isinstance(reviewer.get(field), str) or not reviewer[field].strip():
            errors.append(f"{prefix}.reviewer.{field} missing")
    return errors


def validate_ground_truth(
    payload: dict[str, Any],
    *,
    reference_layer_sha256: str,
    input_srt_sha256: str,
    terms_sha256: str,
    reference_layer_path: Path,
    input_srt_path: Path,
    asr_cues_path: Path,
    reference_tokens_path: Path,
) -> list[str]:
    errors = validate_reviewer(payload, "ground_truth")
    if payload.get("reference_layer_sha256") != reference_layer_sha256:
        errors.append("ground_truth reference_layer_sha256 mismatch")
    if payload.get("input_srt_sha256") != input_srt_sha256:
        errors.append("ground_truth input_srt_sha256 mismatch")
    if payload.get("terms_sha256") != terms_sha256:
        errors.append("ground_truth terms_sha256 mismatch")
    if payload.get("meeting_id") != MEETING_ID:
        errors.append("ground_truth meeting_id mismatch")
    window = payload.get("window", {})
    expected_window = {
        "start_inclusive": str(WINDOW_START),
        "end_exclusive": str(WINDOW_END),
    }
    if window != expected_window:
        errors.append("ground_truth window mismatch")
    for field, expected in POLICIES.items():
        if payload.get(field) != expected:
            errors.append(f"ground_truth {field} mismatch")
    attestation = payload.get("full_window_glossary_opportunity_review_attestation")
    if not isinstance(attestation, dict):
        errors.append("ground_truth full_window_glossary_opportunity_review_attestation missing")
    else:
        if not isinstance(attestation.get("completed"), bool):
            errors.append("ground_truth opportunity review attestation.completed missing")
        text = attestation.get("reviewer_attestation")
        if not isinstance(text, str) or not text.strip():
            errors.append("ground_truth opportunity review attestation text missing")
    reviewed_cue_count = payload.get("reviewed_cue_count")
    reference_token_count = payload.get("reference_token_count")
    if not isinstance(reviewed_cue_count, int) or reviewed_cue_count < 0:
        errors.append("ground_truth reviewed_cue_count invalid")
    if not isinstance(reference_token_count, int) or reference_token_count < 0:
        errors.append("ground_truth reference_token_count invalid")

    cues_payload = read_json(asr_cues_path)
    cues = cues_payload.get("cues", [])
    if reviewed_cue_count != len(cues):
        errors.append("ground_truth reviewed_cue_count mismatch with ASR cue ledger")
    reference_ids = {
        json.loads(line)["element_id"]
        for line in reference_tokens_path.read_text(encoding="utf-8").splitlines()
        if line and json.loads(line).get("tag") == "w"
    }
    reference_lexical_count = len(reference_ids)
    if reference_token_count != reference_lexical_count:
        errors.append("ground_truth reference_token_count mismatch with reference ledger")

    if sha256_file(reference_layer_path) != reference_layer_sha256:
        errors.append("reference layer hash mismatch during ground-truth validation")
    if sha256_file(input_srt_path) != input_srt_sha256:
        errors.append("input SRT hash mismatch during ground-truth validation")

    frozen_terms = parse_session_terms()
    seen: set[str] = set()
    for idx, opp in enumerate(payload.get("opportunities", [])):
        for key in (
            "opportunity_id",
            "canonical_term",
            "source_rendering",
            "speaker",
            "cue_index",
            "start",
            "end",
            "reference_token_ids",
            "acceptable_variant",
            "support_rationale",
        ):
            if key not in opp:
                errors.append(f"opportunity[{idx}] missing {key}")
        opportunity_id = opp.get("opportunity_id")
        if opportunity_id in seen:
            errors.append(f"duplicate opportunity_id {opportunity_id}")
        seen.add(opportunity_id)
        if opp.get("acceptable_variant") is not False:
            errors.append(f"opportunity[{idx}] acceptable_variant must be false")
        token_ids = opp.get("reference_token_ids") or []
        if not token_ids:
            errors.append(f"opportunity[{idx}] requires localized reference token ids")
        if opp.get("canonical_term") not in frozen_terms:
            errors.append(f"opportunity[{idx}] canonical_term not in frozen session terms")
        cue_index = opp.get("cue_index")
        if not isinstance(cue_index, int) or cue_index < 1 or cue_index > len(cues):
            errors.append(f"opportunity[{idx}] cue_index out of range")
        else:
            cue = cues[cue_index - 1]
            if not cue.get("text"):
                errors.append(f"opportunity[{idx}] cue_index does not resolve in cue ledger")
        try:
            start = Decimal(str(opp.get("start")))
            end = Decimal(str(opp.get("end")))
        except Exception:
            errors.append(f"opportunity[{idx}] start/end invalid")
            start = end = Decimal(0)
        midpoint = (start + end) / Decimal(2)
        if midpoint < WINDOW_START or midpoint >= WINDOW_END:
            errors.append(f"opportunity[{idx}] time outside frozen window")
        for token_id in token_ids:
            if token_id not in reference_ids:
                errors.append(
                    f"opportunity[{idx}] reference token id missing from reference layer: {token_id}"
                )
        if not str(opp.get("support_rationale", "")).strip():
            errors.append(f"opportunity[{idx}] support_rationale required")
    return errors


def validate_decision_inputs(
    payload: dict[str, Any],
    inventory: dict[str, Any],
) -> list[str]:
    errors: list[str] = []
    errors.extend(validate_reviewer(payload, "decision_inputs"))
    if payload.get("transcript_revision") != inventory.get("transcript_revision"):
        errors.append("decision transcript_revision mismatch with inventory")
    decisions = payload.get("decisions", [])
    candidates = inventory.get("candidates", [])
    if len(decisions) != len(candidates):
        errors.append(
            f"decision count {len(decisions)} != candidate count {len(candidates)}"
        )
    fingerprints = payload.get("candidate_fingerprints", [])
    if fingerprints != [c.get("fingerprint") for c in candidates]:
        errors.append("candidate_fingerprints do not match frozen inventory order")
    for idx, decision in enumerate(decisions):
        if not ALLOWED_DECISION_RE.match(decision):
            errors.append(f"invalid decision syntax at index {idx}: {decision!r}")
        if decision.startswith("a "):
            alt_index = int(decision.split()[1])
            alts = candidates[idx].get("alternatives", [])
            if alt_index >= len(alts):
                errors.append(f"accept index out of range at {idx}")
    return errors


def validate_candidate_labels(
    payload: dict[str, Any],
    inventory: dict[str, Any],
    ground_truth: dict[str, Any],
    reference_layer_sha256: str,
) -> list[str]:
    errors = validate_reviewer(payload, "candidate_labels")
    if payload.get("reference_layer_sha256") != reference_layer_sha256:
        errors.append("candidate_labels reference_layer_sha256 mismatch")
    labels = payload.get("labels", [])
    if len(labels) != inventory.get("candidate_count", 0):
        errors.append("label count mismatch")
    opportunity_ids = {o["opportunity_id"] for o in ground_truth.get("opportunities", [])}
    matched: set[str] = set()
    for idx, label in enumerate(labels):
        if "candidate_fingerprint" not in label:
            errors.append(f"label[{idx}] missing candidate_fingerprint")
        elif label["candidate_fingerprint"] != inventory["candidates"][idx]["fingerprint"]:
            errors.append(f"label[{idx}] fingerprint mismatch")
        if label.get("classification") not in {"selected_true", "selected_false"}:
            errors.append(f"label[{idx}] invalid classification")
        opportunity = label.get("matched_opportunity_id")
        if label.get("classification") == "selected_true":
            if opportunity not in opportunity_ids:
                errors.append(f"label[{idx}] missing/unknown opportunity id")
            elif opportunity in matched:
                errors.append(f"duplicate one-to-one opportunity match: {opportunity}")
            else:
                matched.add(opportunity)
            if label.get("replacement_supported") is not True:
                errors.append(f"label[{idx}] selected_true replacement unsupported")
            if label.get("boundary_supported") is not True:
                errors.append(f"label[{idx}] selected_true boundary unsupported")
        elif opportunity is not None:
            errors.append(f"label[{idx}] false candidate must not match opportunity")
        for field in ("replacement_supported", "boundary_supported"):
            if field not in label:
                errors.append(f"label[{idx}] missing {field}")
        if (
            label.get("classification") == "selected_false"
            and label.get("replacement_supported") is True
            and label.get("boundary_supported") is True
        ):
            errors.append(f"label[{idx}] selected_false cannot claim full support")
        rationale = label.get("label_rationale")
        if rationale is not None and (not isinstance(rationale, str) or not rationale.strip()):
            errors.append(f"label[{idx}] label_rationale must be nonempty when present")
        for forbidden in (
            "materialized_correctly_if_accepted",
            "unsafe_if_accepted",
            "unsafe_edit_rationale",
            "unsafe_definition_id",
        ):
            if forbidden in label:
                errors.append(f"label[{idx}] pre-review field forbidden: {forbidden}")
    for forbidden in ("unsafe_definition_id",):
        if forbidden in payload:
            errors.append(f"candidate_labels pre-review field forbidden: {forbidden}")
    return errors


def validate_review_inputs(
    *,
    ground_truth: dict[str, Any],
    labels: dict[str, Any],
    decisions: dict[str, Any],
    inventory: dict[str, Any],
    reference_layer_path: Path,
    input_srt_path: Path,
    terms_path: Path,
    asr_cues_path: Path,
    reference_tokens_path: Path,
) -> list[str]:
    reference_hash = sha256_file(reference_layer_path)
    errors = validate_ground_truth(
        ground_truth,
        reference_layer_sha256=reference_hash,
        input_srt_sha256=sha256_file(input_srt_path),
        terms_sha256=sha256_file(terms_path),
        reference_layer_path=reference_layer_path,
        input_srt_path=input_srt_path,
        asr_cues_path=asr_cues_path,
        reference_tokens_path=reference_tokens_path,
    )
    errors.extend(
        validate_candidate_labels(labels, inventory, ground_truth, reference_hash)
    )
    errors.extend(validate_decision_inputs(decisions, inventory))
    reviewer_ids = {
        payload.get("reviewer", {}).get("reviewer_id")
        for payload in (ground_truth, labels, decisions)
    }
    if len(reviewer_ids) != 1:
        errors.append("designated human reviewer identity differs across inputs")
    for payload_name, payload in (
        ("candidate_labels", labels),
        ("decision_inputs", decisions),
    ):
        if payload.get("inventory_sha256") != sha256_file(
            Path(inventory["_inventory_path"])
        ):
            errors.append(f"{payload_name} inventory_sha256 mismatch")
    return errors


def render_stdin_decisions(decisions: list[str]) -> str:
    return "\n".join(decisions) + ("\n" if decisions else "")


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description="Validate human-authored review inputs")
    sub = parser.add_subparsers(dest="command", required=True)
    gt = sub.add_parser("validate-ground-truth")
    gt.add_argument("--ground-truth", required=True)
    gt.add_argument("--reference-layer", required=True)
    gt.add_argument("--input-srt", required=True)
    gt.add_argument("--terms", required=True)
    gt.add_argument("--asr-cues", required=True)
    gt.add_argument("--reference-tokens", required=True)
    di = sub.add_parser("validate-decisions")
    di.add_argument("--decision-inputs", required=True)
    di.add_argument("--inventory", required=True)
    cl = sub.add_parser("validate-labels")
    cl.add_argument("--labels", required=True)
    cl.add_argument("--inventory", required=True)
    cl.add_argument("--ground-truth", required=True)
    render = sub.add_parser("render-stdin")
    render.add_argument("--decision-inputs", required=True)
    combined = sub.add_parser("validate-review-inputs")
    combined.add_argument("--ground-truth", required=True)
    combined.add_argument("--labels", required=True)
    combined.add_argument("--decision-inputs", required=True)
    combined.add_argument("--inventory", required=True)
    combined.add_argument("--reference-layer", required=True)
    combined.add_argument("--input-srt", required=True)
    combined.add_argument("--terms", required=True)
    combined.add_argument("--asr-cues", required=True)
    combined.add_argument("--reference-tokens", required=True)
    args = parser.parse_args()

    if args.command == "validate-ground-truth":
        payload = read_json(Path(args.ground_truth))
        errors = validate_ground_truth(
            payload,
            reference_layer_sha256=sha256_file(Path(args.reference_layer)),
            input_srt_sha256=sha256_file(Path(args.input_srt)),
            terms_sha256=sha256_file(Path(args.terms)),
            reference_layer_path=Path(args.reference_layer),
            input_srt_path=Path(args.input_srt),
            asr_cues_path=Path(args.asr_cues),
            reference_tokens_path=Path(args.reference_tokens),
        )
    elif args.command == "validate-decisions":
        inventory = read_json(Path(args.inventory))
        errors = validate_decision_inputs(read_json(Path(args.decision_inputs)), inventory)
    elif args.command == "validate-labels":
        errors = validate_candidate_labels(
            read_json(Path(args.labels)),
            read_json(Path(args.inventory)),
            read_json(Path(args.ground_truth)),
            sha256_file(Path(args.reference_layer)),
        )
    elif args.command == "render-stdin":
        decisions = read_json(Path(args.decision_inputs))["decisions"]
        sys.stdout.write(render_stdin_decisions(decisions))
        return 0
    else:
        inventory_path = Path(args.inventory)
        inventory = read_json(inventory_path)
        inventory["_inventory_path"] = str(inventory_path)
        errors = validate_review_inputs(
            ground_truth=read_json(Path(args.ground_truth)),
            labels=read_json(Path(args.labels)),
            decisions=read_json(Path(args.decision_inputs)),
            inventory=inventory,
            reference_layer_path=Path(args.reference_layer),
            input_srt_path=Path(args.input_srt),
            terms_path=Path(args.terms),
            asr_cues_path=Path(args.asr_cues),
            reference_tokens_path=Path(args.reference_tokens),
        )

    status = "pass" if not errors else "fail"
    print(json.dumps({"status": status, "errors": errors}, indent=2))
    return 0 if status == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
