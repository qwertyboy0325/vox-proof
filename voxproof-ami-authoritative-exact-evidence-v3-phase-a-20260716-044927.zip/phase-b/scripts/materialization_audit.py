#!/usr/bin/env python3
"""Post-authoritative-review deterministic materialization audit."""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from ami_common import parse_srt_text  # noqa: E402
from common import read_json, sha256_file, utc_now, write_json  # noqa: E402
from study_config import UNSAFE_DEFINITION_ID  # noqa: E402

ACCEPT_RE = re.compile(r"^a (\d+)$")


def find_matched_occurrences(text: str, matched: str) -> list[tuple[int, int]]:
    if not matched:
        return []
    positions: list[tuple[int, int]] = []
    start = 0
    while True:
        index = text.find(matched, start)
        if index < 0:
            break
        positions.append((index, index + len(matched)))
        start = index + 1
    return positions


def single_edit_regions(before: str, after: str) -> list[tuple[int, int, int, int]]:
    """Return contiguous edit regions as (before_start, before_end, after_start, after_end)."""
    if before == after:
        return []
    prefix = 0
    while prefix < len(before) and prefix < len(after) and before[prefix] == after[prefix]:
        prefix += 1
    suffix = 0
    while (
        suffix < len(before) - prefix
        and suffix < len(after) - prefix
        and before[len(before) - 1 - suffix] == after[len(after) - 1 - suffix]
    ):
        suffix += 1
    before_start = prefix
    before_end = len(before) - suffix
    after_start = prefix
    after_end = len(after) - suffix
    if before_start > before_end or after_start > after_end:
        return []
    return [(before_start, before_end, after_start, after_end)]


def expected_cue_after_replacement(
    cue_text: str, matched: str, replacement: str, start: int, end: int
) -> str:
    return cue_text[:start] + replacement + cue_text[end:]


def verify_replacement_at_span(
    input_cue: str, reviewed_cue: str, matched: str, replacement: str
) -> dict[str, Any]:
    occurrences = find_matched_occurrences(input_cue, matched)
    matching_spans: list[dict[str, Any]] = []
    for start, end in occurrences:
        expected = expected_cue_after_replacement(input_cue, matched, replacement, start, end)
        if reviewed_cue == expected:
            matching_spans.append(
                {
                    "start_byte": start,
                    "end_byte": end,
                    "expected_cue_text": expected,
                }
            )
    if len(matching_spans) == 1:
        span = matching_spans[0]
        return {
            "pass": True,
            "matched_span": {"start_byte": span["start_byte"], "end_byte": span["end_byte"]},
            "actual_reviewed_span_text": reviewed_cue[span["start_byte"] : span["start_byte"] + len(replacement)],
            "detail": "reviewed cue equals input cue with one matched span replacement",
        }
    if not matching_spans:
        return {
            "pass": False,
            "matched_span": None,
            "actual_reviewed_span_text": reviewed_cue,
            "detail": "reviewed cue does not match any matched-text replacement hypothesis",
        }
    return {
        "pass": False,
        "matched_span": None,
        "actual_reviewed_span_text": reviewed_cue,
        "detail": "ambiguous matched-text replacement spans",
    }


def verify_boundary(input_cue: str, reviewed_cue: str) -> dict[str, Any]:
    regions = single_edit_regions(input_cue, reviewed_cue)
    if len(regions) == 1:
        return {
            "pass": True,
            "edit_region_count": 1,
            "detail": "exactly one contiguous cue edit region",
        }
    return {
        "pass": False,
        "edit_region_count": len(regions),
        "detail": "cue edit is not a single contiguous region",
    }


def collect_unrelated_cue_edits(
    input_segments: list[dict[str, Any]],
    reviewed_segments: list[dict[str, Any]],
    accepted_segment_positions: set[int],
) -> list[dict[str, Any]]:
    unrelated: list[dict[str, Any]] = []
    for position, (source, reviewed) in enumerate(zip(input_segments, reviewed_segments)):
        if source["text"] == reviewed["text"]:
            continue
        if position not in accepted_segment_positions:
            unrelated.append(
                {
                    "segment_position": position,
                    "cue_index": position + 1,
                    "input_cue_text": source["text"],
                    "reviewed_cue_text": reviewed["text"],
                }
            )
    return unrelated


def audit_materialization(
    *,
    input_srt: Path,
    reviewed_srt: Path,
    inventory: dict[str, Any],
    labels_payload: dict[str, Any],
    decisions_payload: dict[str, Any],
    ground_truth: dict[str, Any],
    binding: dict[str, Any],
    input_srt_sha256: str,
    terms_sha256: str,
    reference_layer_sha256: str,
) -> dict[str, Any]:
    input_segments = parse_srt_text(input_srt.read_text(encoding="utf-8"))
    reviewed_segments = parse_srt_text(reviewed_srt.read_text(encoding="utf-8"))
    if len(input_segments) != len(reviewed_segments):
        raise ValueError("input/reviewed SRT segment count mismatch")

    labels = labels_payload["labels"]
    decisions = decisions_payload["decisions"]
    candidates = inventory["candidates"]
    if len(labels) != len(candidates) or len(decisions) != len(candidates):
        raise ValueError("inventory/labels/decisions length mismatch")

    opportunity_by_id = {
        row["opportunity_id"]: row for row in ground_truth.get("opportunities", [])
    }
    records: list[dict[str, Any]] = []
    accepted_segment_positions: set[int] = set()

    for index, (candidate, label, decision) in enumerate(
        zip(candidates, labels, decisions)
    ):
        base = {
            "candidate_index": index,
            "candidate_fingerprint": candidate["fingerprint"],
            "decision": decision,
            "classification": label.get("classification"),
            "pre_review_replacement_supported": label.get("replacement_supported"),
            "pre_review_boundary_supported": label.get("boundary_supported"),
            "matched_opportunity_id": label.get("matched_opportunity_id"),
        }
        accept = ACCEPT_RE.match(decision)
        if not accept:
            records.append(
                {
                    **base,
                    "status": "non_materialized",
                    "accepted_alternative_index": None,
                    "expected_replacement": None,
                    "actual_reviewed_cue_text": None,
                    "actual_reviewed_span_text": None,
                    "actual_boundary_verification": None,
                    "actual_replacement_verification": None,
                    "materialized_correctly": False,
                    "unsafe_materialized_edit": False,
                    "rationale": "reject/defer/manual decisions do not materialize edits",
                }
            )
            continue

        alt_index = int(accept.group(1))
        alternatives = candidate.get("alternatives", [])
        if alt_index >= len(alternatives):
            raise ValueError(f"accepted alternative out of range at candidate {index}")
        expected_replacement = alternatives[alt_index]["replacement_text"]
        segment_position = int(candidate["source_segment_position"])
        cue_index = int(candidate["cue_index"])
        if segment_position != cue_index - 1:
            raise ValueError(
                f"candidate {index} cue_index/source_segment_position inconsistent"
            )
        if segment_position >= len(input_segments):
            raise ValueError(f"candidate {index} segment position out of range")
        accepted_segment_positions.add(segment_position)

        input_cue = input_segments[segment_position]["text"]
        reviewed_cue = reviewed_segments[segment_position]["text"]
        matched_text = candidate["matched_text"]
        replacement_check = verify_replacement_at_span(
            input_cue, reviewed_cue, matched_text, expected_replacement
        )
        boundary_check = verify_boundary(input_cue, reviewed_cue)
        opportunity = (
            opportunity_by_id.get(label["matched_opportunity_id"])
            if label.get("matched_opportunity_id")
            else None
        )
        opportunity_term_match = (
            opportunity is not None
            and opportunity.get("canonical_term") == expected_replacement
        )
        materialized_correctly = (
            label.get("classification") == "selected_true"
            and label.get("replacement_supported") is True
            and label.get("boundary_supported") is True
            and replacement_check["pass"]
            and boundary_check["pass"]
            and opportunity_term_match
            and label.get("matched_opportunity_id") is not None
        )
        unsafe_materialized_edit = (
            label.get("classification") == "selected_false"
            or label.get("replacement_supported") is not True
            or label.get("boundary_supported") is not True
            or not replacement_check["pass"]
            or not boundary_check["pass"]
            or not opportunity_term_match
        )
        records.append(
            {
                **base,
                "status": "materialized",
                "accepted_alternative_index": alt_index,
                "expected_replacement": expected_replacement,
                "actual_reviewed_cue_text": reviewed_cue,
                "actual_reviewed_span_text": replacement_check.get(
                    "actual_reviewed_span_text"
                ),
                "actual_boundary_verification": boundary_check,
                "actual_replacement_verification": replacement_check,
                "materialized_correctly": materialized_correctly,
                "unsafe_materialized_edit": unsafe_materialized_edit,
                "rationale": (
                    "deterministic post-review materialization verification"
                    if materialized_correctly
                    else "accepted edit failed deterministic materialization checks"
                ),
                "human_attestation": None,
            }
        )

    unrelated = collect_unrelated_cue_edits(
        input_segments, reviewed_segments, accepted_segment_positions
    )
    if unrelated:
        for record in records:
            if record["status"] == "materialized":
                record["materialized_correctly"] = False
                record["unsafe_materialized_edit"] = True
                record["rationale"] = (
                    "unrelated cue edits detected outside accepted candidate targets"
                )

    return {
        "schema_revision": "voxproof-ami-materialization-audit-v1",
        "unsafe_definition_id": UNSAFE_DEFINITION_ID,
        "recorded_at_utc": utc_now(),
        "bindings": {
            "reviewed_output_sha256": sha256_file(reviewed_srt),
            "decision_log_sha256": binding["artifact_hashes"]["decision_log_sha256"],
            "authoritative_review_binding_sha256": sha256_file(
                Path(str(binding["_binding_path"]))
            ),
            "candidate_inventory_sha256": sha256_file(Path(str(binding["_inventory_path"]))),
            "ground_truth_sha256": sha256_file(Path(str(binding["_ground_truth_path"]))),
            "candidate_labels_sha256": sha256_file(Path(str(binding["_labels_path"]))),
            "decision_inputs_sha256": sha256_file(Path(str(binding["_decisions_path"]))),
            "input_srt_sha256": input_srt_sha256,
            "terms_sha256": terms_sha256,
            "reference_layer_sha256": reference_layer_sha256,
        },
        "records": records,
        "unrelated_cue_edits": unrelated,
        "accepted_candidate_count": sum(
            1 for decision in decisions if decision.startswith("a ")
        ),
        "materialized_record_count": sum(
            1 for record in records if record["status"] == "materialized"
        ),
        "correctly_materialized_opportunity_ids": sorted(
            {
                record["matched_opportunity_id"]
                for record in records
                if record["status"] == "materialized"
                and record["materialized_correctly"]
                and record.get("matched_opportunity_id")
            }
        ),
        "unsafe_materialized_accept_count": sum(
            1
            for record in records
            if record["status"] == "materialized"
            and record["unsafe_materialized_edit"]
        ),
    }


def run_materialization_audit(
    *,
    input_srt: Path,
    reviewed_srt: Path,
    decision_log: Path,
    binding_path: Path,
    inventory_path: Path,
    ground_truth_path: Path,
    labels_path: Path,
    decisions_path: Path,
    reference_layer_path: Path,
    terms_path: Path,
    output_path: Path,
) -> dict[str, Any]:
    binding = read_json(binding_path)
    binding["_binding_path"] = str(binding_path)
    binding["_inventory_path"] = str(inventory_path)
    binding["_ground_truth_path"] = str(ground_truth_path)
    binding["_labels_path"] = str(labels_path)
    binding["_decisions_path"] = str(decisions_path)
    if sha256_file(reviewed_srt) != binding["artifact_hashes"]["reviewed_output_sha256"]:
        raise RuntimeError("reviewed output hash mismatch with authoritative binding")
    if sha256_file(decision_log) != binding["artifact_hashes"]["decision_log_sha256"]:
        raise RuntimeError("decision log hash mismatch with authoritative binding")

    payload = audit_materialization(
        input_srt=input_srt,
        reviewed_srt=reviewed_srt,
        inventory=read_json(inventory_path),
        labels_payload=read_json(labels_path),
        decisions_payload=read_json(decisions_path),
        ground_truth=read_json(ground_truth_path),
        binding=binding,
        input_srt_sha256=sha256_file(input_srt),
        terms_sha256=sha256_file(terms_path),
        reference_layer_sha256=sha256_file(reference_layer_path),
    )
    write_json(output_path, payload)
    return payload


def main() -> int:
    import argparse
    import json

    parser = argparse.ArgumentParser(description="Audit post-review materialization")
    parser.add_argument("--input-srt", required=True)
    parser.add_argument("--reviewed-srt", required=True)
    parser.add_argument("--decision-log", required=True)
    parser.add_argument("--binding", required=True)
    parser.add_argument("--inventory", required=True)
    parser.add_argument("--ground-truth", required=True)
    parser.add_argument("--labels", required=True)
    parser.add_argument("--decision-inputs", required=True)
    parser.add_argument("--reference-layer", required=True)
    parser.add_argument("--terms", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    payload = run_materialization_audit(
        input_srt=Path(args.input_srt),
        reviewed_srt=Path(args.reviewed_srt),
        decision_log=Path(args.decision_log),
        binding_path=Path(args.binding),
        inventory_path=Path(args.inventory),
        ground_truth_path=Path(args.ground_truth),
        labels_path=Path(args.labels),
        decisions_path=Path(args.decision_inputs),
        reference_layer_path=Path(args.reference_layer),
        terms_path=Path(args.terms),
        output_path=Path(args.output),
    )
    print(
        json.dumps(
            {
                "status": "ok",
                "materialized_record_count": payload["materialized_record_count"],
                "unsafe_materialized_accept_count": payload[
                    "unsafe_materialized_accept_count"
                ],
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
