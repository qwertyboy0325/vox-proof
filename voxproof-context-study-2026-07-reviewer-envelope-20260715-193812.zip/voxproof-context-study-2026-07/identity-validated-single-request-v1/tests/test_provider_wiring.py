from __future__ import annotations

import json
import os
import shlex
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HARNESS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HARNESS))

from single_request_protocol import (  # noqa: E402
    PROTOCOL_REVISION,
    RANKING_SCHEMA_REVISION,
    request_identity,
    wrapper_request,
)

REQUEST = {
    "schema_revision": RANKING_SCHEMA_REVISION,
    "session_description": "Sports commentary",
    "nearby_context": "The team played tennis.",
    "source_surface": "ten days",
    "candidates": [
        {
            "candidate_id": "experimental-1",
            "canonical_term": "tennis",
            "producer": "LatinNormalizedDistance",
            "source_representation": "ten days",
            "target_representation": "tennis",
            "distance": 1,
            "ratio_numerator": 8,
            "ratio_denominator": 9,
        }
    ],
}


def valid_wrapper_response(identity: str, *, wrong_identity: bool = False) -> dict:
    echoed = "wrong-identity" if wrong_identity else identity
    return {
        "protocol_revision": PROTOCOL_REVISION,
        "request_identity": echoed,
        "response": {
            "schema_revision": RANKING_SCHEMA_REVISION,
            "selected_candidate_id": "experimental-1",
            "assessment": "strong",
            "reason_codes": ["nearby_context_term_overlap"],
            "requires_review": True,
            "display_explanation": None,
        },
    }


class ProviderWiringTests(unittest.TestCase):
    def fake_codex_script(self, response: dict, *, stderr_message: str = "") -> str:
        response_json = json.dumps(response, separators=(",", ":"))
        return (
            "import json,sys,argparse; "
            "parser=argparse.ArgumentParser(); "
            "parser.add_argument('exec'); "
            "parser.add_argument('--output-last-message'); "
            "parser.add_argument('prompt'); "
            "args, _ = parser.parse_known_args(); "
            f"response=json.loads({json.dumps(response_json)}); "
            "open(args.output_last_message, 'wb').write(json.dumps(response,separators=(',',':')).encode()); "
            f"sys.stderr.write({json.dumps(stderr_message)}); "
            "sys.exit(0)"
        )

    def run_provider(
        self,
        *,
        codex_script: str,
        wrapper: dict,
        timeout_seconds: str = "5",
    ) -> subprocess.CompletedProcess:
        env = {
            **os.environ,
            "VOXPROOF_CODEX_PATH": f"{sys.executable} -c {shlex.quote(codex_script)}",
            "VOXPROOF_PROVIDER_TIMEOUT_SECONDS": timeout_seconds,
            "VOXPROOF_STUDY_ROOT": str(HARNESS.parent),
        }
        return subprocess.run(
            [sys.executable, str(HARNESS / "codex_single_request_provider.py")],
            input=json.dumps(wrapper, separators=(",", ":")).encode("utf-8"),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            check=False,
        )

    def test_provider_reads_one_wrapper_request_on_stdin(self) -> None:
        identity = request_identity(REQUEST)
        wrapper = wrapper_request(REQUEST)
        with tempfile.TemporaryDirectory() as temporary:
            stdin_capture = Path(temporary) / "stdin-check.json"
            script = (
                "import json,sys,argparse; "
                f"open({json.dumps(str(stdin_capture))}, 'w').write(sys.stdin.read()); "
                "parser=argparse.ArgumentParser(); "
                "parser.add_argument('exec'); "
                "parser.add_argument('--output-last-message'); "
                "parser.add_argument('prompt'); "
                "args, _ = parser.parse_known_args(); "
                f"response=json.loads({json.dumps(json.dumps(valid_wrapper_response(identity), separators=(',', ':')))}); "
                "open(args.output_last_message, 'wb').write(json.dumps(response,separators=(',',':')).encode())"
            )
            completed = self.run_provider(codex_script=script, wrapper=wrapper)
            self.assertEqual(0, completed.returncode, completed.stderr.decode())
            self.assertEqual(wrapper, json.loads(stdin_capture.read_text()))

    def test_provider_stdout_passes_model_bytes_unchanged(self) -> None:
        identity = request_identity(REQUEST)
        response = valid_wrapper_response(identity)
        expected = json.dumps(response, separators=(",", ":")).encode("utf-8")
        completed = self.run_provider(
            codex_script=self.fake_codex_script(response),
            wrapper=wrapper_request(REQUEST),
        )
        self.assertEqual(0, completed.returncode, completed.stderr.decode())
        self.assertEqual(expected, completed.stdout)

    def test_provider_stderr_does_not_contaminate_stdout(self) -> None:
        identity = request_identity(REQUEST)
        response = valid_wrapper_response(identity)
        completed = self.run_provider(
            codex_script=self.fake_codex_script(response, stderr_message="catalog refresh note"),
            wrapper=wrapper_request(REQUEST),
        )
        self.assertEqual(0, completed.returncode)
        self.assertEqual(json.dumps(response, separators=(",", ":")).encode("utf-8"), completed.stdout)
        self.assertIn(b"catalog refresh note", completed.stderr)

    def test_identity_mismatch_suppressed_by_harness(self) -> None:
        identity = request_identity(REQUEST)
        response = valid_wrapper_response(identity, wrong_identity=True)
        with tempfile.TemporaryDirectory() as temporary:
            completed = subprocess.run(
                [
                    sys.executable,
                    str(HARNESS / "identity_validated_adapter.py"),
                ],
                input=json.dumps(REQUEST).encode("utf-8"),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env={
                    **os.environ,
                    "VOX_PROOF_SINGLE_REQUEST_COMMAND": (
                        f"{shlex.quote(sys.executable)} {shlex.quote(str(HARNESS / 'codex_single_request_provider.py'))}"
                    ),
                    "VOX_PROOF_SINGLE_REQUEST_ARTIFACT_DIR": temporary,
                    "VOXPROOF_CODEX_PATH": f"{sys.executable} -c {shlex.quote(self.fake_codex_script(response))}",
                },
                check=False,
            )
            self.assertNotEqual(0, completed.returncode)
            self.assertEqual(b"", completed.stdout)
            self.assertIn(b"identity_mismatch", completed.stderr)


if __name__ == "__main__":
    unittest.main()
